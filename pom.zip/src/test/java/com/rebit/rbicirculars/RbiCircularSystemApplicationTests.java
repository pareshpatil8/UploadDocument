package com.rebit.rbicirculars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RbiCircularSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
