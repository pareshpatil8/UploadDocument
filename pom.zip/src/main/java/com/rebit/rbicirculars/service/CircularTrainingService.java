package com.rebit.rbicirculars.service;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.repository.CircularRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class CircularTrainingService {

    private final CircularRepository circularRepository;
    private final CircularChatbotService chatbotService;
    private final AtomicBoolean isTraining = new AtomicBoolean(false);
    private LocalDate lastTrainingDate = LocalDate.now().minusDays(7);

    @Autowired
    public CircularTrainingService(CircularRepository circularRepository,
                                   CircularChatbotService chatbotService) {
        this.circularRepository = circularRepository;
        this.chatbotService = chatbotService;
    }

    /**
     * Train the model with a new circular that's been added
     */
    public void trainWithNewCircular(Circular circular) {
        // Add the new circular to the index
        chatbotService.addCircularToIndex(circular);
    }

    /**
     * Manually trigger a retraining of the model with all circulars
     */
    public boolean retrainModel() {
        // If already training, don't start another training process
        if (isTraining.getAndSet(true)) {
            return false;
        }

        try {
            chatbotService.reindexAllCirculars();
            lastTrainingDate = LocalDate.now();
            return true;
        } finally {
            isTraining.set(false);
        }
    }

    /**
     * Scheduled task to check for new circulars and update the model
     * Runs every day at midnight
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void scheduledRetraining() {
        // If already training, skip this scheduled run
        if (isTraining.getAndSet(true)) {
            return;
        }

        try {
            List<Circular> newCirculars = circularRepository.findByPublishDateBetween(
                    lastTrainingDate, LocalDate.now());

            if (!newCirculars.isEmpty()) {
                chatbotService.reindexAllCirculars();
                lastTrainingDate = LocalDate.now();
            }
        } finally {
            isTraining.set(false);
        }
    }

    /**
     * Get training status information
     */
    public TrainingStatus getTrainingStatus() {
        TrainingStatus status = new TrainingStatus();
        status.setTraining(isTraining.get());
        status.setLastTrainingDate(lastTrainingDate);
        return status;
    }

    /**
     * Inner class to represent training status
     */
    public static class TrainingStatus {
        private boolean isTraining;
        private LocalDate lastTrainingDate;

        public boolean isTraining() {
            return isTraining;
        }

        public void setTraining(boolean training) {
            isTraining = training;
        }

        public LocalDate getLastTrainingDate() {
            return lastTrainingDate;
        }

        public void setLastTrainingDate(LocalDate lastTrainingDate) {
            this.lastTrainingDate = lastTrainingDate;
        }
    }
}