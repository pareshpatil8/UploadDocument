package com.rebit.rbicirculars.service;

import com.rebit.rbicirculars.model.ChatMessage;
import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.repository.ChatMessageRepository;
import com.rebit.rbicirculars.repository.CircularRepository;
import org.apache.lucene.queryparser.classic.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Service
public class CircularChatbotService {

    private final CircularRepository circularRepository;
    private final CircularIndexService indexService;
    private final ChatMessageRepository chatMessageRepository;

    @Value("${chatbot.max.results:5}")
    private int maxResults;

    @Autowired
    public CircularChatbotService(CircularRepository circularRepository,
                                  CircularIndexService indexService,
                                  ChatMessageRepository chatMessageRepository) {
        this.circularRepository = circularRepository;
        this.indexService = indexService;
        this.chatMessageRepository = chatMessageRepository;
    }

    @PostConstruct
    public void initializeIndex() {
        try {
            List<Circular> allCirculars = circularRepository.findAll();
            indexService.reindexAllCirculars(allCirculars);
        } catch (IOException e) {
            // Log error but don't crash the application
            System.err.println("Failed to initialize circular index: " + e.getMessage());
        }
    }

    public void addCircularToIndex(Circular circular) {

        indexService.indexCircular(circular);

    }

    public void reindexAllCirculars() {
        try {
            List<Circular> allCirculars = circularRepository.findAll();
            indexService.reindexAllCirculars(allCirculars);
        } catch (IOException e) {
            System.err.println("Failed to reindex circulars: " + e.getMessage());
        }
    }

    public Map<String, Object> answerQuestion(String question, String sessionId) {
        // Generate session ID if not provided
        if (sessionId == null || sessionId.trim().isEmpty()) {
            sessionId = UUID.randomUUID().toString();
        }

        // Store user question in chat history
        ChatMessage userMessage = new ChatMessage();
        userMessage.setSessionId(sessionId);
        userMessage.setMessage(question);
        userMessage.setUser(true);
        chatMessageRepository.save(userMessage);

        try {
            Map<String, Object> response = indexService.getRelevantPassage(question, maxResults);

            if (response.isEmpty()) {
                String noAnswerText = "I couldn't find information related to your question in the available circulars.";

                // Store bot response in chat history
                ChatMessage botMessage = new ChatMessage();
                botMessage.setSessionId(sessionId);
                botMessage.setMessage(noAnswerText);
                botMessage.setUser(false);
                chatMessageRepository.save(botMessage);

                Map<String, Object> noAnswer = new HashMap<>();
                noAnswer.put("answer", noAnswerText);
                noAnswer.put("confidence", 0.0f);
                noAnswer.put("sessionId", sessionId);
                return noAnswer;
            }

            // Enhance the answer with additional circular information
            String circularId = (String) response.get("circularId");
            String circularNumber = (String) response.get("circularNumber");
            String answerText = (String) response.get("answer");

            if (circularId != null) {
                Optional<Circular> circular = circularRepository.findById(Long.valueOf(circularId));
                if (circular.isPresent()) {
                    response.put("circular", circular.get());

                    // Add reference to the answer text
                    answerText += "\n\nThis information is from circular: " + circularNumber;
                    response.put("answer", answerText);

                    // Store bot response in chat history
                    ChatMessage botMessage = new ChatMessage();
                    botMessage.setSessionId(sessionId);
                    botMessage.setMessage(answerText);
                    botMessage.setUser(false);
                    botMessage.setCircularId(Long.valueOf(circularId));
                    botMessage.setCircularReference(circularNumber);
                    chatMessageRepository.save(botMessage);
                }
            }

            response.put("sessionId", sessionId);
            return response;
        } catch (IOException | ParseException e) {
            String errorText = "Sorry, I encountered an error while processing your question.";

            // Store bot error response in chat history
            ChatMessage botMessage = new ChatMessage();
            botMessage.setSessionId(sessionId);
            botMessage.setMessage(errorText);
            botMessage.setUser(false);
            chatMessageRepository.save(botMessage);

            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("answer", errorText);
            errorResponse.put("error", e.getMessage());
            errorResponse.put("sessionId", sessionId);
            return errorResponse;
        }
    }

    public Map<String, Object> answerQuestion(String question) {
        return answerQuestion(question, null);
    }

    public List<ChatMessage> getChatHistory(String sessionId) {
        return chatMessageRepository.findBySessionIdOrderByTimestampAsc(sessionId);
    }

    public void clearChatHistory(String sessionId) {
        chatMessageRepository.deleteBySessionId(sessionId);
    }
}