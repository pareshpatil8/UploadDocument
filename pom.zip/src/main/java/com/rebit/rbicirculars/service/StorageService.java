package com.rebit.rbicirculars.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class StorageService {

    @Value("${storage.location:uploads}")
    private String storageLocation;

    public String saveFile(MultipartFile file) throws IOException {
        Path rootLocation = Paths.get(storageLocation);

        // Create directories if they don't exist
        if (!Files.exists(rootLocation)) {
            Files.createDirectories(rootLocation);
        }

        // Generate unique filename to prevent collisions
        String originalFilename = file.getOriginalFilename();
        String extension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            extension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }

        String filename = UUID.randomUUID().toString() + extension;
        Path destinationPath = rootLocation.resolve(filename);

        // Copy file to the target location
        Files.copy(file.getInputStream(), destinationPath, StandardCopyOption.REPLACE_EXISTING);

        return filename;
    }

    public Path getFilePath(String filename) {
        return Paths.get(storageLocation).resolve(filename);
    }

    public byte[] loadFileAsBytes(String filename) throws IOException {
        Path filePath = getFilePath(filename);
        return Files.readAllBytes(filePath);
    }
}