package com.rebit.rbicirculars.service;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.repository.CircularRepository;
import com.rebit.rbicirculars.service.CircularTrainingService;
import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.model.enums.Department;
import com.rebit.rbicirculars.model.enums.ReferenceNumberPattern;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class CircularService {

    private final CircularRepository circularRepository;
    private final StorageService storageService;
    private final CircularTrainingService trainingService;
    private final NlpService nlpService;
    private final CrossReferenceService crossReferenceService;

    @Autowired
    public CircularService(CircularRepository circularRepository, StorageService storageService,
                           CircularTrainingService trainingService, NlpService nlpService, CrossReferenceService crossReferenceService) {
        this.circularRepository = circularRepository;
        this.storageService = storageService;
        this.trainingService = trainingService;
        this.nlpService = nlpService;
        this.crossReferenceService = crossReferenceService;
    }

    public Circular processAndSaveCircular(MultipartFile file) throws IOException {
        // Save the file to storage
        String filePath = storageService.saveFile(file);

        // Extract information from PDF
        Circular circular = extractInformationFromPDF(file);
        circular.setFilePath(filePath);

        // Save to database
        Circular savedCircular = circularRepository.save(circular);

        // Train the model with the new circular
        trainingService.trainWithNewCircular(savedCircular);

        return savedCircular;
    }

    private Circular extractInformationFromPDF(MultipartFile file) throws IOException {
        PDDocument document = Loader.loadPDF(file.getBytes());
        PDFTextStripper stripper = new PDFTextStripper();
        String rawText = stripper.getText(document);
        document.close();

        // Filter out non-English characters
        // This pattern keeps English letters, numbers, common punctuation, and whitespace
        String text = rawText.replaceAll("[^\\p{ASCII}]", "");

        // Alternative approach with more control (keeping only specific characters)
        // String text = rawText.replaceAll("[^a-zA-Z0-9\\s.,;:!?()\\[\\]{}'\"-]", "");

        // Remove multiple spaces that might have been created after filtering
        text = text.replaceAll("\\s+", " ").trim();

        Circular circular = new Circular();

        // Extract circular number using regex pattern
        Pattern circularNumberPattern = Pattern.compile("RBI/\\d{4}-\\d{2}/\\d+");
        Matcher circularNumberMatcher = circularNumberPattern.matcher(text);
        if (circularNumberMatcher.find()) {
            circular.setCircularNumber(circularNumberMatcher.group());
        }

        // Extract reference number using patterns from ENUM
        String referenceNumber = null;
        for (ReferenceNumberPattern pattern : ReferenceNumberPattern.values()) {
            Pattern refNumberPattern = Pattern.compile(pattern.getPattern());
            Matcher refNumberMatcher = refNumberPattern.matcher(text);
            if (refNumberMatcher.find()) {
                referenceNumber = refNumberMatcher.group();
                break;
            }
        }
        if (referenceNumber == null) {
            referenceNumber = "RBICIRCULAR" + Math.random();
        }

        circular.setReferenceNumber(referenceNumber);

        // Extract date (assuming format like "April 1, 2025")
        Pattern datePattern = Pattern.compile("([A-Za-z]+ \\d+, \\d{4})");
        Matcher dateMatcher = datePattern.matcher(text);
        if (dateMatcher.find()) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
                LocalDate date = LocalDate.parse(dateMatcher.group(), formatter);
                circular.setPublishDate(date);
            } catch (Exception e) {
                // Default to current date if parsing fails
                circular.setPublishDate(LocalDate.now());
            }
        } else {
            circular.setPublishDate(LocalDate.now());
        }

        // Extract department using ENUM
        Department department = Department.findByText(text);
        if (department != null) {
            circular.setIssuingDepartment(department.getDepartmentName());
        } else {
            circular.setIssuingDepartment("Reserve Bank of India");
        }

        // Extract intended recipients
        String intendedRecipients = "General"; // Default value

        // Look for "All Agency Banks" exact match first
        if (text.contains("All Agency Banks")) {
            intendedRecipients = "All Agency Banks";
        } else {
            // Split text into lines and check first 20 lines
            String[] lines = text.split("\\n");
            int linesToCheck = Math.min(20, lines.length);

            for (int i = 0; i < linesToCheck; i++) {
                String line = lines[i].trim();
                // Check if the line contains both "All" and "Banks"
                if (line.contains("All") && line.contains("Banks")) {
                    intendedRecipients = line;
                    break;
                }
            }

            // If still not found, try the salutation pattern as a fallback
            if (intendedRecipients.equals("General")) {
                Pattern recipientPattern = Pattern.compile("(Dear|To)[:\\s]+([^\\n\\r]+)");
                Matcher recipientMatcher = recipientPattern.matcher(text);
                if (recipientMatcher.find()) {
                    String potential = recipientMatcher.group(2).trim();
                    // Only use this if it looks like a meaningful recipient
                    if (potential.length() > 3 && !potential.equalsIgnoreCase("Sir") &&
                            !potential.equalsIgnoreCase("Madam") && !potential.equalsIgnoreCase("Sir/Madam")) {
                        intendedRecipients = potential;
                    }
                }
            }
        }

        // Limit the length to avoid database issues
        if (intendedRecipients.length() > 190) {
            intendedRecipients = intendedRecipients.substring(0, 190) + "...";
        }

        circular.setIntendedRecipients(intendedRecipients);

        // Improved subject extraction
        // First try to find "Master Circular on..." pattern
        Pattern subjectPattern = Pattern.compile("Master Circular on[^\\n\\r]+");
        Matcher subjectMatcher = subjectPattern.matcher(text);

        // Variable to store the subject
        String subjectText = null;

        // If "Master Circular on..." pattern is found
        if (subjectMatcher.find()) {
            subjectText = subjectMatcher.group();
        } else {
            // Try to find "Subject:" or similar patterns
            subjectPattern = Pattern.compile("(?:Subject|RE|Regarding)[:\\s]+([^\\n\\r]+)");
            subjectMatcher = Pattern.compile(subjectPattern.pattern()).matcher(text);

            if (subjectMatcher.find()) {
                subjectText = subjectMatcher.group(1).trim();
            } else {
                // Fallback: get the first significant line after typical header content
                String[] lines = text.split("\\n");
                boolean headerPassed = false;

                for (String line : lines) {
                    line = line.trim();
                    // Check if we've passed header content
                    if (!headerPassed && (line.contains("Dear") || line.contains("Madam") || line.contains("Sir"))) {
                        headerPassed = true;
                        continue;
                    }

                    // Once past header, get first significant line
                    if (headerPassed && line.length() > 15) {
                        subjectText = line;
                        break;
                    }
                }

                // Last resort
                if (subjectText == null) {
                    for (String line : lines) {
                        if (line.trim().length() > 15 && !line.contains("RBI") && !line.contains("RESERVE BANK OF INDIA")) {
                            subjectText = line.trim();
                            break;
                        }
                    }
                }
            }
        }

        // Apply length limitation to the subject
        if (subjectText != null) {
            // Limit subject to 1990 characters (leaving room for ellipsis)
            if (subjectText.length() > 1990) {
                subjectText = subjectText.substring(0, 1990) + "...";
            }
            circular.setSubject(subjectText);
        } else {
            // If no subject was found, provide a default
            circular.setSubject("RBI Circular " + circular.getCircularNumber());
        }

        // Generate summary using NLP
        String summary = nlpService.generateSummary(text, 3); // 3 sentence summary
        circular.setSummary(summary);

        // Extract named entities using NLP
        Set<String> namedEntities = nlpService.extractNamedEntities(text);
        circular.setNamedEntities(namedEntities);

        // Extract action items with improved detection logic
        List<String> actionItems = new ArrayList<>();

        // First, look for sections that likely contain action items
        String[] sections = {"action", "required", "instruction", "implement", "compliance", "guideline", "direction"};
        String[] lines = text.split("\\n");
        int actionSectionStart = -1;

        // Try to find the beginning of an action section
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].toLowerCase().trim();
            for (String section : sections) {
                if (line.contains(section) &&
                        (line.endsWith(":") || line.endsWith("s:") || line.endsWith("s") ||
                                line.length() < 50)) { // Likely a section header
                    actionSectionStart = i + 1; // Start from next line
                    break;
                }
            }
            if (actionSectionStart >= 0) break;
        }

        // If we found an action section
        if (actionSectionStart >= 0) {
            // Look for numbered items in that section
            Pattern actionPattern = Pattern.compile("(?:\\d+\\.|[a-z]\\)|[ivx]+\\.)\\s+([^\\n\\r\\.]+)");
            int itemCount = 0;

            // Check up to 10 lines after the section header or until we hit another section
            int maxLinesToCheck = Math.min(actionSectionStart + 10, lines.length);
            for (int i = actionSectionStart; i < maxLinesToCheck; i++) {
                Matcher matcher = actionPattern.matcher(lines[i]);
                if (matcher.find()) {
                    String actionItem = matcher.group(1).trim();
                    // Only add if it seems like an instruction (contains a verb)
                    if (actionItem.length() > 10 && containsActionVerb(actionItem)) {
                        if (actionItem.length() > 990) { // Limit length to avoid DB issues
                            actionItem = actionItem.substring(0, 990) + "...";
                        }
                        actionItems.add(actionItem);
                        itemCount++;
                        if (itemCount >= 5) break; // Limit to 5 items
                    }
                }
            }
        }

        // If no action section found or no items extracted, fall back to general numbered item detection
        if (actionItems.isEmpty()) {
            // Look for sentences with action verbs that are prefixed with numbers
            Pattern fallbackPattern = Pattern.compile("(?:\\d+\\.|[a-z]\\)|[ivx]+\\.)\\s+([^\\n\\r\\.]+)");
            Matcher matcher = fallbackPattern.matcher(text);

            while (matcher.find() && actionItems.size() < 5) {
                String potentialAction = matcher.group(1).trim();
                // Only include if it contains action verbs
                if (potentialAction.length() > 10 && containsActionVerb(potentialAction)) {
                    if (potentialAction.length() > 990) { // Limit length
                        potentialAction = potentialAction.substring(0, 990) + "...";
                    }
                    actionItems.add(potentialAction);
                }
            }
        }

        circular.setActionItems(actionItems);

        // Process cross-references
        crossReferenceService.processCircularReferences(circular, text);

        return circular;
    }

    public Optional<Circular> getCircularById(Long id) {
        return circularRepository.findById(id);
    }

    public Page<Circular> searchCirculars(String circularNumber, String referenceNumber,
                                          String department, String recipient,
                                          LocalDate fromDate, LocalDate toDate,
                                          String keyword, String entity, Pageable pageable) {
        // Update repository method to include entity search
        return circularRepository.searchCirculars(
                circularNumber, referenceNumber, department,
                recipient, fromDate, toDate, keyword, entity, pageable);
    }

    public Page<Circular> findAll(Pageable pageable) {
        return circularRepository.findAll(pageable);
    }

    // Helper method to check if text contains common action verbs
    private boolean containsActionVerb(String text) {
        String[] actionVerbs = {
                "submit", "provide", "ensure", "comply", "implement", "report",
                "follow", "maintain", "update", "review", "complete", "conduct",
                "prepare", "notify", "inform", "advise", "consider", "establish",
                "required", "must", "shall", "should", "need to", "have to"
        };

        String lowerText = text.toLowerCase();
        for (String verb : actionVerbs) {
            if (lowerText.contains(verb)) {
                return true;
            }
        }
        return false;
    }
}