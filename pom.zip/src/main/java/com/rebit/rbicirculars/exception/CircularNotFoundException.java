package com.rebit.rbicirculars.exception;

public class CircularNotFoundException extends RuntimeException {

    public CircularNotFoundException(Long id) {
        super("Circular not found with id: " + id);
    }

    public CircularNotFoundException(String circularNumber) {
        super("Circular not found with number: " + circularNumber);
    }
}