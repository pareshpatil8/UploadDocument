package com.rebit.rbicirculars.controller;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.service.CircularService;
import com.rebit.rbicirculars.service.StorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;

@RestController
@RequestMapping("/api/circulars")
@Tag(name = "Circular Search", description = "API for searching and retrieving RBI circulars")
public class CircularSearchController {

    private final CircularService circularService;
    private final StorageService storageService;

    @Autowired
    public CircularSearchController(CircularService circularService, StorageService storageService) {
        this.circularService = circularService;
        this.storageService = storageService;
    }

    @GetMapping("/search")
    @Operation(summary = "Search circulars", description = "Search circulars based on various criteria")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Search results",
                    content = @Content(mediaType = "application/json"))
    })
    public ResponseEntity<Page<Circular>> searchCirculars(
            @Parameter(description = "Circular number to search for")
            @RequestParam(required = false) String circularNumber,
            @Parameter(description = "Reference number to search for")
            @RequestParam(required = false) String referenceNumber,
            @Parameter(description = "Department that issued the circular")
            @RequestParam(required = false) String department,
            @Parameter(description = "Intended recipient of the circular")
            @RequestParam(required = false) String recipient,
            @Parameter(description = "Start date for search range")
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @Parameter(description = "End date for search range")
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @Parameter(description = "Keyword to search in subject and summary")
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Named entity to search for")
            @RequestParam(required = false) String entity,
            @Parameter(description = "Page number (0-based)")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Number of results per page")
            @RequestParam(defaultValue = "10") int size,
            @Parameter(description = "Field to sort by")
            @RequestParam(defaultValue = "publishDate") String sortBy,
            @Parameter(description = "Sort direction (asc or desc)")
            @RequestParam(defaultValue = "desc") String sortDir) {

        Sort.Direction direction = sortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));

        Page<Circular> circulars = circularService.searchCirculars(
                circularNumber, referenceNumber, department,
                recipient, fromDate, toDate, keyword, entity, pageable);

        return ResponseEntity.ok(circulars);
    }

    @GetMapping("/list")
    @Operation(summary = "List all circulars", description = "Get a paginated list of all circulars")
    public ResponseEntity<Page<Circular>> getAllCirculars(
            @Parameter(description = "Page number (0-based)")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Number of results per page")
            @RequestParam(defaultValue = "10") int size,
            @Parameter(description = "Field to sort by")
            @RequestParam(defaultValue = "publishDate") String sortBy,
            @Parameter(description = "Sort direction (asc or desc)")
            @RequestParam(defaultValue = "desc") String sortDir) {

        Sort.Direction direction = sortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));

        Page<Circular> circulars = circularService.findAll(pageable);

        return ResponseEntity.ok(circulars);
    }

    @GetMapping("/download/{id}")
    @Operation(summary = "Download circular PDF", description = "Download the PDF file of a circular")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "PDF file",
                    content = @Content(mediaType = "application/pdf")),
            @ApiResponse(responseCode = "404", description = "Circular not found")
    })
    public ResponseEntity<ByteArrayResource> downloadCircular(
            @Parameter(description = "ID of the circular to download", required = true)
            @PathVariable Long id) {

        Optional<Circular> optionalCircular = circularService.getCircularById(id);

        if (optionalCircular.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Circular circular = optionalCircular.get();
        try {
            byte[] data = storageService.loadFileAsBytes(circular.getFilePath());
            ByteArrayResource resource = new ByteArrayResource(data);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + circular.getFilePath())
                    .contentType(MediaType.APPLICATION_PDF)
                    .contentLength(data.length)
                    .body(resource);
        } catch (IOException e) {
            return ResponseEntity.notFound().build(); // or internalServerError, depending on your intent
        }
    }

}