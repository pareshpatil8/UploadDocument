package com.rebit.rbicirculars.controller;

import com.rebit.rbicirculars.model.ChatMessage;
import com.rebit.rbicirculars.service.CircularChatbotService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chatbot")
@Tag(name = "Circular Chatbot", description = "API for interacting with the RBI circular chatbot")
public class CircularChatbotController {

    private final CircularChatbotService chatbotService;

    @Autowired
    public CircularChatbotController(CircularChatbotService chatbotService) {
        this.chatbotService = chatbotService;
    }

    @PostMapping("/ask")
    @Operation(summary = "Ask a question to the chatbot", description = "Submit a question about RBI circulars to get a relevant answer")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful response",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<Map<String, Object>> askQuestion(
            @Parameter(description = "Question and optional session ID", required = true)
            @RequestBody Map<String, String> request) {
        String question = request.get("question");
        String sessionId = request.get("sessionId");

        if (question == null || question.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        Map<String, Object> response = chatbotService.answerQuestion(question, sessionId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/history/{sessionId}")
    @Operation(summary = "Get chat history", description = "Retrieve the conversation history for a specific chat session")
    public ResponseEntity<List<ChatMessage>> getChatHistory(
            @Parameter(description = "Session ID", required = true)
            @PathVariable String sessionId) {
        if (sessionId == null || sessionId.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<ChatMessage> history = chatbotService.getChatHistory(sessionId);
        return ResponseEntity.ok(history);
    }

    @DeleteMapping("/history/{sessionId}")
    @Operation(summary = "Clear chat history", description = "Delete the conversation history for a specific chat session")
    public ResponseEntity<Void> clearChatHistory(
            @Parameter(description = "Session ID", required = true)
            @PathVariable String sessionId) {
        if (sessionId == null || sessionId.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        chatbotService.clearChatHistory(sessionId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/reindex")
    @Operation(summary = "Reindex all circulars", description = "Rebuild the search index for all circulars to improve chatbot responses")
    public ResponseEntity<Void> reindexCirculars() {
        chatbotService.reindexAllCirculars();
        return ResponseEntity.ok().build();
    }
}