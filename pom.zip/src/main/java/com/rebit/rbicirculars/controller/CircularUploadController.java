package com.rebit.rbicirculars.controller;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.service.CircularService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/circulars")
@Tag(name = "Circular Upload", description = "API for uploading and managing RBI circulars")
public class CircularUploadController {

    private final CircularService circularService;

    @Autowired
    public CircularUploadController(CircularService circularService) {
        this.circularService = circularService;
    }

    @PostMapping("/upload")
    @Operation(summary = "Upload a new circular", description = "Uploads a PDF circular and extracts relevant information")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Circular uploaded successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Circular.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input"),
            @ApiResponse(responseCode = "500", description = "Server error")
    })
    public ResponseEntity<Circular> uploadCircular(
            @Parameter(description = "PDF file of the circular", required = true)
            @RequestParam("file") MultipartFile file) {
        try {
            Circular circular = circularService.processAndSaveCircular(file);
            return new ResponseEntity<>(circular, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get circular by ID", description = "Returns a circular based on its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Circular found",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Circular.class))),
            @ApiResponse(responseCode = "404", description = "Circular not found")
    })
    public ResponseEntity<Circular> getCircularById(
            @Parameter(description = "ID of the circular", required = true)
            @PathVariable Long id) {
        return circularService.getCircularById(id)
                .map(circular -> new ResponseEntity<>(circular, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}