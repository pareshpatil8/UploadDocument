// ReferenceNumberPattern.java
package com.rebit.rbicirculars.model.enums;

public enum ReferenceNumberPattern {
    DGBA_GBD("CO\\.DGBA\\.GBD\\.No\\.[^\\s]+"),
    DNBR("DNBR\\.\\w+\\.No\\.[^\\s]+"),
    DPSS("DPSS\\.\\w+\\.No\\.[^\\s]+"),
    DOR("DOR\\.\\w+\\.No\\.[^\\s]+"),
    FED("FED\\.\\w+\\.No\\.[^\\s]+");

    private final String pattern;

    ReferenceNumberPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getPattern() {
        return pattern;
    }
}