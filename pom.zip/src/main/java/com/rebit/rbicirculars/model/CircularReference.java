package com.rebit.rbicirculars.model;

import jakarta.persistence.*;


@Entity
@Table(name = "circular_references")
public class CircularReference {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "source_circular_id", nullable = false)
    private Circular sourceCircular;

    @ManyToOne
    @JoinColumn(name = "referenced_circular_id", nullable = false)
    private Circular referencedCircular;

    @Column(name = "reference_type")
    private String referenceType;  // CITES, SUPERSEDES, AMENDS, etc.

    @Column(name = "context", length = 500)
    private String context;  // Optional: extract context of the reference


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Circular getSourceCircular() {
        return sourceCircular;
    }

    public void setSourceCircular(Circular sourceCircular) {
        this.sourceCircular = sourceCircular;
    }

    public Circular getReferencedCircular() {
        return referencedCircular;
    }

    public void setReferencedCircular(Circular referencedCircular) {
        this.referencedCircular = referencedCircular;
    }

    public String getReferenceType() {
        return referenceType;
    }

    public void setReferenceType(String referenceType) {
        this.referenceType = referenceType;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

}