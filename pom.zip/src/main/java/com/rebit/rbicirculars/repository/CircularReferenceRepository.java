package com.rebit.rbicirculars.repository;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.model.CircularReference;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CircularReferenceRepository extends JpaRepository<CircularReference, Long> {

    List<CircularReference> findBySourceCircularId(Long circularId);

    List<CircularReference> findByReferencedCircularId(Long circularId);

    List<CircularReference> findByReferenceType(String referenceType);

    @Query("SELECT r FROM CircularReference r WHERE r.sourceCircular.id = :circularId OR r.referencedCircular.id = :circularId")
    List<CircularReference> findAllReferencesInvolvingCircular(Long circularId);

    // Add this new method to check for existing relationships
    boolean existsBySourceCircularIdAndReferencedCircularIdAndReferenceType(
            Long sourceId, Long referencedId, String referenceType);
}