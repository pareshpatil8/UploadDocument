package com.rebit.ocr.processor;

import com.rebit.ocr.model.Document;
import com.rebit.ocr.service.ImageProcessor;
import com.rebit.ocr.service.TesseractService;
import net.sourceforge.tess4j.TesseractException;
import org.bytedeco.opencv.opencv_core.Mat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.UUID;

/**
 * Generic document processor that extracts text from any document
 */
@Component
public class GenericDocumentProcessor implements DocumentProcessor<Document> {

    private static final Logger logger = LoggerFactory.getLogger(GenericDocumentProcessor.class);

    private final ImageProcessor imageProcessor;
    private final TesseractService tesseractService;

    public GenericDocumentProcessor(ImageProcessor imageProcessor, TesseractService tesseractService) {
        this.imageProcessor = imageProcessor;
        this.tesseractService = tesseractService;
    }

    @Override
    public Document process(File imageFile) throws Exception {
        logger.info("Processing generic document: {}", imageFile.getName());

        // Load and preprocess the image
        Mat originalImage = imageProcessor.loadImage(imageFile);
        if (originalImage.empty()) {
            throw new IllegalArgumentException("Failed to load image: " + imageFile.getAbsolutePath());
        }

        // Preprocess the image for better OCR
        Mat preprocessedImage = imageProcessor.preprocess(originalImage);

        // Attempt to deskew the image if necessary
        Mat deskewedImage = imageProcessor.deskew(preprocessedImage);

        // Extract text from the entire image
        String fullText;
        try {
            fullText = tesseractService.performOcr(deskewedImage);
        } catch (TesseractException e) {
            logger.error("OCR failed: {}", e.getMessage());
            throw e;
        }

        // Create document
        Document document = new Document();
        document.setId(UUID.randomUUID().toString());
        document.setDocumentType("GENERIC");
        document.setFullText(fullText);

        // Add some metadata
        document.addMetadata("filename", imageFile.getName());
        document.addMetadata("filesize", String.valueOf(imageFile.length()));
        document.addMetadata("width", String.valueOf(originalImage.cols()));
        document.addMetadata("height", String.valueOf(originalImage.rows()));

        logger.info("Completed processing generic document: {}", imageFile.getName());
        return document;
    }

    @Override
    public boolean canProcess(String documentType) {
        return "GENERIC".equalsIgnoreCase(documentType) || documentType == null;
    }

    @Override
    public String getDocumentType() {
        return "GENERIC";
    }
}