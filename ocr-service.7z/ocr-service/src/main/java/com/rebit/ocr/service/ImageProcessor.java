package com.rebit.ocr.service;

import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_imgproc.Vec4iVector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

import static org.bytedeco.opencv.global.opencv_imgproc.*;
import static org.bytedeco.opencv.global.opencv_core.*;
import static org.bytedeco.opencv.global.opencv_imgcodecs.*;

/**
 * Service for image processing operations used in the OCR pipeline
 */
@Component
public class ImageProcessor {

    private static final Logger logger = LoggerFactory.getLogger(ImageProcessor.class);

    /**
     * Load image from file path
     */
    public Mat loadImage(String imagePath) {
        logger.debug("Loading image from path: {}", imagePath);
        return imread(imagePath);
    }

    /**
     * Load image from file
     */
    public Mat loadImage(File imageFile) {
        logger.debug("Loading image from file: {}", imageFile.getName());
        return imread(imageFile.getAbsolutePath());
    }

    /**
     * Convert Mat to BufferedImage
     */
    public BufferedImage matToBufferedImage(Mat mat) {
        int width = mat.cols();
        int height = mat.rows();
        int channels = mat.channels();
        byte[] sourcePixels = new byte[width * height * channels];
        mat.data().get(sourcePixels);

        BufferedImage image = new BufferedImage(width, height,
                channels > 1 ? BufferedImage.TYPE_3BYTE_BGR : BufferedImage.TYPE_BYTE_GRAY);
        final byte[] targetPixels = ((java.awt.image.DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(sourcePixels, 0, targetPixels, 0, sourcePixels.length);

        return image;
    }

    /**
     * Enhanced preprocessing for better OCR accuracy
     * Applies a combination of techniques to improve text recognition

    public Mat preprocess(Mat source) {
        logger.debug("Preprocessing image for OCR");
        Mat destination = new Mat();

        // Check if the image is loaded properly
        if (source.empty()) {
            logger.error("Source image is empty");
            return source;
        }

        // Step 1: Convert to grayscale
        Mat gray = new Mat();
        if (source.channels() > 1) {
            cvtColor(source, gray, COLOR_BGR2GRAY);
        } else {
            source.copyTo(gray);
        }

        // Step 2: Apply bilateral filter to preserve edges while removing noise
        Mat filtered = new Mat();
        bilateralFilter(gray, filtered, 9, 75, 75);

        // Step 3: Apply adaptive thresholding to handle varying lighting conditions
        Mat binary = new Mat();
        adaptiveThreshold(filtered, binary, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY, 11, 2);

        // Step 4: Perform noise removal using morphological operations
        Mat kernel = getStructuringElement(MORPH_RECT, new Size(2, 2));
        morphologyEx(binary, destination, MORPH_CLOSE, kernel);

        // Step 5: Apply sharpening filter to enhance text edges
        Mat sharpened = new Mat();
        Mat blurred = new Mat();
        GaussianBlur(destination, blurred, new Size(0, 0), 3);
        addWeighted(destination, 1.5, blurred, -0.5, 0, sharpened);

        return sharpened;
    } */

    public Mat preprocess(Mat source) {
        logger.debug("Preprocessing image for OCR");

        // Check if the image is loaded properly
        if (source.empty()) {
            logger.error("Source image is empty");
            return source;
        }

        // Convert to grayscale
        Mat gray = new Mat();
        if (source.channels() > 1) {
            cvtColor(source, gray, COLOR_BGR2GRAY);
        } else {
            source.copyTo(gray);
        }

        // Apply Gaussian Blur to reduce noise before contrast enhancement
        Mat blurred = new Mat();
        GaussianBlur(gray, blurred, new Size(3, 3), 0);

        // Apply CLAHE for better contrast
        org.bytedeco.opencv.opencv_imgproc.CLAHE clahe = opencv_imgproc.createCLAHE(2.0, new Size(8, 8));
        Mat enhanced = new Mat();
        clahe.apply(gray, enhanced);

        // Apply Otsu's thresholding - more reliable for invoices with colored backgrounds
        Mat binary = new Mat();
        threshold(enhanced, binary, 0, 255, THRESH_BINARY | THRESH_OTSU);

        // Apply morphological closing to fill small gaps in text
        Mat kernel = getStructuringElement(MORPH_RECT, new Size(3, 3));
        Mat closed = new Mat();
        morphologyEx(binary, closed, MORPH_CLOSE, kernel);

        // Clean up noise
        kernel = getStructuringElement(MORPH_RECT, new Size(1, 1));
        Mat cleaned = new Mat();
        morphologyEx(binary, cleaned, MORPH_OPEN, kernel);

        return cleaned;
    }
    /**
     * Apply deskewing to correct rotation in the document
     */
    public Mat deskew(Mat source) {
        logger.debug("Deskewing document");
        Mat destination = source.clone();

        // Convert to grayscale if necessary
        Mat gray = new Mat();
        if (source.channels() > 1) {
            cvtColor(source, gray, COLOR_BGR2GRAY);
        } else {
            source.copyTo(gray);
        }

        // Apply threshold to get binary image
        Mat binary = new Mat();
        threshold(gray, binary, 0, 255, THRESH_BINARY_INV + THRESH_OTSU);

        // Use findNonZero to collect all foreground points
        Mat nonZeroCoordinates = new Mat();
        findNonZero(binary, nonZeroCoordinates);

        // If no foreground points found, return the original image
        if (nonZeroCoordinates.empty()) {
            logger.warn("No foreground pixels found for deskewing.");
            return source;
        }

        // Compute the minimum-area rectangle that bounds the foreground pixels
        RotatedRect box = minAreaRect(nonZeroCoordinates);
        double angle = box.angle();

        // Adjust the angle as the minAreaRect returns angles in the range [-90, 0)
        if (angle < -45) {
            angle += 90;
        }

        logger.debug("Calculated skew angle: {} degrees", angle);

        // Apply rotation only if the angle is significant
        if (Math.abs(angle) > 0.5) {
            Point2f center = new Point2f(source.cols() / 2.0f, source.rows() / 2.0f);
            Mat rotMatrix = getRotationMatrix2D(center, angle, 1.0);
            // Use INTER_CUBIC for smoother interpolation
            warpAffine(source, destination, rotMatrix, source.size());
            logger.debug("Applied deskew rotation of {} degrees", angle);
        }

        return destination;
    }

    /**
     * Detect and extract table structure from the document
     * This is critical for invoice processing
     */
    public Mat detectTableLines(Mat source) {
        logger.debug("Detecting table structure");
        Mat destination = new Mat();

        // Convert to grayscale if necessary
        Mat gray = new Mat();
        if (source.channels() > 1) {
            cvtColor(source, gray, COLOR_BGR2GRAY);
        } else {
            source.copyTo(gray);
        }

        // Apply threshold
        Mat binary = new Mat();
        threshold(gray, binary, 0, 255, THRESH_BINARY_INV + THRESH_OTSU);

        // Define morphological kernel
        Mat kernel = getStructuringElement(MORPH_RECT, new Size(2, 2));

        // Apply morphology operations to clean the image
        morphologyEx(binary, binary, MORPH_CLOSE, kernel);

        // Detect horizontal lines - adjust kernel size based on image resolution
        int horizontalSize = Math.max(binary.cols() / 30, 20); // Adaptive kernel size
        Mat horizontalKernel = getStructuringElement(MORPH_RECT, new Size(horizontalSize, 1));
        Mat horizontalLines = new Mat();
        morphologyEx(binary, horizontalLines, MORPH_OPEN, horizontalKernel);
        dilate(horizontalLines, horizontalLines, getStructuringElement(MORPH_RECT, new Size(3, 1)));

        // Detect vertical lines - adjust kernel size based on image resolution
        int verticalSize = Math.max(binary.rows() / 30, 20); // Adaptive kernel size
        Mat verticalKernel = getStructuringElement(MORPH_RECT, new Size(1, verticalSize));
        Mat verticalLines = new Mat();
        morphologyEx(binary, verticalLines, MORPH_OPEN, verticalKernel);
        dilate(verticalLines, verticalLines, getStructuringElement(MORPH_RECT, new Size(1, 3)));

        // Combine horizontal and vertical lines
        addWeighted(horizontalLines, 1, verticalLines, 1, 0, destination);

        // Clean up the result
        morphologyEx(destination, destination, MORPH_DILATE, kernel);

        return destination;
    }

    /**
     * Extract table cells from the image by finding intersections of lines
     */
    public List<Rect> extractTableCells(Mat tableLines, Mat originalImage) {
        logger.debug("Extracting table cells");

        // Find contours in the table lines image
        Mat hierarchy = new Mat();
        MatVector contours = new MatVector();
        findContours(tableLines, contours, hierarchy, RETR_CCOMP, CHAIN_APPROX_SIMPLE);

        // Filter out contours that are too small or too large
        List<Rect> cells = new ArrayList<>();

        for (int i = 0; i < (int) contours.size(); i++) {
            Rect rect = boundingRect(contours.get(i));

            // Filter based on size
            int minWidth = Math.max(originalImage.cols() / 50, 30);
            int minHeight = Math.max(originalImage.rows() / 50, 10);
            int maxWidth = originalImage.cols() - 10;
            int maxHeight = originalImage.rows() - 10;

            if (rect.width() > minWidth && rect.height() > minHeight &&
                    rect.width() < maxWidth && rect.height() < maxHeight) {
                cells.add(rect);
            }
        }

        logger.debug("Found {} potential table cells", cells.size());
        return cells;
    }

    /**
     * Advanced table cell detection that handles merged cells and missing lines
     */
    public List<Rect> detectTableStructure(Mat image) {
        logger.debug("Detecting advanced table structure");

        // First try standard line detection
        Mat tableLines = detectTableLines(image);
        List<Rect> cells = extractTableCells(tableLines, image);

        // If insufficient cells found, try alternative approach with Hough lines
        if (cells.size() < 4) {
            logger.debug("Standard detection found too few cells ({}), trying Hough line detection", cells.size());

            Mat gray = new Mat();
            if (image.channels() > 1) {
                cvtColor(image, gray, COLOR_BGR2GRAY);
            } else {
                image.copyTo(gray);
            }

            // Apply threshold
            Mat binary = new Mat();
            threshold(gray, binary, 0, 255, THRESH_BINARY_INV + THRESH_OTSU);

            // Detect edges
            Mat edges = new Mat();
            Canny(binary, edges, 50, 150, 3, false);

            // Use probabilistic Hough Line Transform with Vec4iVector
            org.bytedeco.opencv.opencv_imgproc.Vec4iVector linesVec = new org.bytedeco.opencv.opencv_imgproc.Vec4iVector();
            HoughLinesP(edges, linesVec, 1, Math.PI/180, 100, 50, 10);

            // Create an image to draw lines on
            Mat lineImage = Mat.zeros(image.size(), CV_8UC1).asMat();

            // Draw lines
            for (int i = 0; i < (int)linesVec.size(); i++) {
                Scalar4i vec = linesVec.get(i);
                int[] lineCoords = new int[4];
                lineCoords[0] = vec.get(0);
                lineCoords[1] = vec.get(1);
                lineCoords[2] = vec.get(2);
                lineCoords[3] = vec.get(3);
                line(lineImage, new Point(lineCoords[0], lineCoords[1]),
                        new Point(lineCoords[2], lineCoords[3]),
                        new Scalar(255, 255, 255, 255), 2, 8, 0);
            }

            // Dilate the lines to connect nearby lines
            dilate(lineImage, lineImage, getStructuringElement(MORPH_RECT, new Size(3, 3)));

            // Re-extract cells with this new approach
            cells = extractTableCells(lineImage, image);
        }

        return cells;
    }

    public Mat scaleImage(Mat source, double scaleFactor) {
        Mat resized = new Mat();
        Size newSize = new Size((int) (source.cols() * scaleFactor), (int) (source.rows() * scaleFactor));
        resize(source, resized, newSize, 0, 0, INTER_CUBIC);
        return resized;
    }

    /**
     * Draw the table cells on the original image for visualization
     */
    public Mat drawTableCells(Mat original, List<Rect> cells) {
        Mat result = original.clone();

        for (Rect cell : cells) {
            rectangle(result, cell, new Scalar(0, 255, 0, 255), 2, 8, 0);
        }

        return result;
    }

    /**
     * Save the processed image to a file
     */
    public void saveImage(Mat image, String outputPath) {
        logger.debug("Saving image to: {}", outputPath);
        imwrite(outputPath, image);
    }

    /**
     * Save a buffered image to a file
     */
    public void saveBufferedImage(BufferedImage image, String outputPath) throws IOException {
        logger.debug("Saving buffered image to: {}", outputPath);
        File outputFile = new File(outputPath);
        ImageIO.write(image, "png", outputFile);
    }
}
