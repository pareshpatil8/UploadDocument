package com.rebit.ocr.service;

import com.rebit.ocr.model.Document;
import com.rebit.ocr.processor.DocumentProcessor;
import com.rebit.ocr.processor.DocumentProcessorFactory;

import com.rebit.ocr.processor.PdfDocumentProcessor;
import org.bytedeco.opencv.opencv_core.Mat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

/**
 * Main service that orchestrates the OCR pipeline
 */
@Service
public class OcrPipeline {

    private static final Logger logger = LoggerFactory.getLogger(OcrPipeline.class);

    private final ImageProcessor imageProcessor;
    private final TesseractService tesseractService;
    private final DocumentProcessorFactory processorFactory;
    private final PdfProcessingService pdfProcessingService;

    public OcrPipeline(ImageProcessor imageProcessor,
                       TesseractService tesseractService,
                       DocumentProcessorFactory processorFactory, PdfProcessingService pdfProcessingService) {
        this.imageProcessor = imageProcessor;
        this.tesseractService = tesseractService;
        this.processorFactory = processorFactory;
        this.pdfProcessingService = pdfProcessingService;
    }

    /**
     * Process a document through the OCR pipeline
     * Handles both image files and PDFs
     *
     * @param documentFile The file to process
     * @param documentType The type of document (e.g., "INVOICE")
     * @return Processed document
     */
    public Document processDocument(File documentFile, String documentType) throws Exception {
        String uuid = UUID.randomUUID().toString();
        logger.info("Starting document processing for file: {} as type: {}", documentFile.getName(), documentType);

        // Create directory for debug output if not exists
        Path debugDir = Paths.get("debug_output");
        if (!Files.exists(debugDir)) {
            Files.createDirectory(debugDir);
        }

        try {
            // Check file type by extension
            String fileName = documentFile.getName().toLowerCase();

            if (fileName.endsWith(".pdf")) {
                // Process as PDF
                logger.info("Processing file as PDF: {}", documentFile.getName());

                // Use the PDF processor to handle the file
                return pdfProcessingService.processPdf(documentFile);
            } else {
                // Process as image
                logger.info("Processing file as image: {}", documentFile.getName());

                // Load the image
                Mat originalImage = imageProcessor.loadImage(documentFile);
                if (originalImage.empty()) {
                    throw new IllegalArgumentException("Failed to load image: " + documentFile.getAbsolutePath());
                }

                // Save original for debug
                imageProcessor.saveImage(originalImage,
                        debugDir.resolve(uuid + "_1_original.png").toString());

                // Get the appropriate processor for the document type
                DocumentProcessor<? extends Document> processor = processorFactory.getProcessor(documentType);

                // Process the document
                Document document = processor.process(documentFile);

                logger.info("Completed image processing for file: {}", documentFile.getName());
                return document;
            }
        } catch (Exception e) {
            logger.error("Error in document processing pipeline: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Process a PDF document
     *
     * @param pdfFile The PDF file to process
     * @param documentType The type of document
     * @return Processed document
     */
    private Document processPdf(File pdfFile, String documentType) throws Exception {
        // First check if PDF is readable or scanned
        if (pdfProcessingService.isPdfReadable(pdfFile)) {
            logger.info("PDF contains readable text, processing directly: {}", pdfFile.getName());

            // If this is an invoice, use the special processing
            if ("INVOICE".equalsIgnoreCase(documentType)) {
                return pdfProcessingService.processReadablePdf(pdfFile);
            } else {
                // For other document types, extract text and create a generic document
                String fullText = pdfProcessingService.extractTextFromPdf(pdfFile);

                // Get the appropriate processor for the document type
                DocumentProcessor<? extends Document> processor = processorFactory.getProcessor(documentType);

                // Create a temporary image from PDF for any additional processing needed
                Path tempImagePath = pdfProcessingService.convertPdfPageToImage(pdfFile, 0);
                Document document;

                try {
                    // Process using the appropriate processor
                    document = processor.process(tempImagePath.toFile());

                    // Override the full text with what we extracted directly
                    document.setFullText(fullText);
                } finally {
                    // Clean up temporary image
                    Files.deleteIfExists(tempImagePath);
                }

                return document;
            }
        } else {
            logger.info("PDF appears to be scanned, processing with OCR: {}", pdfFile.getName());
            return pdfProcessingService.processPdf(pdfFile);
        }
    }

    /**
     * Process a PDF document with multi-page handling
     *
     * @param pdfFile The PDF file to process
     * @param documentType The type of document
     * @param forceOcr Force OCR processing even for readable PDFs
     * @return PdfDocument containing page information
     */
    public Document processPdfWithPages(File pdfFile, String documentType, boolean forceOcr) throws Exception {
        logger.info("Processing multi-page PDF: {}, ForceOCR: {}", pdfFile.getName(), forceOcr);

        try {
            // Get a PDF processor to handle multiple pages
            PdfDocumentProcessor pdfProcessor = (PdfDocumentProcessor) processorFactory.getProcessor("PDF");

            // Process the PDF with multi-page handling
            return pdfProcessor.processMultiPage(pdfFile, forceOcr);
        } catch (Exception e) {
            logger.error("Error processing multi-page PDF: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Process a document with additional options for PDF handling
     *
     * @param documentFile The file to process
     * @param documentType The type of document (e.g., "INVOICE")
     * @param forceOcr Force OCR processing even for readable PDFs
     * @return Processed document
     */
    public Document processDocument(File documentFile, String documentType, boolean forceOcr) throws Exception {
        String uuid = UUID.randomUUID().toString();
        logger.info("Starting document processing with options. File: {}, Type: {}, ForceOCR: {}",
                documentFile.getName(), documentType, forceOcr);

        // Create directory for debug output if not exists
        Path debugDir = Paths.get("debug_output");
        if (!Files.exists(debugDir)) {
            Files.createDirectory(debugDir);
        }

        try {
            // Check if this is a PDF file based on extension
            String fileName = documentFile.getName().toLowerCase();

            if (fileName.endsWith(".pdf")) {
                // Process as PDF
                logger.info("Processing file as PDF with ForceOCR={}: {}", forceOcr, documentFile.getName());

                // For PDFs, check if we need to use the PDF processing service
                boolean isPdfReadable = !forceOcr && pdfProcessingService.isPdfReadable(documentFile);

                if (isPdfReadable) {
                    // Use direct text extraction for readable PDFs
                    logger.info("PDF contains readable text, extracting directly");
                    return pdfProcessingService.processReadablePdf(documentFile);
                } else {
                    // Use OCR for non-readable PDFs or when OCR is forced
                    logger.info("Using OCR to process PDF");
                    return pdfProcessingService.processPdf(documentFile);
                }
            } else {
                // Process as image - use the standard method
                return processDocument(documentFile, documentType);
            }
        } catch (Exception e) {
            logger.error("Error in document processing pipeline: {}", e.getMessage(), e);
            throw e;
        }
    }
    /**
     * Process an image document
     *
     * @param imageFile The image file to process
     * @param documentType The type of document
     * @param uuid Unique identifier for debugging
     * @param debugDir Directory for debug output
     * @return Processed document
     */
    private Document processImage(File imageFile, String documentType, String uuid, Path debugDir) throws Exception {
        // Load the image
        Mat originalImage = imageProcessor.loadImage(imageFile);
        if (originalImage.empty()) {
            throw new IllegalArgumentException("Failed to load image: " + imageFile.getAbsolutePath());
        }

        // Save original for debug
        imageProcessor.saveImage(originalImage,
                debugDir.resolve(uuid + "_1_original.png").toString());

        // Get the appropriate processor for the document type
        DocumentProcessor<? extends Document> processor = processorFactory.getProcessor(documentType);

        // Process the document
        Document document = processor.process(imageFile);

        logger.info("Completed image processing for file: {}", imageFile.getName());
        return document;
    }

    /**
     * Process a document image from a file path
     */
    public Document processDocument(String documentPath, String documentType) throws Exception {
        return processDocument(new File(documentPath), documentType);
    }
}