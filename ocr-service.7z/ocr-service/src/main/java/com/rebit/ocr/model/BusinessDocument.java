package com.rebit.ocr.model;

/**
 * Base class for all business document types
 * Extends the generic Document with common business fields
 */
public abstract class BusinessDocument extends Document {
    private String documentNumber;
    private String documentDate;
    private String companyName;
    private String companyAddress;

    public BusinessDocument() {
        super();
    }

    // Getters and Setters

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }
}