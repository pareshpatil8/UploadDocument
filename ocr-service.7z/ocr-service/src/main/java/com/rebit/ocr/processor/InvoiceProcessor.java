package com.rebit.ocr.processor;

import com.rebit.ocr.model.Invoice;
import com.rebit.ocr.model.InvoiceLineItem;
import com.rebit.ocr.service.ImageProcessor;
import com.rebit.ocr.service.TesseractService;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.Word;
import org.apache.commons.lang3.StringUtils;
import org.bytedeco.opencv.opencv_core.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.awt.Rectangle;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Invoice processor that extracts structured data from invoice images
 */
@Component
public class InvoiceProcessor implements DocumentProcessor<Invoice> {

    private static final Logger logger = LoggerFactory.getLogger(InvoiceProcessor.class);

    private final ImageProcessor imageProcessor;
    private final TesseractService tesseractService;

    public InvoiceProcessor(ImageProcessor imageProcessor, TesseractService tesseractService) {
        this.imageProcessor = imageProcessor;
        this.tesseractService = tesseractService;
    }

    @Override
    public Invoice process(File imageFile) throws Exception {
        logger.info("Processing invoice: {}", imageFile.getName());

        // Load and preprocess the image
        Mat originalImage = imageProcessor.loadImage(imageFile);
        if (originalImage.empty()) {
            throw new IllegalArgumentException("Failed to load image: " + imageFile.getAbsolutePath());
        }

        // Create a copy of the original image for visualization
        Mat visualizationImage = originalImage.clone();

        // Preprocess the image
        Mat preprocessedImage = imageProcessor.preprocess(originalImage);

        // Attempt to deskew the image if necessary
        Mat deskewedImage = imageProcessor.deskew(preprocessedImage);

        // Extract text from the entire image first
        String fullText = tesseractService.performOcr(deskewedImage);

        // Create invoice object
        Invoice invoice = new Invoice();
        invoice.setId(UUID.randomUUID().toString());
        invoice.setFullText(fullText);

        // Extract key invoice information
        extractHeaderInfo(fullText, invoice);

        // Detect and extract table data
        extractTableData(deskewedImage, invoice);

        logger.info("Completed processing invoice: {}", imageFile.getName());
        return invoice;
    }

    /**
     * Extract header information from the invoice
     */
    private void extractHeaderInfo(String text, Invoice invoice) {
        logger.debug("Extracting header information");

        // Extract GSTIN Number
        extractGstNumber(text, invoice);

        // Extract Invoice Number
        extractInvoiceNumber(text, invoice);

        // Extract Invoice Date
        extractInvoiceDate(text, invoice);

        // Extract Due Date
        extractDueDate(text, invoice);

        // Extract Seller and Buyer details
        extractPartyDetails(text, invoice);
    }

    /**
     * Extract GSTIN number from text
     */
    private void extractGstNumber(String text, Invoice invoice) {
        // Define patterns for GSTIN
        // GSTIN format is 2 digits, 10 chars, 1 digit, 1 char, 1 digit, 1 char
        // Example: 29AACCT3705E000
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));
        patterns.add(Pattern.compile("GSTIN[:\\s]+([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));
        patterns.add(Pattern.compile("GST[:\\s]+([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String gstin = matcher.group(1).trim();
                invoice.setGstinNumber(gstin);
                logger.debug("Found GSTIN: {}", gstin);
                return;
            }
        }

        logger.debug("GSTIN not found");
    }

    /**
     * Extract invoice number
     */
    private void extractInvoiceNumber(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("Invoice No[.:\\s]+([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Invoice Number[.:\\s]+([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Invoice #[.:\\s]*([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Bill No[.:\\s]+([A-Za-z0-9\\-/]+)"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String invoiceNumber = matcher.group(1).trim();
                invoice.setInvoiceNumber(invoiceNumber);
                logger.debug("Found Invoice Number: {}", invoiceNumber);
                return;
            }
        }

        logger.debug("Invoice Number not found");
    }

    /**
     * Extract invoice date
     */
    private void extractInvoiceDate(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("Invoice Date[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Date[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Date[.:\\s]+([0-9]{1,2}\\s+[A-Za-z]{3}\\s+[0-9]{2,4})"));
        patterns.add(Pattern.compile("Dated[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String invoiceDate = matcher.group(1).trim();
                invoice.setInvoiceDate(invoiceDate);
                logger.debug("Found Invoice Date: {}", invoiceDate);
                return;
            }
        }

        logger.debug("Invoice Date not found");
    }

    /**
     * Extract due date
     */
    private void extractDueDate(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("Due Date[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Payment Due[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Due by[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String dueDate = matcher.group(1).trim();
                invoice.setDueDate(dueDate);
                logger.debug("Found Due Date: {}", dueDate);
                return;
            }
        }

        logger.debug("Due Date not found");
    }

    /**
     * Extract seller and buyer details
     */
    private void extractPartyDetails(String text, Invoice invoice) {
        // Extract seller name and address
        List<Pattern> sellerPatterns = new ArrayList<>();
        sellerPatterns.add(Pattern.compile("(?:Seller|From|Billed From)[:\\s]*(.+?)(?=\\n|$)", Pattern.DOTALL));
        sellerPatterns.add(Pattern.compile("(?:Company|Supplier)[:\\s]*(.+?)(?=\\n|$)", Pattern.DOTALL));

        for (Pattern pattern : sellerPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String sellerInfo = matcher.group(1).trim();
                String[] lines = sellerInfo.split("\\n");
                if (lines.length > 0) {
                    invoice.setSellerName(lines[0].trim());
                    if (lines.length > 1) {
                        StringBuilder address = new StringBuilder();
                        for (int i = 1; i < lines.length; i++) {
                            address.append(lines[i].trim()).append(" ");
                        }
                        invoice.setSellerAddress(address.toString().trim());
                    }
                    logger.debug("Found Seller: {}", invoice.getSellerName());
                    break;
                }
            }
        }

        // Extract buyer name and address
        List<Pattern> buyerPatterns = new ArrayList<>();
        buyerPatterns.add(Pattern.compile("(?:Buyer|Bill To|Ship To)[:\\s]*(.+?)(?=\\n|$)", Pattern.DOTALL));
        buyerPatterns.add(Pattern.compile("(?:Customer|Client)[:\\s]*(.+?)(?=\\n|$)", Pattern.DOTALL));

        for (Pattern pattern : buyerPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String buyerInfo = matcher.group(1).trim();
                String[] lines = buyerInfo.split("\\n");
                if (lines.length > 0) {
                    invoice.setBuyerName(lines[0].trim());
                    if (lines.length > 1) {
                        StringBuilder address = new StringBuilder();
                        for (int i = 1; i < lines.length; i++) {
                            address.append(lines[i].trim()).append(" ");
                        }
                        invoice.setBuyerAddress(address.toString().trim());
                    }
                    logger.debug("Found Buyer: {}", invoice.getBuyerName());
                    break;
                }
            }
        }
    }

    /**
     * Extract table data from the invoice
     */
    private void extractTableData(Mat image, Invoice invoice) throws TesseractException {
        logger.debug("Extracting table data");

        // Detect table lines
        Mat tableLines = imageProcessor.detectTableLines(image);

        // Use advanced table detection if standard doesn't work well
        List<Rect> cells = imageProcessor.detectTableStructure(image);

        if (cells.isEmpty()) {
            logger.warn("No table cells detected, skipping table extraction");
            return;
        }

        // Group cells by row (based on y-coordinate)
        List<List<Rect>> rows = groupCellsByRow(cells);

        if (rows.isEmpty()) {
            logger.warn("No table rows detected, skipping table extraction");
            return;
        }

        // Process the table rows
        processTableRows(image, rows, invoice);

        // Extract total amount
        extractTotalAmount(image, cells, invoice);

        // Extract tax information
        extractTaxInformation(image, cells, invoice);
    }

    /**
     * Group cells into rows based on y-coordinate
     */
    private List<List<Rect>> groupCellsByRow(List<Rect> cells) {
        // Using a tolerance for grouping cells with similar y values
        int tolerance = 15; // Pixels tolerance

        // Sort cells by y-coordinate
        cells.sort(Comparator.comparingInt(Rect::y));

        // Group cells into rows
        List<List<Rect>> rows = new ArrayList<>();
        List<Rect> currentRow = new ArrayList<>();
        int lastY = -100; // Initialize with a value that will trigger a new row

        for (Rect cell : cells) {
            if (Math.abs(cell.y() - lastY) > tolerance) {
                // This cell belongs to a new row
                if (!currentRow.isEmpty()) {
                    rows.add(currentRow);
                    currentRow = new ArrayList<>();
                }
                lastY = cell.y();
            }
            currentRow.add(cell);
        }

        // Add the last row if it's not empty
        if (!currentRow.isEmpty()) {
            rows.add(currentRow);
        }

        return rows;
    }

    /**
     * Process table rows to extract line items
     */
    private void processTableRows(Mat image, List<List<Rect>> rows, Invoice invoice) throws TesseractException {
        boolean headerProcessed = false;
        List<String> columnHeaders = new ArrayList<>();

        // Configure Tesseract for table recognition
        tesseractService.configureForTableRecognition();

        for (List<Rect> row : rows) {
            // Sort cells in the row by x-coordinate
            row.sort(Comparator.comparingInt(Rect::x));

            if (!headerProcessed) {
                // Process header row
                for (Rect cell : row) {
                    Rectangle javaRect = new Rectangle(cell.x(), cell.y(), cell.width(), cell.height());
                    String cellText = tesseractService.performOcr(image, javaRect).trim();
                    columnHeaders.add(cellText);
                }
                headerProcessed = true;
                logger.debug("Processed header row: {}", columnHeaders);
            } else {
                // Process data row
                InvoiceLineItem lineItem = new InvoiceLineItem();

                for (int i = 0; i < row.size() && i < columnHeaders.size(); i++) {
                    Rectangle javaRect = new Rectangle(row.get(i).x(), row.get(i).y(),
                            row.get(i).width(), row.get(i).height());
                    String cellText = tesseractService.performOcr(image, javaRect).trim();

                    // Skip empty cells
                    if (StringUtils.isBlank(cellText)) {
                        continue;
                    }

                    // Map cell text to lineItem field based on column header
                    String header = columnHeaders.get(i).toLowerCase();

                    if (header.contains("sl") || header.contains("no") || header.contains("#")) {
                        lineItem.setSerialNumber(cellText);
                    } else if (header.contains("description") || header.contains("product") || header.contains("item")) {
                        lineItem.setDescription(cellText);
                    } else if (header.contains("hsn") || header.contains("sac")) {
                        lineItem.setHsnCode(cellText);
                    } else if (header.contains("qty") || header.contains("quantity")) {
                        lineItem.setQuantity(cellText);
                    } else if (header.contains("rate") || header.contains("price")) {
                        lineItem.setRate(cellText);
                    } else if (header.contains("amount") || header.contains("total")) {
                        lineItem.setAmount(cellText);
                    } else if (header.contains("tax") && header.contains("rate")) {
                        lineItem.setTaxRate(cellText);
                    } else if (header.contains("tax") && header.contains("amount")) {
                        lineItem.setTaxAmount(cellText);
                    } else if (header.contains("discount")) {
                        lineItem.setDiscountAmount(cellText);
                    } else if (header.contains("unit")) {
                        lineItem.setUnit(cellText);
                    }
                }

                // Add line item if it has meaningful data
                if (lineItem.getDescription() != null || lineItem.getAmount() != null) {
                    invoice.addLineItem(lineItem);
                    logger.debug("Added line item: {}", lineItem.getDescription());
                }
            }
        }

        // Reset Tesseract configuration
        tesseractService.resetConfiguration();
    }

    /**
     * Extract total amount from the invoice
     */
    private void extractTotalAmount(Mat image, List<Rect> cells, Invoice invoice) throws TesseractException {
        // Look for cells containing "total" and extract adjacent cell text
        for (Rect cell : cells) {
            Rectangle javaRect = new Rectangle(cell.x(), cell.y(), cell.width(), cell.height());
            String cellText = tesseractService.performOcr(image, javaRect).trim().toLowerCase();

            if (cellText.contains("total") && (cellText.contains("amount") || cellText.contains("payable"))) {
                // Check adjacent cells for amount
                for (Rect adjacentCell : cells) {
                    // Check if the cell is adjacent horizontally
                    if (Math.abs(adjacentCell.y() - cell.y()) < 20 &&
                            adjacentCell.x() > cell.x() + cell.width() - 10) {

                        Rectangle adjRect = new Rectangle(adjacentCell.x(), adjacentCell.y(),
                                adjacentCell.width(), adjacentCell.height());
                        String amountText = tesseractService.performOcr(image, adjRect).trim();

                        // Extract numeric value
                        Pattern amountPattern = Pattern.compile("[₹Rs$]?\\s*([0-9,.]+)");
                        Matcher matcher = amountPattern.matcher(amountText);
                        if (matcher.find()) {
                            invoice.setTotalAmount(matcher.group(1).replaceAll("[^0-9.]", ""));
                            logger.debug("Found Total Amount: {}", invoice.getTotalAmount());
                            return;
                        }
                    }
                }
            }
        }

        // If total amount still not found, try extracting from full text
        if (invoice.getTotalAmount() == null) {
            String fullText = invoice.getFullText();
            Pattern totalPattern = Pattern.compile("(?:Total|Amount)[:\\s]*([$₹Rs.\\s]*)([0-9,.]+)", Pattern.CASE_INSENSITIVE);
            Matcher matcher = totalPattern.matcher(fullText);
            if (matcher.find()) {
                invoice.setTotalAmount(matcher.group(2).replaceAll("[^0-9.]", ""));
                logger.debug("Found Total Amount from full text: {}", invoice.getTotalAmount());
            } else {
                logger.debug("Total Amount not found");
            }
        }
    }

    /**
     * Extract tax information from the invoice
     */
    private void extractTaxInformation(Mat image, List<Rect> cells, Invoice invoice) throws TesseractException {
        // Check for CGST, SGST, IGST
        List<Pattern> taxPatterns = new ArrayList<>();
        taxPatterns.add(Pattern.compile("CGST[:\\s]*([$₹Rs.\\s]*)([0-9,.]+)"));
        taxPatterns.add(Pattern.compile("SGST[:\\s]*([$₹Rs.\\s]*)([0-9,.]+)"));
        taxPatterns.add(Pattern.compile("IGST[:\\s]*([$₹Rs.\\s]*)([0-9,.]+)"));

        String fullText = invoice.getFullText();

        // Extract CGST
        Matcher cgstMatcher = taxPatterns.get(0).matcher(fullText);
        if (cgstMatcher.find()) {
            invoice.setCgstAmount(cgstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found CGST Amount: {}", invoice.getCgstAmount());
        }

        // Extract SGST
        Matcher sgstMatcher = taxPatterns.get(1).matcher(fullText);
        if (sgstMatcher.find()) {
            invoice.setSgstAmount(sgstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found SGST Amount: {}", invoice.getSgstAmount());
        }

        // Extract IGST
        Matcher igstMatcher = taxPatterns.get(2).matcher(fullText);
        if (igstMatcher.find()) {
            invoice.setIgstAmount(igstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found IGST Amount: {}", invoice.getIgstAmount());
        }

        // Extract taxable amount
        Pattern taxablePattern = Pattern.compile("Taxable[\\s:]*(?:Amount|Value)[:\\s]*([$₹Rs.\\s]*)([0-9,.]+)", Pattern.CASE_INSENSITIVE);
        Matcher taxableMatcher = taxablePattern.matcher(fullText);
        if (taxableMatcher.find()) {
            invoice.setTaxableAmount(taxableMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found Taxable Amount: {}", invoice.getTaxableAmount());
        }
    }

    private void extractInvoiceWithoutTableDetection(Mat image, Invoice invoice) throws TesseractException {
        logger.debug("Trying direct OCR without table detection");

        // Configure Tesseract for better invoice recognition
        tesseractService.setTessVariable("textord_tablefind_recognize_tables", "1");
        tesseractService.setTessVariable("textord_min_linesize", "1.5");

        // Perform OCR on the entire image
        String fullText = tesseractService.performOcr(image);

        // Update the full text
        invoice.setFullText(fullText);

        // Extract invoice data using regex patterns
        extractHeaderInfo(fullText, invoice);

        // Reset Tesseract configuration
        tesseractService.resetConfiguration();
    }

    @Override
    public boolean canProcess(String documentType) {
        return "INVOICE".equalsIgnoreCase(documentType);
    }

    @Override
    public String getDocumentType() {
        return "INVOICE";
    }
}