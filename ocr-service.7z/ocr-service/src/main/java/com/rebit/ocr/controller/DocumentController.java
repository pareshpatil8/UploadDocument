package com.rebit.ocr.controller;

import com.rebit.ocr.model.Document;
import com.rebit.ocr.service.OcrPipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * REST controller for document OCR operations
 */
@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private static final Logger logger = LoggerFactory.getLogger(DocumentController.class);
    private static final List<String> SUPPORTED_FILE_TYPES = Arrays.asList(
            "image/jpeg", "image/png", "image/tiff", "application/pdf");

    private final OcrPipeline ocrPipeline;

    public DocumentController(OcrPipeline ocrPipeline) {
        this.ocrPipeline = ocrPipeline;
    }

    /**
     * Extract text and data from a document
     *
     * @param file The document file (image or PDF)
     * @param documentType The type of document (optional)
     * @param forceOcr Force OCR processing even for readable PDFs (optional)
     * @param isPdf Parameter to explicitly indicate the file is a PDF (optional)
     * @return The extracted document data
     */
    @PostMapping(value = "/extract", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> extractDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "documentType", required = false) String documentType,
            @RequestParam(value = "forceOcr", required = false, defaultValue = "false") boolean forceOcr,
            @RequestParam(value = "isPdf", required = false, defaultValue = "false") boolean isPdf) {

        logger.info("Received document extraction request. File: {}, Type: {}, ForceOCR: {}, IsPDF: {}",
                file.getOriginalFilename(), documentType, forceOcr, isPdf);

        // Validate file type
        String contentType = file.getContentType();
        if (contentType == null || !SUPPORTED_FILE_TYPES.contains(contentType.toLowerCase())) {
            return ResponseEntity.badRequest().body(
                    "Unsupported file type. Supported types: " + String.join(", ", SUPPORTED_FILE_TYPES));
        }

        try {
            // Create a temporary file
            String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            Path tempFile = Files.createTempFile("doc_", filename);
            file.transferTo(tempFile.toFile());

            // Process the document
            Document document;

            // Check if it's a PDF and route accordingly
            if (isPdf || (contentType != null && contentType.toLowerCase().equals("application/pdf"))) {
                logger.info("Processing as PDF file");
                document = ocrPipeline.processDocument(tempFile.toFile(), documentType, forceOcr);
            } else {
                // Normal image processing
                document = ocrPipeline.processDocument(tempFile.toFile(), documentType);
            }

            // Clean up the temporary file
            Files.deleteIfExists(tempFile);

            return ResponseEntity.ok(document);
        } catch (Exception e) {
            logger.error("Error processing document: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Error processing document: " + e.getMessage());
        }
    }

    /**
     * Extract text and data from multiple documents
     *
     * @param files The document image files
     * @param documentType The type of documents (optional)
     * @return The extracted document data
     */
    @PostMapping(value = "/batch-extract", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> extractMultipleDocuments(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam(value = "documentType", required = false) String documentType) {

        logger.info("Received batch document extraction request. Files count: {}, Type: {}",
                files.size(), documentType);

        try {
            List<Document> documents = new ArrayList<>();
            List<Path> tempFiles = new ArrayList<>();

            // Process each file
            for (MultipartFile file : files) {
                String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
                Path tempFile = Files.createTempFile("doc_", filename);
                file.transferTo(tempFile.toFile());
                tempFiles.add(tempFile);

                Document document = ocrPipeline.processDocument(tempFile.toFile(), documentType);
                documents.add(document);
            }

            // Clean up temporary files
            for (Path tempFile : tempFiles) {
                Files.deleteIfExists(tempFile);
            }

            return ResponseEntity.ok(documents);
        } catch (Exception e) {
            logger.error("Error processing documents: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Error processing documents: " + e.getMessage());
        }
    }

    /**
     * Extract text and data from a multi-page PDF document
     * Processes each page and returns separate documents
     *
     * @param file The PDF file
     * @param documentType The type of document (optional)
     * @return List of documents, one per page
     */
    @PostMapping(value = "/extract-pdf-pages", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> extractPdfPages(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "documentType", required = false) String documentType) {

        logger.info("Received PDF page extraction request. File: {}, Type: {}",
                file.getOriginalFilename(), documentType);

        // Validate file is PDF
        String contentType = file.getContentType();
        if (contentType == null || !contentType.toLowerCase().equals("application/pdf")) {
            return ResponseEntity.badRequest().body("Only PDF files are supported for this operation");
        }

        try {
            // Create a temporary file
            String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            Path tempFile = Files.createTempFile("pdf_", filename);
            file.transferTo(tempFile.toFile());

            // Process the document as a whole first to get common information
            Document mainDocument = ocrPipeline.processDocument(tempFile.toFile(), documentType);

            // Clean up
            Files.deleteIfExists(tempFile);

            return ResponseEntity.ok(mainDocument);
        } catch (Exception e) {
            logger.error("Error processing PDF pages: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Error processing PDF pages: " + e.getMessage());
        }
    }
}