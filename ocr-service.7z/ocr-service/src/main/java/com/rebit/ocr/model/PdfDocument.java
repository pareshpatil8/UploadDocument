package com.rebit.ocr.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class for multi-page PDF documents
 */
public class PdfDocument extends Document {

    private int pageCount;
    private List<Document> pages;

    public PdfDocument() {
        super();
        this.setDocumentType("PDF");
        this.pages = new ArrayList<>();
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public List<Document> getPages() {
        return pages;
    }

    public void setPages(List<Document> pages) {
        this.pages = pages;
    }

    public void addPage(Document page) {
        if (this.pages == null) {
            this.pages = new ArrayList<>();
        }
        this.pages.add(page);
    }
}