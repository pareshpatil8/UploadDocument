package com.rebit.ocr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for web pages
 */
@Controller
public class WebController {

    /**
     * Home page
     */
    @GetMapping("/")
    public String home() {
        return "index";
    }

    /**
     * Test page
     */
    @GetMapping("/test")
    public String test() {
        return "index";
    }
}