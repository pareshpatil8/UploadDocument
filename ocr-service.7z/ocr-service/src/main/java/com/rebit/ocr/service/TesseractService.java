package com.rebit.ocr.service;

import net.sourceforge.tess4j.ITessAPI;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.Word;
import org.bytedeco.opencv.opencv_core.Mat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

/**
 * Service for interfacing with Tesseract OCR engine
 */
@Service
public class TesseractService {

    private static final Logger logger = LoggerFactory.getLogger(TesseractService.class);

    private final Tesseract tesseract;
    private final ImageProcessor imageProcessor;

    public TesseractService(ImageProcessor imageProcessor,
                            @Value("${tesseract.data.path:/usr/share/tesseract-ocr/4.00/tessdata}") String dataPath,
                            @Value("${tesseract.language:eng}") String language,
                            @Value("${tesseract.ocr.engine.mode:3}") int ocrEngineMode,
                            @Value("${tesseract.page.seg.mode:3}") int pageSegMode,
                            @Value("${tesseract.user_defined_dpi:300}") String userDefinedDpi,
                            @Value("${tesseract.preserve_interword_spaces:1}") String preserveInterwordSpaces,
                            @Value("${tesseract.textord_tabfind_find_tables:1}") String findTables,
                            @Value("${tesseract.whitelist:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,:-/%$@#() }") String whitelist) {

        this.imageProcessor = imageProcessor;
        logger.info("Initializing Tesseract with data path: {}", dataPath);

        // Validate tessdata directory existence
        File tessDataDir = new File(dataPath);
        if (!tessDataDir.exists() || !tessDataDir.isDirectory()) {
            logger.error("Tessdata path '{}' is invalid. Please check the configuration.", dataPath);
            throw new IllegalArgumentException("Invalid tessdata path: " + dataPath);
        }

        // Initialize Tesseract instance
        tesseract = new Tesseract();
        tesseract.setDatapath(dataPath);

        // Set configurable page segmentation mode and engine mode
        tesseract.setPageSegMode(pageSegMode);
        tesseract.setOcrEngineMode(ocrEngineMode);

        // Set language(s)
        tesseract.setLanguage(language);

        // Set whitelist characters for better invoice recognition
        tesseract.setVariable("tessedit_char_whitelist", whitelist);

        // Additional configuration for better OCR results
        tesseract.setVariable("user_defined_dpi", userDefinedDpi);
        tesseract.setVariable("preserve_interword_spaces", preserveInterwordSpaces);
        tesseract.setVariable("textord_tabfind_find_tables", findTables);

        // Optionally, load extra configuration files if needed
        // tesseract.setConfigs(Arrays.asList("invoice"));

        logger.info("Tesseract configuration: language={}, engineMode={}, pageSegMode={}, dpi={}, whitelist={}",
                language, ocrEngineMode, pageSegMode, userDefinedDpi, whitelist);
    }

    /**
     * Perform OCR on the entire image
     */
    public String performOcr(Mat image) throws TesseractException {
        logger.debug("Performing OCR on entire image");
        BufferedImage bufferedImage = imageProcessor.matToBufferedImage(image);
        return tesseract.doOCR(bufferedImage);
    }

    /**
     * Perform OCR on a specific region of the image
     */
    public String performOcr(Mat image, Rectangle rect) throws TesseractException {
        logger.debug("Performing OCR on region: {}", rect);
        BufferedImage bufferedImage = imageProcessor.matToBufferedImage(image);

        // Extract sub-image from the rectangle region
        BufferedImage subImage = bufferedImage.getSubimage(
                rect.x, rect.y,
                Math.min(rect.width, bufferedImage.getWidth() - rect.x),
                Math.min(rect.height, bufferedImage.getHeight() - rect.y)
        );

        // Perform OCR on the extracted region
        return tesseract.doOCR(subImage);
    }

    /**
     * Get words with their bounding boxes
     */
    public List<Word> getWords(Mat image) throws TesseractException {
        logger.debug("Getting words with bounding boxes from entire image");
        BufferedImage bufferedImage = imageProcessor.matToBufferedImage(image);

        // Use the correct method signature - getWords(BufferedImage, int)
        return tesseract.getWords(bufferedImage, ITessAPI.TessPageIteratorLevel.RIL_WORD);
    }

    /**
     * Get words with their bounding boxes from a specific region
     */
    public List<Word> getWords(Mat image, Rectangle rect) throws TesseractException {
        logger.debug("Getting words with bounding boxes from region: {}", rect);
        BufferedImage bufferedImage = imageProcessor.matToBufferedImage(image);

        // Extract sub-image from the rectangle region
        BufferedImage subImage = bufferedImage.getSubimage(
                rect.x, rect.y,
                Math.min(rect.width, bufferedImage.getWidth() - rect.x),
                Math.min(rect.height, bufferedImage.getHeight() - rect.y)
        );

        // Use the correct method signature - getWords(BufferedImage, int)
        List<Word> words = tesseract.getWords(subImage, ITessAPI.TessPageIteratorLevel.RIL_WORD);

        // Adjust coordinates to be relative to the original image
        for (Word word : words) {
            Rectangle wordRect = word.getBoundingBox();
            wordRect.x += rect.x;
            wordRect.y += rect.y;
        }

        return words;
    }

    /**
     * Configure Tesseract for table recognition
     */
    public void configureForTableRecognition() {
        logger.debug("Configuring Tesseract for table recognition");
        // Use a page segmentation mode that treats the image as a single uniform block of text
        tesseract.setPageSegMode(6); // PSM_SINGLE_BLOCK
    }

    /**
     * Configure Tesseract for invoice header/footer recognition
     */
    public void configureForHeaderFooterRecognition() {
        logger.debug("Configuring Tesseract for header/footer recognition");
        // Use a page segmentation mode that treats the image as a single text line
        tesseract.setPageSegMode(7); // PSM_SINGLE_LINE
    }

    /**
     * Set a specific configuration for Tesseract
     */
    public void setTessVariable(String key, String value) {
        logger.debug("Setting Tesseract variable: {} = {}", key, value);
        tesseract.setVariable(key, value);
    }

    public void configureForTextOnlyRecognition() {
        tesseract.setPageSegMode(4); // PSM_SINGLE_COLUMN
        tesseract.setVariable("tessedit_pageseg_mode", "4");
        tesseract.setVariable("textord_tabfind_find_tables", "0");
    }

    /**
     * Reset Tesseract configuration to default values
     */
    public void resetConfiguration() {
        logger.debug("Resetting Tesseract configuration");
        tesseract.setPageSegMode(3); // PSM_AUTO
        tesseract.setOcrEngineMode(3); // LSTM only
    }


}