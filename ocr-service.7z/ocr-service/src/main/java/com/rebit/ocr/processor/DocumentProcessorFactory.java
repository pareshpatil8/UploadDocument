package com.rebit.ocr.processor;

import com.rebit.ocr.model.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Factory class to get the appropriate document processor based on document type
 */
@Component
public class DocumentProcessorFactory {

    private static final Logger logger = LoggerFactory.getLogger(DocumentProcessorFactory.class);

    private final List<DocumentProcessor<?>> processors;
    private final GenericDocumentProcessor genericProcessor;

    public DocumentProcessorFactory(List<DocumentProcessor<?>> processors, GenericDocumentProcessor genericProcessor) {
        this.processors = processors;
        this.genericProcessor = genericProcessor;
    }

    /**
     * Get the appropriate processor for the document type
     *
     * @param documentType The document type
     * @return The document processor
     */
    public DocumentProcessor<? extends Document> getProcessor(String documentType) {
        logger.debug("Looking for processor for document type: {}", documentType);

        if (documentType == null) {
            logger.debug("No document type specified, using generic processor");
            return genericProcessor;
        }

        // Find the processor that can handle this document type
        for (DocumentProcessor<?> processor : processors) {
            if (processor.canProcess(documentType)) {
                logger.debug("Found processor: {}", processor.getClass().getSimpleName());
                return processor;
            }
        }

        // If no specific processor found, return the generic one
        logger.debug("No specific processor found for type {}, using generic processor", documentType);
        return genericProcessor;
    }
}