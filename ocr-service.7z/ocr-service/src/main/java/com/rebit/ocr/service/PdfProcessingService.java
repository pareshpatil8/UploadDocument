package com.rebit.ocr.service;

import com.rebit.ocr.model.Document;
import com.rebit.ocr.model.Invoice;
import com.rebit.ocr.model.InvoiceLineItem;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.rendering.ImageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.bytedeco.opencv.opencv_core.Mat;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service for processing PDF documents
 * Handles both text-based and image-based PDFs
 */
@Service
public class PdfProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(PdfProcessingService.class);
    private static final int MIN_TEXT_LENGTH = 100; // Minimum text length to consider a PDF as readable

    private final ImageProcessor imageProcessor;
    private final TesseractService tesseractService;

    public PdfProcessingService(ImageProcessor imageProcessor, TesseractService tesseractService) {
        this.imageProcessor = imageProcessor;
        this.tesseractService = tesseractService;
    }

    /**
     * Check if a PDF file contains readable text or is scanned
     *
     * @param pdfFile PDF file to check
     * @return true if PDF has readable text, false if it appears to be scanned
     */
    public boolean isPdfReadable(File pdfFile) {
        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(document);

            // A PDF is considered readable if it contains a sufficient amount of text
            boolean isReadable = text.length() > MIN_TEXT_LENGTH;
            logger.info("PDF {} is {}readable. Text length: {}",
                    pdfFile.getName(),
                    isReadable ? "" : "not ",
                    text.length());

            return isReadable;
        } catch (IOException e) {
            logger.error("Error checking if PDF is readable: {}", e.getMessage(), e);
            return false;
        }
    }

    /**
     * Extract text from a readable PDF file
     *
     * @param pdfFile PDF file to process
     * @return Full text extracted from the PDF
     */
    public String extractTextFromPdf(File pdfFile) throws IOException {
        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            // Process all pages
            stripper.setStartPage(1);
            stripper.setEndPage(document.getNumberOfPages());

            String text = stripper.getText(document);
            logger.info("Extracted {} characters of text from PDF {}",
                    text.length(), pdfFile.getName());

            return text;
        }
    }

    /**
     * Extract text from specific page of a PDF file
     *
     * @param pdfFile PDF file to process
     * @param pageNum Page number (1-based)
     * @return Text extracted from the specified page
     */
    public String extractTextFromPage(File pdfFile, int pageNum) throws IOException {
        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setStartPage(pageNum);
            stripper.setEndPage(pageNum);

            return stripper.getText(document);
        }
    }

    /**
     * Get the number of pages in a PDF file
     *
     * @param pdfFile PDF file to check
     * @return Number of pages
     */
    public int getPageCount(File pdfFile) throws IOException {
        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            return document.getNumberOfPages();
        }
    }

    /**
     * Process a readable PDF to extract invoice data
     *
     * @param pdfFile PDF file to process
     * @return Invoice document with extracted data
     */
    public Invoice processReadablePdf(File pdfFile) throws IOException {
        logger.info("Processing readable PDF: {}", pdfFile.getName());

        String fullText = extractTextFromPdf(pdfFile);

        // Create invoice object
        Invoice invoice = new Invoice();
        invoice.setId(UUID.randomUUID().toString());
        invoice.setFullText(fullText);

        // Extract key invoice information
        extractInvoiceInfo(fullText, invoice);

        // Extract line items - for multi-page invoices, this might need special handling
        extractLineItems(fullText, invoice);

        logger.info("Completed processing readable PDF invoice: {}", pdfFile.getName());
        return invoice;
    }

    /**
     * Extract invoice information using regex patterns
     *
     * @param text Full text extracted from PDF
     * @param invoice Invoice object to populate
     */
    private void extractInvoiceInfo(String text, Invoice invoice) {
        logger.debug("Extracting invoice information from text");

        // Extract Invoice Number
        extractInvoiceNumber(text, invoice);

        // Extract Invoice Date
        extractInvoiceDate(text, invoice);

        // Extract GSTIN Number
        extractGstinNumber(text, invoice);

        // Extract Seller and Buyer information
        extractPartyDetails(text, invoice);

        // Extract Total Amount
        extractTotalAmount(text, invoice);

        // Extract Tax Information
        extractTaxInformation(text, invoice);
    }

    /**
     * Process a PDF file as non-readable (scanned), forcing OCR regardless of content
     *
     * @param pdfFile PDF file to process
     * @return Processed document
     */
    public Document processNonReadablePdf(File pdfFile) throws Exception {
        logger.info("Processing PDF as non-readable (forced OCR): {}", pdfFile.getName());

        // Create an Invoice object to store the results
        Invoice invoice = new Invoice();
        invoice.setId(UUID.randomUUID().toString());

        // Convert PDF pages to images for OCR
        List<Path> imagePaths = convertPdfToImages(pdfFile);
        StringBuilder fullText = new StringBuilder();

        // Process each page with OCR
        for (int i = 0; i < imagePaths.size(); i++) {
            Path imagePath = imagePaths.get(i);
            try {
                // Load the image for OCR
                Mat image = imageProcessor.loadImage(imagePath.toFile());

                // Preprocess the image
                Mat preprocessed = imageProcessor.preprocess(image);

                // Perform OCR
                String pageText = tesseractService.performOcr(preprocessed);
                fullText.append(pageText).append("\n\n");

                // For the first page, extract header information
                if (i == 0) {
                    extractInvoiceInfo(pageText, invoice);
                }

                // Extract line items from each page
                extractLineItems(pageText, invoice);

            } finally {
                // Clean up temporary image file
                Files.deleteIfExists(imagePath);
            }
        }

        // Set the full text
        invoice.setFullText(fullText.toString());

        // Add metadata to indicate this was processed with forced OCR
        invoice.addMetadata("processingMethod", "forcedOcr");
        invoice.addMetadata("pageCount", String.valueOf(imagePaths.size()));

        return invoice;
    }

    /**
     * Extract invoice number using regex patterns
     */
    private void extractInvoiceNumber(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("Invoice No[.:\\s]+([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Invoice Number[.:\\s]+([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Invoice #[.:\\s]*([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Bill No[.:\\s]+([A-Za-z0-9\\-/]+)"));
        patterns.add(Pattern.compile("Number[.:\\s]+([A-Za-z0-9\\-/]+)"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String invoiceNumber = matcher.group(1).trim();
                invoice.setInvoiceNumber(invoiceNumber);
                logger.debug("Found Invoice Number: {}", invoiceNumber);
                return;
            }
        }

        logger.debug("Invoice Number not found");
    }

    /**
     * Extract invoice date using regex patterns
     */
    private void extractInvoiceDate(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("Invoice Date[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Date[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));
        patterns.add(Pattern.compile("Date[.:\\s]+([0-9]{1,2}\\s+[A-Za-z]{3}\\s+[0-9]{2,4})"));
        patterns.add(Pattern.compile("Dated[.:\\s]+([0-9]{1,2}[-/][0-9]{1,2}[-/][0-9]{2,4})"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String invoiceDate = matcher.group(1).trim();
                invoice.setInvoiceDate(invoiceDate);
                logger.debug("Found Invoice Date: {}", invoiceDate);
                return;
            }
        }

        logger.debug("Invoice Date not found");
    }

    /**
     * Extract GSTIN number using regex patterns
     */
    private void extractGstinNumber(String text, Invoice invoice) {
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("GSTIN[:\\s]+([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));
        patterns.add(Pattern.compile("GST[:\\s]+([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));
        patterns.add(Pattern.compile("([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z]{1}[0-9A-Z]{1})"));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String gstin = matcher.group(1).trim();
                invoice.setGstinNumber(gstin);
                logger.debug("Found GSTIN: {}", gstin);
                return;
            }
        }

        logger.debug("GSTIN not found");
    }

    /**
     * Extract party (seller/buyer) details using regex patterns
     */
    private void extractPartyDetails(String text, Invoice invoice) {
        // Extract seller information using various common patterns
        List<Pattern> sellerPatterns = new ArrayList<>();
        sellerPatterns.add(Pattern.compile("(?:Seller|From|Billed From|Company|Supplier)[.:\\s]+([\\w\\s.,&-]+)"));
        sellerPatterns.add(Pattern.compile("(?:Company Name|Business Name)[.:\\s]+([\\w\\s.,&-]+)"));

        // Try to extract from company headers in the document
        for (Pattern pattern : sellerPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String sellerName = matcher.group(1).trim();
                invoice.setSellerName(sellerName);
                logger.debug("Found Seller Name: {}", sellerName);
                break;
            }
        }

        // If no seller name found yet, try extracting from GSTIN
        if (invoice.getSellerName() == null && invoice.getGstinNumber() != null) {
            // Look for lines near the GSTIN
            int gstinIndex = text.indexOf(invoice.getGstinNumber());
            if (gstinIndex > 0) {
                // Look for company name in the 3 lines before GSTIN
                String beforeGstin = text.substring(Math.max(0, gstinIndex - 200), gstinIndex);
                String[] lines = beforeGstin.split("\\n");
                if (lines.length > 0) {
                    // Use the last non-empty line before GSTIN as company name
                    for (int i = lines.length - 1; i >= 0; i--) {
                        String line = lines[i].trim();
                        if (!line.isEmpty() && !line.contains("GSTIN") && !line.contains("GST")) {
                            invoice.setSellerName(line);
                            logger.debug("Found Seller Name from GSTIN context: {}", line);
                            break;
                        }
                    }
                }
            }
        }

        // Extract seller address
        List<Pattern> addressPatterns = new ArrayList<>();
        addressPatterns.add(Pattern.compile("(?:Address|Location|Registered Office)[.:\\s]+([\\w\\s.,&\\-/]+)"));

        for (Pattern pattern : addressPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String address = matcher.group(1).trim();
                // Clean up address - remove very long strings that might be false matches
                if (address.length() < 200) {
                    invoice.setSellerAddress(address);
                    logger.debug("Found Seller Address: {}", address);
                    break;
                }
            }
        }

        // If we have a seller name but no address, try to find address after the name
        if (invoice.getSellerName() != null && invoice.getSellerAddress() == null) {
            int nameIndex = text.indexOf(invoice.getSellerName());
            if (nameIndex > 0) {
                // Get 2-3 lines after the company name as potential address
                String afterName = text.substring(nameIndex + invoice.getSellerName().length(),
                        Math.min(text.length(), nameIndex + invoice.getSellerName().length() + 200));
                String[] lines = afterName.split("\\n", 4); // Limit to 3 lines
                if (lines.length > 1) {
                    StringBuilder address = new StringBuilder();
                    // Skip first line (it's the end of the company name line)
                    for (int i = 1; i < Math.min(3, lines.length); i++) {
                        String line = lines[i].trim();
                        if (!line.isEmpty() && !line.contains("GSTIN") && !line.contains("Invoice")) {
                            address.append(line).append(" ");
                        }
                    }
                    if (address.length() > 0) {
                        invoice.setSellerAddress(address.toString().trim());
                        logger.debug("Found Seller Address from context: {}", invoice.getSellerAddress());
                    }
                }
            }
        }

        // Extract buyer/customer name - try various patterns
        List<Pattern> buyerPatterns = new ArrayList<>();
        buyerPatterns.add(Pattern.compile("(?:Buyer|To|Bill To|Ship To|Customer|Client)[.:\\s]+([\\w\\s.,&-]+)"));
        buyerPatterns.add(Pattern.compile("(?:Customer Name|Billing Name)[.:\\s]+([\\w\\s.,&-]+)"));
        buyerPatterns.add(Pattern.compile("Passenger Name[.:\\s]+([\\w\\s]+)"));
        buyerPatterns.add(Pattern.compile("Name of Customer[.:\\s]+([\\w\\s.,&-]+)"));

        for (Pattern pattern : buyerPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String buyerName = matcher.group(1).trim();
                invoice.setBuyerName(buyerName);
                logger.debug("Found Buyer Name: {}", buyerName);
                break;
            }
        }

        // Extract buyer address
        List<Pattern> buyerAddressPatterns = new ArrayList<>();
        buyerAddressPatterns.add(Pattern.compile("(?:Billing Address|Customer Address|Shipped To)[.:\\s]+([\\w\\s.,&\\-/]+)"));

        for (Pattern pattern : buyerAddressPatterns) {
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                String address = matcher.group(1).trim();
                if (address.length() < 200) {
                    invoice.setBuyerAddress(address);
                    logger.debug("Found Buyer Address: {}", address);
                    break;
                }
            }
        }
    }

    /**
     * Extract total amount using regex patterns
     */
    private void extractTotalAmount(String text, Invoice invoice) {
        // Define patterns to match various total formats
        List<Pattern> patterns = new ArrayList<>();

        // Pattern for "Grand Total" with multiple columns
        patterns.add(Pattern.compile("(?:Grand Total|Total Amount)[\\s:]*([$₹Rs.\\s]*[\\d,.]+)"));

        // Pattern for "Total(Incl Taxes)" as seen in some invoices
        patterns.add(Pattern.compile("Total\\s*(?:\\(Incl\\s*Taxes\\)|\\(Including GST\\))[\\s:]*([$₹Rs.\\s]*[\\d.,]+)"));

        // Pattern for "Amount Payable" or "Net Amount"
        patterns.add(Pattern.compile("(?:Amount Payable|Net Amount|Balance Due|Amount Due)[\\s:]*([$₹Rs.\\s]*[\\d.,]+)"));

        // Simple "Total" pattern - try last since it might match subtotals
        patterns.add(Pattern.compile("Total[\\s:]*([$₹Rs.\\s]*[\\d.,]+)"));

        // Pattern for finding the last occurrence of money amount after the word "Total"
        patterns.add(Pattern.compile("Total(?:(?!Total).)*?([$₹Rs.\\s]*[\\d.,]+)(?!.*Total)", Pattern.DOTALL));

        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(text);

            // For most patterns, find the first occurrence
            if (patterns.indexOf(pattern) != patterns.size() - 1) {
                if (matcher.find()) {
                    String amount = matcher.group(1).replaceAll("[^0-9.]", "");

                    // Basic validation - amounts should be reasonable
                    if (!amount.isEmpty() && amount.length() <= 10) { // Limit to 10 digits
                        invoice.setTotalAmount(amount);
                        logger.debug("Found Total Amount: {}", amount);
                        return;
                    }
                }
            } else {
                // For the last pattern, find the last occurrence
                String lastMatch = null;
                while (matcher.find()) {
                    lastMatch = matcher.group(1).replaceAll("[^0-9.]", "");
                }

                if (lastMatch != null && !lastMatch.isEmpty() && lastMatch.length() <= 10) {
                    invoice.setTotalAmount(lastMatch);
                    logger.debug("Found Total Amount (last match): {}", lastMatch);
                    return;
                }
            }
        }

        // Fallback: Look for the largest amount in the document that appears after keywords
        // like "Total", "Amount", "Due", "Payable"
        Pattern amountPattern = Pattern.compile("([$₹Rs.\\s]*[\\d.,]+)");
        Matcher amountMatcher = amountPattern.matcher(text);

        double largestAmount = 0.0;
        String largestAmountStr = null;

        while (amountMatcher.find()) {
            String amountStr = amountMatcher.group(1).replaceAll("[^0-9.]", "");

            try {
                double amount = Double.parseDouble(amountStr);

                // Check if this appears after a total indicator word
                int pos = amountMatcher.start();
                String precedingText = text.substring(Math.max(0, pos - 50), pos).toLowerCase();

                if ((precedingText.contains("total") ||
                        precedingText.contains("amount") ||
                        precedingText.contains("due") ||
                        precedingText.contains("payable")) &&
                        amount > largestAmount) {

                    largestAmount = amount;
                    largestAmountStr = amountStr;
                }
            } catch (NumberFormatException e) {
                // Skip invalid numbers
            }
        }

        if (largestAmountStr != null) {
            invoice.setTotalAmount(largestAmountStr);
            logger.debug("Found Total Amount (largest after keyword): {}", largestAmountStr);
            return;
        }

        logger.debug("Total Amount not found");
    }

    /**
     * Extract tax information using regex patterns
     */
    private void extractTaxInformation(String text, Invoice invoice) {
        // Extract CGST
        Pattern cgstPattern = Pattern.compile("CGST[\\s\\w]*([\\d.]+)[\\s%]*([\\d.,]+)");
        Matcher cgstMatcher = cgstPattern.matcher(text);
        if (cgstMatcher.find()) {
            invoice.setCgstAmount(cgstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found CGST Amount: {}", invoice.getCgstAmount());
        }

        // Extract SGST
        Pattern sgstPattern = Pattern.compile("SGST[\\s\\w/]*([\\d.]+)[\\s%]*([\\d.,]+)");
        Matcher sgstMatcher = sgstPattern.matcher(text);
        if (sgstMatcher.find()) {
            invoice.setSgstAmount(sgstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found SGST Amount: {}", invoice.getSgstAmount());
        }

        // Extract IGST
        Pattern igstPattern = Pattern.compile("IGST[\\s\\w]*([\\d.]+)[\\s%]*([\\d.,]+)");
        Matcher igstMatcher = igstPattern.matcher(text);
        if (igstMatcher.find()) {
            invoice.setIgstAmount(igstMatcher.group(2).replaceAll("[^0-9.]", ""));
            logger.debug("Found IGST Amount: {}", invoice.getIgstAmount());
        }

        // Extract taxable amount
        Pattern taxablePattern = Pattern.compile("Taxable[\\s\\w]*([\\d.,]+)");
        Matcher taxableMatcher = taxablePattern.matcher(text);
        if (taxableMatcher.find()) {
            invoice.setTaxableAmount(taxableMatcher.group(1).replaceAll("[^0-9.]", ""));
            logger.debug("Found Taxable Amount: {}", invoice.getTaxableAmount());
        }
    }

    /**
     * Extract line items from text using table-like patterns
     */
    private void extractLineItems(String text, Invoice invoice) {
        logger.debug("Extracting line items");

        // First check if we can find a clearly delineated table structure
        boolean tableFound = false;

        // Pattern 1: Look for table headers with common invoice columns
        // This pattern works for many structured invoices with clearly defined tables
        if (text.contains("Description") || text.contains("Item") || text.contains("Particulars")) {

            // Define several patterns to match different table formats
            List<Pattern> tablePatterns = new ArrayList<>();

            // Pattern for tables with description, hsn/sac, quantity, rate, amount
            tablePatterns.add(Pattern.compile(
                    "(?:^|\\n)\\s*(?:([\\w\\s.,&\\-/]+))\\s+(?:([\\w\\d]+))\\s+(?:(\\d[\\d.,]+))\\s+(?:(\\d[\\d.,]+))\\s+(?:(\\d[\\d.,]+))",
                    Pattern.MULTILINE));

            // Pattern for tables with just description and amount
            tablePatterns.add(Pattern.compile(
                    "(?:^|\\n)\\s*(?:([\\w\\s.,&\\-/]+?))\\s+(?:(\\d[\\d.,]+))(?:\\s|$)",
                    Pattern.MULTILINE));

            // Try each pattern
            for (Pattern pattern : tablePatterns) {
                Matcher matcher = pattern.matcher(text);
                boolean foundItems = false;

                while (matcher.find()) {
                    String description = matcher.group(1).trim();

                    // Skip header rows, total rows, or empty descriptions
                    if (description.isEmpty() ||
                            description.equalsIgnoreCase("Description") ||
                            description.equalsIgnoreCase("Item") ||
                            description.equalsIgnoreCase("Particulars") ||
                            description.contains("Total") ||
                            description.contains("Subtotal") ||
                            description.contains("Grand")) {
                        continue;
                    }

                    InvoiceLineItem lineItem = new InvoiceLineItem();
                    lineItem.setDescription(description);

                    // Different patterns will have different group counts
                    if (matcher.groupCount() >= 5) {
                        // Full table format with HSN/SAC, Qty, Rate, Amount
                        lineItem.setHsnCode(matcher.group(2).trim());
                        lineItem.setQuantity(matcher.group(3).trim());
                        lineItem.setRate(matcher.group(4).trim());
                        lineItem.setAmount(matcher.group(5).trim().replaceAll("[^0-9.]", ""));
                    } else if (matcher.groupCount() >= 2) {
                        // Simplified format with just description and amount
                        lineItem.setAmount(matcher.group(2).trim().replaceAll("[^0-9.]", ""));
                    }

                    // Only add if we have at least description and amount
                    if (description.length() > 0 && lineItem.getAmount() != null &&
                            !lineItem.getAmount().isEmpty()) {
                        invoice.addLineItem(lineItem);
                        logger.debug("Added line item: {}, Amount: {}", description, lineItem.getAmount());
                        foundItems = true;
                        tableFound = true;
                    }
                }

                // If we found items with this pattern, no need to try others
                if (foundItems) {
                    break;
                }
            }
        }

        // If no table structure found, try a fallback method to extract key items
        if (!tableFound && invoice.getLineItems().isEmpty()) {
            logger.debug("No structured table found, trying fallback item extraction");

            // Look for patterns like "Air Travel and related charges 5,910.00"
            Pattern simplePattern = Pattern.compile(
                    "([\\w\\s.,&\\-/]+?)\\s+(\\d[\\d.,]+)(?:\\s|$)");

            Matcher matcher = simplePattern.matcher(text);
            while (matcher.find()) {
                String description = matcher.group(1).trim();
                String amount = matcher.group(2).trim().replaceAll("[^0-9.]", "");

                // Skip likely non-item rows
                if (description.isEmpty() ||
                        description.length() < 3 ||
                        description.contains("Total") ||
                        description.contains("GSTIN") ||
                        description.equalsIgnoreCase("Amount") ||
                        description.contains("Subtotal")) {
                    continue;
                }

                InvoiceLineItem lineItem = new InvoiceLineItem();
                lineItem.setDescription(description);
                lineItem.setAmount(amount);

                invoice.addLineItem(lineItem);
                logger.debug("Added fallback line item: {}, Amount: {}", description, amount);
            }
        }

        // Final fallback - if we still don't have line items but have total amount
        // Create a generic line item
        if (invoice.getLineItems().isEmpty() && invoice.getTotalAmount() != null) {
            InvoiceLineItem lineItem = new InvoiceLineItem();
            lineItem.setDescription("Invoice Total");
            lineItem.setAmount(invoice.getTotalAmount());
            invoice.addLineItem(lineItem);
            logger.debug("Added generic line item with total amount: {}", invoice.getTotalAmount());
        }
    }

    /**
     * Convert a PDF page to an image for OCR processing
     *
     * @param pdfFile PDF file to convert
     * @param pageNum Page number (0-based index)
     * @return Path to the created image file
     */
    public Path convertPdfPageToImage(File pdfFile, int pageNum) throws IOException {
        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(document);

            // Render with higher DPI for better OCR results (300 DPI is good for OCR)
            BufferedImage image = renderer.renderImageWithDPI(pageNum, 300, ImageType.RGB);

            // Create a temporary file for the image
            Path tempImagePath = Files.createTempFile("pdf_page_", ".png");
            File tempImageFile = tempImagePath.toFile();

            // Save the image
            ImageIO.write(image, "PNG", tempImageFile);
            logger.info("Converted page {} of PDF {} to image {}",
                    pageNum + 1, pdfFile.getName(), tempImagePath);

            return tempImagePath;
        }
    }

    /**
     * Process a non-readable (scanned) PDF by converting to images and using OCR
     *
     * @param pdfFile PDF file to process
     * @return List of temporary image files created from PDF pages
     */
    public List<Path> convertPdfToImages(File pdfFile) throws IOException {
        List<Path> imagePaths = new ArrayList<>();

        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(document);
            int pageCount = document.getNumberOfPages();

            logger.info("Converting {} pages of PDF {} to images", pageCount, pdfFile.getName());

            for (int i = 0; i < pageCount; i++) {
                // Convert each page to an image
                Path imagePath = convertPdfPageToImage(pdfFile, i);
                imagePaths.add(imagePath);
            }
        }

        return imagePaths;
    }

    /**
     * Process a PDF file that may be readable or scanned
     *
     * @param pdfFile PDF file to process
     * @return Processed document
     */
    public Document processPdf(File pdfFile) throws Exception {
        logger.info("Processing PDF file: {}", pdfFile.getName());

        // Check if PDF has readable text
        if (isPdfReadable(pdfFile)) {
            // Process as readable PDF
            return processReadablePdf(pdfFile);
        } else {
            // Process as scanned PDF - convert to images and use OCR
            logger.info("PDF appears to be scanned, converting to images for OCR");

            // Create an Invoice object to store the results
            Invoice invoice = new Invoice();
            invoice.setId(UUID.randomUUID().toString());

            List<Path> imagePaths = convertPdfToImages(pdfFile);
            StringBuilder fullText = new StringBuilder();

            // Process each page with OCR
            for (int i = 0; i < imagePaths.size(); i++) {
                Path imagePath = imagePaths.get(i);
                try {
                    // Load the image for OCR
                    Mat image = imageProcessor.loadImage(imagePath.toFile());

                    // Preprocess the image
                    Mat preprocessed = imageProcessor.preprocess(image);

                    // Perform OCR
                    String pageText = tesseractService.performOcr(preprocessed);
                    fullText.append(pageText).append("\n\n");

                    // For the first page, extract header information
                    if (i == 0) {
                        extractInvoiceInfo(pageText, invoice);
                    }

                    // Extract line items from each page
                    // This is a simplified approach - might need more sophisticated table detection
                    extractLineItems(pageText, invoice);

                } finally {
                    // Clean up temporary image file
                    Files.deleteIfExists(imagePath);
                }
            }

            // Set the full text
            invoice.setFullText(fullText.toString());

            return invoice;
        }
    }
}