package com.rebit.ocr.processor;

import com.rebit.ocr.model.Document;
import java.io.File;

/**
 * Interface for document processors
 * Different implementations can handle different document types
 */
public interface DocumentProcessor<T extends Document> {

    /**
     * Process a document image and extract structured data
     *
     * @param imageFile The input image file
     * @return The processed document
     * @throws Exception If processing fails
     */
    T process(File imageFile) throws Exception;

    /**
     * Check if this processor can handle the given document type
     *
     * @param documentType The document type to check
     * @return true if this processor can handle the document type
     */
    boolean canProcess(String documentType);

    /**
     * Get the document type this processor handles
     *
     * @return The document type
     */
    String getDocumentType();
}