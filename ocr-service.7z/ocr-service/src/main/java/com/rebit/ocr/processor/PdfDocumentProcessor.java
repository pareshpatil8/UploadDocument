package com.rebit.ocr.processor;

import com.rebit.ocr.model.Document;
import com.rebit.ocr.model.Invoice;
import com.rebit.ocr.model.PdfDocument;
import com.rebit.ocr.service.ImageProcessor;
import com.rebit.ocr.service.PdfProcessingService;
import com.rebit.ocr.service.TesseractService;
import org.bytedeco.opencv.opencv_core.Mat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

/**
 * Processor for PDF documents
 */
@Component
public class PdfDocumentProcessor implements DocumentProcessor<Document> {

    private static final Logger logger = LoggerFactory.getLogger(PdfDocumentProcessor.class);

    private final PdfProcessingService pdfProcessingService;
    private final ImageProcessor imageProcessor;
    private final TesseractService tesseractService;

    public PdfDocumentProcessor(PdfProcessingService pdfProcessingService, ImageProcessor imageProcessor, TesseractService tesseractService) {
        this.pdfProcessingService = pdfProcessingService;
        this.tesseractService = tesseractService;
        this.imageProcessor = imageProcessor;
    }

    @Override
    public Document process(File pdfFile) throws Exception {
        logger.info("Processing PDF document: {}", pdfFile.getName());

        // Check if this is a readable PDF
        if (pdfProcessingService.isPdfReadable(pdfFile)) {
            logger.info("PDF is readable, processing as text-based PDF");

            // For invoice document type
            if (getDocumentType().equals("INVOICE")) {
                return pdfProcessingService.processReadablePdf(pdfFile);
            } else {
                // For other document types, just extract text
                String fullText = pdfProcessingService.extractTextFromPdf(pdfFile);
                Document document = new Document();
                document.setDocumentType(getDocumentType());
                document.setFullText(fullText);
                return document;
            }
        } else {
            // For scanned PDFs, use the OCR pipeline
            logger.info("PDF appears to be scanned, processing with OCR");
            return pdfProcessingService.processPdf(pdfFile);
        }
    }

    /**
     * Process a multi-page PDF with option to force OCR
     *
     * @param pdfFile PDF file to process
     * @param forceOcr Force OCR processing even for readable PDFs
     * @return PdfDocument containing page-specific documents
     */
    public PdfDocument processMultiPage(File pdfFile, boolean forceOcr) throws Exception {
        logger.info("Processing multi-page PDF document: {}, ForceOCR: {}", pdfFile.getName(), forceOcr);

        PdfDocument pdfDocument = new PdfDocument();

        try {
            // Get page count
            int pageCount = pdfProcessingService.getPageCount(pdfFile);
            pdfDocument.setPageCount(pageCount);

            // Extract text from the entire document for overall context if it's readable
            boolean isReadable = !forceOcr && pdfProcessingService.isPdfReadable(pdfFile);
            String fullText = isReadable ?
                    pdfProcessingService.extractTextFromPdf(pdfFile) :
                    "PDF processed with OCR - see individual pages for extracted text";

            pdfDocument.setFullText(fullText);
            pdfDocument.addMetadata("isPdfReadable", String.valueOf(isReadable));
            pdfDocument.addMetadata("forceOcr", String.valueOf(forceOcr));

            // Process based on readability and forceOcr settings
            if (isReadable && !forceOcr) {
                logger.info("Processing {} pages from readable PDF", pageCount);

                // Process each page
                for (int i = 1; i <= pageCount; i++) {
                    String pageText = pdfProcessingService.extractTextFromPage(pdfFile, i);

                    Document pageDocument = new Document();
                    pageDocument.setDocumentType(getDocumentType());
                    pageDocument.setFullText(pageText);
                    pageDocument.addMetadata("page", String.valueOf(i));
                    pageDocument.addMetadata("totalPages", String.valueOf(pageCount));

                    pdfDocument.addPage(pageDocument);
                }
            } else {
                // For forced OCR or non-readable PDFs, convert to images and use OCR
                logger.info("Processing {} pages from " + (forceOcr ? "forced OCR" : "scanned") + " PDF", pageCount);

                // Process each page using OCR
                for (int i = 0; i < pageCount; i++) {
                    // Convert the page to an image
                    java.nio.file.Path imagePath = pdfProcessingService.convertPdfPageToImage(pdfFile, i);

                    try {
                        // Process the image of this page
                        Mat image = imageProcessor.loadImage(imagePath.toFile());
                        Mat preprocessed = imageProcessor.preprocess(image);
                        String pageText = tesseractService.performOcr(preprocessed);

                        Document pageDocument = new Document();
                        pageDocument.setDocumentType(getDocumentType());
                        pageDocument.setFullText(pageText);
                        pageDocument.addMetadata("page", String.valueOf(i + 1));
                        pageDocument.addMetadata("totalPages", String.valueOf(pageCount));
                        pageDocument.addMetadata("ocrProcessed", "true");

                        pdfDocument.addPage(pageDocument);
                    } finally {
                        // Clean up the temporary image
                        java.nio.file.Files.deleteIfExists(imagePath);
                    }
                }
            }

            return pdfDocument;
        } catch (IOException e) {
            logger.error("Error processing multi-page PDF: {}", e.getMessage(), e);
            throw new Exception("Failed to process multi-page PDF: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean canProcess(String documentType) {
        return "PDF".equalsIgnoreCase(documentType) || "INVOICE".equalsIgnoreCase(documentType);
    }

    @Override
    public String getDocumentType() {
        return "PDF";
    }
}