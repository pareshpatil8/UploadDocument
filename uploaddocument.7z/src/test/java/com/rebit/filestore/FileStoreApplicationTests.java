package com.rebit.filestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
