/**
 * Common JavaScript utilities for the File Storage UI
 */

// Format file size in human-readable format
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Format date to local string
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString();
}

// Get file icon based on file type
function getFileIcon(fileType) {
    let icon = 'fa-file';

    if (!fileType) {
        return icon;
    }

    const type = fileType.toLowerCase();

    if (type.includes('pdf')) {
        icon = 'fa-file-pdf';
    } else if (type.includes('word') || type.includes('docx') || type.includes('doc')) {
        icon = 'fa-file-word';
    } else if (type.includes('excel') || type.includes('xlsx') || type.includes('xls')) {
        icon = 'fa-file-excel';
    } else if (type.includes('powerpoint') || type.includes('pptx') || type.includes('ppt')) {
        icon = 'fa-file-powerpoint';
    } else if (type.includes('image') || type.includes('jpg') || type.includes('png') || type.includes('gif')) {
        icon = 'fa-file-image';
    } else if (type.includes('text') || type.includes('txt')) {
        icon = 'fa-file-alt';
    } else if (type.includes('zip') || type.includes('rar') || type.includes('tar') || type.includes('7z')) {
        icon = 'fa-file-archive';
    } else if (type.includes('audio') || type.includes('mp3') || type.includes('wav')) {
        icon = 'fa-file-audio';
    } else if (type.includes('video') || type.includes('mp4') || type.includes('avi')) {
        icon = 'fa-file-video';
    } else if (type.includes('code') || type.includes('xml') || type.includes('json') || type.includes('html')) {
        icon = 'fa-file-code';
    }

    return icon;
}

// Get status badge class based on document status
function getStatusBadgeClass(status) {
    if (!status) return 'status-badge status-unknown';

    const statusLower = status.toLowerCase();

    switch (statusLower) {
        case 'pending':
            return 'status-badge status-pending';
        case 'processing':
            return 'status-badge status-processing';
        case 'completed':
            return 'status-badge status-completed';
        case 'failed':
            return 'status-badge status-failed';
        case 'archiving':
            return 'status-badge status-archiving';
        case 'archived':
            return 'status-badge status-archived';
        case 'deleting':
            return 'status-badge status-deleting';
        case 'deleted':
            return 'status-badge status-deleted';
        default:
            return 'status-badge status-unknown';
    }
}

// Show alert message
function showAlert(type, message, timeout = 5000) {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    // Insert at the top of the content
    const contentContainer = document.querySelector('.main-content .container');
    contentContainer.insertBefore(alertContainer, contentContainer.firstChild);

    // Auto-close after timeout
    if (timeout > 0) {
        setTimeout(() => {
            alertContainer.classList.remove('show');
            setTimeout(() => alertContainer.remove(), 150);
        }, timeout);
    }
}

// Copy text to clipboard
function copyToClipboard(text) {
    // Create temporary element
    const el = document.createElement('textarea');
    el.value = text;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);

    // Select text and copy
    el.select();
    document.execCommand('copy');

    // Remove temporary element
    document.body.removeChild(el);

    return true;
}

// Add event listener for copy buttons
document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners to copy buttons
    document.querySelectorAll('.copy-btn').forEach(button => {
        button.addEventListener('click', function() {
            const targetSelector = this.getAttribute('data-clipboard-target');
            const targetElement = document.querySelector(targetSelector);

            if (targetElement) {
                copyToClipboard(targetElement.innerText);

                // Change button text temporarily
                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check"></i> Copied!';

                setTimeout(() => {
                    this.innerHTML = originalHtml;
                }, 2000);
            }
        });
    });
});