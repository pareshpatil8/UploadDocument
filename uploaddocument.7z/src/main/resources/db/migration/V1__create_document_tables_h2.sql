-- Create sequences for ID generation
CREATE SEQUENCE DOCUMENT_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE DOCUMENT_CHUNK_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE DOCUMENT_METADATA_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE STORAGE_FOLDER_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE CUSTODY_RECORD_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE ASYNC_OPERATION_ID_SEQ START WITH 1 INCREMENT BY 1;

-- Create DOCUMENTS table
CREATE TABLE DOCUMENTS (
                           ID BIGINT PRIMARY KEY,
                           TOKEN VARCHAR(50) UNIQUE NOT NULL,
                           MODULE VARCHAR(100) NOT NULL,
                           DEPARTMENT VARCHAR(100) NOT NULL,
                           FILE_NAME VARCHAR(255) NOT NULL,
                           FILE_TYPE VARCHAR(50) NOT NULL,
                           SIZE BIGINT NOT NULL,
                           CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                           LAST_ACCESSED_DATE TIMESTAMP,
                           LAST_MODIFIED_DATE TIMESTAMP,
                           STATUS VARCHAR(20) NOT NULL,
                           STORAGE_LEVEL VARCHAR(10) DEFAULT 'PRIMARY' NOT NULL,
                           OCR_TEXT CLOB,
                           OCR_REQUESTED BOOLEAN DEFAULT FALSE NOT NULL,
                           HASH VARCHAR(64)
);

-- Create STORAGE_FOLDERS table
CREATE TABLE STORAGE_FOLDERS (
                                 ID BIGINT PRIMARY KEY,
                                 BASE_PATH VARCHAR(500) NOT NULL,
                                 RELATIVE_PATH VARCHAR(500) NOT NULL,
                                 FULL_PATH VARCHAR(1000) NOT NULL,
                                 STORAGE_LEVEL VARCHAR(10) NOT NULL,
                                 FILE_COUNT INT DEFAULT 0 NOT NULL,
                                 MAX_FILE_COUNT INT NOT NULL,
                                 TOTAL_SIZE BIGINT DEFAULT 0 NOT NULL,
                                 CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                 LAST_MODIFIED_DATE TIMESTAMP,
                                 CONSTRAINT UK_STORAGE_FOLDER_PATH UNIQUE (BASE_PATH, RELATIVE_PATH)
);

-- Create DOCUMENT_CHUNKS table
CREATE TABLE DOCUMENT_CHUNKS (
                                 ID BIGINT PRIMARY KEY,
                                 DOCUMENT_ID BIGINT NOT NULL,
                                 SEQUENCE_NUMBER INT NOT NULL,
                                 SIZE BIGINT NOT NULL,
                                 COMPRESSED_SIZE BIGINT NOT NULL,
                                 COMPRESSION_ALGORITHM VARCHAR(20) NOT NULL,
                                 CHECKSUM VARCHAR(64) NOT NULL,
                                 STORAGE_PATH VARCHAR(1000) NOT NULL,
                                 STORAGE_FOLDER_ID BIGINT NOT NULL,
                                 CONSTRAINT FK_CHUNK_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID),
                                 CONSTRAINT FK_CHUNK_FOLDER FOREIGN KEY (STORAGE_FOLDER_ID) REFERENCES STORAGE_FOLDERS(ID)
);

-- Create DOCUMENT_METADATA table
CREATE TABLE DOCUMENT_METADATA (
                                   ID BIGINT PRIMARY KEY,
                                   DOCUMENT_ID BIGINT NOT NULL,
                                   KEY_NAME VARCHAR(100) NOT NULL,
                                   VALUE VARCHAR(4000) NOT NULL,
                                   CONSTRAINT FK_METADATA_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID),
                                   CONSTRAINT UK_DOCUMENT_METADATA UNIQUE (DOCUMENT_ID, KEY_NAME)
);

-- Create CUSTODY_RECORDS table
CREATE TABLE CUSTODY_RECORDS (
                                 ID BIGINT PRIMARY KEY,
                                 DOCUMENT_ID BIGINT NOT NULL,
                                 ACTION_TYPE VARCHAR(50) NOT NULL,
                                 ACTION_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                 USER_ID VARCHAR(100) NOT NULL,
                                 USER_IP VARCHAR(50),
                                 USER_AGENT VARCHAR(500),
                                 DETAILS VARCHAR(4000),
                                 CONSTRAINT FK_CUSTODY_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID)
);

-- Create ASYNC_OPERATIONS table
CREATE TABLE ASYNC_OPERATIONS (
                                  ID BIGINT PRIMARY KEY,
                                  TOKEN VARCHAR(50) UNIQUE NOT NULL,
                                  OPERATION_TYPE VARCHAR(50) NOT NULL,
                                  STATUS VARCHAR(20) NOT NULL,
                                  PROGRESS_PERCENTAGE INT,
                                  RESULT_IDENTIFIER VARCHAR(100),
                                  ERROR_MESSAGE VARCHAR(4000),
                                  CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                  STARTED_DATE TIMESTAMP,
                                  COMPLETED_DATE TIMESTAMP,
                                  USER_ID VARCHAR(100)
);

-- Comments for documentation
COMMENT ON TABLE DOCUMENTS IS 'Stores document metadata and attributes';
COMMENT ON TABLE DOCUMENT_CHUNKS IS 'Stores information about document chunks';
COMMENT ON TABLE DOCUMENT_METADATA IS 'Stores custom metadata for documents';
COMMENT ON TABLE STORAGE_FOLDERS IS 'Tracks physical storage locations';
COMMENT ON TABLE CUSTODY_RECORDS IS 'Tracks document access and modifications';
COMMENT ON TABLE ASYNC_OPERATIONS IS 'Tracks asynchronous operations';