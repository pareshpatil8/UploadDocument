-- Create sequences for ID generation
CREATE SEQUENCE DOCUMENT_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE DOCUMENT_CHUNK_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE DOCUMENT_METADATA_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE STORAGE_FOLDER_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE CUSTODY_RECORD_ID_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE ASYNC_OPERATION_ID_SEQ START WITH 1 INCREMENT BY 1;

-- Create DOCUMENTS table
CREATE TABLE DOCUMENTS (
                           ID NUMBER(19) PRIMARY KEY,
                           TOKEN VARCHAR2(50) UNIQUE NOT NULL,
                           MODULE VARCHAR2(100) NOT NULL,
                           DEPARTMENT VARCHAR2(100) NOT NULL,
                           FILE_NAME VARCHAR2(255) NOT NULL,
                           FILE_TYPE VARCHAR2(50) NOT NULL,
                           SIZE NUMBER(19) NOT NULL,
                           CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                           LAST_ACCESSED_DATE TIMESTAMP,
                           LAST_MODIFIED_DATE TIMESTAMP,
                           STATUS VARCHAR2(20) NOT NULL,
                           STORAGE_LEVEL VARCHAR2(10) DEFAULT 'PRIMARY' NOT NULL,
                           OCR_TEXT CLOB,
                           OCR_REQUESTED NUMBER(1) DEFAULT 0 NOT NULL,
                           HASH VARCHAR2(64)
);

-- Create STORAGE_FOLDERS table
CREATE TABLE STORAGE_FOLDERS (
                                 ID NUMBER(19) PRIMARY KEY,
                                 BASE_PATH VARCHAR2(500) NOT NULL,
                                 RELATIVE_PATH VARCHAR2(500) NOT NULL,
                                 FULL_PATH VARCHAR2(1000) NOT NULL,
                                 STORAGE_LEVEL VARCHAR2(10) NOT NULL,
                                 FILE_COUNT NUMBER(10) DEFAULT 0 NOT NULL,
                                 MAX_FILE_COUNT NUMBER(10) NOT NULL,
                                 TOTAL_SIZE NUMBER(19) DEFAULT 0 NOT NULL,
                                 CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                 LAST_MODIFIED_DATE TIMESTAMP,
                                 CONSTRAINT UK_STORAGE_FOLDER_PATH UNIQUE (BASE_PATH, RELATIVE_PATH)
);

-- Create DOCUMENT_CHUNKS table
CREATE TABLE DOCUMENT_CHUNKS (
                                 ID NUMBER(19) PRIMARY KEY,
                                 DOCUMENT_ID NUMBER(19) NOT NULL,
                                 SEQUENCE_NUMBER NUMBER(10) NOT NULL,
                                 SIZE NUMBER(19) NOT NULL,
                                 COMPRESSED_SIZE NUMBER(19) NOT NULL,
                                 COMPRESSION_ALGORITHM VARCHAR2(20) NOT NULL,
                                 CHECKSUM VARCHAR2(64) NOT NULL,
                                 STORAGE_PATH VARCHAR2(1000) NOT NULL,
                                 STORAGE_FOLDER_ID NUMBER(19) NOT NULL,
                                 CONSTRAINT FK_CHUNK_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID),
                                 CONSTRAINT FK_CHUNK_FOLDER FOREIGN KEY (STORAGE_FOLDER_ID) REFERENCES STORAGE_FOLDERS(ID)
);

-- Create DOCUMENT_METADATA table
CREATE TABLE DOCUMENT_METADATA (
                                   ID NUMBER(19) PRIMARY KEY,
                                   DOCUMENT_ID NUMBER(19) NOT NULL,
                                   KEY_NAME VARCHAR2(100) NOT NULL,
                                   VALUE VARCHAR2(4000) NOT NULL,
                                   CONSTRAINT FK_METADATA_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID),
                                   CONSTRAINT UK_DOCUMENT_METADATA UNIQUE (DOCUMENT_ID, KEY_NAME)
);

-- Create CUSTODY_RECORDS table
CREATE TABLE CUSTODY_RECORDS (
                                 ID NUMBER(19) PRIMARY KEY,
                                 DOCUMENT_ID NUMBER(19) NOT NULL,
                                 ACTION_TYPE VARCHAR2(50) NOT NULL,
                                 ACTION_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                 USER_ID VARCHAR2(100) NOT NULL,
                                 USER_IP VARCHAR2(50),
                                 USER_AGENT VARCHAR2(500),
                                 DETAILS VARCHAR2(4000),
                                 CONSTRAINT FK_CUSTODY_DOCUMENT FOREIGN KEY (DOCUMENT_ID) REFERENCES DOCUMENTS(ID)
);

-- Create ASYNC_OPERATIONS table
CREATE TABLE ASYNC_OPERATIONS (
                                  ID NUMBER(19) PRIMARY KEY,
                                  TOKEN VARCHAR2(50) UNIQUE NOT NULL,
                                  OPERATION_TYPE VARCHAR2(50) NOT NULL,
                                  STATUS VARCHAR2(20) NOT NULL,
                                  PROGRESS_PERCENTAGE NUMBER(3),
                                  RESULT_IDENTIFIER VARCHAR2(100),
                                  ERROR_MESSAGE VARCHAR2(4000),
                                  CREATED_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                  STARTED_DATE TIMESTAMP,
                                  COMPLETED_DATE TIMESTAMP,
                                  USER_ID VARCHAR2(100)
);

-- Comments for documentation
COMMENT ON TABLE DOCUMENTS IS 'Stores document metadata and attributes';
COMMENT ON TABLE DOCUMENT_CHUNKS IS 'Stores information about document chunks';
COMMENT ON TABLE DOCUMENT_METADATA IS 'Stores custom metadata for documents';
COMMENT ON TABLE STORAGE_FOLDERS IS 'Tracks physical storage locations';
COMMENT ON TABLE CUSTODY_RECORDS IS 'Tracks document access and modifications';
COMMENT ON TABLE ASYNC_OPERATIONS IS 'Tracks asynchronous operations';