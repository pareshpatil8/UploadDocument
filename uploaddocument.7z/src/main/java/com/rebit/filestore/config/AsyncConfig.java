package com.rebit.filestore.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configuration for asynchronous processing capabilities.
 *
 * Configures thread pools for various asynchronous operations:
 * - Document processing
 * - Chunk processing
 * - OCR integration
 * - Archival operations
 */
@Configuration
public class AsyncConfig implements AsyncConfigurer {

    @Value("${file-store.async.core-pool-size:10}")
    private int corePoolSize;

    @Value("${file-store.async.max-pool-size:50}")
    private int maxPoolSize;

    @Value("${file-store.async.queue-capacity:100}")
    private int queueCapacity;

    /**
     * Default async executor for general purpose async operations
     */
    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("default-async-");
        executor.initialize();
        return executor;
    }

    /**
     * Specialized executor for document processing
     */
    @Bean(name = "documentProcessingExecutor")
    public Executor documentProcessingExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("doc-processing-");
        executor.initialize();
        return executor;
    }

    /**
     * Specialized executor for chunk processing with higher concurrency
     * Leverages virtual threads from Java 21 for efficient I/O operations
     */
    @Bean(name = "chunkProcessingExecutor")
    public Executor chunkProcessingExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize * 2);
        executor.setMaxPoolSize(maxPoolSize * 2);
        executor.setQueueCapacity(queueCapacity * 2);
        executor.setThreadNamePrefix("chunk-processing-");
        executor.setVirtualThreads(true); // Using Java 21 virtual threads
        executor.initialize();
        return executor;
    }

    /**
     * Specialized executor for OCR processing
     */
    @Bean(name = "ocrProcessingExecutor")
    public Executor ocrProcessingExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize / 2); // Lower core pool size for OCR
        executor.setMaxPoolSize(maxPoolSize / 2);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("ocr-processing-");
        executor.initialize();
        return executor;
    }

    /**
     * Specialized executor for archival operations
     */
    @Bean(name = "archivalExecutor")
    public Executor archivalExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5); // Fewer threads for archival
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("archival-");
        executor.initialize();
        return executor;
    }
}