package com.rebit.filestore.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Configuration for file storage functionality.
 *
 * Manages storage locations, validates storage paths,
 * and configures storage-related properties.
 */
@Configuration
public class StorageConfig {

    private static final Logger logger = LoggerFactory.getLogger(StorageConfig.class);

    @Value("${file-store.storage.base-paths}")
    private String storagePathsStr;

    @Value("${file-store.storage.temp-dir}")
    private String storagePathsTempDir;

    @Value("${file-store.storage.max-files-per-folder:1000}")
    private int maxFilesPerFolder;

    /**
     * Initialize storage locations
     * Creates base directories if they don't exist
     *
     * @return List of validated storage paths
     * @throws IOException if storage paths cannot be created or accessed
     */
    @Bean
    public List<Path> storageLocations() throws IOException {
        List<Path> validatedPaths = new ArrayList<>();

        // Parse comma-separated string into list of paths
        String[] pathsArray = storagePathsStr.split(",");

        for (String pathStr : pathsArray) {
            Path path = Paths.get(pathStr.trim());

            if (!Files.exists(path)) {
                logger.info("Creating storage directory: {}", path);
                Files.createDirectories(path);
            }

            if (!Files.isWritable(path)) {
                throw new IOException("Storage location is not writable: " + path);
            }

            validatedPaths.add(path);
            logger.info("Validated storage path: {}", path);
        }

        if (validatedPaths.isEmpty()) {
            throw new IOException("No valid storage locations configured");
        }

        return validatedPaths;
    }

    /**
     * @return Maximum number of files allowed per folder
     */
    @Bean
    public int maxFilesPerFolder() {
        return maxFilesPerFolder;
    }

    /**
     * Creates and validates storage folder path
     *
     * @param baseDir Base storage directory
     * @param folderPath Relative folder path
     * @return Full path to storage folder
     * @throws IOException if folder cannot be created or accessed
     */
    public Path createStorageFolder(Path baseDir, String folderPath) throws IOException {
        Path fullPath = baseDir.resolve(folderPath);

        if (!Files.exists(fullPath)) {
            Files.createDirectories(fullPath);
        }

        return fullPath;
    }

    /**
     * Checks if a folder has reached the maximum file limit
     *
     * @param folderPath Path to check
     * @return true if folder has reached or exceeded the file limit
     */
    public boolean isFolderFull(Path folderPath) {
        File folder = folderPath.toFile();
        String[] files = folder.list();
        return files != null && files.length >= maxFilesPerFolder;
    }

    @Bean
    public String storagePathsTempDir() {
        File directory = new File(storagePathsTempDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        return storagePathsTempDir;
    }
}