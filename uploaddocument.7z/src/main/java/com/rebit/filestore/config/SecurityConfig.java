package com.rebit.filestore.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.servlet.util.matcher.MvcRequestMatcher;
import org.springframework.web.servlet.handler.HandlerMappingIntrospector;

/**
 * Security configuration for the file store service.
 *
 * Configures authentication, authorization, and security policies
 * for API endpoints and resources.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    /**
     * Configures the security filter chain
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                                   HandlerMappingIntrospector introspector) throws Exception {
        MvcRequestMatcher.Builder mvcMatcherBuilder = new MvcRequestMatcher.Builder(introspector);

        return http
                .csrf(AbstractHttpConfigurer::disable) // Disable CSRF for API
                .cors(cors -> cors.configure(http)) // Enable CORS
                .authorizeHttpRequests(authorize -> authorize
                        // Health and info endpoints open for monitoring
                        .requestMatchers(mvcMatcherBuilder.pattern("/actuator/health/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/actuator/info")).permitAll()

                        // Web resources and H2 console access
                        .requestMatchers(mvcMatcherBuilder.pattern("/css/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/js/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/h2-console/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/webjars/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/upload")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/status/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/document/**")).permitAll()
                        .requestMatchers(mvcMatcherBuilder.pattern("/search")).permitAll()

                        // Document retrieval and upload requires authentication
                        .requestMatchers(mvcMatcherBuilder.pattern("/api/documents/**")).permitAll() // For testing UI

                        // Admin endpoints require ADMIN role
                        .requestMatchers(mvcMatcherBuilder.pattern("/api/admin/**")).hasRole("ADMIN")
                        .requestMatchers(mvcMatcherBuilder.pattern("/admin")).hasRole("ADMIN")

                        // Any other request requires authentication
                        .anyRequest().authenticated()
                )
                .httpBasic(httpBasic -> {}) // Enable HTTP Basic authentication
                //.headers(headers -> headers.frameOptions(Custom).disable()) // Allow iframe for H2 console
                .build();
    }

    /**
     * Configure content security policy
     * This helps prevent XSS attacks and other security vulnerabilities
     */
    @Bean
    public org.springframework.web.filter.CorsFilter corsFilter() {
        org.springframework.web.cors.CorsConfiguration corsConfig = new org.springframework.web.cors.CorsConfiguration();
        corsConfig.addAllowedOrigin("*"); // Configure appropriately for production
        corsConfig.addAllowedMethod("*");
        corsConfig.addAllowedHeader("*");
        corsConfig.setMaxAge(3600L);

        org.springframework.web.cors.UrlBasedCorsConfigurationSource source =
                new org.springframework.web.cors.UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfig);

        return new org.springframework.web.filter.CorsFilter(source);
    }
}