package com.rebit.filestore.controller;

import com.rebit.filestore.domain.dto.response.DocumentMetadataResponse;
import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.domain.enums.StorageLevel;
import com.rebit.filestore.service.archival.ArchivalService;
import com.rebit.filestore.service.document.DocumentService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Arrays;
import java.util.Map;

/**
 * Controller for web interface pages
 */
@Controller
public class WebController {

    private final DocumentService documentService;
    private final ArchivalService archivalService;

    @Autowired
    public WebController(DocumentService documentService, ArchivalService archivalService) {
        this.documentService = documentService;
        this.archivalService = archivalService;
    }

    /**
     * Home page / dashboard
     */
    @GetMapping("/")
    public String home(Model model) {
        try {
            Map<String, Object> stats = archivalService.getStorageStatistics();
            model.addAttribute("stats", stats);
        } catch (Exception e) {
            model.addAttribute("error", "Error loading storage statistics: " + e.getMessage());
        }
        return "index";
    }

    /**
     * Document upload page
     */
    @GetMapping("/upload")
    public String uploadPage(Model model) {
        model.addAttribute("modules", Arrays.asList("LOANS", "ACCOUNTS", "PAYMENTS", "CARDS", "CUSTOMERS", "COMPLIANCE"));
        model.addAttribute("departments", Arrays.asList("RETAIL", "CORPORATE", "TREASURY", "OPERATIONS", "LEGAL", "HR"));
        return "upload";
    }

    /**
     * Document status page
     */
    @GetMapping("/status/{token}")
    public String statusPage(@PathVariable String token, Model model) {
        model.addAttribute("token", token);
        return "status";
    }

    /**
     * Document details page
     */
    @GetMapping("/document/{id}")
    public String documentDetailsPage(@PathVariable Long id, Model model) {
        try {
            DocumentMetadataResponse document = documentService.getDocumentMetadata(id);
            model.addAttribute("document", document);

            // Add available storage levels for moving documents
            model.addAttribute("storageLevels", StorageLevel.values());

            // Load document history
            Map<String, Object> history = archivalService.getDocumentAccessHistory(id, 0, 10);
            model.addAttribute("history", history);
        } catch (Exception e) {
            model.addAttribute("error", "Error loading document: " + e.getMessage());
        }
        return "document";
    }

    /**
     * Document search page
     */
    @GetMapping("/search")
    public String searchPage(Model model) {
        model.addAttribute("modules", Arrays.asList("LOANS", "ACCOUNTS", "PAYMENTS", "CARDS", "CUSTOMERS", "COMPLIANCE"));
        model.addAttribute("departments", Arrays.asList("RETAIL", "CORPORATE", "TREASURY", "OPERATIONS", "LEGAL", "HR"));
        return "search";
    }

    /**
     * Admin dashboard
     */
    @GetMapping("/admin")
    public String adminDashboard(Model model) {
        try {
            Map<String, Object> stats = archivalService.getStorageStatistics();
            model.addAttribute("stats", stats);
        } catch (Exception e) {
            model.addAttribute("error", "Error loading storage statistics: " + e.getMessage());
        }
        return "admin";
    }

    @ModelAttribute
    public void addAttributes(Model model, HttpServletRequest request) {
        model.addAttribute("request", request);
    }
}