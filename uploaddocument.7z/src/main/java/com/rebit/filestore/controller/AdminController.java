package com.rebit.filestore.controller;

import com.rebit.filestore.domain.enums.StorageLevel;
import com.rebit.filestore.service.archival.ArchivalService;
import com.rebit.filestore.service.storage.StorageService;
import com.rebit.filestore.util.SecurityUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for administrative operations
 */
@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@Tag(name = "Admin API", description = "API endpoints for administrative operations")
public class AdminController {

    private final ArchivalService archivalService;
    private final StorageService storageService;
    private final SecurityUtils securityUtils;

    @Autowired
    public AdminController(ArchivalService archivalService,
                           StorageService storageService,
                           SecurityUtils securityUtils) {
        this.archivalService = archivalService;
        this.storageService = storageService;
        this.securityUtils = securityUtils;
    }

    /**
     * Trigger archive process manually
     */
    @PostMapping("/archive/run")
    @Operation(summary = "Run archival", description = "Manually trigger the archival process")
    @ApiResponse(responseCode = "200", description = "Archival process initiated")
    public ResponseEntity<Map<String, String>> runArchival() {
        String userId = securityUtils.getCurrentUserId();
        archivalService.triggerArchival(userId);

        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Archival process has been initiated");

        return ResponseEntity.ok(response);
    }

    /**
     * Get storage statistics
     */
    @GetMapping("/storage/stats")
    @Operation(summary = "Get storage stats", description = "Retrieve storage usage statistics")
    @ApiResponse(responseCode = "200", description = "Storage statistics")
    public ResponseEntity<Map<String, Object>> getStorageStats() {
        Map<String, Object> stats = archivalService.getStorageStatistics();
        return ResponseEntity.ok(stats);
    }

    /**
     * Move document to a different storage level
     */
    @PostMapping("/documents/{id}/move")
    @Operation(summary = "Move document", description = "Move a document to a different storage level")
    @ApiResponse(responseCode = "200", description = "Document moved")
    public ResponseEntity<Map<String, String>> moveDocument(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId,
            @Parameter(description = "Target storage level") @RequestParam StorageLevel targetLevel) {

        String userId = securityUtils.getCurrentUserId();
        archivalService.moveDocumentToStorageLevel(documentId, targetLevel, userId);

        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Document has been moved to " + targetLevel);

        return ResponseEntity.ok(response);
    }

    /**
     * Get document access history
     */
    @GetMapping("/documents/{id}/history")
    @Operation(summary = "Get access history", description = "Retrieve chain of custody records for a document")
    @ApiResponse(responseCode = "200", description = "Access history")
    public ResponseEntity<Map<String, Object>> getDocumentHistory(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId,
            @Parameter(description = "Page number") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "20") int size) {

        Map<String, Object> history = archivalService.getDocumentAccessHistory(documentId, page, size);
        return ResponseEntity.ok(history);
    }

    @ModelAttribute
    public void addAttributes(Model model, HttpServletRequest request) {
        model.addAttribute("request", request);
    }
}