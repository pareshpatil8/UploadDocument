package com.rebit.filestore.controller;

import com.rebit.filestore.domain.dto.request.DocumentRetrieveRequest;
import com.rebit.filestore.domain.dto.request.DocumentSearchRequest;
import com.rebit.filestore.domain.dto.request.DocumentUploadRequest;
import com.rebit.filestore.domain.dto.response.DocumentMetadataResponse;
import com.rebit.filestore.domain.dto.response.DocumentStatusResponse;
import com.rebit.filestore.domain.dto.response.DocumentUploadResponse;
import com.rebit.filestore.service.document.DocumentService;
import com.rebit.filestore.util.SecurityUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for document operations
 */
@RestController
@RequestMapping("/api/documents")
@Tag(name = "Document API", description = "API endpoints for document management")
public class DocumentController {

    private final DocumentService documentService;
    private final SecurityUtils securityUtils;

    @Autowired
    public DocumentController(DocumentService documentService, SecurityUtils securityUtils) {
        this.documentService = documentService;
        this.securityUtils = securityUtils;
    }

    /**
     * Upload a document
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload a document", description = "Upload a document with metadata")
    @ApiResponse(responseCode = "200", description = "Document upload initiated",
            content = @Content(schema = @Schema(implementation = DocumentUploadResponse.class)))
    public ResponseEntity<DocumentUploadResponse> uploadDocument(
            @Parameter(description = "Document file") @RequestPart("file") MultipartFile file,
            @Parameter(description = "Document metadata") @Valid @RequestPart("request") DocumentUploadRequest request) {

        String userId = securityUtils.getCurrentUserId();
        DocumentUploadResponse response = documentService.uploadDocument(file, request, userId);
        return ResponseEntity.ok(response);
    }

    /**
     * Get document upload status
     */
    @GetMapping("/status/{token}")
    @Operation(summary = "Get document status", description = "Check the status of a document upload")
    @ApiResponse(responseCode = "200", description = "Document status",
            content = @Content(schema = @Schema(implementation = DocumentStatusResponse.class)))
    public ResponseEntity<DocumentStatusResponse> getDocumentStatus(
            @Parameter(description = "Upload token") @PathVariable String token) {

        DocumentStatusResponse response = documentService.getDocumentStatus(token);
        return ResponseEntity.ok(response);
    }

    /**
     * Get document metadata by ID
     */
    @GetMapping("/{id}")
    @Operation(summary = "Get document metadata", description = "Retrieve metadata for a document")
    @ApiResponse(responseCode = "200", description = "Document metadata",
            content = @Content(schema = @Schema(implementation = DocumentMetadataResponse.class)))
    public ResponseEntity<DocumentMetadataResponse> getDocumentMetadata(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId) {

        DocumentMetadataResponse response = documentService.getDocumentMetadata(documentId);
        return ResponseEntity.ok(response);
    }

    /**
     * Download document content
     */
    @GetMapping("/{id}/content")
    @Operation(summary = "Download document", description = "Download the document content")
    @ApiResponse(responseCode = "200", description = "Document content",
            content = @Content(mediaType = "application/octet-stream"))
    public ResponseEntity<Resource> downloadDocument(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId) {

        String userId = securityUtils.getCurrentUserId();
        DocumentMetadataResponse metadata = documentService.getDocumentMetadata(documentId);
        byte[] content = documentService.getDocumentContent(documentId, userId);

        ByteArrayResource resource = new ByteArrayResource(content);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + metadata.getFileName() + "\"")
                .contentLength(content.length)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    /**
     * Search for documents
     */
    @PostMapping("/search")
    @Operation(summary = "Search documents", description = "Search for documents based on criteria")
    @ApiResponse(responseCode = "200", description = "Search results",
            content = @Content(schema = @Schema(implementation = Page.class)))
    public ResponseEntity<Page<DocumentMetadataResponse>> searchDocuments(
            @Parameter(description = "Search criteria") @Valid @RequestBody DocumentSearchRequest request) {

        Page<DocumentMetadataResponse> response = documentService.searchDocuments(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Delete a document
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete document", description = "Delete a document (admin only)")
    @ApiResponse(responseCode = "204", description = "Document deleted")
    public ResponseEntity<Void> deleteDocument(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId) {

        String userId = securityUtils.getCurrentUserId();
        documentService.deleteDocument(documentId, userId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Find documents by metadata
     */
    @GetMapping("/by-metadata")
    @Operation(summary = "Find by metadata", description = "Find documents with specific metadata")
    @ApiResponse(responseCode = "200", description = "Documents with matching metadata",
            content = @Content(schema = @Schema(implementation = Page.class)))
    public ResponseEntity<Page<DocumentMetadataResponse>> findDocumentsByMetadata(
            @Parameter(description = "Metadata key") @RequestParam String key,
            @Parameter(description = "Metadata value") @RequestParam String value,
            @Parameter(description = "Page number") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "20") int size) {

        Page<DocumentMetadataResponse> response = documentService.findDocumentsByMetadata(key, value, page, size);
        return ResponseEntity.ok(response);
    }

    /**
     * Get OCR text for a document
     */
    @GetMapping("/{id}/ocr")
    @Operation(summary = "Get OCR text", description = "Retrieve OCR text for a document if available")
    @ApiResponse(responseCode = "200", description = "OCR text", content = @Content(mediaType = "text/plain"))
    @ApiResponse(responseCode = "404", description = "OCR text not available")
    public ResponseEntity<String> getDocumentOcrText(
            @Parameter(description = "Document ID") @PathVariable("id") Long documentId) {

        Optional<String> ocrText = documentService.getDocumentOcrText(documentId);

        return ocrText
                .map(text -> ResponseEntity.ok().contentType(MediaType.TEXT_PLAIN).body(text))
                .orElse(ResponseEntity.notFound().build());
    }

    @ModelAttribute
    public void addAttributes(Model model, HttpServletRequest request) {
        model.addAttribute("request", request);
    }
}