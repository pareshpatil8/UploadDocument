package com.rebit.filestore.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Custom error controller for handling error pages
 */
@Controller
public class CustomErrorController implements ErrorController {

    /**
     * Handle error requests
     *
     * @param request HTTP request
     * @param model Model for the view
     * @return Error view name
     */
    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        // Get error details from request attributes
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Object message = request.getAttribute(RequestDispatcher.ERROR_MESSAGE);
        Object exception = request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);

        // Add error details to model
        if (status != null) {
            model.addAttribute("status", status);
        }

        if (message != null && !message.toString().isEmpty()) {
            model.addAttribute("message", message);
        } else {
            model.addAttribute("message", getDefaultMessageForStatus(status));
        }

        if (exception != null) {
            model.addAttribute("exception", exception.toString());

            // Include stack trace in development environment only
            if (exception instanceof Exception) {
                StackTraceElement[] stackTrace = ((Exception) exception).getStackTrace();
                StringBuilder stackTraceStr = new StringBuilder();
                for (StackTraceElement element : stackTrace) {
                    stackTraceStr.append(element.toString()).append("\n");
                }
                model.addAttribute("trace", stackTraceStr.toString());
            }
        }

        return "error";
    }

    /**
     * Get default error message for HTTP status code
     *
     * @param status HTTP status code
     * @return Default error message
     */
    private String getDefaultMessageForStatus(Object status) {
        if (status == null) {
            return "An unexpected error occurred";
        }

        int statusCode = Integer.parseInt(status.toString());

        return switch (statusCode) {
            case 400 -> "Bad Request - The server could not understand the request";
            case 401 -> "Unauthorized - Authentication is required";
            case 403 -> "Forbidden - You don't have permission to access this resource";
            case 404 -> "Not Found - The requested resource could not be found";
            case 405 -> "Method Not Allowed - The request method is not supported for this resource";
            case 500 -> "Internal Server Error - The server encountered an unexpected condition";
            case 502 -> "Bad Gateway - The server received an invalid response from an upstream server";
            case 503 -> "Service Unavailable - The server is currently unavailable";
            case 504 -> "Gateway Timeout - The server did not receive a timely response from an upstream server";
            default -> "Error " + statusCode + " - An error occurred";
        };
    }

    @ModelAttribute
    public void addAttributes(Model model, HttpServletRequest request) {
        model.addAttribute("request", request);
    }
}