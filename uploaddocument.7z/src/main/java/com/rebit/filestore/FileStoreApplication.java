package com.rebit.filestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for the File Store service.
 *
 * This service provides centralized storage for various file types in a banking application,
 * with advanced features like adaptive chunking, compression, and intelligent archival.
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
@EnableFeignClients
public class FileStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileStoreApplication.class, args);
	}
}