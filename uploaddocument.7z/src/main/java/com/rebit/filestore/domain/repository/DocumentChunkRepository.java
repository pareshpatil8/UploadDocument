package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.DocumentChunk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Repository interface for DocumentChunk entity
 */
public interface DocumentChunkRepository extends JpaRepository<DocumentChunk, Long> {

    /**
     * Find all chunks for a document ordered by sequence number
     */
    List<DocumentChunk> findByDocumentIdOrderBySequenceNumber(Long documentId);

    /**
     * Count the number of chunks for a document
     */
    long countByDocumentId(Long documentId);

    /**
     * Delete all chunks for a document
     */
    void deleteByDocumentId(Long documentId);

    /**
     * Find chunks for multiple documents
     */
    @Query("SELECT c FROM DocumentChunk c WHERE c.document.id IN :documentIds ORDER BY c.document.id, c.sequenceNumber")
    List<DocumentChunk> findByDocumentIds(@Param("documentIds") List<Long> documentIds);

    /**
     * Find chunks stored in a specific storage folder
     */
    List<DocumentChunk> findByStorageFolderId(Long storageFolderId);

    /**
     * Get the total compressed size of chunks for a document
     */
    @Query("SELECT SUM(c.compressedSize) FROM DocumentChunk c WHERE c.document.id = :documentId")
    Long getTotalCompressedSizeByDocumentId(@Param("documentId") Long documentId);

    /**
     * Get the total original size of chunks for a document
     */
    @Query("SELECT SUM(c.size) FROM DocumentChunk c WHERE c.document.id = :documentId")
    Long getTotalSizeByDocumentId(@Param("documentId") Long documentId);

    /**
     * Find chunks by storage path pattern (useful for migrating chunks)
     */
    @Query("SELECT c FROM DocumentChunk c WHERE c.storagePath LIKE :pathPattern")
    List<DocumentChunk> findByStoragePathPattern(@Param("pathPattern") String pathPattern);
}