package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.enums.DocumentStatus;
import com.rebit.filestore.domain.enums.StorageLevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Document entity
 */
public interface DocumentRepository extends JpaRepository<Document, Long> {

    /**
     * Find a document by its token
     */
    Optional<Document> findByToken(String token);

    /**
     * Find documents by their status
     */
    List<Document> findByStatus(DocumentStatus status);

    /**
     * Find documents by multiple IDs
     */
    List<Document> findByIdIn(List<Long> ids);

    /**
     * Find documents by module
     */
    Page<Document> findByModule(String module, Pageable pageable);

    /**
     * Find documents by department
     */
    Page<Document> findByDepartment(String department, Pageable pageable);

    /**
     * Find documents by module and department
     */
    Page<Document> findByModuleAndDepartment(String module, String department, Pageable pageable);

    /**
     * Find documents that need archiving (last accessed before a certain date and at a specific storage level)
     */
    @Query("SELECT d FROM Document d WHERE d.lastAccessedDate < :cutoffDate AND d.storageLevel = :currentLevel AND d.status = 'COMPLETED'")
    List<Document> findDocumentsForArchiving(@Param("cutoffDate") LocalDateTime cutoffDate,
                                             @Param("currentLevel") StorageLevel currentLevel);

    /**
     * Update the OCR text for a document
     */
    @Modifying
    @Query("UPDATE Document d SET d.ocrText = :ocrText WHERE d.id = :documentId")
    void updateOcrText(@Param("documentId") Long documentId, @Param("ocrText") String ocrText);

    /**
     * Update the last accessed date for a document
     */
    @Modifying
    @Query("UPDATE Document d SET d.lastAccessedDate = :accessDate WHERE d.id = :documentId")
    void updateLastAccessedDate(@Param("documentId") Long documentId, @Param("accessDate") LocalDateTime accessDate);

    /**
     * Find documents with a specific metadata key and value
     */
    @Query("SELECT d FROM Document d JOIN d.metadata m WHERE m.key = :key AND m.value = :value")
    Page<Document> findByMetadata(@Param("key") String key, @Param("value") String value, Pageable pageable);

    /**
     * Count documents by storage level
     */
    long countByStorageLevel(StorageLevel storageLevel);

    /**
     * Find documents that have OCR processing requested but not yet completed
     */
    @Query("SELECT d FROM Document d WHERE d.ocrRequested = true AND d.ocrText IS NULL AND d.status = 'COMPLETED'")
    List<Document> findDocumentsForOcrProcessing();
}