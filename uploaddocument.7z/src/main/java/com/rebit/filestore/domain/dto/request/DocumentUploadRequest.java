package com.rebit.filestore.domain.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.HashMap;
import java.util.Map;

/**
 * DTO for document upload request containing metadata
 */
public class DocumentUploadRequest {

    @NotBlank(message = "Module is required")
    @Size(max = 100, message = "Module name cannot exceed 100 characters")
    private String module;

    @NotBlank(message = "Department is required")
    @Size(max = 100, message = "Department name cannot exceed 100 characters")
    private String department;

    private boolean ocrRequested = false;

    private Map<String, String> additionalMetadata = new HashMap<>();

    // Getters and Setters
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public boolean isOcrRequested() {
        return ocrRequested;
    }

    public void setOcrRequested(boolean ocrRequested) {
        this.ocrRequested = ocrRequested;
    }

    public Map<String, String> getAdditionalMetadata() {
        return additionalMetadata;
    }

    public void setAdditionalMetadata(Map<String, String> additionalMetadata) {
        this.additionalMetadata = additionalMetadata;
    }
}
