package com.rebit.filestore.domain.dto.response;

import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.domain.enums.StorageLevel;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * DTO for document metadata response
 */
public class DocumentMetadataResponse {

    private Long id;
    private String fileName;
    private FileType fileType;
    private Long size;
    private String module;
    private String department;
    private LocalDateTime createdDate;
    private LocalDateTime lastAccessedDate;
    private LocalDateTime lastModifiedDate;
    private StorageLevel storageLevel;
    private boolean ocrAvailable;
    private Map<String, String> additionalMetadata = new HashMap<>();

    // Constructors
    public DocumentMetadataResponse() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public FileType getFileType() {
        return fileType;
    }

    public void setFileType(FileType fileType) {
        this.fileType = fileType;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getLastAccessedDate() {
        return lastAccessedDate;
    }

    public void setLastAccessedDate(LocalDateTime lastAccessedDate) {
        this.lastAccessedDate = lastAccessedDate;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public StorageLevel getStorageLevel() {
        return storageLevel;
    }

    public void setStorageLevel(StorageLevel storageLevel) {
        this.storageLevel = storageLevel;
    }

    public boolean isOcrAvailable() {
        return ocrAvailable;
    }

    public void setOcrAvailable(boolean ocrAvailable) {
        this.ocrAvailable = ocrAvailable;
    }

    public Map<String, String> getAdditionalMetadata() {
        return additionalMetadata;
    }

    public void setAdditionalMetadata(Map<String, String> additionalMetadata) {
        this.additionalMetadata = additionalMetadata;
    }
}
