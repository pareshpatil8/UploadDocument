package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.DocumentMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for DocumentMetadata entity
 */
public interface DocumentMetadataRepository extends JpaRepository<DocumentMetadata, Long> {

    /**
     * Find all metadata for a document
     */
    List<DocumentMetadata> findByDocumentId(Long documentId);

    /**
     * Find a specific metadata entry for a document by key
     */
    Optional<DocumentMetadata> findByDocumentIdAndKey(Long documentId, String key);

    /**
     * Delete all metadata for a document
     */
    void deleteByDocumentId(Long documentId);

    /**
     * Find documents with a specific metadata key and value
     */
    @Query("SELECT m.document.id FROM DocumentMetadata m WHERE m.key = :key AND m.value = :value")
    List<Long> findDocumentIdsByMetadata(@Param("key") String key, @Param("value") String value);

    /**
     * Get distinct metadata keys used in the system
     */
    @Query("SELECT DISTINCT m.key FROM DocumentMetadata m")
    List<String> findDistinctKeys();
}
