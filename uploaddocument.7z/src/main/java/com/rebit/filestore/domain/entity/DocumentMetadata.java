package com.rebit.filestore.domain.entity;

import jakarta.persistence.*;

/**
 * Entity representing custom metadata associated with a document.
 * Stores key-value pairs of metadata for documents.
 */
@Entity
@Table(name = "DOCUMENT_METADATA",
        uniqueConstraints = @UniqueConstraint(columnNames = {"DOCUMENT_ID", "KEY_NAME"}))
public class DocumentMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "metadata_seq")
    @SequenceGenerator(name = "metadata_seq", sequenceName = "DOCUMENT_METADATA_ID_SEQ", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOCUMENT_ID", nullable = false)
    private Document document;

    @Column(name = "KEY_NAME", nullable = false, length = 100)
    private String key;

    @Column(name = "VALUE_DATA", nullable = false, length = 4000)
    private String value;

    // Constructors
    public DocumentMetadata() {
    }

    public DocumentMetadata(Document document, String key, String value) {
        this.document = document;
        this.key = key;
        this.value = value;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DocumentMetadata metadata = (DocumentMetadata) o;

        if (id != null && metadata.id != null) {
            return id.equals(metadata.id);
        }

        return document != null && document.equals(metadata.document) &&
                key != null && key.equals(metadata.key);
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (document != null ? document.getId().hashCode() : 0);
        result = 31 * result + (key != null ? key.hashCode() : 0);
        return result;
    }
}