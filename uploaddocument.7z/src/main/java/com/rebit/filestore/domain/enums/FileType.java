package com.rebit.filestore.domain.enums;

/**
 * Enumeration for supported file types
 */
public enum FileType {
    // Text documents
    TXT("text/plain", "txt"),
    XML("application/xml", "xml"),
    HTML("text/html", "html"),

    // Office documents
    PDF("application/pdf", "pdf"),
    DOC("application/msword", "doc"),
    DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx"),
    XLS("application/vnd.ms-excel", "xls"),
    XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"),
    PPT("application/vnd.ms-powerpoint", "ppt"),
    PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx"),

    // Images
    JPEG("image/jpeg", "jpg", "jpeg"),
    PNG("image/png", "png"),
    GIF("image/gif", "gif"),
    TIFF("image/tiff", "tiff", "tif"),

    // Audio
    MP3("audio/mpeg", "mp3"),
    WAV("audio/wav", "wav"),

    // Video
    MP4("video/mp4", "mp4"),
    AVI("video/x-msvideo", "avi"),

    // Archives
    ZIP("application/zip", "zip"),
    RAR("application/x-rar-compressed", "rar"),

    // Other
    UNKNOWN("application/octet-stream", "bin");

    private final String mimeType;
    private final String[] extensions;

    FileType(String mimeType, String... extensions) {
        this.mimeType = mimeType;
        this.extensions = extensions;
    }

    public String getMimeType() {
        return mimeType;
    }

    public String[] getExtensions() {
        return extensions;
    }

    public static FileType fromExtension(String extension) {
        if (extension == null) {
            return UNKNOWN;
        }

        String lowerCaseExt = extension.toLowerCase();

        for (FileType type : values()) {
            for (String ext : type.extensions) {
                if (ext.equals(lowerCaseExt)) {
                    return type;
                }
            }
        }

        return UNKNOWN;
    }

    public static FileType fromMimeType(String mimeType) {
        if (mimeType == null) {
            return UNKNOWN;
        }

        for (FileType type : values()) {
            if (type.mimeType.equals(mimeType)) {
                return type;
            }
        }

        return UNKNOWN;
    }
}
