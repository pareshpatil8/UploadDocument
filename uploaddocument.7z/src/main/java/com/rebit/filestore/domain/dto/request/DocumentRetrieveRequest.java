package com.rebit.filestore.domain.dto.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * DTO for document retrieval request
 */
public class DocumentRetrieveRequest {

    @NotEmpty(message = "Document IDs are required")
    @Size(max = 100, message = "Cannot retrieve more than 100 documents at once")
    private List<Long> documentIds;

    public List<Long> getDocumentIds() {
        return documentIds;
    }

    public void setDocumentIds(List<Long> documentIds) {
        this.documentIds = documentIds;
    }
}
