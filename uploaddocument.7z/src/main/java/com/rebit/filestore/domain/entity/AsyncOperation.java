package com.rebit.filestore.domain.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity representing an asynchronous operation.
 * Used to track the state and progress of long-running operations.
 */
@Entity
@Table(name = "ASYNC_OPERATIONS")
public class AsyncOperation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "async_op_seq")
    @SequenceGenerator(name = "async_op_seq", sequenceName = "ASYNC_OPERATION_ID_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "TOKEN", unique = true, nullable = false, length = 50)
    private String token;

    @Column(name = "OPERATION_TYPE", nullable = false, length = 50)
    private String operationType;

    @Column(name = "STATUS", nullable = false, length = 20)
    private String status; // PENDING, PROCESSING, COMPLETED, FAILED

    @Column(name = "PROGRESS_PERCENTAGE")
    private Integer progressPercentage;

    @Column(name = "RESULT_IDENTIFIER", length = 100)
    private String resultIdentifier; // Document ID, etc.

    @Column(name = "ERROR_MESSAGE", length = 4000)
    private String errorMessage;

    @Column(name = "CREATED_DATE", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "STARTED_DATE")
    private LocalDateTime startedDate;

    @Column(name = "COMPLETED_DATE")
    private LocalDateTime completedDate;

    @Column(name = "USER_ID", length = 100)
    private String userId;

    // Constructors
    public AsyncOperation() {
        this.createdDate = LocalDateTime.now();
        this.progressPercentage = 0;
        this.status = "PENDING";
    }

    public AsyncOperation(String token, String operationType, String userId) {
        this();
        this.token = token;
        this.operationType = operationType;
        this.userId = userId;
    }

    // Business methods
    public void markStarted() {
        this.status = "PROCESSING";
        this.startedDate = LocalDateTime.now();
    }

    public void markCompleted(String resultIdentifier) {
        this.status = "COMPLETED";
        this.completedDate = LocalDateTime.now();
        this.resultIdentifier = resultIdentifier;
        this.progressPercentage = 100;
    }

    public void markFailed(String errorMessage) {
        this.status = "FAILED";
        this.completedDate = LocalDateTime.now();
        this.errorMessage = errorMessage;
    }

    public void updateProgress(int progressPercentage) {
        this.progressPercentage = progressPercentage;
    }

    // Factory methods
    public static AsyncOperation createUploadOperation(String token, String userId) {
        return new AsyncOperation(token, "DOCUMENT_UPLOAD", userId);
    }

    public static AsyncOperation createRetrieveOperation(String token, String userId) {
        return new AsyncOperation(token, "DOCUMENT_RETRIEVE", userId);
    }

    public static AsyncOperation createOcrOperation(String token, String userId) {
        return new AsyncOperation(token, "OCR_PROCESSING", userId);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getProgressPercentage() {
        return progressPercentage;
    }

    public void setProgressPercentage(Integer progressPercentage) {
        this.progressPercentage = progressPercentage;
    }

    public String getResultIdentifier() {
        return resultIdentifier;
    }

    public void setResultIdentifier(String resultIdentifier) {
        this.resultIdentifier = resultIdentifier;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getStartedDate() {
        return startedDate;
    }

    public void setStartedDate(LocalDateTime startedDate) {
        this.startedDate = startedDate;
    }

    public LocalDateTime getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(LocalDateTime completedDate) {
        this.completedDate = completedDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AsyncOperation that = (AsyncOperation) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}