package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.AsyncOperation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for AsyncOperation entity
 */
public interface AsyncOperationRepository extends JpaRepository<AsyncOperation, Long> {

    /**
     * Find an operation by its token
     */
    Optional<AsyncOperation> findByToken(String token);

    /**
     * Find operations by their status
     */
    List<AsyncOperation> findByStatus(String status);

    /**
     * Find operations by type and status
     */
    List<AsyncOperation> findByOperationTypeAndStatus(String operationType, String status);

    /**
     * Find operations created by a specific user
     */
    List<AsyncOperation> findByUserId(String userId);

    /**
     * Find stalled operations (processing for too long)
     */
    @Query("SELECT a FROM AsyncOperation a WHERE a.status = 'PROCESSING' AND a.startedDate < :cutoff")
    List<AsyncOperation> findStalledOperations(@Param("cutoff") LocalDateTime cutoff);

    /**
     * Find the oldest pending operation of a specific type
     */
    @Query("SELECT a FROM AsyncOperation a WHERE a.status = 'PENDING' AND a.operationType = :type ORDER BY a.createdDate ASC")
    Optional<AsyncOperation> findOldestPendingOperation(@Param("type") String type);

    /**
     * Clean up old completed or failed operations
     */
    @Query("DELETE FROM AsyncOperation a WHERE (a.status = 'COMPLETED' OR a.status = 'FAILED') AND a.completedDate < :cutoff")
    void cleanupOldOperations(@Param("cutoff") LocalDateTime cutoff);
}
