package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.CustodyRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Repository interface for CustodyRecord entity
 */
public interface CustodyRecordRepository extends JpaRepository<CustodyRecord, Long> {

    /**
     * Find all custody records for a document ordered by timestamp (descending)
     */
    List<CustodyRecord> findByDocumentIdOrderByActionTimestampDesc(Long documentId);

    /**
     * Find custody records by document ID with pagination
     */
    Page<CustodyRecord> findByDocumentId(Long documentId, Pageable pageable);

    /**
     * Find custody records by user ID
     */
    Page<CustodyRecord> findByUserId(String userId, Pageable pageable);

    /**
     * Find custody records by action type
     */
    Page<CustodyRecord> findByActionType(String actionType, Pageable pageable);

    /**
     * Find custody records for a specific period
     */
    @Query("SELECT c FROM CustodyRecord c WHERE c.actionTimestamp BETWEEN :startDate AND :endDate")
    Page<CustodyRecord> findByDateRange(@Param("startDate") LocalDateTime startDate,
                                        @Param("endDate") LocalDateTime endDate,
                                        Pageable pageable);

    /**
     * Find custody records for a document and action type
     */
    List<CustodyRecord> findByDocumentIdAndActionType(Long documentId, String actionType);

    /**
     * Count the number of times a document has been accessed
     */
    @Query("SELECT COUNT(c) FROM CustodyRecord c WHERE c.document.id = :documentId AND c.actionType IN ('VIEW', 'DOWNLOAD')")
    Long countAccessByDocumentId(@Param("documentId") Long documentId);
}
