package com.rebit.filestore.domain.dto.response;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * DTO for document upload response
 */
public class DocumentUploadResponse {

    private String token;
    private String message;
    private LocalDateTime timestamp;

    // Constructors
    public DocumentUploadResponse() {
        this.timestamp = LocalDateTime.now();
    }

    public DocumentUploadResponse(String token, String message) {
        this();
        this.token = token;
        this.message = message;
    }

    // Static factory method
    public static DocumentUploadResponse success(String token) {
        return new DocumentUploadResponse(token, "File upload initiated successfully");
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
