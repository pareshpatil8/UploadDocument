package com.rebit.filestore.domain.enums;

/**
 * Enumeration for document processing status
 */
public enum DocumentStatus {
    PENDING,       // Initial upload received, pending processing
    PROCESSING,    // Document is being processed (chunking, compression)
    COMPLETED,     // Document processing completed successfully
    FAILED,        // Document processing failed
    ARCHIVING,     // Document is being moved to archive storage
    ARCHIVED,      // Document has been archived
    DELETING,      // Document is being deleted
    DELETED        // Document has been deleted (soft delete)
}
