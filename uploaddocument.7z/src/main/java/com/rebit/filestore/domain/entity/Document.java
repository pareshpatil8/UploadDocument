package com.rebit.filestore.domain.entity;

import com.rebit.filestore.domain.enums.DocumentStatus;
import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.domain.enums.StorageLevel;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Entity representing a document in the system.
 * Contains metadata about the document and references to its chunks.
 */
@Entity
@Table(name = "DOCUMENTS")
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "doc_seq")
    @SequenceGenerator(name = "doc_seq", sequenceName = "DOCUMENT_ID_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "TOKEN", unique = true, nullable = false, length = 50)
    private String token;

    @Column(name = "MODULE", nullable = false, length = 100)
    private String module;

    @Column(name = "DEPARTMENT", nullable = false, length = 100)
    private String department;

    @Column(name = "FILE_NAME", nullable = false, length = 255)
    private String fileName;

    @Column(name = "FILE_TYPE", nullable = false, length = 50)
    @Enumerated(EnumType.STRING)
    private FileType fileType;

    @Column(name = "SIZE", nullable = false)
    private Long size;

    @Column(name = "CREATED_DATE", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "LAST_ACCESSED_DATE")
    private LocalDateTime lastAccessedDate;

    @Column(name = "LAST_MODIFIED_DATE")
    private LocalDateTime lastModifiedDate;

    @Column(name = "STATUS", nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private DocumentStatus status;

    @Column(name = "STORAGE_LEVEL", nullable = false, length = 10)
    @Enumerated(EnumType.STRING)
    private StorageLevel storageLevel;

    @Column(name = "OCR_TEXT")
    @Lob
    private String ocrText;

    @Column(name = "OCR_REQUESTED")
    private Boolean ocrRequested;

    @Column(name = "HASH", length = 64)
    private String hash;

    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DocumentChunk> chunks = new ArrayList<>();

    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<DocumentMetadata> metadata = new HashSet<>();

    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL)
    private List<CustodyRecord> custodyRecords = new ArrayList<>();

    // Constructors
    public Document() {
        this.createdDate = LocalDateTime.now();
        this.status = DocumentStatus.PENDING;
        this.storageLevel = StorageLevel.PRIMARY;
        this.ocrRequested = false;
    }

    // Helper methods to maintain bidirectional relationships
    public void addChunk(DocumentChunk chunk) {
        chunks.add(chunk);
        chunk.setDocument(this);
    }

    public void removeChunk(DocumentChunk chunk) {
        chunks.remove(chunk);
        chunk.setDocument(null);
    }

    public void addMetadata(DocumentMetadata meta) {
        metadata.add(meta);
        meta.setDocument(this);
    }

    public void removeMetadata(DocumentMetadata meta) {
        metadata.remove(meta);
        meta.setDocument(null);
    }

    public void addCustodyRecord(CustodyRecord record) {
        custodyRecords.add(record);
        record.setDocument(this);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public FileType getFileType() {
        return fileType;
    }

    public void setFileType(FileType fileType) {
        this.fileType = fileType;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getLastAccessedDate() {
        return lastAccessedDate;
    }

    public void setLastAccessedDate(LocalDateTime lastAccessedDate) {
        this.lastAccessedDate = lastAccessedDate;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public DocumentStatus getStatus() {
        return status;
    }

    public void setStatus(DocumentStatus status) {
        this.status = status;
    }

    public StorageLevel getStorageLevel() {
        return storageLevel;
    }

    public void setStorageLevel(StorageLevel storageLevel) {
        this.storageLevel = storageLevel;
    }

    public String getOcrText() {
        return ocrText;
    }

    public void setOcrText(String ocrText) {
        this.ocrText = ocrText;
    }

    public Boolean getOcrRequested() {
        return ocrRequested;
    }

    public void setOcrRequested(Boolean ocrRequested) {
        this.ocrRequested = ocrRequested;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public List<DocumentChunk> getChunks() {
        return chunks;
    }

    public void setChunks(List<DocumentChunk> chunks) {
        this.chunks = chunks;
    }

    public Set<DocumentMetadata> getMetadata() {
        return metadata;
    }

    public void setMetadata(Set<DocumentMetadata> metadata) {
        this.metadata = metadata;
    }

    public List<CustodyRecord> getCustodyRecords() {
        return custodyRecords;
    }

    public void setCustodyRecords(List<CustodyRecord> custodyRecords) {
        this.custodyRecords = custodyRecords;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Document document = (Document) o;
        return id != null && id.equals(document.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}