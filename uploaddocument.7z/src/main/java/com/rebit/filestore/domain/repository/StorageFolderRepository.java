package com.rebit.filestore.domain.repository;

import com.rebit.filestore.domain.entity.StorageFolder;
import com.rebit.filestore.domain.enums.StorageLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for StorageFolder entity
 */
public interface StorageFolderRepository extends JpaRepository<StorageFolder, Long> {

    /**
     * Find a storage folder by its base path and relative path
     */
    Optional<StorageFolder> findByBasePathAndRelativePath(String basePath, String relativePath);

    /**
     * Find all storage folders for a specific storage level
     */
    List<StorageFolder> findByStorageLevel(StorageLevel storageLevel);

    /**
     * Find storage folders that are not full yet for a specific storage level
     */
    @Query("SELECT f FROM StorageFolder f WHERE f.storageLevel = :level AND f.fileCount < f.maxFileCount ORDER BY f.fileCount ASC")
    List<StorageFolder> findAvailableFolders(@Param("level") StorageLevel level);

    /**
     * Find the storage folder with the least number of files for a specific storage level
     * <TODO>Return only the first row which can be changed in Oracle as H2 creates new DB everytime</TODO>
     */
    @Query("SELECT f FROM StorageFolder f WHERE f.storageLevel = :level AND f.fileCount < f.maxFileCount ORDER BY f.fileCount ASC LIMIT 1")
    Optional<StorageFolder> findLeastUsedFolder(@Param("level") StorageLevel level);

    /**
     * Find folders with a specific base path
     */
    List<StorageFolder> findByBasePath(String basePath);

    /**
     * Count the number of folders for a storage level
     */
    long countByStorageLevel(StorageLevel storageLevel);

    /**
     * Find all full folders (file count >= max file count)
     */
    @Query("SELECT f FROM StorageFolder f WHERE f.fileCount >= f.maxFileCount")
    List<StorageFolder> findFullFolders();

    /**
     * Calculate total storage used across all folders
     */
    @Query("SELECT SUM(f.totalSize) FROM StorageFolder f")
    Long calculateTotalStorageUsed();

    /**
     * Calculate storage used for a specific storage level
     */
    @Query("SELECT SUM(f.totalSize) FROM StorageFolder f WHERE f.storageLevel = :level")
    Long calculateStorageUsedByLevel(@Param("level") StorageLevel level);
}