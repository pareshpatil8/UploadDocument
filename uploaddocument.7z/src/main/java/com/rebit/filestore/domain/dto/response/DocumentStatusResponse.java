package com.rebit.filestore.domain.dto.response;

import com.rebit.filestore.domain.enums.DocumentStatus;

import java.time.LocalDateTime;

/**
 * DTO for document status response
 */
public class DocumentStatusResponse {

    private String token;
    private Long documentId;
    private DocumentStatus status;
    private Integer progressPercentage;
    private String errorMessage;
    private LocalDateTime requestTimestamp;
    private LocalDateTime completedTimestamp;

    // Constructors
    public DocumentStatusResponse() {
    }

    // Static factory methods
    public static DocumentStatusResponse pending(String token) {
        DocumentStatusResponse response = new DocumentStatusResponse();
        response.setToken(token);
        response.setStatus(DocumentStatus.PENDING);
        response.setProgressPercentage(0);
        return response;
    }

    public static DocumentStatusResponse processing(String token, Integer progressPercentage) {
        DocumentStatusResponse response = new DocumentStatusResponse();
        response.setToken(token);
        response.setStatus(DocumentStatus.PROCESSING);
        response.setProgressPercentage(progressPercentage);
        return response;
    }

    public static DocumentStatusResponse completed(String token, Long documentId) {
        DocumentStatusResponse response = new DocumentStatusResponse();
        response.setToken(token);
        response.setDocumentId(documentId);
        response.setStatus(DocumentStatus.COMPLETED);
        response.setProgressPercentage(100);
        response.setCompletedTimestamp(LocalDateTime.now());
        return response;
    }

    public static DocumentStatusResponse failed(String token, String errorMessage) {
        DocumentStatusResponse response = new DocumentStatusResponse();
        response.setToken(token);
        response.setStatus(DocumentStatus.FAILED);
        response.setErrorMessage(errorMessage);
        response.setCompletedTimestamp(LocalDateTime.now());
        return response;
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public DocumentStatus getStatus() {
        return status;
    }

    public void setStatus(DocumentStatus status) {
        this.status = status;
    }

    public Integer getProgressPercentage() {
        return progressPercentage;
    }

    public void setProgressPercentage(Integer progressPercentage) {
        this.progressPercentage = progressPercentage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getRequestTimestamp() {
        return requestTimestamp;
    }

    public void setRequestTimestamp(LocalDateTime requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    public LocalDateTime getCompletedTimestamp() {
        return completedTimestamp;
    }

    public void setCompletedTimestamp(LocalDateTime completedTimestamp) {
        this.completedTimestamp = completedTimestamp;
    }
}
