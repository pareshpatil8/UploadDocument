package com.rebit.filestore.domain.entity;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;

import jakarta.persistence.*;

/**
 * Entity representing a chunk of a document.
 * A document is split into multiple chunks for efficient storage and retrieval.
 */
@Entity
@Table(name = "DOCUMENT_CHUNKS")
public class DocumentChunk {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "chunk_seq")
    @SequenceGenerator(name = "chunk_seq", sequenceName = "DOCUMENT_CHUNK_ID_SEQ", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOCUMENT_ID", nullable = false)
    private Document document;

    @Column(name = "SEQUENCE_NUMBER", nullable = false)
    private Integer sequenceNumber;

    @Column(name = "SIZE", nullable = false)
    private Long size;

    @Column(name = "COMPRESSED_SIZE", nullable = false)
    private Long compressedSize;

    @Column(name = "COMPRESSION_ALGORITHM", nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private CompressionAlgorithm compressionAlgorithm;

    @Column(name = "CHECKSUM", nullable = false, length = 64)
    private String checksum;

    @Column(name = "STORAGE_PATH", nullable = false, length = 1000)
    private String storagePath;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STORAGE_FOLDER_ID", nullable = false)
    private StorageFolder storageFolder;

    // Constructors
    public DocumentChunk() {
    }

    public DocumentChunk(Document document, Integer sequenceNumber, Long size,
                         Long compressedSize, CompressionAlgorithm compressionAlgorithm,
                         String checksum, String storagePath, StorageFolder storageFolder) {
        this.document = document;
        this.sequenceNumber = sequenceNumber;
        this.size = size;
        this.compressedSize = compressedSize;
        this.compressionAlgorithm = compressionAlgorithm;
        this.checksum = checksum;
        this.storagePath = storagePath;
        this.storageFolder = storageFolder;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getCompressedSize() {
        return compressedSize;
    }

    public void setCompressedSize(Long compressedSize) {
        this.compressedSize = compressedSize;
    }

    public CompressionAlgorithm getCompressionAlgorithm() {
        return compressionAlgorithm;
    }

    public void setCompressionAlgorithm(CompressionAlgorithm compressionAlgorithm) {
        this.compressionAlgorithm = compressionAlgorithm;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getStoragePath() {
        return storagePath;
    }

    public void setStoragePath(String storagePath) {
        this.storagePath = storagePath;
    }

    public StorageFolder getStorageFolder() {
        return storageFolder;
    }

    public void setStorageFolder(StorageFolder storageFolder) {
        this.storageFolder = storageFolder;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DocumentChunk that = (DocumentChunk) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}