package com.rebit.filestore.domain.dto.response;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for document retrieval response
 */
public class DocumentRetrieveResponse {

    private String token;
    private String status;
    private Integer progressPercentage;
    private List<DocumentRetrieveResult> results;
    private String errorMessage;
    private LocalDateTime requestTimestamp;
    private LocalDateTime completedTimestamp;

    // Inner class for individual document retrieval result
    public static class DocumentRetrieveResult {
        private Long documentId;
        private String fileName;
        private String status;
        private String errorMessage;
        private byte[] content;

        // Getters and Setters
        public Long getDocumentId() {
            return documentId;
        }

        public void setDocumentId(Long documentId) {
            this.documentId = documentId;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public byte[] getContent() {
            return content;
        }

        public void setContent(byte[] content) {
            this.content = content;
        }
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getProgressPercentage() {
        return progressPercentage;
    }

    public void setProgressPercentage(Integer progressPercentage) {
        this.progressPercentage = progressPercentage;
    }

    public List<DocumentRetrieveResult> getResults() {
        return results;
    }

    public void setResults(List<DocumentRetrieveResult> results) {
        this.results = results;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getRequestTimestamp() {
        return requestTimestamp;
    }

    public void setRequestTimestamp(LocalDateTime requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    public LocalDateTime getCompletedTimestamp() {
        return completedTimestamp;
    }

    public void setCompletedTimestamp(LocalDateTime completedTimestamp) {
        this.completedTimestamp = completedTimestamp;
    }
}
