package com.rebit.filestore.domain.enums;

/**
 * Enumeration for compression algorithms
 */
public enum CompressionAlgorithm {
    NONE,       // No compression
    GZIP,       // General purpose compression
    DEFLATE,    // General purpose compression
    BZIP2,      // High compression ratio
    ZSTD,       // Fast compression and decompression
    LZ4,        // Very fast compression
    JPEG,       // Image specific compression
    PNG,        // Image specific compression
    PDF         // PDF specific compression
}
