package com.rebit.filestore.domain.enums;

/**
 * Enumeration for storage level/tier
 */
public enum StorageLevel {
    PRIMARY,    // Frequent access storage (fast)
    SECONDARY,  // Less frequent access storage
    TERTIARY    // Archive storage (slow)
}
