package com.rebit.filestore.domain.entity;

import com.rebit.filestore.domain.enums.StorageLevel;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity representing a physical storage folder on disk.
 * Tracks folder usage, file counts, and storage level.
 */
@Entity
@Table(name = "STORAGE_FOLDERS",
        uniqueConstraints = @UniqueConstraint(columnNames = {"BASE_PATH", "RELATIVE_PATH"}))
public class StorageFolder {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "folder_seq")
    @SequenceGenerator(name = "folder_seq", sequenceName = "STORAGE_FOLDER_ID_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "BASE_PATH", nullable = false, length = 500)
    private String basePath;

    @Column(name = "RELATIVE_PATH", nullable = false, length = 500)
    private String relativePath;

    @Column(name = "FULL_PATH", nullable = false, length = 1000)
    private String fullPath;

    @Column(name = "STORAGE_LEVEL", nullable = false, length = 10)
    @Enumerated(EnumType.STRING)
    private StorageLevel storageLevel;

    @Column(name = "FILE_COUNT", nullable = false)
    private Integer fileCount;

    @Column(name = "MAX_FILE_COUNT", nullable = false)
    private Integer maxFileCount;

    @Column(name = "TOTAL_SIZE", nullable = false)
    private Long totalSize;

    @Column(name = "CREATED_DATE", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "LAST_MODIFIED_DATE")
    private LocalDateTime lastModifiedDate;

    @OneToMany(mappedBy = "storageFolder", cascade = CascadeType.ALL)
    private List<DocumentChunk> chunks = new ArrayList<>();

    // Constructors
    public StorageFolder() {
        this.fileCount = 0;
        this.totalSize = 0L;
        this.createdDate = LocalDateTime.now();
    }

    public StorageFolder(String basePath, String relativePath, String fullPath,
                         StorageLevel storageLevel, Integer maxFileCount) {
        this();
        this.basePath = basePath;
        this.relativePath = relativePath;
        this.fullPath = fullPath;
        this.storageLevel = storageLevel;
        this.maxFileCount = maxFileCount;
    }

    // Business methods
    public boolean isFull() {
        return fileCount >= maxFileCount;
    }

    public void incrementFileCount() {
        this.fileCount++;
        this.lastModifiedDate = LocalDateTime.now();
    }

    public void decrementFileCount() {
        if (this.fileCount > 0) {
            this.fileCount--;
            this.lastModifiedDate = LocalDateTime.now();
        }
    }

    public void addToTotalSize(Long size) {
        this.totalSize += size;
        this.lastModifiedDate = LocalDateTime.now();
    }

    public void subtractFromTotalSize(Long size) {
        this.totalSize = Math.max(0, this.totalSize - size);
        this.lastModifiedDate = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBasePath() {
        return basePath;
    }

    public void setBasePath(String basePath) {
        this.basePath = basePath;
    }

    public String getRelativePath() {
        return relativePath;
    }

    public void setRelativePath(String relativePath) {
        this.relativePath = relativePath;
    }

    public String getFullPath() {
        return fullPath;
    }

    public void setFullPath(String fullPath) {
        this.fullPath = fullPath;
    }

    public StorageLevel getStorageLevel() {
        return storageLevel;
    }

    public void setStorageLevel(StorageLevel storageLevel) {
        this.storageLevel = storageLevel;
    }

    public Integer getFileCount() {
        return fileCount;
    }

    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }

    public Integer getMaxFileCount() {
        return maxFileCount;
    }

    public void setMaxFileCount(Integer maxFileCount) {
        this.maxFileCount = maxFileCount;
    }

    public Long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(Long totalSize) {
        this.totalSize = totalSize;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public List<DocumentChunk> getChunks() {
        return chunks;
    }

    public void setChunks(List<DocumentChunk> chunks) {
        this.chunks = chunks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StorageFolder that = (StorageFolder) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}