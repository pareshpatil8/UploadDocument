package com.rebit.filestore.domain.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity representing a chain of custody record for document access.
 * Tracks all access and modifications to documents for auditing purposes.
 */
@Entity
@Table(name = "CUSTODY_RECORDS")
public class CustodyRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "custody_seq")
    @SequenceGenerator(name = "custody_seq", sequenceName = "CUSTODY_RECORD_ID_SEQ", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOCUMENT_ID", nullable = false)
    private Document document;

    @Column(name = "ACTION_TYPE", nullable = false, length = 50)
    private String actionType;

    @Column(name = "ACTION_TIMESTAMP", nullable = false)
    private LocalDateTime actionTimestamp;

    @Column(name = "USER_ID", nullable = false, length = 100)
    private String userId;

    @Column(name = "USER_IP", length = 50)
    private String userIp;

    @Column(name = "USER_AGENT", length = 500)
    private String userAgent;

    @Column(name = "DETAILS", length = 4000)
    private String details;

    // Constructors
    public CustodyRecord() {
        this.actionTimestamp = LocalDateTime.now();
    }

    public CustodyRecord(Document document, String actionType, String userId,
                         String userIp, String userAgent, String details) {
        this();
        this.document = document;
        this.actionType = actionType;
        this.userId = userId;
        this.userIp = userIp;
        this.userAgent = userAgent;
        this.details = details;
    }

    // Factory methods for common actions
    public static CustodyRecord forUpload(Document document, String userId, String userIp, String userAgent) {
        return new CustodyRecord(document, "UPLOAD", userId, userIp, userAgent,
                "Document uploaded: " + document.getFileName());
    }

    public static CustodyRecord forDownload(Document document, String userId, String userIp, String userAgent) {
        return new CustodyRecord(document, "DOWNLOAD", userId, userIp, userAgent,
                "Document downloaded: " + document.getFileName());
    }

    public static CustodyRecord forView(Document document, String userId, String userIp, String userAgent) {
        return new CustodyRecord(document, "VIEW", userId, userIp, userAgent,
                "Document viewed: " + document.getFileName());
    }

    public static CustodyRecord forModify(Document document, String userId, String userIp, String userAgent, String details) {
        return new CustodyRecord(document, "MODIFY", userId, userIp, userAgent, details);
    }

    public static CustodyRecord forArchive(Document document, String userId, String oldLevel, String newLevel) {
        return new CustodyRecord(document, "ARCHIVE", userId, null, null,
                "Archived from " + oldLevel + " to " + newLevel);
    }

    public static CustodyRecord forDelete(Document document, String userId, String userIp, String userAgent) {
        return new CustodyRecord(document, "DELETE", userId, userIp, userAgent,
                "Document deleted: " + document.getFileName());
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public LocalDateTime getActionTimestamp() {
        return actionTimestamp;
    }

    public void setActionTimestamp(LocalDateTime actionTimestamp) {
        this.actionTimestamp = actionTimestamp;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustodyRecord that = (CustodyRecord) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}