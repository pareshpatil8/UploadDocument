package com.rebit.filestore.service.archival;

import com.rebit.filestore.domain.entity.CustodyRecord;
import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import com.rebit.filestore.domain.enums.DocumentStatus;
import com.rebit.filestore.domain.enums.StorageLevel;
import com.rebit.filestore.domain.repository.DocumentChunkRepository;
import com.rebit.filestore.domain.repository.DocumentRepository;
import com.rebit.filestore.domain.repository.StorageFolderRepository;
import com.rebit.filestore.exception.DocumentNotFoundException;
import com.rebit.filestore.exception.ProcessingException;
import com.rebit.filestore.service.custody.CustodyService;
import com.rebit.filestore.service.storage.StorageService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

/**
 * Implementation of ArchivalService interface
 */
@Service
public class ArchivalServiceImpl implements ArchivalService {

    private static final Logger logger = LoggerFactory.getLogger(ArchivalServiceImpl.class);

    @Value("${file-store.archival.primary-to-secondary-days:90}")
    private int primaryToSecondaryDays;

    @Value("${file-store.archival.secondary-to-tertiary-days:365}")
    private int secondaryToTertiaryDays;

    private final DocumentRepository documentRepository;
    private final DocumentChunkRepository chunkRepository;
    private final StorageFolderRepository folderRepository;
    private final StorageService storageService;
    private final CustodyService custodyService;

    @Autowired
    @Qualifier("archivalExecutor")
    private Executor archivalExecutor;

    @Autowired
    public ArchivalServiceImpl(DocumentRepository documentRepository,
                               DocumentChunkRepository chunkRepository,
                               StorageFolderRepository folderRepository,
                               StorageService storageService,
                               CustodyService custodyService) {
        this.documentRepository = documentRepository;
        this.chunkRepository = chunkRepository;
        this.folderRepository = folderRepository;
        this.storageService = storageService;
        this.custodyService = custodyService;
    }

    @Override
    @Transactional
    public void triggerArchival(String userId) {
        logger.info("Manual archival process triggered by user: {}", userId);
        runArchival();
    }

    @Override
    @Transactional
    public boolean moveDocumentToStorageLevel(Long documentId, StorageLevel targetLevel, String userId) {
        logger.info("Moving document {} to storage level {} requested by user: {}",
                documentId, targetLevel, userId);

        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        if (document.getStorageLevel() == targetLevel) {
            logger.info("Document {} is already at storage level {}, no action needed",
                    documentId, targetLevel);
            return true;
        }

        // Update document status
        document.setStatus(DocumentStatus.ARCHIVING);
        documentRepository.save(document);

        // Get all chunks
        List<DocumentChunk> chunks = chunkRepository.findByDocumentIdOrderBySequenceNumber(documentId);

        try {
            // Move each chunk to new storage level
            for (DocumentChunk chunk : chunks) {
                storageService.moveChunk(chunk, targetLevel);
            }

            // Update document storage level and status
            StorageLevel oldLevel = document.getStorageLevel();
            document.setStorageLevel(targetLevel);
            document.setStatus(DocumentStatus.COMPLETED);
            documentRepository.save(document);

            // Record the move in custody tracking
            custodyService.recordDocumentAction(
                    document,
                    "STORAGE_MOVE",
                    userId,
                    null,
                    null,
                    "Document moved from " + oldLevel + " to " + targetLevel
            );

            return true;
        } catch (IOException e) {
            // Reset document status
            document.setStatus(DocumentStatus.FAILED);
            documentRepository.save(document);

            logger.error("Error moving document {} to storage level {}", documentId, targetLevel, e);
            throw new ProcessingException("Error moving document to new storage level", e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getStorageStatistics() {
        Map<String, Object> stats = new HashMap<>();

        // Document counts by storage level
        stats.put("documentCountPrimary", documentRepository.countByStorageLevel(StorageLevel.PRIMARY));
        stats.put("documentCountSecondary", documentRepository.countByStorageLevel(StorageLevel.SECONDARY));
        stats.put("documentCountTertiary", documentRepository.countByStorageLevel(StorageLevel.TERTIARY));

        // Storage used by level
        stats.put("storageUsedPrimary", folderRepository.calculateStorageUsedByLevel(StorageLevel.PRIMARY));
        stats.put("storageUsedSecondary", folderRepository.calculateStorageUsedByLevel(StorageLevel.SECONDARY));
        stats.put("storageUsedTertiary", folderRepository.calculateStorageUsedByLevel(StorageLevel.TERTIARY));

        // Total storage used
        stats.put("totalStorageUsed", folderRepository.calculateTotalStorageUsed());

        // Folder counts by level
        stats.put("folderCountPrimary", folderRepository.countByStorageLevel(StorageLevel.PRIMARY));
        stats.put("folderCountSecondary", folderRepository.countByStorageLevel(StorageLevel.SECONDARY));
        stats.put("folderCountTertiary", folderRepository.countByStorageLevel(StorageLevel.TERTIARY));

        // Full folders
        stats.put("fullFolderCount", folderRepository.findFullFolders().size());

        return stats;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getDocumentAccessHistory(Long documentId, int page, int size) {
        Map<String, Object> history = new HashMap<>();

        // Get document
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        // Get access history
        Page<CustodyRecord> records = custodyService.getDocumentAccessHistory(documentId, page, size);

        // Basic document info
        history.put("documentId", document.getId());
        history.put("fileName", document.getFileName());
        history.put("storageLevel", document.getStorageLevel());
        history.put("createdDate", document.getCreatedDate());
        history.put("lastAccessedDate", document.getLastAccessedDate());

        // Access records
        history.put("accessRecords", records.getContent().stream()
                .map(this::mapCustodyRecord)
                .collect(Collectors.toList()));

        // Pagination info
        history.put("page", records.getNumber());
        history.put("size", records.getSize());
        history.put("totalPages", records.getTotalPages());
        history.put("totalElements", records.getTotalElements());

        return history;
    }

    /**
     * Scheduled archival process - runs daily at 2 AM
     */
    @Scheduled(cron = "0 0 2 * * ?")
    @Async("archivalExecutor")
    public void scheduledArchival() {
        logger.info("Starting scheduled archival process");
        runArchival();
    }

    /**
     * Run the archival process
     */
    private void runArchival() {
        try {
            // Archive from PRIMARY to SECONDARY
            LocalDateTime primaryCutoff = LocalDateTime.now().minusDays(primaryToSecondaryDays);
            List<Document> primaryDocuments = documentRepository.findDocumentsForArchiving(
                    primaryCutoff, StorageLevel.PRIMARY);

            logger.info("Found {} documents to archive from PRIMARY to SECONDARY", primaryDocuments.size());

            for (Document document : primaryDocuments) {
                try {
                    moveDocumentToStorageLevel(document.getId(), StorageLevel.SECONDARY, "SYSTEM");
                } catch (Exception e) {
                    logger.error("Error archiving document {} to SECONDARY", document.getId(), e);
                }
            }

            // Archive from SECONDARY to TERTIARY
            LocalDateTime secondaryCutoff = LocalDateTime.now().minusDays(secondaryToTertiaryDays);
            List<Document> secondaryDocuments = documentRepository.findDocumentsForArchiving(
                    secondaryCutoff, StorageLevel.SECONDARY);

            logger.info("Found {} documents to archive from SECONDARY to TERTIARY", secondaryDocuments.size());

            for (Document document : secondaryDocuments) {
                try {
                    moveDocumentToStorageLevel(document.getId(), StorageLevel.TERTIARY, "SYSTEM");
                } catch (Exception e) {
                    logger.error("Error archiving document {} to TERTIARY", document.getId(), e);
                }
            }

            logger.info("Archival process completed");
        } catch (Exception e) {
            logger.error("Error during archival process", e);
        }
    }

    /**
     * Map custody record to DTO for API response
     */
    private Map<String, Object> mapCustodyRecord(CustodyRecord record) {
        Map<String, Object> mapped = new HashMap<>();

        mapped.put("id", record.getId());
        mapped.put("actionType", record.getActionType());
        mapped.put("actionTimestamp", record.getActionTimestamp());
        mapped.put("userId", record.getUserId());
        mapped.put("details", record.getDetails());

        return mapped;
    }
}
