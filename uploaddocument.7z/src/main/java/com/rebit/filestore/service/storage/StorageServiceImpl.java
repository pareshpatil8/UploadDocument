package com.rebit.filestore.service.storage;

import com.rebit.filestore.config.StorageConfig;
import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import com.rebit.filestore.domain.entity.StorageFolder;
import com.rebit.filestore.domain.enums.StorageLevel;
import com.rebit.filestore.domain.repository.DocumentChunkRepository;
import com.rebit.filestore.domain.repository.StorageFolderRepository;
import com.rebit.filestore.exception.ProcessingException;
import com.rebit.filestore.exception.StorageException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Implementation of StorageService interface
 */
@Service
public class StorageServiceImpl implements StorageService {

    private static final Logger logger = LoggerFactory.getLogger(StorageServiceImpl.class);
    private static final DateTimeFormatter DATE_FOLDER_FORMAT = DateTimeFormatter.ofPattern("yyyy/MM/dd");

    private final StorageConfig storageConfig;
    private final StorageFolderRepository folderRepository;
    private final DocumentChunkRepository chunkRepository;
    private final List<Path> storagePaths;
    private final int maxFilesPerFolder;

    @Autowired
    public StorageServiceImpl(StorageConfig storageConfig,
                              StorageFolderRepository folderRepository,
                              DocumentChunkRepository chunkRepository,
                              List<Path> storagePaths,
                              int maxFilesPerFolder) {
        this.storageConfig = storageConfig;
        this.folderRepository = folderRepository;
        this.chunkRepository = chunkRepository;
        this.storagePaths = storagePaths;
        this.maxFilesPerFolder = maxFilesPerFolder;
    }

    @Override
    @Transactional
    public StorageFolder storeChunk(byte[] data, Document document, int sequenceNumber) throws IOException {
        // Get appropriate storage folder
        StorageFolder folder = getAvailableFolder(document.getStorageLevel());

        // Build chunk filename
        String filename = buildChunkFilename(document.getId(), sequenceNumber);

        // Write data to file
        Path chunkPath = Path.of(folder.getFullPath(), filename);
        Files.write(chunkPath, data);

        // Update folder statistics
        folder.incrementFileCount();
        folder.addToTotalSize((long) data.length);
        folder.setLastModifiedDate(LocalDateTime.now());

        // Save updated folder information
        return folderRepository.save(folder);
    }

    @Override
    public byte[] retrieveChunk(DocumentChunk chunk) throws IOException {
        StorageFolder folder = chunk.getStorageFolder();
        String chunkFilename = Path.of(chunk.getStoragePath()).getFileName().toString();

        Path chunkPath = Path.of(folder.getFullPath(), chunkFilename);

        if (!Files.exists(chunkPath)) {
            throw new StorageException("Chunk file not found: " + chunkPath);
        }

        return Files.readAllBytes(chunkPath);
    }

    @Override
    @Transactional
    public void deleteChunk(DocumentChunk chunk) throws IOException {
        StorageFolder folder = chunk.getStorageFolder();
        String chunkFilename = Path.of(chunk.getStoragePath()).getFileName().toString();

        Path chunkPath = Path.of(folder.getFullPath(), chunkFilename);

        if (Files.exists(chunkPath)) {
            Files.delete(chunkPath);

            // Update folder statistics
            folder.decrementFileCount();
            folder.subtractFromTotalSize(chunk.getCompressedSize());
            folder.setLastModifiedDate(LocalDateTime.now());

            // Save updated folder information
            folderRepository.save(folder);
        }
    }

    @Override
    @Transactional
    public StorageFolder getAvailableFolder(StorageLevel level) throws IOException {
        // Check for existing non-full folder
        Optional<StorageFolder> folder = folderRepository.findLeastUsedFolder(level);

        if (folder.isPresent() && !folder.get().isFull()) {
            return folder.get();
        }

        // No available folder found, create a new one
        return createNewFolder(level);
    }

    @Override
    @Transactional
    public DocumentChunk moveChunk(DocumentChunk chunk, StorageLevel targetLevel) throws IOException {
        // Read current chunk data
        byte[] chunkData = retrieveChunk(chunk);

        // Get target storage folder
        StorageFolder targetFolder = getAvailableFolder(targetLevel);

        // Build new chunk filename
        String filename = buildChunkFilename(chunk.getDocument().getId(), chunk.getSequenceNumber());

        // Write data to new location
        Path targetPath = Path.of(targetFolder.getFullPath(), filename);
        Files.write(targetPath, chunkData);

        // Update target folder statistics
        targetFolder.incrementFileCount();
        targetFolder.addToTotalSize(chunk.getCompressedSize());
        targetFolder.setLastModifiedDate(LocalDateTime.now());
        folderRepository.save(targetFolder);

        // Delete from original location
        deleteChunk(chunk);

        // Update chunk information
        String newStoragePath = targetFolder.getRelativePath() + "/" + filename;
        chunk.setStoragePath(newStoragePath);
        chunk.setStorageFolder(targetFolder);

        return chunkRepository.save(chunk);
    }

    /**
     * Create a new storage folder
     */
    private StorageFolder createNewFolder(StorageLevel level) throws IOException {
        // Select base storage path based on level
        Path basePath = selectBasePathForLevel(level);

        // Create date-based folder structure with random component to avoid too many files in one folder
        String datePath = LocalDateTime.now().format(DATE_FOLDER_FORMAT);
        String randomComponent = UUID.randomUUID().toString().substring(0, 8);
        String relativePath = level.name().toLowerCase() + "/" + datePath + "/" + randomComponent;

        // Create physical folder
        Path fullPath = storageConfig.createStorageFolder(basePath, relativePath);

        // Create and save folder entity
        StorageFolder folder = new StorageFolder(
                basePath.toString(),
                relativePath,
                fullPath.toString(),
                level,
                maxFilesPerFolder
        );

        return folderRepository.save(folder);
    }

    /**
     * Select appropriate base storage path for a storage level
     */
    private Path selectBasePathForLevel(StorageLevel level) {
        if (storagePaths.isEmpty()) {
            throw new StorageException("No storage paths configured");
        }

        // Different strategies can be implemented here
        // For simplicity, we currently use the first path for primary,
        // second for secondary (if available), and third for tertiary (if available)

        switch (level) {
            case PRIMARY:
                return storagePaths.get(0);
            case SECONDARY:
                return storagePaths.size() > 1 ? storagePaths.get(1) : storagePaths.get(0);
            case TERTIARY:
                return storagePaths.size() > 2 ? storagePaths.get(2) :
                        storagePaths.size() > 1 ? storagePaths.get(1) : storagePaths.get(0);
            default:
                return storagePaths.get(0);
        }
    }

    /**
     * Build filename for a chunk
     */
    private String buildChunkFilename(Long documentId, int sequenceNumber) {
        return String.format("doc_%d_chunk_%d.bin", documentId, sequenceNumber);
    }
}
