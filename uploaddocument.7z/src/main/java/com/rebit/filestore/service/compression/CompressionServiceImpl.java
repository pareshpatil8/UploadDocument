package com.rebit.filestore.service.compression;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.exception.ProcessingException;
import com.rebit.filestore.service.compression.strategy.CompressionStrategy;
import com.rebit.filestore.service.compression.strategy.BinaryCompressionStrategy;
import com.rebit.filestore.service.compression.strategy.ImageCompressionStrategy;
import com.rebit.filestore.service.compression.strategy.TextCompressionStrategy;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.lz4.FramedLZ4CompressorInputStream;
import org.apache.commons.compress.compressors.lz4.FramedLZ4CompressorOutputStream;
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream;
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementation of CompressionService interface
 */
@Service
public class CompressionServiceImpl implements CompressionService {

    private static final Logger logger = LoggerFactory.getLogger(CompressionServiceImpl.class);

    private final Map<String, CompressionStrategy> strategies = new ConcurrentHashMap<>();

    public CompressionServiceImpl() {
        // Initialize strategies
        strategies.put("text", new TextCompressionStrategy());
        strategies.put("image", new ImageCompressionStrategy());
        strategies.put("binary", new BinaryCompressionStrategy());
    }

    @Override
    public byte[] compressData(byte[] data, CompressionAlgorithm algorithm) {
        if (algorithm == CompressionAlgorithm.NONE) {
            return data; // No compression
        }

        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            OutputStream compressorStream = createCompressorOutputStream(outputStream, algorithm);

            compressorStream.write(data);
            compressorStream.close();

            return outputStream.toByteArray();
        } catch (IOException e) {
            logger.error("Error compressing data with algorithm: {}", algorithm, e);
            throw new ProcessingException("Compression failed: " + e.getMessage());
        }
    }

    @Override
    public byte[] decompressData(byte[] compressedData, CompressionAlgorithm algorithm) {
        if (algorithm == CompressionAlgorithm.NONE) {
            return compressedData; // No decompression needed
        }

        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(compressedData);
            InputStream decompressorStream = createDecompressorInputStream(inputStream, algorithm);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = decompressorStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            decompressorStream.close();
            return outputStream.toByteArray();
        } catch (IOException e) {
            logger.error("Error decompressing data with algorithm: {}", algorithm, e);
            throw new ProcessingException("Decompression failed: " + e.getMessage());
        }
    }

    @Override
    public CompressionAlgorithm selectAlgorithm(FileType fileType) {
        // Get appropriate strategy for the file type
        CompressionStrategy strategy = getStrategyForFileType(fileType);
        return strategy.selectAlgorithm(fileType);
    }

    @Override
    public double calculateCompressionRatio(long originalSize, long compressedSize) {
        if (compressedSize == 0) {
            return 0.0; // Avoid division by zero
        }
        return (double) originalSize / compressedSize;
    }

    /**
     * Get the appropriate compression strategy for a file type
     */
    private CompressionStrategy getStrategyForFileType(FileType fileType) {
        if (fileType == null) {
            return strategies.get("binary"); // Default to binary strategy
        }

        switch (fileType) {
            case TXT:
            case XML:
            case HTML:
                return strategies.get("text");

            case JPEG:
            case PNG:
            case GIF:
            case TIFF:
                return strategies.get("image");

            default:
                return strategies.get("binary");
        }
    }

    /**
     * Create compressor output stream based on algorithm
     */
    private OutputStream createCompressorOutputStream(OutputStream out, CompressionAlgorithm algorithm) throws IOException {
        switch (algorithm) {
            case GZIP:
                return new GzipCompressorOutputStream(out);
            case DEFLATE:
                return new DeflateCompressorOutputStream(out);
            case BZIP2:
                return new BZip2CompressorOutputStream(out);
            case ZSTD:
                return new GzipCompressorOutputStream(out);
            case LZ4:
                return new FramedLZ4CompressorOutputStream(out);
            default:
                throw new ProcessingException("Unsupported compression algorithm: " + algorithm);
        }
    }

    /**
     * Create decompressor input stream based on algorithm
     */
    private InputStream createDecompressorInputStream(InputStream in, CompressionAlgorithm algorithm) throws IOException {
        switch (algorithm) {
            case GZIP:
                return new GzipCompressorInputStream(in);
            case DEFLATE:
                return new DeflateCompressorInputStream(in);
            case BZIP2:
                return new BZip2CompressorInputStream(in);
            case ZSTD:
                return new ZstdCompressorInputStream(in);
            case LZ4:
                return new FramedLZ4CompressorInputStream(in);
            default:
                throw new ProcessingException("Unsupported decompression algorithm: " + algorithm);
        }
    }
}
