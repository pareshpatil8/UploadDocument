package com.rebit.filestore.service.chunking;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Service interface for file chunking operations
 */
public interface FileChunker {

    /**
     * Split a file into chunks and store them
     *
     * @param file File to chunk
     * @param document Document entity
     * @return List of created document chunks
     * @throws IOException If file processing fails
     */
    List<DocumentChunk> chunkFile(MultipartFile file, Document document) throws IOException;

    /**
     * Split file data into chunks and store them
     *
     * @param inputStream Input stream of file data
     * @param fileSize Total file size
     * @param document Document entity
     * @return List of created document chunks
     * @throws IOException If file processing fails
     */
    List<DocumentChunk> chunkStream(InputStream inputStream, long fileSize, Document document) throws IOException;

    /**
     * Calculate optimal chunk size for a file
     *
     * @param fileType MIME type of the file
     * @param fileSize Size of the file in bytes
     * @return Optimal chunk size in bytes
     */
    int calculateOptimalChunkSize(String fileType, long fileSize);

    /**
     * Calculate the approximate number of chunks that will be created
     *
     * @param fileSize Size of the file in bytes
     * @param fileType MIME type of the file
     * @return Estimated number of chunks
     */
    int estimateChunkCount(long fileSize, String fileType);
}
