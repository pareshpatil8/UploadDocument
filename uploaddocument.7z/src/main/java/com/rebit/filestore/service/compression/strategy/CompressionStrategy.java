package com.rebit.filestore.service.compression.strategy;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;

/**
 * Strategy interface for determining compression algorithms
 */
public interface CompressionStrategy {

    /**
     * Select the most appropriate compression algorithm for a file type
     *
     * @param fileType Type of file to compress
     * @return Recommended compression algorithm
     */
    CompressionAlgorithm selectAlgorithm(FileType fileType);
}
