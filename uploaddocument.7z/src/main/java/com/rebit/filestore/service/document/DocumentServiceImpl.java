package com.rebit.filestore.service.document;

import com.rebit.filestore.domain.dto.request.DocumentSearchRequest;
import com.rebit.filestore.domain.dto.request.DocumentUploadRequest;
import com.rebit.filestore.domain.dto.response.DocumentMetadataResponse;
import com.rebit.filestore.domain.dto.response.DocumentStatusResponse;
import com.rebit.filestore.domain.dto.response.DocumentUploadResponse;
import com.rebit.filestore.domain.entity.*;
import com.rebit.filestore.domain.enums.DocumentStatus;
import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.domain.enums.StorageLevel;
import com.rebit.filestore.domain.repository.*;
import com.rebit.filestore.exception.DocumentNotFoundException;
import com.rebit.filestore.exception.ProcessingException;
import com.rebit.filestore.service.async.AsyncProcessingService;
import com.rebit.filestore.service.chunking.FileChunker;
import com.rebit.filestore.service.custody.CustodyService;
import com.rebit.filestore.service.metadata.MetadataService;
import com.rebit.filestore.service.ocr.OcrIntegrationService;
import com.rebit.filestore.service.storage.StorageService;
import com.rebit.filestore.util.FileTypeDetector;
import com.rebit.filestore.util.TokenGenerator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Implementation of DocumentService interface
 */
@Service
public class DocumentServiceImpl implements DocumentService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentServiceImpl.class);

    private final DocumentRepository documentRepository;
    private final DocumentChunkRepository chunkRepository;
    private final DocumentMetadataRepository metadataRepository;
    private final AsyncOperationRepository asyncOperationRepository;
    private final CustodyRecordRepository custodyRepository;

    private final FileChunker fileChunker;
    private final StorageService storageService;
    private final MetadataService metadataService;
    private final CustodyService custodyService;
    private final AsyncProcessingService asyncProcessingService;
    private final OcrIntegrationService ocrService;

    private final FileTypeDetector fileTypeDetector;
    private final TokenGenerator tokenGenerator;

    @Autowired
    private String storagePathsTempDir;

    @Autowired
    public DocumentServiceImpl(DocumentRepository documentRepository,
                               DocumentChunkRepository chunkRepository,
                               DocumentMetadataRepository metadataRepository,
                               AsyncOperationRepository asyncOperationRepository,
                               CustodyRecordRepository custodyRepository,
                               FileChunker fileChunker,
                               StorageService storageService,
                               MetadataService metadataService,
                               CustodyService custodyService,
                               AsyncProcessingService asyncProcessingService,
                               OcrIntegrationService ocrService,
                               FileTypeDetector fileTypeDetector,
                               TokenGenerator tokenGenerator) {
        this.documentRepository = documentRepository;
        this.chunkRepository = chunkRepository;
        this.metadataRepository = metadataRepository;
        this.asyncOperationRepository = asyncOperationRepository;
        this.custodyRepository = custodyRepository;
        this.fileChunker = fileChunker;
        this.storageService = storageService;
        this.metadataService = metadataService;
        this.custodyService = custodyService;
        this.asyncProcessingService = asyncProcessingService;
        this.ocrService = ocrService;
        this.fileTypeDetector = fileTypeDetector;
        this.tokenGenerator = tokenGenerator;
    }

    @Override
    @Transactional
    public DocumentUploadResponse uploadDocument(MultipartFile file, DocumentUploadRequest request, String userId) {
        // Generate a unique token for the upload
        String token = tokenGenerator.generateToken();

        try {

            // Save uploaded file to permanent temp storage
            String tempFilePath = saveToTempStorage(file, token);

            // Create the document record with initial metadata
            Document document = new Document();
            document.setToken(token);
            document.setModule(request.getModule());
            document.setDepartment(request.getDepartment());
            document.setFileName(file.getOriginalFilename());
            document.setFileType(fileTypeDetector.detectFileType(file));
            document.setSize(file.getSize());
            document.setStatus(DocumentStatus.PENDING);
            document.setStorageLevel(StorageLevel.PRIMARY);
            document.setOcrRequested(request.isOcrRequested());
            document.setCreatedDate(LocalDateTime.now());

            // Save the initial document record
            documentRepository.save(document);

            // Add metadata
            metadataService.addMetadata(document, request.getAdditionalMetadata());

            // Create custody record for upload
            custodyService.recordDocumentAction(document, "UPLOAD", userId, null, null, "Document uploaded");

            // Create async operation record
            AsyncOperation operation = AsyncOperation.createUploadOperation(token, userId);
            asyncOperationRepository.save(operation);

            // Store references to the values needed in the async method
            final Long docId = document.getId();
            //final MultipartFile fileRef = file;
            final String tempPath = tempFilePath;

            // Register a post-commit hook to ensure the transaction is committed before async processing starts
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    // Start async processing only after transaction is committed
                    asyncProcessingService.processDocumentUploadFromPath(token, tempPath, docId);
                }
            });

            return DocumentUploadResponse.success(token);
        } catch (Exception e) {
            logger.error("Error initiating document upload", e);
            throw new ProcessingException("Error initiating document upload: " + e.getMessage());
        }
    }

    /**
     * Save the uploaded file to a temporary but persistent location
     */
    private String saveToTempStorage(MultipartFile file, String token) throws IOException {
        String filename = token + "_" + StringUtils.cleanPath(file.getOriginalFilename());
        Path targetPath = Paths.get(storagePathsTempDir, filename);

        // Copy uploaded file to target location
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        return targetPath.toString();
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentStatusResponse getDocumentStatus(String token) {
        AsyncOperation operation = asyncOperationRepository.findByToken(token)
                .orElseThrow(() -> new DocumentNotFoundException("No operation found with token: " + token));

        DocumentStatusResponse response = new DocumentStatusResponse();
        response.setToken(token);
        response.setRequestTimestamp(operation.getCreatedDate());

        switch(operation.getStatus()) {
            case "PENDING":
                response.setStatus(DocumentStatus.PENDING);
                response.setProgressPercentage(0);
                break;
            case "PROCESSING":
                response.setStatus(DocumentStatus.PROCESSING);
                response.setProgressPercentage(operation.getProgressPercentage());
                break;
            case "COMPLETED":
                response.setStatus(DocumentStatus.COMPLETED);
                response.setProgressPercentage(100);
                response.setDocumentId(Long.valueOf(operation.getResultIdentifier()));
                response.setCompletedTimestamp(operation.getCompletedDate());
                break;
            case "FAILED":
                response.setStatus(DocumentStatus.FAILED);
                response.setErrorMessage(operation.getErrorMessage());
                response.setCompletedTimestamp(operation.getCompletedDate());
                break;
        }

        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentMetadataResponse getDocumentMetadata(Long documentId) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        return convertToMetadataResponse(document);
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentMetadataResponse getDocumentMetadataByToken(String token) {
        Document document = documentRepository.findByToken(token)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with token: " + token));

        return convertToMetadataResponse(document);
    }

    @Override
    @Transactional
    public byte[] getDocumentContent(Long documentId, String userId) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        // Update last accessed date
        document.setLastAccessedDate(LocalDateTime.now());
        documentRepository.save(document);

        // Create custody record for download
        custodyService.recordDocumentAction(document, "DOWNLOAD", userId, null, null, "Document downloaded");

        // Get all chunks ordered by sequence number
        List<DocumentChunk> chunks = chunkRepository.findByDocumentIdOrderBySequenceNumber(documentId);

        if (chunks.isEmpty()) {
            throw new ProcessingException("Document has no content chunks");
        }

        try {
            // Reassemble document from chunks
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            for (DocumentChunk chunk : chunks) {
                byte[] chunkData = storageService.retrieveChunk(chunk);
                outputStream.write(chunkData);
            }

            return outputStream.toByteArray();
        } catch (IOException e) {
            logger.error("Error retrieving document chunks", e);
            throw new ProcessingException("Error retrieving document content: " + e.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Page<DocumentMetadataResponse> searchDocuments(DocumentSearchRequest request) {
        Sort sort = Sort.by(
                request.getSortDirection().equalsIgnoreCase("ASC") ?
                        Sort.Direction.ASC : Sort.Direction.DESC,
                request.getSortBy()
        );

        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), sort);

        // Build dynamic query based on search criteria
        // This is a simplified implementation - in a real app, you'd use a more sophisticated approach
        Page<Document> documents;

        if (request.getModule() != null && request.getDepartment() != null) {
            documents = documentRepository.findByModuleAndDepartment(
                    request.getModule(), request.getDepartment(), pageable);
        } else if (request.getModule() != null) {
            documents = documentRepository.findByModule(request.getModule(), pageable);
        } else if (request.getDepartment() != null) {
            documents = documentRepository.findByDepartment(request.getDepartment(), pageable);
        } else if (!request.getMetadata().isEmpty()) {
            // This is a simplified approach - for a real app with multiple metadata criteria,
            // you'd need a more sophisticated query mechanism
            Map.Entry<String, String> entry = request.getMetadata().entrySet().iterator().next();
            documents = documentRepository.findByMetadata(entry.getKey(), entry.getValue(), pageable);
        } else {
            documents = documentRepository.findAll(pageable);
        }

        return documents.map(this::convertToMetadataResponse);
    }

    @Override
    @Transactional
    public boolean deleteDocument(Long documentId, String userId) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        document.setStatus(DocumentStatus.DELETING);
        documentRepository.save(document);

        // Create custody record for deletion
        custodyService.recordDocumentAction(document, "DELETE", userId, null, null, "Document deleted");

        // Start async deletion process
        asyncProcessingService.processDocumentDeletion(documentId, userId);

        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<DocumentMetadataResponse> findDocumentsByMetadata(String key, String value, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Document> documents = documentRepository.findByMetadata(key, value, pageable);

        return documents.map(this::convertToMetadataResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<String> getDocumentOcrText(Long documentId) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        return Optional.ofNullable(document.getOcrText());
    }

    /**
     * Helper method to convert Document entity to DocumentMetadataResponse DTO
     */
    private DocumentMetadataResponse convertToMetadataResponse(Document document) {
        DocumentMetadataResponse response = new DocumentMetadataResponse();
        response.setId(document.getId());
        response.setFileName(document.getFileName());
        response.setFileType(document.getFileType());
        response.setSize(document.getSize());
        response.setModule(document.getModule());
        response.setDepartment(document.getDepartment());
        response.setCreatedDate(document.getCreatedDate());
        response.setLastAccessedDate(document.getLastAccessedDate());
        response.setLastModifiedDate(document.getLastModifiedDate());
        response.setStorageLevel(document.getStorageLevel());
        response.setOcrAvailable(document.getOcrText() != null && !document.getOcrText().isEmpty());

        // Convert metadata entities to map
        Map<String, String> metadataMap = new HashMap<>();
        document.getMetadata().forEach(meta -> metadataMap.put(meta.getKey(), meta.getValue()));
        response.setAdditionalMetadata(metadataMap);

        return response;
    }
}
