package com.rebit.filestore.service.custody;

import com.rebit.filestore.domain.entity.CustodyRecord;
import com.rebit.filestore.domain.entity.Document;
import org.springframework.data.domain.Page;

/**
 * Service interface for chain of custody tracking
 */
public interface CustodyService {

    /**
     * Record a document action in the chain of custody
     *
     * @param document Document being accessed
     * @param actionType Type of action (UPLOAD, VIEW, DOWNLOAD, etc.)
     * @param userId User ID performing the action
     * @param userIp User IP address (optional)
     * @param userAgent User agent string (optional)
     * @param details Additional details about the action
     * @return Created custody record
     */
    CustodyRecord recordDocumentAction(Document document, String actionType, String userId,
                                       String userIp, String userAgent, String details);

    /**
     * Get access history for a document
     *
     * @param documentId Document ID
     * @param page Page number
     * @param size Page size
     * @return Page of custody records
     */
    Page<CustodyRecord> getDocumentAccessHistory(Long documentId, int page, int size);

    /**
     * Get all actions performed by a user
     *
     * @param userId User ID
     * @param page Page number
     * @param size Page size
     * @return Page of custody records
     */
    Page<CustodyRecord> getUserActionHistory(String userId, int page, int size);

    /**
     * Get all actions of a specific type
     *
     * @param actionType Action type
     * @param page Page number
     * @param size Page size
     * @return Page of custody records
     */
    Page<CustodyRecord> getActionTypeHistory(String actionType, int page, int size);
}
