package com.rebit.filestore.service.storage;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import com.rebit.filestore.domain.entity.StorageFolder;
import com.rebit.filestore.domain.enums.StorageLevel;

import java.io.IOException;

/**
 * Service interface for physical storage operations
 */
public interface StorageService {

    /**
     * Store a chunk in the appropriate storage location
     *
     * @param data Chunk data to store
     * @param document Parent document
     * @param sequenceNumber Chunk sequence number
     * @return Storage folder where chunk was stored
     * @throws IOException If storage fails
     */
    StorageFolder storeChunk(byte[] data, Document document, int sequenceNumber) throws IOException;

    /**
     * Retrieve a chunk from storage
     *
     * @param chunk Chunk entity with storage information
     * @return Chunk data
     * @throws IOException If retrieval fails
     */
    byte[] retrieveChunk(DocumentChunk chunk) throws IOException;

    /**
     * Delete a chunk from storage
     *
     * @param chunk Chunk entity with storage information
     * @throws IOException If deletion fails
     */
    void deleteChunk(DocumentChunk chunk) throws IOException;

    /**
     * Get an available storage folder for the specified storage level
     *
     * @param level Storage level (PRIMARY, SECONDARY, TERTIARY)
     * @return Available storage folder
     * @throws IOException If no folder is available
     */
    StorageFolder getAvailableFolder(StorageLevel level) throws IOException;

    /**
     * Move a chunk to a different storage location
     *
     * @param chunk Chunk to move
     * @param targetLevel Target storage level
     * @return Updated chunk entity with new storage location
     * @throws IOException If move fails
     */
    DocumentChunk moveChunk(DocumentChunk chunk, StorageLevel targetLevel) throws IOException;
}
