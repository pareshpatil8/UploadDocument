package com.rebit.filestore.service.ocr;

import com.rebit.filestore.domain.enums.FileType;

/**
 * Service interface for OCR integration
 */
public interface OcrIntegrationService {

    /**
     * Perform OCR on document content
     *
     * @param content Document content
     * @param fileType Type of file
     * @return OCR text
     */
    String performOcr(byte[] content, FileType fileType);

    /**
     * Check if OCR is available for a file type
     *
     * @param fileType Type of file
     * @return True if OCR can be performed on this file type
     */
    boolean isOcrAvailable(FileType fileType);
}
