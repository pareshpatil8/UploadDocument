package com.rebit.filestore.service.metadata;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentMetadata;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Service interface for document metadata operations
 */
public interface MetadataService {

    /**
     * Add metadata to a document
     *
     * @param document Document entity
     * @param metadata Map of metadata key-value pairs
     * @return Set of created metadata entities
     */
    Set<DocumentMetadata> addMetadata(Document document, Map<String, String> metadata);

    /**
     * Update metadata for a document
     *
     * @param documentId Document ID
     * @param metadata Map of metadata key-value pairs to update
     * @return Set of updated metadata entities
     */
    Set<DocumentMetadata> updateMetadata(Long documentId, Map<String, String> metadata);

    /**
     * Get all metadata for a document
     *
     * @param documentId Document ID
     * @return Map of metadata key-value pairs
     */
    Map<String, String> getMetadata(Long documentId);

    /**
     * Get a specific metadata value for a document
     *
     * @param documentId Document ID
     * @param key Metadata key
     * @return Optional containing the metadata value if found
     */
    Optional<String> getMetadataValue(Long documentId, String key);

    /**
     * Delete a specific metadata entry
     *
     * @param documentId Document ID
     * @param key Metadata key
     * @return True if metadata was deleted
     */
    boolean deleteMetadata(Long documentId, String key);

    /**
     * Get all distinct metadata keys in the system
     *
     * @return List of distinct metadata keys
     */
    Set<String> getDistinctMetadataKeys();
}
