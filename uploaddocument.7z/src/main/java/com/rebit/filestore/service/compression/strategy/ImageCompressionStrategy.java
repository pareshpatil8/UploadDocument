package com.rebit.filestore.service.compression.strategy;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;

/**
 * Compression strategy for image files
 */
public class ImageCompressionStrategy implements CompressionStrategy {

    @Override
    public CompressionAlgorithm selectAlgorithm(FileType fileType) {
        // For images, be careful as many formats are already compressed
        switch (fileType) {
            case JPEG:
                // JPEGs are already compressed, so don't compress further
                return CompressionAlgorithm.NONE;

            case PNG:
                // PNGs are already compressed, but sometimes ZSTD can help a bit
                return CompressionAlgorithm.ZSTD;

            case GIF:
                // GIFs are compressed but usually not efficiently
                return CompressionAlgorithm.DEFLATE;

            case TIFF:
                // TIFFs may or may not be compressed, try LZ4 (fast)
                return CompressionAlgorithm.LZ4;

            default:
                // For other image formats, use LZ4 for speed
                return CompressionAlgorithm.LZ4;
        }
    }
}
