package com.rebit.filestore.service.async;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Service interface for asynchronous processing operations
 */
public interface AsyncProcessingService {

    /**
     * Process document upload asynchronously
     *
     * @param token Operation token
     * @param file Document file
     * @param documentId Document ID
     * @return CompletableFuture that completes when processing is done
     */
    CompletableFuture<Void> processDocumentUpload(String token, MultipartFile file, Long documentId);

    /**
     * Process document retrieval asynchronously
     *
     * @param token Operation token
     * @param documentIds List of document IDs to retrieve
     * @param userId User requesting the documents
     * @return CompletableFuture that completes when processing is done
     */
    CompletableFuture<Void> processDocumentRetrieval(String token, List<Long> documentIds, String userId);

    /**
     * Process document deletion asynchronously
     *
     * @param documentId Document ID to delete
     * @param userId User requesting the deletion
     * @return CompletableFuture that completes when processing is done
     */
    CompletableFuture<Void> processDocumentDeletion(Long documentId, String userId);

    /**
     * Process OCR for a document asynchronously
     *
     * @param documentId Document ID to OCR
     * @return CompletableFuture that completes when processing is done
     */
    CompletableFuture<Void> processOcr(Long documentId);

    CompletableFuture<Void> processDocumentUploadFromPath(String token, String filePath, Long documentId);

    /**
     * Check for and reprocess stalled async operations
     */
    void checkStalledOperations();
}
