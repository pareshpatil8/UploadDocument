package com.rebit.filestore.service.compression.strategy;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;

/**
 * Compression strategy for binary files
 */
public class BinaryCompressionStrategy implements CompressionStrategy {

    @Override
    public CompressionAlgorithm selectAlgorithm(FileType fileType) {
        // For binary and other files, select based on types
        switch (fileType) {
            case MP3:
            case MP4:
            case AVI:
                // Media files are already compressed, don't compress further
                return CompressionAlgorithm.NONE;

            case ZIP:
            case RAR:
                // Archive files are already compressed
                return CompressionAlgorithm.NONE;

            case WAV:
                // Uncompressed audio, ZSTD should work well
                return CompressionAlgorithm.ZSTD;

            case UNKNOWN:
                // For unknown binary files, use LZ4 for speed
                return CompressionAlgorithm.LZ4;

            default:
                // Default to ZSTD for general binary files (good balance)
                return CompressionAlgorithm.ZSTD;
        }
    }
}
