package com.rebit.filestore.service.compression;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;

/**
 * Service interface for compression operations
 */
public interface CompressionService {

    /**
     * Compress data using specified algorithm
     *
     * @param data Data to compress
     * @param algorithm Compression algorithm to use
     * @return Compressed data
     */
    byte[] compressData(byte[] data, CompressionAlgorithm algorithm);

    /**
     * Decompress data using specified algorithm
     *
     * @param compressedData Compressed data
     * @param algorithm Algorithm used for compression
     * @return Decompressed data
     */
    byte[] decompressData(byte[] compressedData, CompressionAlgorithm algorithm);

    /**
     * Select the most appropriate compression algorithm for a file type
     *
     * @param fileType Type of file
     * @return Recommended compression algorithm
     */
    CompressionAlgorithm selectAlgorithm(FileType fileType);

    /**
     * Calculate compression ratio
     *
     * @param originalSize Original size in bytes
     * @param compressedSize Compressed size in bytes
     * @return Compression ratio (1.0 means no change, 2.0 means halved size)
     */
    double calculateCompressionRatio(long originalSize, long compressedSize);
}