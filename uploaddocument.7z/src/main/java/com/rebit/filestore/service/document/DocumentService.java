package com.rebit.filestore.service.document;

import com.rebit.filestore.domain.dto.request.DocumentSearchRequest;
import com.rebit.filestore.domain.dto.request.DocumentUploadRequest;
import com.rebit.filestore.domain.dto.response.DocumentMetadataResponse;
import com.rebit.filestore.domain.dto.response.DocumentStatusResponse;
import com.rebit.filestore.domain.dto.response.DocumentUploadResponse;
import com.rebit.filestore.domain.entity.Document;
import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for document operations
 */
public interface DocumentService {

    /**
     * Upload a document asynchronously
     *
     * @param file Document file
     * @param request Upload request with metadata
     * @param userId User performing the upload
     * @return Upload response with token
     */
    DocumentUploadResponse uploadDocument(MultipartFile file, DocumentUploadRequest request, String userId);

    /**
     * Get status of a document upload by token
     *
     * @param token Upload token
     * @return Status response
     */
    DocumentStatusResponse getDocumentStatus(String token);

    /**
     * Get document metadata by ID
     *
     * @param documentId Document ID
     * @return Document metadata
     */
    DocumentMetadataResponse getDocumentMetadata(Long documentId);

    /**
     * Get document metadata by token
     *
     * @param token Document token
     * @return Document metadata
     */
    DocumentMetadataResponse getDocumentMetadataByToken(String token);

    /**
     * Get document content as byte array
     *
     * @param documentId Document ID
     * @param userId User ID retrieving the document
     * @return Document content
     */
    byte[] getDocumentContent(Long documentId, String userId);

    /**
     * Search for documents based on criteria
     *
     * @param request Search criteria
     * @return Page of document metadata
     */
    Page<DocumentMetadataResponse> searchDocuments(DocumentSearchRequest request);

    /**
     * Delete a document
     *
     * @param documentId Document ID
     * @param userId User performing the deletion
     * @return True if successful
     */
    boolean deleteDocument(Long documentId, String userId);

    /**
     * Find documents with specific metadata
     *
     * @param key Metadata key
     * @param value Metadata value
     * @param page Page number
     * @param size Page size
     * @return Page of document metadata
     */
    Page<DocumentMetadataResponse> findDocumentsByMetadata(String key, String value, int page, int size);

    /**
     * Get the OCR text for a document
     *
     * @param documentId Document ID
     * @return OCR text if available
     */
    Optional<String> getDocumentOcrText(Long documentId);
}
