package com.rebit.filestore.service.metadata;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentMetadata;
import com.rebit.filestore.domain.repository.DocumentMetadataRepository;
import com.rebit.filestore.domain.repository.DocumentRepository;
import com.rebit.filestore.exception.DocumentNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation of MetadataService interface
 */
@Service
public class MetadataServiceImpl implements MetadataService {

    private static final Logger logger = LoggerFactory.getLogger(MetadataServiceImpl.class);

    private final DocumentRepository documentRepository;
    private final DocumentMetadataRepository metadataRepository;

    @Autowired
    public MetadataServiceImpl(DocumentRepository documentRepository,
                               DocumentMetadataRepository metadataRepository) {
        this.documentRepository = documentRepository;
        this.metadataRepository = metadataRepository;
    }

    @Override
    @Transactional
    public Set<DocumentMetadata> addMetadata(Document document, Map<String, String> metadata) {
        if (metadata == null || metadata.isEmpty()) {
            return Collections.emptySet();
        }

        Set<DocumentMetadata> metadataEntities = new HashSet<>();

        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            // Skip blank keys or values
            if (key == null || key.isBlank() || value == null) {
                continue;
            }

            // Create metadata entity
            DocumentMetadata metadataEntity = new DocumentMetadata(document, key, value);
            document.addMetadata(metadataEntity);
            metadataEntities.add(metadataEntity);
        }

        return metadataEntities;
    }

    @Override
    @Transactional
    public Set<DocumentMetadata> updateMetadata(Long documentId, Map<String, String> metadata) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        if (metadata == null || metadata.isEmpty()) {
            return Collections.emptySet();
        }

        Set<DocumentMetadata> updatedMetadata = new HashSet<>();

        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            // Skip blank keys or values
            if (key == null || key.isBlank() || value == null) {
                continue;
            }

            // Check if metadata already exists
            Optional<DocumentMetadata> existingMetadata = document.getMetadata().stream()
                    .filter(meta -> key.equals(meta.getKey()))
                    .findFirst();

            if (existingMetadata.isPresent()) {
                // Update existing metadata
                DocumentMetadata meta = existingMetadata.get();
                meta.setValue(value);
                updatedMetadata.add(meta);
            } else {
                // Create new metadata
                DocumentMetadata newMeta = new DocumentMetadata(document, key, value);
                document.addMetadata(newMeta);
                updatedMetadata.add(newMeta);
            }
        }

        documentRepository.save(document);
        return updatedMetadata;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, String> getMetadata(Long documentId) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

        Map<String, String> metadataMap = new HashMap<>();

        for (DocumentMetadata metadata : document.getMetadata()) {
            metadataMap.put(metadata.getKey(), metadata.getValue());
        }

        return metadataMap;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<String> getMetadataValue(Long documentId, String key) {
        if (key == null || key.isBlank()) {
            return Optional.empty();
        }

        return metadataRepository.findByDocumentIdAndKey(documentId, key)
                .map(DocumentMetadata::getValue);
    }

    @Override
    @Transactional
    public boolean deleteMetadata(Long documentId, String key) {
        if (key == null || key.isBlank()) {
            return false;
        }

        Optional<DocumentMetadata> metadata = metadataRepository.findByDocumentIdAndKey(documentId, key);

        if (metadata.isPresent()) {
            DocumentMetadata meta = metadata.get();
            Document document = meta.getDocument();
            document.removeMetadata(meta);
            documentRepository.save(document);
            return true;
        }

        return false;
    }

    @Override
    @Transactional(readOnly = true)
    public Set<String> getDistinctMetadataKeys() {
        List<String> keys = metadataRepository.findDistinctKeys();
        return new HashSet<>(keys);
    }
}
