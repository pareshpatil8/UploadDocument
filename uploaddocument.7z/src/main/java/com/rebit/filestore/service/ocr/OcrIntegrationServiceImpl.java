package com.rebit.filestore.service.ocr;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.filestore.domain.enums.FileType;
import com.rebit.filestore.exception.ProcessingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

/**
 * Implementation of OcrIntegrationService interface
 */
@Service
public class OcrIntegrationServiceImpl implements OcrIntegrationService {

    private static final Logger logger = LoggerFactory.getLogger(OcrIntegrationServiceImpl.class);

    // File types that support OCR
    private static final Set<FileType> OCR_SUPPORTED_TYPES = new HashSet<>(Arrays.asList(
            FileType.PDF, FileType.JPEG, FileType.PNG, FileType.TIFF, FileType.DOC, FileType.DOCX
    ));

    @Value("${file-store.ocr.service-url}")
    private String ocrServiceUrl;

    @Value("${file-store.ocr.enabled:true}")
    private boolean ocrEnabled;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Autowired
    public OcrIntegrationServiceImpl(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
    }

    @Override
    public String performOcr(byte[] content, FileType fileType) {
        if (!ocrEnabled) {
            logger.info("OCR is disabled, skipping");
            return null;
        }

        if (!isOcrAvailable(fileType)) {
            logger.info("OCR not available for file type: {}", fileType);
            return null;
        }

        try {
            logger.info("Requesting OCR for file type: {}, content size: {} bytes", fileType, content.length);

            // Prepare request with file content
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("file", new ByteArrayResource(content) {
                @Override
                public String getFilename() {
                    return "document." + (fileType.getExtensions().length > 0 ? fileType.getExtensions()[0] : "bin");
                }
            });
            body.add("fileType", fileType.name());

            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

            // Send request to OCR service
            ResponseEntity<OcrResponse> response = restTemplate.exchange(
                    ocrServiceUrl,
                    HttpMethod.POST,
                    requestEntity,
                    OcrResponse.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                OcrResponse ocrResponse = response.getBody();
                logger.info("OCR completed successfully, text length: {}",
                        ocrResponse.getText() != null ? ocrResponse.getText().length() : 0);
                return ocrResponse.getText();
            } else {
                logger.warn("OCR service returned non-OK response: {}", response.getStatusCode());
                return null;
            }
        } catch (Exception e) {
            logger.error("Error performing OCR", e);
            throw new ProcessingException("Error performing OCR: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean isOcrAvailable(FileType fileType) {
        return OCR_SUPPORTED_TYPES.contains(fileType);
    }

    /**
     * Simple response class for OCR service
     */
    private static class OcrResponse {
        private String text;
        private boolean success;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }
    }
}
