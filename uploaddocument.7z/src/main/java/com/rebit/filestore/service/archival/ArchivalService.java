package com.rebit.filestore.service.archival;

import com.rebit.filestore.domain.enums.StorageLevel;

import java.util.Map;

/**
 * Service interface for archival operations
 */
public interface ArchivalService {

    /**
     * Manually trigger archival process
     *
     * @param userId User triggering the archival
     */
    void triggerArchival(String userId);

    /**
     * Move a document to a specific storage level
     *
     * @param documentId Document ID
     * @param targetLevel Target storage level
     * @param userId User triggering the move
     * @return true if move was successful
     */
    boolean moveDocumentToStorageLevel(Long documentId, StorageLevel targetLevel, String userId);

    /**
     * Get storage statistics
     *
     * @return Map of storage statistics
     */
    Map<String, Object> getStorageStatistics();

    /**
     * Get document access history
     *
     * @param documentId Document ID
     * @param page Page number
     * @param size Page size
     * @return Map of access history
     */
    Map<String, Object> getDocumentAccessHistory(Long documentId, int page, int size);
}
