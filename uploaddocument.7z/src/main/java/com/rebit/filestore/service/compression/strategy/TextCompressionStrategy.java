package com.rebit.filestore.service.compression.strategy;

import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.enums.FileType;

/**
 * Compression strategy for text files
 */
public class TextCompressionStrategy implements CompressionStrategy {

    @Override
    public CompressionAlgorithm selectAlgorithm(FileType fileType) {
        // For text files, ZSTD is a good balance of compression ratio and speed
        switch (fileType) {
            case TXT:
            case XML:
            case HTML:
                return CompressionAlgorithm.ZSTD;

            case DOC:
            case DOCX:
            case XLS:
            case XLSX:
            case PPT:
            case PPTX:
                // Office formats are already compressed internally, but GZIP might still help
                return CompressionAlgorithm.GZIP;

            case PDF:
                // PDFs are often already compressed, but we can try DEFLATE
                return CompressionAlgorithm.DEFLATE;

            default:
                // Fall back to GZIP for other text-like formats
                return CompressionAlgorithm.GZIP;
        }
    }
}
