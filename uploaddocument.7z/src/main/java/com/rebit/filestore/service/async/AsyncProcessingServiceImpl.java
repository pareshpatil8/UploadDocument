package com.rebit.filestore.service.async;

import com.rebit.filestore.domain.entity.AsyncOperation;
import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import com.rebit.filestore.domain.enums.DocumentStatus;
import com.rebit.filestore.domain.repository.AsyncOperationRepository;
import com.rebit.filestore.domain.repository.DocumentChunkRepository;
import com.rebit.filestore.domain.repository.DocumentRepository;
import com.rebit.filestore.exception.DocumentNotFoundException;
import com.rebit.filestore.exception.ProcessingException;
import com.rebit.filestore.service.chunking.FileChunker;
import com.rebit.filestore.service.custody.CustodyService;
import com.rebit.filestore.service.ocr.OcrIntegrationService;
import com.rebit.filestore.service.storage.StorageService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Implementation of AsyncProcessingService interface
 */
@Service
public class AsyncProcessingServiceImpl implements AsyncProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(AsyncProcessingServiceImpl.class);
    private static final int STALL_HOURS = 2; // Operations stalled for over 2 hours

    private final DocumentRepository documentRepository;
    private final DocumentChunkRepository chunkRepository;
    private final AsyncOperationRepository operationRepository;

    private final FileChunker fileChunker;
    private final StorageService storageService;
    private final CustodyService custodyService;
    private final OcrIntegrationService ocrService;

    @Autowired
    @Qualifier("documentProcessingExecutor")
    private Executor documentProcessingExecutor;

    @Autowired
    @Qualifier("ocrProcessingExecutor")
    private Executor ocrProcessingExecutor;

    @Autowired
    public AsyncProcessingServiceImpl(DocumentRepository documentRepository,
                                      DocumentChunkRepository chunkRepository,
                                      AsyncOperationRepository operationRepository,
                                      FileChunker fileChunker,
                                      StorageService storageService,
                                      CustodyService custodyService,
                                      OcrIntegrationService ocrService) {
        this.documentRepository = documentRepository;
        this.chunkRepository = chunkRepository;
        this.operationRepository = operationRepository;
        this.fileChunker = fileChunker;
        this.storageService = storageService;
        this.custodyService = custodyService;
        this.ocrService = ocrService;
    }

    @Override
    @Async("documentProcessingExecutor")
    @Transactional
    public CompletableFuture<Void> processDocumentUpload(String token, MultipartFile file, Long documentId) {
        logger.info("Starting async document upload processing: {} for document: {}", token, documentId);

        try {
            // Get the operation and document
            AsyncOperation operation = operationRepository.findByToken(token)
                    .orElseThrow(() -> new ProcessingException("Operation not found with token: " + token));

            Document document = documentRepository.findById(documentId)
                    .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

            // Mark operation as started
            operation.markStarted();
            operationRepository.save(operation);

            // Update document status
            document.setStatus(DocumentStatus.PROCESSING);
            documentRepository.save(document);

            // Process file in chunks
            operation.updateProgress(10);
            operationRepository.save(operation);

            List<DocumentChunk> chunks = fileChunker.chunkFile(file, document);

            // Update document status to completed
            document.setStatus(DocumentStatus.COMPLETED);
            documentRepository.save(document);

            operation.updateProgress(90);
            operationRepository.save(operation);

            // Process OCR if requested
            if (document.getOcrRequested()) {
                processOcr(documentId);
            }

            // Mark operation as completed
            operation.markCompleted(String.valueOf(documentId));
            operationRepository.save(operation);

            logger.info("Completed async document upload processing: {} for document: {}", token, documentId);

            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            logger.error("Error processing document upload", e);

            try {
                // Update operation status
                AsyncOperation operation = operationRepository.findByToken(token).orElse(null);
                if (operation != null) {
                    operation.markFailed(e.getMessage());
                    operationRepository.save(operation);
                }

                // Update document status
                Optional<Document> document = documentRepository.findById(documentId);
                document.ifPresent(doc -> {
                    doc.setStatus(DocumentStatus.FAILED);
                    documentRepository.save(doc);
                });
            } catch (Exception ex) {
                logger.error("Error updating status after failure", ex);
            }

            throw new ProcessingException("Error processing document upload: " + e.getMessage(), e);
        }
    }

    @Override
    @Async("documentProcessingExecutor")
    @Transactional
    public CompletableFuture<Void> processDocumentRetrieval(String token, List<Long> documentIds, String userId) {
        logger.info("Starting async document retrieval processing: {} for documents: {}", token, documentIds);

        try {
            // Get the operation
            AsyncOperation operation = operationRepository.findByToken(token)
                    .orElseThrow(() -> new ProcessingException("Operation not found with token: " + token));

            // Mark operation as started
            operation.markStarted();
            operationRepository.save(operation);

            // Verify documents exist
            List<Document> documents = documentRepository.findByIdIn(documentIds);
            if (documents.size() != documentIds.size()) {
                throw new DocumentNotFoundException("One or more documents not found");
            }

            // For each document, record access
            for (Document document : documents) {
                document.setLastAccessedDate(LocalDateTime.now());
                documentRepository.save(document);

                custodyService.recordDocumentAction(document, "VIEW", userId, null, null, "Document viewed");

                // Update progress incrementally
                int progress = (int) ((documents.indexOf(document) + 1) / (double) documents.size() * 100);
                operation.updateProgress(progress);
                operationRepository.save(operation);
            }

            // Mark operation as completed
            operation.markCompleted("Retrieved " + documents.size() + " documents");
            operationRepository.save(operation);

            logger.info("Completed async document retrieval processing: {}", token);

            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            logger.error("Error processing document retrieval", e);

            try {
                // Update operation status
                AsyncOperation operation = operationRepository.findByToken(token).orElse(null);
                if (operation != null) {
                    operation.markFailed(e.getMessage());
                    operationRepository.save(operation);
                }
            } catch (Exception ex) {
                logger.error("Error updating status after failure", ex);
            }

            throw new ProcessingException("Error processing document retrieval: " + e.getMessage(), e);
        }
    }

    @Override
    @Async("documentProcessingExecutor")
    @Transactional
    public CompletableFuture<Void> processDocumentDeletion(Long documentId, String userId) {
        logger.info("Starting async document deletion for document: {}", documentId);

        try {
            // Get the document
            Document document = documentRepository.findById(documentId)
                    .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

            // Get all chunks
            List<DocumentChunk> chunks = chunkRepository.findByDocumentIdOrderBySequenceNumber(documentId);

            // Delete each chunk
            for (DocumentChunk chunk : chunks) {
                storageService.deleteChunk(chunk);
            }

            // Update document status
            document.setStatus(DocumentStatus.DELETED);
            documentRepository.save(document);

            // Record deletion
            custodyService.recordDocumentAction(document, "DELETE", userId, null, null, "Document deleted");

            logger.info("Completed async document deletion for document: {}", documentId);

            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            logger.error("Error processing document deletion", e);

            try {
                // Update document status
                Optional<Document> document = documentRepository.findById(documentId);
                document.ifPresent(doc -> {
                    doc.setStatus(DocumentStatus.FAILED);
                    documentRepository.save(doc);
                });
            } catch (Exception ex) {
                logger.error("Error updating status after failure", ex);
            }

            throw new ProcessingException("Error processing document deletion: " + e.getMessage(), e);
        }
    }

    @Override
    @Async("ocrProcessingExecutor")
    @Transactional
    public CompletableFuture<Void> processOcr(Long documentId) {
        logger.info("Starting async OCR processing for document: {}", documentId);

        try {
            // Get the document
            Document document = documentRepository.findById(documentId)
                    .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

            if (!document.getOcrRequested()) {
                logger.info("OCR not requested for document: {}, skipping", documentId);
                return CompletableFuture.completedFuture(null);
            }

            // Get document content for OCR
            List<DocumentChunk> chunks = chunkRepository.findByDocumentIdOrderBySequenceNumber(documentId);
            if (chunks.isEmpty()) {
                logger.warn("No chunks found for document: {}, skipping OCR", documentId);
                return CompletableFuture.completedFuture(null);
            }

            // Assemble document content
            byte[] content = new byte[0];
            for (DocumentChunk chunk : chunks) {
                byte[] chunkContent = storageService.retrieveChunk(chunk);

                // Extend array
                byte[] newContent = new byte[content.length + chunkContent.length];
                System.arraycopy(content, 0, newContent, 0, content.length);
                System.arraycopy(chunkContent, 0, newContent, content.length, chunkContent.length);
                content = newContent;
            }

            // Call OCR service
            String ocrText = ocrService.performOcr(content, document.getFileType());

            // Update document with OCR text
            document.setOcrText(ocrText);
            documentRepository.save(document);

            logger.info("Completed async OCR processing for document: {}", documentId);

            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            logger.error("Error processing OCR", e);
            throw new ProcessingException("Error processing OCR: " + e.getMessage(), e);
        }
    }

    @Override
    @Scheduled(fixedDelay = 60000) // Check every minute
    public void checkStalledOperations() {
        logger.debug("Checking for stalled operations");

        LocalDateTime cutoff = LocalDateTime.now().minusHours(STALL_HOURS);
        List<AsyncOperation> stalledOperations = operationRepository.findStalledOperations(cutoff);

        for (AsyncOperation operation : stalledOperations) {
            logger.warn("Found stalled operation: {}, token: {}, started at: {}",
                    operation.getId(), operation.getToken(), operation.getStartedDate());

            // Mark as failed
            operation.markFailed("Operation timed out after " + STALL_HOURS + " hours");
            operationRepository.save(operation);
        }
    }

    @Override
    @Async("documentProcessingExecutor")
    @Transactional
    public CompletableFuture<Void> processDocumentUploadFromPath(String token, String filePath, Long documentId) {
        logger.info("Starting async document upload processing from path: {} for document: {}", filePath, documentId);

        try {
            // Get the operation and document
            AsyncOperation operation = operationRepository.findByToken(token)
                    .orElseThrow(() -> new ProcessingException("Operation not found with token: " + token));

            Document document = documentRepository.findById(documentId)
                    .orElseThrow(() -> new DocumentNotFoundException("Document not found with ID: " + documentId));

            // Mark operation as started
            operation.markStarted();
            operationRepository.save(operation);

            // Update document status
            document.setStatus(DocumentStatus.PROCESSING);
            documentRepository.save(document);

            // Process file in chunks using file path
            operation.updateProgress(10);
            operationRepository.save(operation);

            // Create an input stream from the file path
            try (InputStream fileInputStream = Files.newInputStream(Paths.get(filePath))) {
                List<DocumentChunk> chunks = fileChunker.chunkStream(fileInputStream, Files.size(Paths.get(filePath)), document);

                // Update document status to completed
                document.setStatus(DocumentStatus.COMPLETED);
                documentRepository.save(document);

                operation.updateProgress(90);
                operationRepository.save(operation);

                // Process OCR if requested
                if (document.getOcrRequested()) {
                    processOcr(documentId);
                }

                // Mark operation as completed
                operation.markCompleted(String.valueOf(documentId));
                operationRepository.save(operation);

                logger.info("Completed async document upload processing: {} for document: {}", token, documentId);

                // Clean up the temporary file
                try {
                    Files.deleteIfExists(Paths.get(filePath));
                } catch (IOException e) {
                    logger.warn("Failed to delete temporary file: {}", filePath, e);
                }

                return CompletableFuture.completedFuture(null);
            }
        } catch (Exception e) {
            logger.error("Error processing document upload", e);

            try {
                // Update operation status
                AsyncOperation operation = operationRepository.findByToken(token).orElse(null);
                if (operation != null) {
                    operation.markFailed(e.getMessage());
                    operationRepository.save(operation);
                }

                // Update document status
                Optional<Document> document = documentRepository.findById(documentId);
                document.ifPresent(doc -> {
                    doc.setStatus(DocumentStatus.FAILED);
                    documentRepository.save(doc);
                });

                // Clean up the temporary file
                try {
                    Files.deleteIfExists(Paths.get(filePath));
                } catch (IOException ex) {
                    logger.warn("Failed to delete temporary file: {}", filePath, ex);
                }
            } catch (Exception ex) {
                logger.error("Error updating status after failure", ex);
            }

            throw new ProcessingException("Error processing document upload: " + e.getMessage(), e);
        }
    }
}
