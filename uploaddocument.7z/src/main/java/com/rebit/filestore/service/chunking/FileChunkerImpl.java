package com.rebit.filestore.service.chunking;

import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.entity.DocumentChunk;
import com.rebit.filestore.domain.entity.StorageFolder;
import com.rebit.filestore.domain.enums.CompressionAlgorithm;
import com.rebit.filestore.domain.repository.DocumentChunkRepository;
import com.rebit.filestore.service.compression.CompressionService;
import com.rebit.filestore.service.storage.StorageService;
import com.rebit.filestore.util.FileTypeDetector;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Implementation of FileChunker interface
 */
@Service
public class FileChunkerImpl implements FileChunker {

    private static final Logger logger = LoggerFactory.getLogger(FileChunkerImpl.class);

    // Base chunk sizes by file type (bytes)
    private static final int DEFAULT_CHUNK_SIZE = 1024 * 1024; // 1 MB
    private static final int TEXT_CHUNK_SIZE = 512 * 1024; // 512 KB
    private static final int IMAGE_CHUNK_SIZE = 2 * 1024 * 1024; // 2 MB
    private static final int VIDEO_CHUNK_SIZE = 5 * 1024 * 1024; // 5 MB
    private static final int OFFICE_CHUNK_SIZE = 1024 * 1024; // 1 MB

    // Minimum and maximum chunk sizes
    private static final int MIN_CHUNK_SIZE = 64 * 1024; // 64 KB
    private static final int MAX_CHUNK_SIZE = 10 * 1024 * 1024; // 10 MB

    private final DocumentChunkRepository chunkRepository;
    private final StorageService storageService;
    private final CompressionService compressionService;
    private final FileTypeDetector fileTypeDetector;

    @Autowired
    @Qualifier("chunkProcessingExecutor")
    private Executor chunkProcessingExecutor;

    @Autowired
    public FileChunkerImpl(DocumentChunkRepository chunkRepository,
                           StorageService storageService,
                           CompressionService compressionService,
                           FileTypeDetector fileTypeDetector) {
        this.chunkRepository = chunkRepository;
        this.storageService = storageService;
        this.compressionService = compressionService;
        this.fileTypeDetector = fileTypeDetector;
    }

    @Override
    public List<DocumentChunk> chunkFile(MultipartFile file, Document document) throws IOException {
        logger.info("Chunking file: {}, size: {}", file.getOriginalFilename(), file.getSize());

        return chunkStream(file.getInputStream(), file.getSize(), document);
    }

    @Override
    public List<DocumentChunk> chunkStream(InputStream inputStream, long fileSize, Document document) throws IOException {
        String fileType = fileTypeDetector.getMimeType(document.getFileName());
        int chunkSize = calculateOptimalChunkSize(fileType, fileSize);

        logger.info("Using chunk size of {} bytes for document {}", chunkSize, document.getId());

        List<CompletableFuture<DocumentChunk>> chunkFutures = new ArrayList<>();
        List<DocumentChunk> chunks = new ArrayList<>();

        byte[] buffer = new byte[chunkSize];
        int chunkNumber = 0;
        int bytesRead;

        while ((bytesRead = inputStream.read(buffer)) > 0) {
            // If we didn't read a full chunk, create a properly sized array
            byte[] chunkData = bytesRead < chunkSize ?
                    java.util.Arrays.copyOf(buffer, bytesRead) :
                    buffer;

            // Process chunk asynchronously
            int currentChunkNumber = chunkNumber++;
            CompletableFuture<DocumentChunk> future = CompletableFuture.supplyAsync(() -> {
                try {
                    return processChunk(chunkData, document, currentChunkNumber);
                } catch (Exception e) {
                    logger.error("Error processing chunk {}", currentChunkNumber, e);
                    throw new RuntimeException("Error processing chunk " + currentChunkNumber, e);
                }
            }, chunkProcessingExecutor);

            chunkFutures.add(future);

            // Prepare new buffer for next chunk
            buffer = new byte[chunkSize];
        }

        // Wait for all chunks to be processed
        for (CompletableFuture<DocumentChunk> future : chunkFutures) {
            try {
                DocumentChunk chunk = future.join();
                chunks.add(chunk);
            } catch (Exception e) {
                logger.error("Chunk processing failed", e);
                throw new IOException("Failed to process one or more chunks", e);
            }
        }

        return chunks;
    }

    @Override
    public int calculateOptimalChunkSize(String fileType, long fileSize) {
        // Base chunk size by file type
        int baseChunkSize;

        if (fileType.startsWith("text/") || fileType.contains("xml")) {
            baseChunkSize = TEXT_CHUNK_SIZE;
        } else if (fileType.startsWith("image/")) {
            baseChunkSize = IMAGE_CHUNK_SIZE;
        } else if (fileType.startsWith("video/")) {
            baseChunkSize = VIDEO_CHUNK_SIZE;
        } else if (fileType.contains("officedocument") || fileType.contains("pdf")) {
            baseChunkSize = OFFICE_CHUNK_SIZE;
        } else {
            baseChunkSize = DEFAULT_CHUNK_SIZE;
        }

        // Adjust chunk size based on file size
        if (fileSize > 100 * 1024 * 1024) { // Over 100 MB
            baseChunkSize *= 2; // Double chunk size for large files
        } else if (fileSize < 1 * 1024 * 1024) { // Under 1 MB
            baseChunkSize /= 2; // Halve chunk size for small files
        }

        // Ensure chunk size is within allowed range
        return Math.max(MIN_CHUNK_SIZE, Math.min(baseChunkSize, MAX_CHUNK_SIZE));
    }

    @Override
    public int estimateChunkCount(long fileSize, String fileType) {
        int chunkSize = calculateOptimalChunkSize(fileType, fileSize);
        return (int) Math.ceil((double) fileSize / chunkSize);
    }

    /**
     * Process a single chunk: compress, calculate checksum, store, and create record
     */
    private DocumentChunk processChunk(byte[] chunkData, Document document, int sequenceNumber) throws IOException {
        // Determine best compression algorithm for the file type
        CompressionAlgorithm algorithm = compressionService.selectAlgorithm(document.getFileType());

        // Compress chunk
        byte[] compressedData = compressionService.compressData(chunkData, algorithm);

        // Calculate checksum
        String checksum = calculateChecksum(compressedData);

        // Store chunk and get storage location info
        StorageFolder folder = storageService.storeChunk(compressedData, document, sequenceNumber);

        // Build path to the chunk
        String filename = buildChunkFilename(document.getId(), sequenceNumber);
        String storagePath = folder.getRelativePath() + "/" + filename;

        // Create and save chunk entity
        DocumentChunk chunk = new DocumentChunk();
        chunk.setDocument(document);
        chunk.setSequenceNumber(sequenceNumber);
        chunk.setSize((long) chunkData.length);
        chunk.setCompressedSize((long) compressedData.length);
        chunk.setCompressionAlgorithm(algorithm);
        chunk.setChecksum(checksum);
        chunk.setStoragePath(storagePath);
        chunk.setStorageFolder(folder);

        return chunkRepository.save(chunk);
    }

    /**
     * Calculate SHA-256 checksum for a byte array
     */
    private String calculateChecksum(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error calculating checksum", e);
            throw new RuntimeException("Error calculating checksum", e);
        }
    }

    /**
     * Build filename for a chunk
     */
    private String buildChunkFilename(Long documentId, int sequenceNumber) {
        return String.format("doc_%d_chunk_%d.bin", documentId, sequenceNumber);
    }
}
