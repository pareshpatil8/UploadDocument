package com.rebit.filestore.service.custody;

import com.rebit.filestore.domain.entity.CustodyRecord;
import com.rebit.filestore.domain.entity.Document;
import com.rebit.filestore.domain.repository.CustodyRecordRepository;
import com.rebit.filestore.domain.repository.DocumentRepository;
import com.rebit.filestore.exception.DocumentNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of CustodyService interface
 */
@Service
public class CustodyServiceImpl implements CustodyService {

    private static final Logger logger = LoggerFactory.getLogger(CustodyServiceImpl.class);

    private final CustodyRecordRepository custodyRepository;
    private final DocumentRepository documentRepository;

    @Autowired
    public CustodyServiceImpl(CustodyRecordRepository custodyRepository,
                              DocumentRepository documentRepository) {
        this.custodyRepository = custodyRepository;
        this.documentRepository = documentRepository;
    }

    @Override
    @Transactional
    public CustodyRecord recordDocumentAction(Document document, String actionType, String userId,
                                              String userIp, String userAgent, String details) {
        logger.debug("Recording document action: {} on document: {}, by user: {}",
                actionType, document.getId(), userId);

        CustodyRecord record = new CustodyRecord(document, actionType, userId, userIp, userAgent, details);

        return custodyRepository.save(record);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CustodyRecord> getDocumentAccessHistory(Long documentId, int page, int size) {
        // Verify document exists
        if (!documentRepository.existsById(documentId)) {
            throw new DocumentNotFoundException("Document not found with ID: " + documentId);
        }

        return custodyRepository.findByDocumentId(
                documentId,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "actionTimestamp"))
        );
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CustodyRecord> getUserActionHistory(String userId, int page, int size) {
        return custodyRepository.findByUserId(
                userId,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "actionTimestamp"))
        );
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CustodyRecord> getActionTypeHistory(String actionType, int page, int size) {
        return custodyRepository.findByActionType(
                actionType,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "actionTimestamp"))
        );
    }
}
