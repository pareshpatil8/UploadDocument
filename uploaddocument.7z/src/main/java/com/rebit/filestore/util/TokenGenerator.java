package com.rebit.filestore.util;

import org.springframework.stereotype.Component;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.UUID;

/**
 * Utility class for generating secure tokens
 */
@Component
public class TokenGenerator {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int RANDOM_BYTES = 12;

    /**
     * Generate a secure, unique token for document operations
     *
     * @return Secure token
     */
    public String generateToken() {
        // Combine timestamp, random component, and UUID for uniqueness

        // Timestamp component for sorting/chronology
        String timestamp = LocalDateTime.now().format(DATE_FORMAT);

        // Random component for security
        byte[] randomBytes = new byte[RANDOM_BYTES];
        RANDOM.nextBytes(randomBytes);
        String randomComponent = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);

        // Combine parts
        return timestamp + "-" + randomComponent;
    }

    /**
     * Generate a folder path component that's random but organized
     *
     * @return Path component suitable for folder organization
     */
    public String generatePathComponent() {
        // Create a hierarchical path with some randomness
        // Format: aa/bb/cccccccc where each letter is a hex digit

        String uuid = UUID.randomUUID().toString().replace("-", "");

        return uuid.substring(0, 2) + "/" +
                uuid.substring(2, 4) + "/" +
                uuid.substring(4, 12);
    }
}
