package com.rebit.filestore.util;

import com.rebit.filestore.domain.enums.FileType;
import org.apache.tika.Tika;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/**
 * Utility class for detecting file types
 */
@Component
public class FileTypeDetector {

    private final Tika tika;

    public FileTypeDetector() {
        this.tika = new Tika();
    }

    /**
     * Detect file type from MultipartFile
     *
     * @param file File to analyze
     * @return Detected file type
     */
    public FileType detectFileType(MultipartFile file) {
        String filename = file.getOriginalFilename();
        String mimeType = detectMimeType(file);

        return determineFileType(filename, mimeType);
    }

    /**
     * Detect file type from a file on disk
     *
     * @param path Path to file
     * @return Detected file type
     */
    public FileType detectFileType(Path path) {
        try {
            String filename = path.getFileName().toString();
            String mimeType = tika.detect(path);

            return determineFileType(filename, mimeType);
        } catch (IOException e) {
            // If detection fails, fall back to extension-based detection
            String filename = path.getFileName().toString();
            return detectFileTypeFromFilename(filename);
        }
    }

    /**
     * Get MIME type for a file
     *
     * @param file File to analyze
     * @return MIME type string
     */
    public String getMimeType(MultipartFile file) {
        try {
            return tika.detect(file.getInputStream());
        } catch (IOException e) {
            // Fall back to extension-based detection
            return getMimeType(file.getOriginalFilename());
        }
    }

    /**
     * Get MIME type based on filename
     *
     * @param filename Filename to analyze
     * @return MIME type string
     */
    public String getMimeType(String filename) {
        return tika.detect(filename);
    }

    /**
     * Detect MIME type from MultipartFile
     */
    private String detectMimeType(MultipartFile file) {
        try (InputStream is = file.getInputStream()) {
            return tika.detect(is);
        } catch (IOException e) {
            // Fall back to extension-based detection
            return tika.detect(file.getOriginalFilename());
        }
    }

    /**
     * Determine file type based on filename and MIME type
     */
    private FileType determineFileType(String filename, String mimeType) {
        // First try to determine from MIME type
        FileType fileType = FileType.fromMimeType(mimeType);

        // If unknown, try by extension
        if (fileType == FileType.UNKNOWN) {
            fileType = detectFileTypeFromFilename(filename);
        }

        return fileType;
    }

    /**
     * Detect file type from filename extension
     */
    private FileType detectFileTypeFromFilename(String filename) {
        if (filename == null || filename.isEmpty()) {
            return FileType.UNKNOWN;
        }

        int lastDotIndex = filename.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < filename.length() - 1) {
            String extension = filename.substring(lastDotIndex + 1).toLowerCase();
            return FileType.fromExtension(extension);
        }

        return FileType.UNKNOWN;
    }
}
