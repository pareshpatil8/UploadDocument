# Banking Application File Storage Service

A centralized document storage microservice for banking applications that provides secure, scalable, and efficient file storage with adaptive chunking, compression, archival capabilities, and chain of custody tracking.

## Features

- **Adaptive Chunking**: Splits files into dynamically sized chunks based on file type and size
- **Intelligent Compression**: Applies different compression algorithms tailored to file types
- **Hierarchical Storage Management**: Automatically moves files between primary, secondary, and tertiary storage based on access patterns
- **Chain of Custody Tracking**: Full audit trail of document access and modifications
- **Asynchronous Processing**: Non-blocking upload and retrieval operations
- **OCR Integration**: Optional OCR processing for document content
- **Scalable Architecture**: Thread pooling and Java 21 virtual threads for concurrent processing
- **Oracle Database Integration**: Robust metadata storage and document tracking

## Technology Stack

- Java 21
- Spring Boot 3.2
- Spring Data JPA
- Spring Security
- Oracle Database
- Apache Commons IO/Compress
- Apache Tika

## Getting Started

### Prerequisites

- JDK 21
- Maven 3.8+
- IntelliJ IDEA (recommended)

### Setup Instructions

1. Clone the repository
2. Follow the IntelliJ setup instructions in the provided documentation
3. No Oracle database needed for development! The application uses H2 in-memory database
4. Run the application

### Running the Application

1. Build the project:
   ```
   mvn clean install
   ```

2. Run the application:
   ```
   mvn spring-boot:run -Dspring-boot.run.profiles=dev
   ```

3. Access the application:
    - Web Interface: http://localhost:8080/
    - H2 Console: http://localhost:8080/h2-console
        - JDBC URL: `jdbc:h2:mem:filestore_dev`
        - Username: `sa`
        - Password: [leave empty]

### Web Interface Usage

The application provides a comprehensive web interface for testing and administration:

- **Dashboard**: View overall storage statistics
- **Upload**: Upload documents with metadata
- **Search**: Search for documents with various filters
- **Document Details**: View and download documents, see document history
- **Status Tracking**: Track document processing status
- **Admin Dashboard**: Manage storage, run archival processes

### Configuration

The application uses a hierarchical configuration approach:

- `application.yml` - Common configuration
- `application-dev.yml` - Development environment configuration
- `application-prod.yml` - Production environment configuration

Key configuration parameters:

```yaml
file-store:
  storage:
    base-paths: # Define storage locations for different tiers
      - /data/filestore/primary
      - /data/filestore/secondary
      - /data/filestore/tertiary
    max-files-per-folder: 1000 # Limit files per folder
  async:
    core-pool-size: 10 # Thread pool configuration
    max-pool-size: 50
    queue-capacity: 100
  archival:
    primary-to-secondary-days: 90 # Archival thresholds
    secondary-to-tertiary-days: 365
  ocr:
    service-url: http://ocr-service:8080/api/ocr # OCR service address
    enabled: true
```

## API and Web Interface Endpoints

### Web Interface

- `/` - Dashboard with storage statistics and quick actions
- `/upload` - Document upload form
- `/status/{token}` - Check document processing status
- `/document/{id}` - View document details and metadata
- `/search` - Advanced document search
- `/admin` - Administrative dashboard and actions
- `/h2-console` - H2 database console (dev mode only)

### REST API Endpoints

#### Document Operations

- `POST /api/documents/upload` - Upload a document
- `GET /api/documents/status/{token}` - Check upload status
- `GET /api/documents/{id}` - Get document metadata
- `GET /api/documents/{id}/content` - Download document
- `POST /api/documents/search` - Search for documents
- `DELETE /api/documents/{id}` - Delete a document
- `GET /api/documents/by-metadata` - Find documents by metadata
- `GET /api/documents/{id}/ocr` - Get OCR text

#### Administrative Operations

- `POST /api/admin/archive/run` - Trigger archival process
- `GET /api/admin/storage/stats` - Get storage statistics
- `POST /api/admin/documents/{id}/move` - Move document to a different storage level
- `GET /api/admin/documents/{id}/history` - Get document access history

### API Example Usage

Upload a document:
```bash
curl -X POST http://localhost:8080/api/documents/upload \
  -H "Content-Type: multipart/form-data" \
  -F "file=@path/to/document.pdf" \
  -F "request={\"module\":\"LOANS\",\"department\":\"RETAIL\",\"ocrRequested\":true}"
```

Check upload status:
```bash
curl -X GET http://localhost:8080/api/documents/status/[token]
```

## Domain Model

- **Document**: Core entity representing an uploaded file
- **DocumentChunk**: Represents a portion of a document
- **DocumentMetadata**: Custom metadata associated with documents
- **StorageFolder**: Physical storage location tracking
- **CustodyRecord**: Document access and modification history
- **AsyncOperation**: Tracking of asynchronous operations

## Asynchronous Operations

The service uses an asynchronous model for long-running operations:

1. Client initiates an operation (e.g., uploading a file)
2. Service returns a token immediately
3. Client can check operation status using the token
4. Once completed, the actual document ID can be retrieved

## Security

- Role-based access control
- Chain of custody tracking
- Secure storage with checksums
- HTTP Basic authentication (for demonstration; use more secure auth in production)

## Performance Considerations

- Java 21 virtual threads for efficient I/O operations
- Adaptive chunking for optimal performance
- Specialized thread pools for different operation types
- Optimal compression selection based on file type

## Best Practices

- Keep file sizes reasonable (under 100MB for best performance)
- Use metadata to organize and categorize documents
- Monitor storage utilization and schedule regular maintenance
- Set up monitoring for the application health endpoints

## Screenshot Guide

### Dashboard
![Dashboard](dashboard.png)
The dashboard provides an overview of storage statistics and quick access to common actions.

### Upload Document - 1
![Upload](uploaddocument.png)
Upload documents with metadata and optional OCR processing.

### Upload Document - 2
![Upload](afterupload.png)
User gets a token to check status after upload.

### Upload Document - 3
![Upload](afterupload2.png)
Final upload status screen to show all steps of upload.

### Search Document
![Upload](searchdocument.png)
Advanced search with filtering by module, department, date, and custom metadata.

### Document Details
![Document Details](viewdocument.png)
View document metadata, download content, and see access history.

### Primary storage has chunk folders
![Document Details](primary1.png)
Folders are created randomy for storage.

### File saved in chunks
![Document Details](primary2.png)
File is saved in chunks not as uploaded to folder.

### Admin Dashboard
![Admin](https://placeholder-for-admin-screenshot.png)
Administrative functions including storage management and archival processes.

## License

Not applicable