# Payment Anomaly Detection System

## Overview

The Payment Anomaly Detection System is a comprehensive solution for detecting fraudulent or anomalous government payment transactions using ensemble machine learning techniques. The system processes payment XML files from government entities, applies multiple anomaly detection algorithms, and generates alerts for suspicious transactions.

## Features

- **Multi-model anomaly detection**: Combines isolation forest, autoencoder, and temporal pattern analysis
- **Ensemble integration**: Weighted scoring mechanism for improved accuracy
- **Parallel processing**: Efficient computation of anomaly scores
- **Administrative dashboard**: Web interface for monitoring and management
- **Scheduled jobs**: Automated file ingestion, model training, and anomaly detection
- **Detailed alerting**: Comprehensive alert information for investigation

## Architecture

```
org.rebit.ai.fraud
├── config/               # Configuration classes
├── constants/            # Constants and enumerations
├── controller/           # REST APIs for monitoring and management
├── dto/                  # Data transfer objects
├── entity/               # JPA entities
├── exception/            # Custom exceptions
├── model/                # ML model wrappers
│   ├── autoencoder/      # Global autoencoder model
│   ├── isolation/        # Entity-specific isolation forest
│   ├── temporal/         # Temporal pattern analysis
│   └── ensemble/         # Ensemble integration
├── repository/           # JPA repositories
├── service/              # Business logic
│   ├── data/             # Data preparation services
│   ├── detection/        # Anomaly detection services
│   ├── training/         # Model training services
│   └── alert/            # Alert generation services
├── scheduler/            # Scheduled jobs
├── util/                 # Utility classes
```

## Installation

### Prerequisites

- Java 21
- Oracle Database
- Maven
- Spring Boot 3.2+

### Setup

1. Clone the repository
```bash
git clone https://github.com/your-org/payment-anomaly-detection.git
cd payment-anomaly-detection
```

2. Configure database connection in `application.yml`
```yaml
spring:
  datasource:
    url: jdbc:oracle:thin:@//your-oracle-host:1521/YOUR_SID
    username: your_username
    password: your_password
```

3. Build the project
```bash
mvn clean package
```

4. Set up model storage directory
```bash
mkdir -p /var/models/{global,isolation,temporal}
chmod -R 755 /var/models
```

5. Run the application
```bash
java -jar target/fraud-detection-1.0.0.jar
```

## Data Integration

### Data Flow

```
Payment XML Files → File Ingestion → Feature Engineering → Anomaly Detection → Alerts
```

### File Structure Requirements

The system processes XML payment files following the standard payment format (example in `payment.xml`). Files should contain:

- Batch header information
- Source entity details
- Individual payment transactions

### Setting Up Daily Data Integration

#### 1. Create Data Directory Structure

```bash
mkdir -p /var/payment-data/{incoming,processed,failed}
chmod -R 755 /var/payment-data
```

#### 2. Configure File Ingestion Path

Update `application.yml` with the path to your incoming files:

```yaml
file:
  ingestion:
    input-dir: /var/payment-data/incoming
    processed-dir: /var/payment-data/processed
    failed-dir: /var/payment-data/failed
```

#### 3. Set Up File Transfer

**Option A: Manual File Upload**
Place XML files in the `/var/payment-data/incoming` directory.

**Option B: SFTP Integration**
Configure your payment system to transfer files via SFTP to the incoming directory.

**Option C: Automated ETL Process**
Set up a scheduled job to extract files from the source system and place them in the incoming directory.

#### 4. Schedule File Processing

Configure the cron expression in `application.yml` to control when files are processed:

```yaml
schedule:
  file-ingestion-cron: "0 0 18 * * ?"  # 6:00 PM daily
```

## Testing the System

### 1. Initial Testing with Sample Data

1. Place sample XML files in the incoming directory:
```bash
cp ./sample-data/*.xml /var/payment-data/incoming/
```

2. Trigger manual file ingestion:
```bash
curl -X POST http://localhost:8080/api/files/ingest
```

3. View transactions in the database:
```bash
curl -X GET http://localhost:8080/api/transactions
```

### 2. Run Anomaly Detection

Trigger anomaly detection manually:
```bash
curl -X POST http://localhost:8080/api/detection/run
```

### 3. Check for Alerts

```bash
curl -X GET http://localhost:8080/api/alerts
```

### 4. Web Interface Testing

Access the admin console at:
```
http://localhost:8080/
```

## Configuration Options

Key configuration parameters in `application.yml`:

```yaml
model:
  dir: /var/models/
  ensemble:
    weights:
      isolation-forest: 0.4
      autoencoder: 0.3
      temporal: 0.3
    anomaly-threshold: 0.8

isolationForest:
  nTrees: 100
  subsample: 256

autoencoder:
  learningRate: 0.001
  epochs: 100
  hidden-layers: [64, 32, 16, 32, 64]

temporal:
  seasonality:
    default-period: 7
    z-score-normalization-factor: 3.0
  context-weights:
    business-day: 0.2
    non-business-day: 0.5
    end-of-month: 0.2
    frequency: 0.1
```

## Monitoring and Maintenance

### Scheduled Jobs

The system includes several scheduled jobs:

1. `FileIngestionJob`: Processes new payment files (runs daily)
2. `ModelTrainingJob`: Trains/updates models (runs nightly)
3. `AnomalyDetectionJob`: Runs detection on recent data (follows training)
4. `AlertCleanupJob`: Archives older alerts (runs weekly)

### Actuator Endpoints

Monitor the system using Spring Boot Actuator:

```
http://localhost:8080/actuator/health
http://localhost:8080/actuator/metrics
http://localhost:8080/actuator/prometheus
```

## Troubleshooting

### Common Issues

1. **File processing errors**
   - Check file format matches expected XML schema
   - Verify file permissions on incoming directory
   - Check logs for detailed error messages

2. **Model training failures**
   - Ensure sufficient data is available for training
   - Check model directory permissions
   - Verify H2O initialization

3. **No anomalies detected**
   - Verify anomaly threshold in configuration
   - Check if models have been trained
   - Inspect feature engineering process

### Logging

Log files are located at:
```
/var/log/payment-detection/application.log
```

Adjust log levels in `application.yml`:
```yaml
logging:
  level:
    org.rebit.ai.fraud: DEBUG
```

## Integration Checklist

For new developers integrating this system, follow these steps:

- [ ] Configure database connection
- [ ] Set up data directories
- [ ] Configure input and output paths
- [ ] Set up scheduled tasks
- [ ] Implement file transfer mechanism
- [ ] Configure alerts recipients
- [ ] Test with sample data
- [ ] Train initial models
- [ ] Monitor detection results
- [ ] Tune anomaly thresholds

## API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/files/upload` | POST | Upload payment files |
| `/api/files/ingest` | POST | Process files in the incoming directory |
| `/api/detection/run` | POST | Run anomaly detection |
| `/api/training/run` | POST | Train all models |
| `/api/alerts` | GET | Get all alerts |
| `/api/models` | GET | Get all models |
| `/api/dashboard` | GET | Get dashboard metrics |

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a new pull request

## License

This project is proprietary and confidential.

---

For more information, contact the development team.
