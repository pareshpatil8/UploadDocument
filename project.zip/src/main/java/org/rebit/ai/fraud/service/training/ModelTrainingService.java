package org.rebit.ai.fraud.service.training;

import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.rebit.ai.fraud.entity.GovernmentEntity;
import org.rebit.ai.fraud.entity.AnomalyModel;
import org.rebit.ai.fraud.constants.ModelType;
import org.rebit.ai.fraud.repository.PaymentTransactionRepository;
import org.rebit.ai.fraud.repository.GovernmentEntityRepository;
import org.rebit.ai.fraud.repository.AnomalyModelRepository;
import org.rebit.ai.fraud.model.isolation.PureJavaIsolationForest;
import org.rebit.ai.fraud.model.autoencoder.AutoencoderModelWrapper;
import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.service.data.FeatureEngineeringService;
import org.rebit.ai.fraud.util.h2o.H2OUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import water.H2O;
import water.Key;
import water.fvec.Frame;
import water.parser.ParseDataset;

import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;

@Service
public class ModelTrainingService {

    @Autowired
    private PaymentTransactionRepository paymentTransactionRepo;
    @Autowired
    private GovernmentEntityRepository entityRepo;
    @Autowired
    private AnomalyModelRepository anomalyModelRepo;
    @Autowired
    private FeatureEngineeringService featureEngineeringService;

    private static final String MODEL_DIR = "/var/models/";

    private final ObjectMapper objectMapper = new ObjectMapper();

    public void trainAllModels() {
        // 1. Isolation Forest per entity
        for (GovernmentEntity entity : entityRepo.findAll()) {
            List<PaymentTransaction> txs = paymentTransactionRepo.findByBatchId(entity.getEntityId());
            List<double[]> fvList = new ArrayList<>();
            for (PaymentTransaction tx : txs) {
                try {
                    Map<String, Double> features = objectMapper.readValue(tx.getFeaturesJson(), Map.class);
                    // Ensure feature order
                    double[] featureArray = new double[]{
                            features.getOrDefault("amount", 0.0),
                            features.getOrDefault("account_hash", 0.0),
                            features.getOrDefault("bank_hash", 0.0)
                    };
                    fvList.add(featureArray);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (!fvList.isEmpty()) {
                PureJavaIsolationForest isoModel = new PureJavaIsolationForest(100, 256);
                isoModel.fit(fvList);
                String modelPath = MODEL_DIR + entity.getEntityId() + "/" + LocalDate.now() + ".model";
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(modelPath))) {
                    oos.writeObject(isoModel);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                AnomalyModel modelMeta = new AnomalyModel();
                modelMeta.setEntityId(entity.getEntityId());
                modelMeta.setModelType(ModelType.ISOLATION_FOREST.name());
                modelMeta.setTrainingDate(LocalDate.now());
                modelMeta.setFilePath(modelPath);
                modelMeta.setActive(true);
                anomalyModelRepo.save(modelMeta);
            }
        }

        // 2. H2O Autoencoder - global
        List<PaymentTransaction> allTxs = paymentTransactionRepo.findAll();
        File tempCsv = new File("/tmp/h2o_autoencoder_data.csv");
        try (PrintWriter pw = new PrintWriter(tempCsv)) {
            pw.println("amount,account_hash,bank_hash");
            for (PaymentTransaction tx : allTxs) {
                Map<String, Double> features = objectMapper.readValue(tx.getFeaturesJson(), Map.class);
                pw.printf("%f,%f,%f%n",
                        features.getOrDefault("amount", 0.0),
                        features.getOrDefault("account_hash", 0.0),
                        features.getOrDefault("bank_hash", 0.0));
            }
        } catch (Exception e) { e.printStackTrace(); }
        // Init H2O
        // Start H2O if not already running
        H2O.main(new String[] {});
        H2O.waitForCloudSize(1, 10000 /* ms */);
        Frame frame = H2OUtils.loadCSVToFrame(tempCsv.getPath());
        AutoencoderModelWrapper autoModel = new AutoencoderModelWrapper();
        autoModel.train(frame, 100, 0.001);
        String autoModelPath = MODEL_DIR + "global/autoencoder/" + LocalDate.now() + ".model";
        autoModel.save(autoModelPath);
        AnomalyModel autoMeta = new AnomalyModel();
        autoMeta.setModelType(ModelType.AUTOENCODER.name());
        autoMeta.setTrainingDate(LocalDate.now());
        autoMeta.setFilePath(autoModelPath);
        autoMeta.setActive(true);
        anomalyModelRepo.save(autoMeta);
        frame.delete();
        tempCsv.delete();
    }

}
