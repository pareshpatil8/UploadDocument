package org.rebit.ai.fraud.controller;

import org.rebit.ai.fraud.entity.AnomalyModel;
import org.rebit.ai.fraud.repository.AnomalyModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/models")
public class ModelManagementController {

    @Autowired
    private AnomalyModelRepository modelRepo;

    @GetMapping
    public List<AnomalyModel> getAllModels() {
        return modelRepo.findAll();
    }

    @GetMapping("/active")
    public List<AnomalyModel> getActiveModels() {
        return modelRepo.findByActiveTrue();
    }
}
