package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class CdtrAcctId {
    @XmlElement(name = "Othr")
    private Othr othr;

    // getters/setters
}
