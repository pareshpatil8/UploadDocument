package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnomalyAlertRepository extends JpaRepository<AnomalyAlert, Long> {
    List<AnomalyAlert> findByStatus(String status);
    List<AnomalyAlert> findByTransactionId(String transactionId);
}
