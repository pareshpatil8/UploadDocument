package org.rebit.ai.fraud.model.isolation;

import java.util.*;

public class PureJavaIsolationForest {

    private List<IsolationTree> trees = new ArrayList<>();
    private int nTrees;
    private int subsampleSize;

    public PureJavaIsolationForest(int nTrees, int subsampleSize) {
        this.nTrees = nTrees;
        this.subsampleSize = subsampleSize;
    }

    public void fit(List<double[]> data) {
        Random rand = new Random();
        for (int i = 0; i < nTrees; i++) {
            // Random subsample
            List<double[]> sample = new ArrayList<>();
            for (int j = 0; j < subsampleSize; j++) {
                sample.add(data.get(rand.nextInt(data.size())));
            }
            trees.add(new IsolationTree(sample, 0, (int) Math.ceil(Math.log(subsampleSize) / Math.log(2))));
        }
    }

    // Returns anomaly score in [0,1]; high is anomalous
    public double score(double[] instance) {
        double avgPathLength = 0;
        for (IsolationTree t : trees) {
            avgPathLength += t.pathLength(instance, 0);
        }
        avgPathLength /= nTrees;
        double c = c(subsampleSize);
        return Math.pow(2, -avgPathLength / c);
    }

    private double c(int n) {
        // Harmonic number approximation
        return n > 2 ? 2.0 * (Math.log(n - 1) + 0.5772156649) - (2.0 * (n - 1) / n) : 1;
    }

    // Nested static class for isolation tree
    private static class IsolationTree {
        private IsolationNode root;

        IsolationTree(List<double[]> data, int currentDepth, int maxDepth) {
            root = buildTree(data, currentDepth, maxDepth);
        }

        private IsolationNode buildTree(List<double[]> data, int depth, int maxDepth) {
            if (depth >= maxDepth || data.size() <= 1) {
                return new IsolationNode(null, null, -1, 0, data.size());
            }
            int nFeatures = data.get(0).length;
            Random rand = new Random();
            int q = rand.nextInt(nFeatures);
            double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
            for (double[] d : data) {
                min = Math.min(min, d[q]);
                max = Math.max(max, d[q]);
            }
            if (min == max) return new IsolationNode(null, null, -1, 0, data.size());
            double p = min + rand.nextDouble() * (max - min);
            List<double[]> left = new ArrayList<>(), right = new ArrayList<>();
            for (double[] d : data) {
                if (d[q] < p) left.add(d); else right.add(d);
            }
            return new IsolationNode(
                    buildTree(left, depth + 1, maxDepth),
                    buildTree(right, depth + 1, maxDepth),
                    q, p, data.size()
            );
        }

        double pathLength(double[] instance, int depth) {
            return root.pathLength(instance, depth);
        }

        private static class IsolationNode {
            IsolationNode left, right;
            int splitAttr;
            double splitValue;
            int size;

            IsolationNode(IsolationNode l, IsolationNode r, int q, double p, int size) {
                this.left = l;
                this.right = r;
                this.splitAttr = q;
                this.splitValue = p;
                this.size = size;
            }

            double pathLength(double[] inst, int depth) {
                if (left == null && right == null)
                    return depth + c(size);
                if (inst[splitAttr] < splitValue) {
                    return left.pathLength(inst, depth + 1);
                } else {
                    return right.pathLength(inst, depth + 1);
                }
            }

            private double c(int n) {
                return n > 2 ? 2.0 * (Math.log(n - 1) + 0.5772156649) - (2.0 * (n - 1) / n) : 1;
            }
        }
    }
}
