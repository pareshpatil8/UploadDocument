package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class PmtId {
    @XmlElement(name = "InstrId")
    private String instrId;

    @XmlElement(name = "EndToEndId")
    private String endToEndId;

    // getters/setters
}
