package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Amt {
    @XmlElement(name = "InstdAmt")
    private InstdAmt instdAmt;

    // getters/setters
}
