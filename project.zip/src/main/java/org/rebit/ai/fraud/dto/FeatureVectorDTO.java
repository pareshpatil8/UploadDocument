package org.rebit.ai.fraud.dto;

import java.util.Map;

public class FeatureVectorDTO {
    private Map<String, Double> features;

    // Add getters and setters

    public Map<String, Double> getFeatures() {
        return features;
    }

    public void setFeatures(Map<String, Double> features) {
        this.features = features;
    }
}
