package org.rebit.ai.fraud.scheduler;

import org.rebit.ai.fraud.service.data.FileIngestionService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class FileIngestionJob {

    private final FileIngestionService fileIngestionService;

    @Value("${schedule.file-ingestion-cron}")
    private String cronExpression;

    public FileIngestionJob(FileIngestionService fileIngestionService) {
        this.fileIngestionService = fileIngestionService;
    }

    // The cron expression is picked up from application.yml
    @Scheduled(cron = "${schedule.file-ingestion-cron}")
    public void runFileIngestion() {
        fileIngestionService.ingestFilesForTheDay();
    }
}
