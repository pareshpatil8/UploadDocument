package org.rebit.ai.fraud.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {
    // Application-wide beans/configs can be defined here if needed.
}
