package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class CdtrAgt {
    @XmlElement(name = "FinInstnId")
    private FinInstnId finInstnId;

    // getters/setters
}
