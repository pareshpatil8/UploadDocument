package org.rebit.ai.fraud.model.isolation;

import java.io.*;
import java.util.*;

public class IsolationForestModelWrapper implements Serializable {

    private static final long serialVersionUID = 1L;

    private PureJavaIsolationForest isolationForest;
    private List<String> featureOrder; // Order of feature names (e.g., ["amount", "account_hash", "bank_hash"])

    public IsolationForestModelWrapper(List<String> featureOrder, int nTrees, int subsampleSize) {
        this.featureOrder = featureOrder;
        this.isolationForest = new PureJavaIsolationForest(nTrees, subsampleSize);
    }

    public void train(List<Map<String, Double>> featureList) {
        List<double[]> vectors = new ArrayList<>();
        for (Map<String, Double> fv : featureList) {
            double[] arr = new double[featureOrder.size()];
            for (int i = 0; i < featureOrder.size(); i++) {
                arr[i] = fv.getOrDefault(featureOrder.get(i), 0.0);
            }
            vectors.add(arr);
        }
        isolationForest.fit(vectors);
    }

    public double predict(Map<String, Double> featureVector) {
        double[] arr = new double[featureOrder.size()];
        for (int i = 0; i < featureOrder.size(); i++) {
            arr[i] = featureVector.getOrDefault(featureOrder.get(i), 0.0);
        }
        return isolationForest.score(arr);
    }

    public void save(File file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(this);
        }
    }

    public static IsolationForestModelWrapper load(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (IsolationForestModelWrapper) ois.readObject();
        }
    }

    public List<String> getFeatureOrder() {
        return featureOrder;
    }
}
