package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.AnomalyModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnomalyModelRepository extends JpaRepository<AnomalyModel, Long> {
    List<AnomalyModel> findByEntityId(String entityId);
    List<AnomalyModel> findByActiveTrue();
}
