package org.rebit.ai.fraud.util.ml;

import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import water.fvec.Frame;
import water.fvec.Vec;
import water.Key;

import java.util.Map;

public class AutoencoderUtil {

    /**
     * Converts a FeatureVectorDTO to a single-row H2O Frame for scoring.
     */
    public static Frame singleRowToFrame(FeatureVectorDTO fv) {
        Map<String, Double> features = fv.getFeatures();
        String[] colNames = features.keySet().toArray(new String[0]);
        double[][] data = new double[1][colNames.length];
        for (int i = 0; i < colNames.length; i++) {
            data[0][i] = features.getOrDefault(colNames[i], 0.0);
        }
        Frame frame = new Frame(Key.make(), colNames, new Vec[colNames.length]);
        for (int i = 0; i < colNames.length; i++) {
            frame.add(colNames[i], Vec.makeVec(new double[]{data[0][i]}, Vec.newKey()));
        }
        return frame;
    }
}
