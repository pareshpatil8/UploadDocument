package org.rebit.ai.fraud.service.detection;

import org.rebit.ai.fraud.config.MLConfig;
import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.dto.PaymentTransactionDTO;
import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.rebit.ai.fraud.exception.FraudDetectionException;
import org.rebit.ai.fraud.model.isolation.IsolationForestModelWrapper;
import org.rebit.ai.fraud.model.autoencoder.AutoencoderModelWrapper;
import org.rebit.ai.fraud.model.temporal.TemporalPatternService;
import org.rebit.ai.fraud.model.ensemble.EnsembleIntegrationService;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.PaymentTransactionRepository;
import org.rebit.ai.fraud.service.alert.AlertGenerationService;
import org.rebit.ai.fraud.service.data.FeatureEngineeringService;
import org.rebit.ai.fraud.util.ml.AutoencoderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import water.fvec.Frame;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
public class AnomalyDetectionService {
    private static final Logger logger = LoggerFactory.getLogger(AnomalyDetectionService.class);

    private final IsolationForestModelWrapper isoModel;
    private final AutoencoderModelWrapper autoModel;
    private final TemporalPatternService temporalPatternService;
    private final EnsembleIntegrationService ensembleService;
    private final FeatureEngineeringService featureEngineeringService;
    private final AlertGenerationService alertGenerationService;
    private final AnomalyAlertRepository anomalyAlertRepo;
    private final PaymentTransactionRepository paymentTransactionRepo;
    private final PaymentNetworkAnalysisService networkAnalysisService;

    // Thread pool for parallel processing
    private final Executor executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    @Value("${model.ensemble.anomaly-threshold:0.8}")
    private double anomalyThreshold;

    @Autowired
    public AnomalyDetectionService(
            IsolationForestModelWrapper isoModel,
            AutoencoderModelWrapper autoModel,
            TemporalPatternService temporalPatternService,
            EnsembleIntegrationService ensembleService,
            FeatureEngineeringService featureEngineeringService,
            AlertGenerationService alertGenerationService,
            AnomalyAlertRepository anomalyAlertRepo,
            PaymentTransactionRepository paymentTransactionRepo,
            PaymentNetworkAnalysisService networkAnalysisService) {
        this.isoModel = isoModel;
        this.autoModel = autoModel;
        this.temporalPatternService = temporalPatternService;
        this.ensembleService = ensembleService;
        this.featureEngineeringService = featureEngineeringService;
        this.alertGenerationService = alertGenerationService;
        this.anomalyAlertRepo = anomalyAlertRepo;
        this.paymentTransactionRepo = paymentTransactionRepo;
        this.networkAnalysisService = networkAnalysisService;
    }

    /**
     * Computes the anomaly score for a given transaction using ensemble methods.
     * This method runs all models in parallel for better performance.
     */
    public double scoreTransaction(
            FeatureVectorDTO fv,
            List<Double> historicalAmounts,
            LocalDate transactionDate,
            List<LocalDate> historicalDates,
            Set<LocalDate> holidaysSet,
            String transactionId,
            String beneficiaryAccount,
            String sourceEntity,
            List<PaymentTransaction> historicalTransactions
    ) {
        if (fv == null || fv.getFeatures() == null) {
            logger.warn("Null feature vector or features provided for scoring");
            return 0.0;
        }

        try {
            // Run isolation forest score computation asynchronously
            CompletableFuture<Double> isoScoreFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return isoModel.predict(fv.getFeatures());
                } catch (Exception e) {
                    logger.error("Error calculating isolation forest score", e);
                    return 0.0;
                }
            }, executor);

            // Run autoencoder score computation asynchronously
            CompletableFuture<Double> autoScoreFuture = CompletableFuture.supplyAsync(() -> {
                Frame frame = null;
                try {
                    frame = AutoencoderUtil.singleRowToFrame(fv);
                    return autoModel.score(frame);
                } catch (Exception e) {
                    logger.error("Error calculating autoencoder score", e);
                    return 0.0;
                } finally {
                    if (frame != null) {
                        try {
                            frame.delete();
                        } catch (Exception e) {
                            logger.warn("Error deleting frame", e);
                        }
                    }
                }
            }, executor);

            // Run temporal score computation asynchronously
            CompletableFuture<Double> temporalScoreFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return temporalPatternService.combinedTemporalAnomalyScore(
                            historicalAmounts,
                            fv.getFeatures().getOrDefault("amount", 0.0),
                            transactionDate,
                            historicalDates,
                            holidaysSet
                    );
                } catch (Exception e) {
                    logger.error("Error calculating temporal score", e);
                    return 0.0;
                }
            }, executor);

            // Run network analysis asynchronously
            CompletableFuture<Double> networkScoreFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return networkAnalysisService.detectNetworkAnomalies(
                            transactionId,
                            beneficiaryAccount,
                            sourceEntity,
                            historicalTransactions
                    );
                } catch (Exception e) {
                    logger.error("Error calculating network score", e);
                    return 0.0;
                }
            }, executor);

            // Calculate beneficiary payment pattern anomaly
            CompletableFuture<Double> beneficiaryPatternFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return temporalPatternService.beneficiaryPaymentPatternAnomaly(
                            beneficiaryAccount,
                            transactionDate,
                            fv.getFeatures().getOrDefault("amount", 0.0),
                            historicalTransactions
                    );
                } catch (Exception e) {
                    logger.error("Error calculating beneficiary pattern score", e);
                    return 0.0;
                }
            }, executor);

            // Calculate amount variability anomaly
            CompletableFuture<Double> amountVariabilityFuture = CompletableFuture.supplyAsync(() -> {
                try {
                    return temporalPatternService.amountVariabilityAnomaly(
                            beneficiaryAccount,
                            fv.getFeatures().getOrDefault("amount", 0.0),
                            historicalTransactions
                    );
                } catch (Exception e) {
                    logger.error("Error calculating amount variability score", e);
                    return 0.0;
                }
            }, executor);

            // Wait for all futures to complete and combine results
            double isoScore = isoScoreFuture.get();
            double autoScore = autoScoreFuture.get();
            double temporalScore = temporalScoreFuture.get();
            double networkScore = networkScoreFuture.get();
            double beneficiaryPatternScore = beneficiaryPatternFuture.get();
            double amountVariabilityScore = amountVariabilityFuture.get();

            // Enhance temporal score with additional pattern insights
            temporalScore = 0.6 * temporalScore + 0.2 * beneficiaryPatternScore + 0.2 * amountVariabilityScore;

            // Get the transaction amount
            double amount = fv.getFeatures().getOrDefault("amount", 0.0);

            // Combine scores using weighted ensemble with new method signature
            return ensembleService.ensembleScore(isoScore, autoScore, temporalScore, networkScore, amount);

        } catch (InterruptedException | ExecutionException e) {
            logger.error("Error during parallel score computation", e);
            Thread.currentThread().interrupt();
            throw new FraudDetectionException("Failed to compute anomaly score", e);
        }
    }

    /**
     * Batch anomaly detection on recent transactions with enhanced error handling
     * and parallel processing for improved performance.
     */
    @Transactional
    public void runDetectionOnRecentData() {
        // Define what "recent" means. Example: today and yesterday for robustness
        LocalDate today = LocalDate.now();
        LocalDate yesterday = today.minusDays(1);

        logger.info("Running anomaly detection for dates: {} and {}", yesterday, today);

        try {
            // Get transactions for both days
            List<PaymentTransaction> recentTxs = new ArrayList<>();
            recentTxs.addAll(paymentTransactionRepo.findByTransactionDate(today));
            recentTxs.addAll(paymentTransactionRepo.findByTransactionDate(yesterday));

            if (recentTxs.isEmpty()) {
                logger.info("No recent transactions found for detection");
                return;
            }

            logger.info("Processing {} recent transactions for anomaly detection", recentTxs.size());

            // Group transactions by source entity for more efficient historical data retrieval
            Map<String, List<PaymentTransaction>> txsByEntity = recentTxs.stream()
                    .collect(Collectors.groupingBy(PaymentTransaction::getSourceEntity));

            int alertCount = 0;

            // Process each entity's transactions
            for (Map.Entry<String, List<PaymentTransaction>> entry : txsByEntity.entrySet()) {
                String entityId = entry.getKey();
                List<PaymentTransaction> entityTxs = entry.getValue();

                // Get historical transactions for this entity (once per entity)
                List<PaymentTransaction> entityHistory = paymentTransactionRepo
                        .findBySourceEntityAndTransactionDateBefore(entityId, yesterday);

                // Extract historical dates and amounts (once per entity)
                List<LocalDate> historicalDates = entityHistory.stream()
                        .map(PaymentTransaction::getTransactionDate)
                        .collect(Collectors.toList());

                List<Double> historicalAmounts = entityHistory.stream()
                        .map(PaymentTransaction::getAmount)
                        .collect(Collectors.toList());

                Set<LocalDate> holidaySet = getHolidaySet();

                // Process each transaction for this entity
                for (PaymentTransaction tx : entityTxs) {
                    try {
                        // Build feature vector
                        PaymentTransactionDTO txDto = mapToDTO(tx);
                        FeatureVectorDTO fv = featureEngineeringService.extractFeatures(txDto);

                        // Add government-specific features
                        Map<String, Double> govFeatures = featureEngineeringService.extractGovernmentSpecificFeatures(txDto);
                        fv.getFeatures().putAll(govFeatures);

                        // Score transaction with enhanced parameters
                        double score = scoreTransaction(
                                fv,
                                historicalAmounts,
                                tx.getTransactionDate(),
                                historicalDates,
                                holidaySet,
                                tx.getTransactionId(),
                                tx.getBeneficiaryAccount(),
                                tx.getSourceEntity(),
                                entityHistory
                        );

                        // Generate alert if score exceeds threshold
                        if (score > anomalyThreshold) {
                            // Create more detailed alert notes
                            String alertNotes = buildAlertNotes(tx, score);

                            AnomalyAlert alert = alertGenerationService.generateAlert(
                                    tx.getTransactionId(),
                                    score,
                                    "ENSEMBLE",
                                    alertNotes);

                            anomalyAlertRepo.save(alert);
                            alertCount++;

                            logger.info("Alert generated for transaction {} with score {}",
                                    tx.getTransactionId(), String.format("%.4f", score));
                        }
                    } catch (Exception e) {
                        logger.error("Error processing transaction {}: {}",
                                tx.getTransactionId(), e.getMessage(), e);
                    }
                }
            }

            logger.info("Anomaly detection completed. Generated {} alerts from {} transactions",
                    alertCount, recentTxs.size());

        } catch (Exception e) {
            logger.error("Failed to run anomaly detection on recent data", e);
            throw new FraudDetectionException("Anomaly detection failed", e);
        }
    }

    /**
     * Creates detailed alert notes explaining anomaly factors
     */
    private String buildAlertNotes(PaymentTransaction tx, double score) {
        StringBuilder notes = new StringBuilder();
        notes.append("Auto-detected anomaly - score: ").append(String.format("%.4f", score));
        notes.append("\nAmount: ").append(tx.getAmount());
        notes.append("\nBeneficiary: ").append(tx.getBeneficiaryName());
        notes.append("\nBeneficiary Account: ").append(tx.getBeneficiaryAccount());
        notes.append("\nBeneficiary Bank: ").append(tx.getBeneficiaryBank());
        notes.append("\nDetection Date: ").append(LocalDate.now());

        // Add analysis reason if round amount (often a fraud indicator)
        if (tx.getAmount() % 1000 == 0 || tx.getAmount() % 500 == 0 ||
                tx.getAmount() % 100 == 0) {
            notes.append("\nNote: Transaction amount is a round number, which may indicate fraud.");
        }

        // Check historical context
        List<PaymentTransaction> history = paymentTransactionRepo
                .findByBeneficiaryAccount(tx.getBeneficiaryAccount());

        if (history.size() <= 1) {
            notes.append("\nNote: First payment to this beneficiary account.");
        }

        return notes.toString();
    }

    // Helper to map PaymentTransaction entity to PaymentTransactionDTO
    private PaymentTransactionDTO mapToDTO(PaymentTransaction tx) {
        PaymentTransactionDTO dto = new PaymentTransactionDTO();
        dto.setTransactionId(tx.getTransactionId());
        dto.setBatchId(tx.getBatchId());
        dto.setSourceEntity(tx.getSourceEntity());
        dto.setAmount(tx.getAmount());
        dto.setCurrency(tx.getCurrency());
        dto.setBeneficiaryAccount(tx.getBeneficiaryAccount());
        dto.setBeneficiaryName(tx.getBeneficiaryName());
        dto.setBeneficiaryBank(tx.getBeneficiaryBank());
        dto.setTransactionDate(tx.getTransactionDate());
        return dto;
    }

    // Helper to get holiday set (should be enhanced to use a proper holiday calendar service)
    private Set<LocalDate> getHolidaySet() {
        // TODO: Wire this up to your holiday calendar service or table
        // For now, hard-coded Indian holidays as an example
        Set<LocalDate> holidays = new HashSet<>();
        int currentYear = LocalDate.now().getYear();

        // Republic Day
        holidays.add(LocalDate.of(currentYear, 1, 26));

        // Independence Day
        holidays.add(LocalDate.of(currentYear, 8, 15));

        // Gandhi Jayanti
        holidays.add(LocalDate.of(currentYear, 10, 2));

        return holidays;
    }
}