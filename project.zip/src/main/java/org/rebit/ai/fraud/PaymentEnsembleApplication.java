package org.rebit.ai.ai.fraud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentEnsembleApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaymentEnsembleApplication.class, args);
    }

}
