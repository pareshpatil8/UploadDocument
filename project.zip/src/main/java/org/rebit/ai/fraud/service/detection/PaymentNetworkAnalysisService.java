// Create a new class: PaymentNetworkAnalysisService.java
package org.rebit.ai.fraud.service.detection;

import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PaymentNetworkAnalysisService {

    /**
     * Detects unusual network patterns among beneficiaries
     */
    public double detectNetworkAnomalies(String transactionId,
                                         String beneficiaryAccount,
                                         String sourceEntity,
                                         List<PaymentTransaction> historicalTxs) {
        // Create a map of transaction counts by source-beneficiary pair
        Map<String, Integer> sourceToAccountCounts = new HashMap<>();
        Map<String, Set<String>> accountToSources = new HashMap<>();

        // Build network relationships
        for (PaymentTransaction tx : historicalTxs) {
            String key = tx.getSourceEntity() + "-" + tx.getBeneficiaryAccount();
            sourceToAccountCounts.merge(key, 1, Integer::sum);

            // Track all sources that paid to this account
            accountToSources
                    .computeIfAbsent(tx.getBeneficiaryAccount(), k -> new HashSet<>())
                    .add(tx.getSourceEntity());
        }

        // 1. Check if this source-beneficiary pair is rare
        String currentKey = sourceEntity + "-" + beneficiaryAccount;
        int pairCount = sourceToAccountCounts.getOrDefault(currentKey, 0);
        double rarePairScore = (pairCount == 0) ? 1.0 : Math.min(1.0, 5.0/pairCount);

        // 2. Check if this beneficiary receives from multiple sources (potential data aggregator)
        Set<String> sourcesForAccount = accountToSources.getOrDefault(beneficiaryAccount, Collections.emptySet());
        double multiSourceScore = Math.min(1.0, sourcesForAccount.size() / 10.0);

        // 3. Cyclic payment detection (not applicable directly for government payments, but included)
        Set<String> beneficiariesFromSameSource = historicalTxs.stream()
                .filter(tx -> tx.getSourceEntity().equals(sourceEntity))
                .map(PaymentTransaction::getBeneficiaryAccount)
                .collect(Collectors.toSet());

        double cyclicScore = 0.0;
        // Higher score if entities pay each other

        // Combined network anomaly score
        return 0.5 * rarePairScore + 0.3 * multiSourceScore + 0.2 * cyclicScore;
    }
}