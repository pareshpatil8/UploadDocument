package org.rebit.ai.fraud.model.autoencoder;

import hex.ScoreKeeper;
import hex.deeplearning.DeepLearning;
import hex.deeplearning.DeepLearningModel;
import hex.deeplearning.DeepLearningModel.DeepLearningParameters;
import org.rebit.ai.fraud.exception.FraudDetectionException;
import org.springframework.beans.factory.annotation.Value;
import water.Key;
import water.fvec.Frame;
import water.H2O;
import water.parser.ParseDataset;
import water.util.FrameUtils;
import hex.genmodel.utils.DistributionFamily;
import water.api.API;
import water.api.APIException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;


public class AutoencoderModelWrapper {
    private static final Logger logger = Logger.getLogger(AutoencoderModelWrapper.class.getName());

    private DeepLearningModel model;

    @Value("${autoencoder.hidden-layers:64,32,16,32,64}")
    private int[] hiddenLayers;

    @Value("${autoencoder.activation:Rectifier}")
    private String activation;

    @Value("${autoencoder.l1:0.001}")
    private double l1;

    public void train(Frame frame, int epochs, double learningRate) {
        if (frame == null || frame.numRows() == 0) {
            throw new IllegalArgumentException("Training frame cannot be null or empty");
        }

        try {
            DeepLearningParameters params = new DeepLearningParameters();
            params._train = frame._key;
            params._autoencoder = true;
            params._epochs = epochs;
            params._activation = getActivationFunction(activation);
            params._hidden = hiddenLayers;
            params._l1 = l1;
            params._rate = learningRate;

            // Early stopping for robustness
            params._stopping_rounds = 5;
            params._stopping_metric = ScoreKeeper.StoppingMetric.MSE;
            params._stopping_tolerance = 0.01;

            // Add input dropout for regularization
            params._input_dropout_ratio = 0.1;

            // Add compute distribution metrics if possible
            params._distribution = DistributionFamily.gaussian;

            logger.info("Starting autoencoder training with " + frame.numRows() + " rows and epochs: " + epochs);
            DeepLearning job = new DeepLearning(params);
            this.model = job.trainModel().get();

            if (this.model == null) {
                throw new FraudDetectionException("Failed to train autoencoder model");
            }

            logger.info("Autoencoder training completed successfully");
        } catch (Exception e) {
            logger.severe("Error during autoencoder training: " + e.getMessage());
            throw new FraudDetectionException("Autoencoder training failed", e);
        }
    }

    private DeepLearningParameters.Activation getActivationFunction(String activationName) {
        try {
            return DeepLearningParameters.Activation.valueOf(activationName);
        } catch (IllegalArgumentException e) {
            logger.warning("Unknown activation function: " + activationName + ". Using Rectifier as default.");
            return DeepLearningParameters.Activation.Rectifier;
        }
    }

    public double score(Frame frame) {
        if (frame == null || model == null) {
            throw new IllegalArgumentException("Frame or model cannot be null");
        }

        // Reconstruct and calculate MSE for anomaly detection
        Frame reconstructed = null;
        try {
            reconstructed = model.scoreAutoEncoder(frame, Key.make(), false);

            double mse = 0.0;

            // Use more efficient vector operations where possible
            for (long row = 0; row < frame.numRows(); row++) {
                double rowMSE = 0.0;
                for (int col = 0; col < frame.numCols(); col++) {
                    double diff = frame.vec(col).at(row) - reconstructed.vec(col).at(row);
                    rowMSE += diff * diff;
                }
                mse += rowMSE / frame.numCols();
            }

            return mse / frame.numRows();
        } catch (Exception e) {
            logger.severe("Error during autoencoder scoring: " + e.getMessage());
            throw new FraudDetectionException("Autoencoder scoring failed", e);
        } finally {
            if (reconstructed != null) {
                try {
                    reconstructed.delete();
                } catch (Exception e) {
                    logger.warning("Failed to clean up reconstructed frame: " + e.getMessage());
                }
            }
        }
    }

    public void save(String path) {
        if (model == null) {
            throw new IllegalStateException("Cannot save: model is null");
        }

        try {
            File directory = new File(path).getParentFile();
            if (!directory.exists()) {
                if (!directory.mkdirs()) {
                    throw new IOException("Failed to create directory: " + directory.getAbsolutePath());
                }
            }

            logger.info("Saving autoencoder model to: " + path);
            model.exportBinaryModel(path, true);
        } catch (IOException e) {
            logger.severe("Error saving autoencoder model: " + e.getMessage());
            throw new FraudDetectionException("Failed to save autoencoder model", e);
        }
    }

    public static AutoencoderModelWrapper load(String path) {
        try {
            logger.info("Loading autoencoder model from: " + path);
            File modelFile = Paths.get(path).toFile();
            if (!modelFile.exists()) {
                throw new IOException("Model file does not exist: " + path);
            }

            DeepLearningModel loaded = DeepLearningModel.importBinaryModel(modelFile.getAbsolutePath());
            if (loaded == null) {
                throw new IOException("Failed to load model from: " + path);
            }

            AutoencoderModelWrapper wrapper = new AutoencoderModelWrapper();
            wrapper.model = loaded;
            return wrapper;
        } catch (IOException e) {
            logger.severe("Error loading autoencoder model: " + e.getMessage());
            throw new FraudDetectionException("Failed to load autoencoder model", e);
        }
    }
}