package org.rebit.ai.fraud.constants;

public enum EntityType {
    CENTRAL, STATE
}
