package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class FinInstnId {
    @XmlElement(name = "ClrSysMmbId")
    private ClrSysMmbId clrSysMmbId;
    // getters/setters


    public ClrSysMmbId getClrSysMmbId() {
        return clrSysMmbId;
    }

    public void setClrSysMmbId(ClrSysMmbId clrSysMmbId) {
        this.clrSysMmbId = clrSysMmbId;
    }
}
