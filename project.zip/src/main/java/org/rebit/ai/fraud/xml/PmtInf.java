package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class PmtInf {
    @XmlElement(name = "PmtInfId")
    private String pmtInfId;

    @XmlElement(name = "PmtMtd")
    private String pmtMtd;

    @XmlElement(name = "BtchBookg")
    private Boolean btchBookg;

    @XmlElement(name = "NbOfTxs")
    private Integer nbOfTxs;

    @XmlElement(name = "CtrlSum")
    private Double ctrlSum;

    @XmlElement(name = "CdtTrfTxInf")
    private List<CdtTrfTxInf> cdtTrfTxInf;
    // More fields can be added as needed
    // getters/setters


    public String getPmtInfId() {
        return pmtInfId;
    }

    public void setPmtInfId(String pmtInfId) {
        this.pmtInfId = pmtInfId;
    }

    public String getPmtMtd() {
        return pmtMtd;
    }

    public void setPmtMtd(String pmtMtd) {
        this.pmtMtd = pmtMtd;
    }

    public Boolean getBtchBookg() {
        return btchBookg;
    }

    public void setBtchBookg(Boolean btchBookg) {
        this.btchBookg = btchBookg;
    }

    public Integer getNbOfTxs() {
        return nbOfTxs;
    }

    public void setNbOfTxs(Integer nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
    }

    public Double getCtrlSum() {
        return ctrlSum;
    }

    public void setCtrlSum(Double ctrlSum) {
        this.ctrlSum = ctrlSum;
    }

    public List<CdtTrfTxInf> getCdtTrfTxInf() {
        return cdtTrfTxInf;
    }

    public void setCdtTrfTxInf(List<CdtTrfTxInf> cdtTrfTxInf) {
        this.cdtTrfTxInf = cdtTrfTxInf;
    }
}
