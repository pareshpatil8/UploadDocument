// Enhanced EnsembleIntegrationService.java
package org.rebit.ai.fraud.model.ensemble;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EnsembleIntegrationService {

    @Value("${model.ensemble.weights.isolation-forest:0.4}")
    private double isolationForestWeight;

    @Value("${model.ensemble.weights.autoencoder:0.3}")
    private double autoencoderWeight;

    @Value("${model.ensemble.weights.temporal:0.3}")
    private double temporalWeight;

    @Value("${model.ensemble.weights.network:0.2}")
    private double networkWeight;

    @Value("${model.ensemble.anomaly-threshold:0.8}")
    private double anomalyThreshold;

    /**
     * Advanced weighted ensemble with dynamic score adjustment
     */
    public double ensembleScore(double isoScore, double autoScore, double tempScore,
                                double networkScore, double amount) {
        // 1. Basic weighted average with configurable weights
        double baseScore = isoScore * isolationForestWeight +
                autoScore * autoencoderWeight +
                tempScore * temporalWeight +
                networkScore * networkWeight;

        // 2. Adaptive threshold based on amount
        // Higher amounts get more scrutiny (lower threshold)
        double amountFactor = 1.0;
        if (amount > 1000000) { // Very large payments
            amountFactor = 0.7; // 30% lower threshold for high-value payments
        } else if (amount > 100000) {
            amountFactor = 0.85; // 15% lower threshold for medium-high payments
        }

        // 3. Model agreement bonus
        // If multiple models agree on anomaly, increase score
        int anomalyVotes = 0;
        if (isoScore > 0.7) anomalyVotes++;
        if (autoScore > 0.7) anomalyVotes++;
        if (tempScore > 0.7) anomalyVotes++;
        if (networkScore > 0.7) anomalyVotes++;

        double agreementBonus = 0.0;
        if (anomalyVotes >= 3) {
            agreementBonus = 0.15; // Strong agreement
        } else if (anomalyVotes == 2) {
            agreementBonus = 0.05; // Moderate agreement
        }

        // Apply adjustments
        double adjustedScore = baseScore * amountFactor + agreementBonus;

        // Cap at 1.0
        return Math.min(1.0, adjustedScore);
    }
}