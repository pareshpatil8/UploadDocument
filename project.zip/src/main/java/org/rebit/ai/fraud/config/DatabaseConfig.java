package org.rebit.ai.fraud.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = "org.rebit.ai.fraud.repository")
public class DatabaseConfig {
    // Uses properties from application.yml
}
