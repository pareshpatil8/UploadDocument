package org.rebit.ai.fraud.controller;

import org.rebit.ai.fraud.dto.AnomalyAlertDTO;
import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/alerts")
public class AnomalyAlertController {

    @Autowired
    private AnomalyAlertRepository alertRepo;

    @GetMapping
    public List<AnomalyAlertDTO> getAllAlerts() {
        return alertRepo.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @GetMapping("/{transactionId}")
    public List<AnomalyAlertDTO> getAlertsForTransaction(@PathVariable String transactionId) {
        return alertRepo.findByTransactionId(transactionId).stream().map(this::toDto).collect(Collectors.toList());
    }

    private AnomalyAlertDTO toDto(AnomalyAlert alert) {
        AnomalyAlertDTO dto = new AnomalyAlertDTO();
        dto.setAlertId(alert.getAlertId());
        dto.setTransactionId(alert.getTransactionId());
        dto.setAlertScore(alert.getAlertScore());
        dto.setAlertType(alert.getAlertType());
        dto.setStatus(alert.getStatus());
        dto.setDetectionDate(alert.getDetectionDate() != null ? alert.getDetectionDate().toString() : null);
        dto.setNotes(alert.getNotes());
        dto.setReviewed(alert.getReviewed());
        return dto;
    }
}
