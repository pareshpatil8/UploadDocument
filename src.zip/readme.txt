RBI Circular Management System
A comprehensive application for managing Reserve Bank of India circulars with advanced search, AI-powered chatbot, and cross-reference analytics capabilities.
Table of Contents

Features
System Architecture
Technologies Used
Getting Started

Prerequisites
Installation
Configuration


Features in Detail

Circular Management
Intelligent Search
AI-Powered Chatbot
Cross-Reference Analytics


Database Schema
API Documentation
Development Guidelines
Deployment

Features

Circular Management

Upload and process PDF circulars
Automatic extraction of metadata using NLP
PDF storage with metadata in database
Versioning and change tracking


Intelligent Search

Multi-criteria search (by number, date, department, etc.)
Full-text search with relevance ranking
Named entity-based search
Metadata filtering and sorting


AI-Powered Chatbot

Natural language question answering
Precise references to source circulars
Contextual understanding of financial terminology
Self-learning capability as new circulars are added


Cross-Reference Analytics

Detect circular relationships (citations and superseding)
Visualize circular reference networks
Track superseded circulars
Follow regulatory evolution over time



System Architecture
The system follows a microservices-based architecture organized in the following components:

Core Services

Circular Upload Service
Circular Search Service
Circular Indexing Service
Cross-Reference Service


AI Components

NLP Service for text analysis
Named Entity Recognition
Lucene-based Information Retrieval


Storage

PDF file storage
Oracle/H2 database for metadata
Lucene index for search


Web Interface

Upload interface
Search interface
Chatbot interface
Reference visualization



Technologies Used

Backend: Java 11, Spring Boot 2.7
Database: Oracle (Production), H2 (Development)
Search Engine: Apache Lucene
PDF Processing: Apache PDFBox
Natural Language Processing: Apache OpenNLP
Data Migration: Flyway
API Documentation: OpenAPI/Swagger
Web Technologies: HTML, CSS, JavaScript, Bootstrap 5
Visualization: Vis.js for network graphs
Build Tool: Maven

Getting Started
Prerequisites

Java 11 or higher
Maven 3.6+
Oracle Database (for production) or H2 (for development)
OpenNLP models (download required)
Adequate storage for PDF files

Installation

Clone the repository

git clone https://github.com/rebit/rbi-circular-system.git
cd rbi-circular-system

Download OpenNLP models and place them in src/main/resources/models/:

en-sent.bin
en-token.bin
en-ner-person.bin
en-ner-organization.bin
en-ner-location.bin

These can be downloaded from: https://opennlp.apache.org/models.html
Build the project

mvn clean install

Run the application

java -jar target/rbi-circular-system-1.0.0.jar
Or with Spring profiles:
java -jar -Dspring.profiles.active=dev target/rbi-circular-system-1.0.0.jar
Configuration
The application uses Spring profiles for environment-specific configuration:

dev: Uses H2 in-memory database for development and testing
prod: Uses Oracle database for production

Configuration files:

application.properties: Common configuration
application-dev.properties: Development environment configuration
application-prod.properties: Production environment configuration

Features in Detail
Circular Management
The system allows uploading PDF circulars and automatically extracts the following information:

Circular number (e.g., RBI/2025-26/06)
Reference number
Publishing date
Issuing department
Intended recipients
Subject
Summary (NLP-generated)
Named entities (people, organizations, locations)
Action items

Intelligent Search
The search capabilities include:

Text-based search across all fields
Filtering by date range, department, and other metadata
Sorting and pagination
Named entity search
Full-text relevance scoring

AI-Powered Chatbot
The chatbot uses information retrieval techniques to:

Answer questions about circular content
Provide references to source circulars
Understand banking and regulatory terminology
Continuously improve as new circulars are added

Cross-Reference Analytics
The cross-reference analytics feature:

Identifies when circulars reference each other
Tracks superseded and amended circulars
Provides visualizations of reference networks
Shows circular relationships in both list and graph form