package com.rebit.rbicirculars.controller;

import com.rebit.rbicirculars.service.CircularTrainingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/training")
@Tag(name = "Model Training", description = "API for managing chatbot model training")
public class TrainingController {

    private final CircularTrainingService trainingService;

    @Autowired
    public TrainingController(CircularTrainingService trainingService) {
        this.trainingService = trainingService;
    }

    @PostMapping("/retrain")
    @Operation(summary = "Retrain the model", description = "Start a retraining process for the chatbot model with all circulars")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Training started or already in progress",
                    content = @Content(mediaType = "application/json"))
    })
    public ResponseEntity<Object> retrainModel() {
        boolean started = trainingService.retrainModel();

        if (started) {
            return ResponseEntity.ok().body(
                    java.util.Map.of("status", "Training process started")
            );
        } else {
            return ResponseEntity.ok().body(
                    java.util.Map.of("status", "Training already in progress")
            );
        }
    }

    @GetMapping("/status")
    @Operation(summary = "Get training status", description = "Check if training is in progress and when was the last training")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Training status",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CircularTrainingService.TrainingStatus.class)))
    })
    public ResponseEntity<CircularTrainingService.TrainingStatus> getTrainingStatus() {
        return ResponseEntity.ok(trainingService.getTrainingStatus());
    }
}