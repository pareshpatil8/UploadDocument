package com.rebit.rbicirculars.controller;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.model.CircularReference;
import com.rebit.rbicirculars.service.CircularService;
import com.rebit.rbicirculars.repository.CircularReferenceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/circulars/references")
public class CircularReferenceController {

    private final CircularService circularService;
    private final CircularReferenceRepository referenceRepository;

    @Autowired
    public CircularReferenceController(CircularService circularService,
                                       CircularReferenceRepository referenceRepository) {
        this.circularService = circularService;
        this.referenceRepository = referenceRepository;
    }

    @GetMapping("/circular/{id}")
    public ResponseEntity<Map<String, Object>> getCircularReferences(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        // Get all references where this circular is either source or target
        List<CircularReference> allReferences = referenceRepository.findAllReferencesInvolvingCircular(id);

        // Split into citations and referenced-by
        List<CircularReference> outgoingReferences = allReferences.stream()
                .filter(ref -> ref.getSourceCircular().getId().equals(id))
                .collect(Collectors.toList());

        List<CircularReference> incomingReferences = allReferences.stream()
                .filter(ref -> ref.getReferencedCircular().getId().equals(id))
                .collect(Collectors.toList());

        // Check if this circular supersedes others
        List<CircularReference> supersedes = outgoingReferences.stream()
                .filter(ref -> "SUPERSEDES".equals(ref.getReferenceType()))
                .collect(Collectors.toList());

        // Check if this circular is superseded by others
        List<CircularReference> supersededBy = incomingReferences.stream()
                .filter(ref -> "SUPERSEDES".equals(ref.getReferenceType()))
                .collect(Collectors.toList());

        response.put("cites", formatReferences(outgoingReferences, id));
        response.put("citedBy", formatReferences(incomingReferences, id));
        response.put("supersedes", formatReferences(supersedes, id));
        response.put("supersededBy", formatReferences(supersededBy, id));

        return ResponseEntity.ok(response);
    }

    private List<Map<String, Object>> formatReferences(List<CircularReference> references, Long currentCircularId) {
        return references.stream().map(ref -> {
            Map<String, Object> formatted = new HashMap<>();
            Circular circular = ref.getSourceCircular().getId().equals(currentCircularId) ?
                    ref.getReferencedCircular() : ref.getSourceCircular();

            formatted.put("id", circular.getId());
            formatted.put("circularNumber", circular.getCircularNumber());
            formatted.put("subject", circular.getSubject());
            formatted.put("date", circular.getPublishDate());
            formatted.put("referenceType", ref.getReferenceType());
            return formatted;
        }).collect(Collectors.toList());
    }
}