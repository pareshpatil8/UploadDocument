// Updated CircularRepository.java
package com.rebit.rbicirculars.repository;

import com.rebit.rbicirculars.model.Circular;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CircularRepository extends JpaRepository<Circular, Long> {

    Page<Circular> findByCircularNumberContainingIgnoreCaseOrSubjectContainingIgnoreCaseOrSummaryContainingIgnoreCase(
            String circularNumber, String subject, String summary, Pageable pageable);

    @Query("SELECT c FROM Circular c LEFT JOIN c.namedEntities ne WHERE " +
            "(:circularNumber IS NULL OR c.circularNumber LIKE %:circularNumber%) AND " +
            "(:referenceNumber IS NULL OR c.referenceNumber LIKE %:referenceNumber%) AND " +
            "(:department IS NULL OR c.issuingDepartment LIKE %:department%) AND " +
            "(:recipient IS NULL OR c.intendedRecipients LIKE %:recipient%) AND " +
            "(:fromDate IS NULL OR c.publishDate >= :fromDate) AND " +
            "(:toDate IS NULL OR c.publishDate <= :toDate) AND " +
            "(:keyword IS NULL OR c.subject LIKE %:keyword% OR c.summary LIKE %:keyword%) AND " +
            "(:entity IS NULL OR :entity MEMBER OF c.namedEntities)")
    Page<Circular> searchCirculars(
            @Param("circularNumber") String circularNumber,
            @Param("referenceNumber") String referenceNumber,
            @Param("department") String department,
            @Param("recipient") String recipient,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            @Param("keyword") String keyword,
            @Param("entity") String entity,
            Pageable pageable);

    List<Circular> findByPublishDateBetween(LocalDate fromDate, LocalDate toDate);

    // Find by exact circular number - might return none or one match
    Circular findByCircularNumberEquals(String circularNumber);

    // Find by circular number pattern - might return multiple matches
    List<Circular> findByCircularNumberContaining(String circularNumberPart);

    // Find by circular number with custom fuzzy matching
    @Query("SELECT c FROM Circular c WHERE " +
            "c.circularNumber LIKE %:number% OR " +
            "LOWER(c.referenceNumber) LIKE LOWER(CONCAT('%', :number, '%'))")
    List<Circular> findByCircularNumberFuzzy(@Param("number") String number);
}