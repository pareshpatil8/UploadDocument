// Department.java
package com.rebit.rbicirculars.model.enums;

public enum Department {
    GOVERNMENT_AND_BANK_ACCOUNTS("Department of Government and Bank Accounts"),
    REGULATION("Department of Regulation"),
    BANKING_SUPERVISION("Department of Banking Supervision"),
    CURRENCY_MANAGEMENT("Department of Currency Management"),
    PAYMENT_AND_SETTLEMENT("Department of Payment and Settlement Systems"),
    FINANCIAL_MARKETS("Financial Markets Department"),
    FOREIGN_EXCHANGE("Foreign Exchange Department");

    private final String departmentName;

    Department(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public static Department findByText(String text) {
        for (Department department : values()) {
            if (text.contains(department.getDepartmentName())) {
                return department;
            }
        }
        return null; // Default to null if no match found
    }
}