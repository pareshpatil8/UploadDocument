package com.rebit.rbicirculars.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "circular")
public class Circular {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "circular_number", nullable = false)
    private String circularNumber;

    @Column(name = "reference_number")
    private String referenceNumber;

    @Column(name = "publish_date", nullable = false)
    private LocalDate publishDate;

    @Column(name = "issuing_department", nullable = false)
    private String issuingDepartment;

    @Column(name = "intended_recipients", nullable = false, columnDefinition = "CLOB")
    private String intendedRecipients;

    @Column(name = "subject", nullable = false, columnDefinition = "CLOB")
    private String subject;

    @Column(name = "summary", nullable = false, length = 5000)
    private String summary;

    @Column(name = "file_path", nullable = false)
    private String filePath;

    @ElementCollection
    @CollectionTable(name = "circular_action_items", joinColumns = @JoinColumn(name = "circular_id"))
    @Column(name = "action_item", length = 1000)
    private List<String> actionItems = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "circular_named_entities", joinColumns = @JoinColumn(name = "circular_id"))
    @Column(name = "entity")
    private Set<String> namedEntities = new HashSet<>();

    @Column(name = "created_at")
    private LocalDate createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDate.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCircularNumber() {
        return circularNumber;
    }

    public void setCircularNumber(String circularNumber) {
        this.circularNumber = circularNumber;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public LocalDate getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(LocalDate publishDate) {
        this.publishDate = publishDate;
    }

    public String getIssuingDepartment() {
        return issuingDepartment;
    }

    public void setIssuingDepartment(String issuingDepartment) {
        this.issuingDepartment = issuingDepartment;
    }

    public String getIntendedRecipients() {
        return intendedRecipients;
    }

    public void setIntendedRecipients(String intendedRecipients) {
        this.intendedRecipients = intendedRecipients;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public List<String> getActionItems() {
        return actionItems;
    }

    public void setActionItems(List<String> actionItems) {
        this.actionItems = actionItems;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public Set<String> getNamedEntities() {
        return namedEntities;
    }

    public void setNamedEntities(Set<String> namedEntities) {
        this.namedEntities = namedEntities;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }
}