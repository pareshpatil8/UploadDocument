package com.rebit.rbicirculars.service;

import com.rebit.rbicirculars.model.Circular;
import com.rebit.rbicirculars.model.CircularReference;
import com.rebit.rbicirculars.repository.CircularReferenceRepository;
import com.rebit.rbicirculars.repository.CircularRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class CrossReferenceService {

    private final CircularRepository circularRepository;
    private final CircularReferenceRepository referenceRepository;

    @Autowired
    public CrossReferenceService(CircularRepository circularRepository,
                                 CircularReferenceRepository referenceRepository) {
        this.circularRepository = circularRepository;
        this.referenceRepository = referenceRepository;
    }

    public void processCircularReferences(Circular circular, String fullText) {
        // Find references to other circulars
        List<String> referencedCirculars = extractCircularReferences(fullText);

        // For each referenced circular number
        for (String referencedNumber : referencedCirculars) {
            // Try exact match first
            Circular exactMatch = circularRepository.findByCircularNumberEquals(referencedNumber);

            if (exactMatch != null) {
                // Create a relationship record for exact match
                createCitationReference(circular, exactMatch);
            } else {
                // Try fuzzy matching
                List<Circular> fuzzyMatches = circularRepository.findByCircularNumberFuzzy(referencedNumber);

                if (!fuzzyMatches.isEmpty()) {
                    // Sort by similarity if multiple matches
                    if (fuzzyMatches.size() > 1) {
                        // Sort by similarity to reference
                        fuzzyMatches.sort((c1, c2) -> {
                            int sim1 = calculateSimilarity(referencedNumber, c1.getCircularNumber());
                            int sim2 = calculateSimilarity(referencedNumber, c2.getCircularNumber());
                            return Integer.compare(sim2, sim1); // Higher similarity first
                        });

                        // Take only the top match or limit to a reasonable number
                        // For citations, we might want to be more conservative and just take the top match
                        fuzzyMatches = fuzzyMatches.subList(0, 1); // Just take the best match
                    }

                    // Create references for the matches
                    for (Circular match : fuzzyMatches) {
                        createCitationReference(circular, match);
                    }
                }
            }
        }
    }

    private void createCitationReference(Circular source, Circular target) {
        // Check if this relationship already exists
        boolean exists = referenceRepository.existsBySourceCircularIdAndReferencedCircularIdAndReferenceType(
                source.getId(), target.getId(), "CITES");

        if (!exists) {
            CircularReference reference = new CircularReference();
            reference.setSourceCircular(source);
            reference.setReferencedCircular(target);
            reference.setReferenceType("CITES");
            referenceRepository.save(reference);
        }
    }

    private List<String> extractCircularReferences(String text) {
        List<String> references = new ArrayList<>();

        // Common patterns of RBI circular references
        List<Pattern> refPatterns = new ArrayList<>();
        refPatterns.add(Pattern.compile("RBI/\\d{4}-\\d{2}/\\d+"));
        refPatterns.add(Pattern.compile("circular (?:no\\.?|number) [A-Z]+\\.[A-Z]+\\.[A-Z]+\\.[^\\d]+(\\d+/\\d{4})"));
        refPatterns.add(Pattern.compile("dated (?:the )?\\d{1,2}(?:st|nd|rd|th)? [A-Za-z]+,? \\d{4}"));

        // Apply each pattern
        for (Pattern pattern : refPatterns) {
            Matcher matcher = pattern.matcher(text);
            while (matcher.find()) {
                String reference = matcher.group();
                references.add(reference);
            }
        }

        return references;
    }

    public List<Circular> findSupersededCirculars(Circular circular, String fullText) {
        List<Circular> supersededCirculars = new ArrayList<>();

        // Patterns indicating superseding
        List<String> supersedingPhrases = List.of(
                "supersedes", "replaces", "superseding",
                "in supersession of", "stands withdrawn",
                "is hereby withdrawn"
        );

        // Check for superseding language
        String lowerText = fullText.toLowerCase();
        boolean mightSupersede = supersedingPhrases.stream()
                .anyMatch(phrase -> lowerText.contains(phrase));

        if (mightSupersede) {
            // Extract references near superseding phrases
            List<String> potentialSupersededRefs = new ArrayList<>();

            for (String phrase : supersedingPhrases) {
                int index = lowerText.indexOf(phrase);
                if (index >= 0) {
                    // Extract 200 characters after the phrase
                    int endIndex = Math.min(index + phrase.length() + 200, fullText.length());
                    String context = fullText.substring(index, endIndex);

                    // Find circular references in this context
                    List<String> refsInContext = extractCircularReferences(context);
                    potentialSupersededRefs.addAll(refsInContext);
                }
            }

            // Process each potential reference
            for (String ref : potentialSupersededRefs) {
                // Try exact match first
                Circular exactMatch = circularRepository.findByCircularNumberEquals(ref);

                if (exactMatch != null) {
                    // Perfect match found
                    supersededCirculars.add(exactMatch);
                    createSupersededReference(circular, exactMatch);
                } else {
                    // Try fuzzy matching
                    List<Circular> fuzzyMatches = circularRepository.findByCircularNumberFuzzy(ref);

                    if (!fuzzyMatches.isEmpty()) {
                        // Sort by similarity if multiple matches
                        if (fuzzyMatches.size() > 1) {
                            // Sort by similarity to reference (simple implementation)
                            fuzzyMatches.sort((c1, c2) -> {
                                int sim1 = calculateSimilarity(ref, c1.getCircularNumber());
                                int sim2 = calculateSimilarity(ref, c2.getCircularNumber());
                                return Integer.compare(sim2, sim1); // Higher similarity first
                            });

                            // Take only the most similar match or limit to a reasonable number
                            fuzzyMatches = fuzzyMatches.subList(0, Math.min(fuzzyMatches.size(), 3));
                        }

                        // Add all matches (or just the top ones)
                        for (Circular match : fuzzyMatches) {
                            supersededCirculars.add(match);
                            createSupersededReference(circular, match);
                        }
                    }
                }
            }
        }

        return supersededCirculars;
    }

    private void createSupersededReference(Circular source, Circular target) {
        // Check if this relationship already exists
        boolean exists = referenceRepository.existsBySourceCircularIdAndReferencedCircularIdAndReferenceType(
                source.getId(), target.getId(), "SUPERSEDES");

        if (!exists) {
            CircularReference reference = new CircularReference();
            reference.setSourceCircular(source);
            reference.setReferencedCircular(target);
            reference.setReferenceType("SUPERSEDES");
            referenceRepository.save(reference);
        }
    }

    // Simple string similarity calculation (Levenshtein distance-based)
    private int calculateSimilarity(String s1, String s2) {
        // Normalize strings
        s1 = s1.toLowerCase().replaceAll("[^a-z0-9/]", "");
        s2 = s2.toLowerCase().replaceAll("[^a-z0-9/]", "");

        // Calculate Levenshtein distance
        int[] costs = new int[s2.length() + 1];
        for (int i = 0; i <= s1.length(); i++) {
            int lastValue = i;
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    costs[j] = j;
                } else if (j > 0) {
                    int newValue = costs[j - 1];
                    if (s1.charAt(i - 1) != s2.charAt(j - 1)) {
                        newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
                    }
                    costs[j - 1] = lastValue;
                    lastValue = newValue;
                }
            }
            if (i > 0) {
                costs[s2.length()] = lastValue;
            }
        }

        // Return similarity score (invert distance so higher is better)
        int maxLength = Math.max(s1.length(), s2.length());
        return maxLength - costs[s2.length()];
    }
}