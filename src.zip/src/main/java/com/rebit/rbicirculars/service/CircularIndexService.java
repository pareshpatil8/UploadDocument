package com.rebit.rbicirculars.service;

import com.rebit.rbicirculars.model.Circular;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.search.highlight.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CircularIndexService {

    private final StandardAnalyzer analyzer = new StandardAnalyzer();
    private Directory index;
    private IndexWriter writer;

    @Value("${lucene.index.location:index}")
    private String indexLocation;

    public CircularIndexService(@Value("${lucene.index.location:index}") String indexLocation) throws IOException {
        this.indexLocation = indexLocation;
        Path indexPath = Paths.get(indexLocation);

        if (!Files.exists(indexPath)) {
            Files.createDirectories(indexPath);
        }

        this.index = FSDirectory.open(indexPath);
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        this.writer = new IndexWriter(index, config);
    }

    public void indexCircular(Circular circular)  {
        try {
            Document doc = new Document();

            // Add ID field (should never be null)
            doc.add(new StringField("id", circular.getId().toString(), Field.Store.YES));

            // Add text fields with null checks
            if (circular.getCircularNumber() != null) {
                doc.add(new TextField("circularNumber", circular.getCircularNumber(), Field.Store.YES));
            }

            if (circular.getReferenceNumber() != null) {
                doc.add(new TextField("referenceNumber", circular.getReferenceNumber(), Field.Store.YES));
            }

            if (circular.getPublishDate() != null) {
                doc.add(new StringField("publishDate", circular.getPublishDate().toString(), Field.Store.YES));
            }

            if (circular.getIssuingDepartment() != null) {
                doc.add(new TextField("issuingDepartment", circular.getIssuingDepartment(), Field.Store.YES));
            }

            if (circular.getIntendedRecipients() != null) {
                doc.add(new TextField("intendedRecipients", circular.getIntendedRecipients(), Field.Store.YES));
            }

            if (circular.getSubject() != null) {
                doc.add(new TextField("subject", circular.getSubject(), Field.Store.YES));
            }

            if (circular.getSummary() != null) {
                doc.add(new TextField("summary", circular.getSummary(), Field.Store.YES));
            }

            // Add action items
            if (circular.getActionItems() != null && !circular.getActionItems().isEmpty()) {
                String actionItemsText = String.join(". ", circular.getActionItems());
                doc.add(new TextField("actionItems", actionItemsText, Field.Store.YES));
            }

            // Add named entities
            if (circular.getNamedEntities() != null && !circular.getNamedEntities().isEmpty()) {
                for (String entity : circular.getNamedEntities()) {
                    doc.add(new TextField("namedEntity", entity, Field.Store.YES));
                }
            }

            // Add action items
            if (circular.getActionItems() != null && !circular.getActionItems().isEmpty()) {
                String actionItemsText = String.join(". ", circular.getActionItems());
                doc.add(new TextField("actionItems", actionItemsText, Field.Store.YES));
            }

            // Add the document to the index
            writer.updateDocument(new Term("id", circular.getId().toString()), doc);
            writer.commit();
        }catch (IOException e) {
            // Log the error
            System.err.println("Error indexing circular: " + e.getMessage());

            // Try to unlock the index if it's a locking issue
            if (e.getMessage().contains("write.lock")) {
                try {
                    // Check if the lock file exists and delete it
                    Path lockFile = Paths.get(indexLocation, "write.lock");
                    if (Files.exists(lockFile)) {
                        Files.delete(lockFile);
                        System.out.println("Deleted stale lock file. Please try again.");
                    }
                } catch (IOException lockEx) {
                    System.err.println("Failed to delete lock file: " + lockEx.getMessage());
                }
            }
        }
    }

    public void reindexAllCirculars(List<Circular> circulars) throws IOException {
        // Delete all existing documents
        writer.deleteAll();

        // Add all circulars to the index
        for (Circular circular : circulars) {
            indexCircular(circular);
        }

        writer.commit();
    }

    public void deleteCircularFromIndex(Long id) throws IOException {
        writer.deleteDocuments(new Term("id", id.toString()));
        writer.commit();
    }

    public List<Map<String, Object>> searchCirculars(String queryStr, int maxResults) throws IOException, ParseException {
        // Create a query parser for multiple fields with different boosts
        Map<String, Float> boosts = new HashMap<>();
        boosts.put("subject", 2.0f);
        boosts.put("summary", 1.5f);
        boosts.put("actionItems", 1.2f);
        boosts.put("circularNumber", 3.0f);
        boosts.put("referenceNumber", 3.0f);

        // Build a boolean query with multiple field queries
        BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
        QueryParser parser;

        for (Map.Entry<String, Float> entry : boosts.entrySet()) {
            parser = new QueryParser(entry.getKey(), analyzer);
            Query query = parser.parse(queryStr);
            query = new BoostQuery(query, entry.getValue());
            booleanQuery.add(query, BooleanClause.Occur.SHOULD);
        }

        // Create a searcher and execute the query
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(booleanQuery.build(), maxResults);

        // Set up highlighter
        QueryScorer scorer = new QueryScorer(booleanQuery.build());
        Highlighter highlighter = new Highlighter(new SimpleHTMLFormatter("<em>", "</em>"), scorer);

        // Process search results
        List<Map<String, Object>> results = new ArrayList<>();
        for (ScoreDoc scoreDoc : docs.scoreDocs) {
            Document doc = searcher.storedFields().document(scoreDoc.doc);
            Map<String, Object> result = new HashMap<>();

            // Extract fields from the document
            result.put("id", doc.get("id"));
            result.put("circularNumber", doc.get("circularNumber"));
            result.put("subject", doc.get("subject"));
            result.put("publishDate", doc.get("publishDate"));
            result.put("score", scoreDoc.score);

            // Get highlighted snippets
            String summary = doc.get("summary");
            try {
                String highlighted = highlighter.getBestFragment(analyzer, "summary", summary);
                result.put("highlightedText", highlighted != null ? highlighted : summary.substring(0, Math.min(summary.length(), 200)) + "...");
            } catch (InvalidTokenOffsetsException e) {
                result.put("highlightedText", summary.substring(0, Math.min(summary.length(), 200)) + "...");
            }

            results.add(result);
        }

        reader.close();
        return results;
    }

    public Map<String, Object> getRelevantPassage(String question, int maxResults) throws IOException, ParseException {
        List<Map<String, Object>> searchResults = searchCirculars(question, maxResults);

        if (searchResults.isEmpty()) {
            return Collections.emptyMap();
        }

        // Find the most relevant result
        Map<String, Object> bestMatch = searchResults.stream()
                .max(Comparator.comparingDouble(result -> ((Float) result.get("score"))))
                .orElse(searchResults.get(0));

        // Get the circular ID to reference the source
        String circularId = (String) bestMatch.get("id");
        String circularNumber = (String) bestMatch.get("circularNumber");
        String highlightedText = (String) bestMatch.get("highlightedText");

        Map<String, Object> response = new HashMap<>();
        response.put("answer", highlightedText);
        response.put("circularId", circularId);
        response.put("circularNumber", circularNumber);
        response.put("confidence", bestMatch.get("score"));

        return response;
    }

    public void close() throws IOException {
        writer.close();
        index.close();
    }
}