// NlpService.java
package com.rebit.rbicirculars.service;

import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.util.Span;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class NlpService {

    private SentenceDetectorME sentenceDetector;
    private TokenizerME tokenizer;
    private Map<String, NameFinderME> entityFinders = new HashMap<>();

    @PostConstruct
    public void init() throws IOException {
        // Load models from classpath resources
        try (InputStream sentenceModelIn = new ClassPathResource("models/en-sent.bin").getInputStream();
             InputStream tokenizerModelIn = new ClassPathResource("models/en-token.bin").getInputStream();
             InputStream personModelIn = new ClassPathResource("models/en-ner-person.bin").getInputStream();
             InputStream organizationModelIn = new ClassPathResource("models/en-ner-organization.bin").getInputStream();
             InputStream locationModelIn = new ClassPathResource("models/en-ner-location.bin").getInputStream()) {

            // Initialize sentence detector
            SentenceModel sentenceModel = new SentenceModel(sentenceModelIn);
            sentenceDetector = new SentenceDetectorME(sentenceModel);

            // Initialize tokenizer
            TokenizerModel tokenizerModel = new TokenizerModel(tokenizerModelIn);
            tokenizer = new TokenizerME(tokenizerModel);

            // Initialize entity finders
            TokenNameFinderModel personModel = new TokenNameFinderModel(personModelIn);
            TokenNameFinderModel organizationModel = new TokenNameFinderModel(organizationModelIn);
            TokenNameFinderModel locationModel = new TokenNameFinderModel(locationModelIn);

            entityFinders.put("person", new NameFinderME(personModel));
            entityFinders.put("organization", new NameFinderME(organizationModel));
            entityFinders.put("location", new NameFinderME(locationModel));
        } catch (IOException e) {
            // Fallback to ensure the service can start even if models are not available
            System.err.println("Error loading NLP models: " + e.getMessage());
            throw e;
        }
    }

    public String generateSummary(String text, int maxSentences) {
        // Detect sentences
        String[] sentences = sentenceDetector.sentDetect(text);

        if (sentences.length <= maxSentences) {
            return String.join(" ", sentences);
        }

        // Simple extractive summarization based on sentence position
        // First 2 sentences + last sentence + middle sentences with most important keywords
        List<String> summaryLines = new ArrayList<>();

        // Add first sentence as it usually contains important context
        summaryLines.add(sentences[0]);

        // If we have more than 1 sentence, add the second one too
        if (sentences.length > 1) {
            summaryLines.add(sentences[1]);
        }

        // Add last sentence as it often contains conclusions
        if (sentences.length > 2) {
            summaryLines.add(sentences[sentences.length - 1]);
        }

        // If we need more sentences to reach maxSentences, add from the middle
        if (summaryLines.size() < maxSentences && sentences.length > 3) {
            // For simplicity, just add the middle sentences
            int middleIndex = sentences.length / 2;
            int remaining = maxSentences - summaryLines.size();

            for (int i = 0; i < remaining && middleIndex + i < sentences.length - 1; i++) {
                summaryLines.add(sentences[middleIndex + i]);
            }
        }

        return String.join(" ", summaryLines);
    }

    public Set<String> extractNamedEntities(String text) {
        Set<String> entities = new HashSet<>();

        // Detect sentences first for better accuracy
        String[] sentences = sentenceDetector.sentDetect(text);

        for (String sentence : sentences) {
            // Tokenize the sentence
            String[] tokens = tokenizer.tokenize(sentence);

            // Apply each entity finder
            for (Map.Entry<String, NameFinderME> finderEntry : entityFinders.entrySet()) {
                NameFinderME finder = finderEntry.getValue();
                String entityType = finderEntry.getKey();

                Span[] nameSpans = finder.find(tokens);

                // Extract entity text and add to result set
                for (Span span : nameSpans) {
                    String entity = String.join(" ", Arrays.copyOfRange(tokens, span.getStart(), span.getEnd()));
                    entities.add(entity.trim());
                }

                // Clear adaptive data in name finder
                finder.clearAdaptiveData();
            }
        }

        // Filter out common noise and very short entities
        return entities.stream()
                .filter(entity -> entity.length() > 2)
                .filter(entity -> !entity.equalsIgnoreCase("RBI"))
                .filter(entity -> !entity.equalsIgnoreCase("Reserve Bank of India"))
                .collect(Collectors.toSet());
    }

    // Custom extensions for financial entity recognition could be added here
}