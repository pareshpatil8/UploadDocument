// Global Variables
let currentPage = 0;
let pageSize = 10;
let totalPages = 0;
let chatSessionId = null;

// Document Ready
document.addEventListener('DOMContentLoaded', function() {
    // Upload Form Submission
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        e.preventDefault();
        uploadCircular();
    });

    // Search Form Submission
    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        currentPage = 0;
        searchCirculars();
    });

    // Chat Input Handling
    document.getElementById('sendButton').addEventListener('click', sendChatMessage);
    document.getElementById('chatInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });

    // Retrain Model Button
    document.getElementById('retrainButton').addEventListener('click', retrainModel);

    // Initialize chatbot session
    initializeChatSession();

    // Check training status
    checkTrainingStatus();
});

// Initialize a new chat session
function initializeChatSession() {
    chatSessionId = generateUUID();
    console.log('Chat session initialized: ' + chatSessionId);
}

// Generate a UUID for chat sessions
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Upload a circular
function uploadCircular() {
    const fileInput = document.getElementById('circularFile');
    const resultDiv = document.getElementById('uploadResult');

    if (!fileInput.files.length) {
        resultDiv.innerHTML = '<div class="alert alert-danger">Please select a file to upload.</div>';
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);

    resultDiv.innerHTML = '<div class="alert alert-info">Uploading and processing file...</div>';

    fetch('/api/circulars/upload', {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Upload failed');
            }
            return response.json();
        })
        .then(data => {
            resultDiv.innerHTML = `<div class="alert alert-success">
            Circular uploaded successfully!<br>
            Circular Number: ${data.circularNumber}<br>
            Subject: ${data.subject}
        </div>`;
            // Reset the form
            document.getElementById('uploadForm').reset();
        })
        .catch(error => {
            resultDiv.innerHTML = `<div class="alert alert-danger">
            Error uploading circular: ${error.message}
        </div>`;
        });
}

// Search circulars
function searchCirculars() {
    const circularNumber = document.getElementById('circularNumber').value;
    const department = document.getElementById('department').value;
    const keyword = document.getElementById('keyword').value;
    const fromDate = document.getElementById('fromDate').value;
    const toDate = document.getElementById('toDate').value;
    const entity = document.getElementById('entity').value;


    // Build the URL with query parameters
    let url = `/api/circulars/search?page=${currentPage}&size=${pageSize}`;

    if (circularNumber) url += `&circularNumber=${encodeURIComponent(circularNumber)}`;
    if (department) url += `&department=${encodeURIComponent(department)}`;
    if (keyword) url += `&keyword=${encodeURIComponent(keyword)}`;
    if (fromDate) url += `&fromDate=${encodeURIComponent(fromDate)}`;
    if (toDate) url += `&toDate=${encodeURIComponent(toDate)}`;
    if (entity) url += `&entity=${encodeURIComponent(entity)}`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Search failed');
            }
            return response.json();
        })
        .then(data => {
            displaySearchResults(data);
        })
        .catch(error => {
            const resultsBody = document.getElementById('searchResultsBody');
            resultsBody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">
            Error searching circulars: ${error.message}
        </td></tr>`;
        });
}

// Display search results
function displaySearchResults(data) {
    const resultsBody = document.getElementById('searchResultsBody');

    // Clear the existing results
    resultsBody.innerHTML = '';

    if (data.content.length === 0) {
        resultsBody.innerHTML = '<tr><td colspan="6" class="text-center">No circulars found</td></tr>';
        return;
    }

    // Add each result to the table
    data.content.forEach(circular => {
        // Format named entities as badges
        let entityBadges = '';
        if (circular.namedEntities && circular.namedEntities.length > 0) {
            entityBadges = circular.namedEntities
                .slice(0, 3) // Show only first 3 entities to save space
                .map(entity => `<span class="badge bg-info me-1">${entity}</span>`)
                .join('');

            if (circular.namedEntities.length > 3) {
                entityBadges += `<span class="badge bg-secondary">+${circular.namedEntities.length - 3} more</span>`;
            }
        }

        resultsBody.innerHTML += `
            <tr>
                <td>${circular.circularNumber}</td>
                <td>${circular.subject}</td>
                <td>${circular.issuingDepartment}</td>
                <td>${circular.publishDate}</td>
                <td>${entityBadges}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="viewCircularDetails(${circular.id})">View</button>
                    <a href="/api/circulars/download/${circular.id}" class="btn btn-sm btn-success" target="_blank">Download</a>
                </td>
            </tr>
        `;
    });

    // Update pagination
    updatePagination(data);
}

// Update pagination controls
function updatePagination(data) {
    const paginationElement = document.getElementById('pagination');

    // Clear the existing pagination
    paginationElement.innerHTML = '';

    totalPages = data.totalPages;

    // Add the Previous button
    paginationElement.innerHTML += `
        <li class="page-item ${currentPage === 0 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="navigateToPage(${currentPage - 1}); return false;">Previous</a>
        </li>
    `;

    // Add page number buttons
    for (let i = 0; i < totalPages; i++) {
        paginationElement.innerHTML += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="navigateToPage(${i}); return false;">${i + 1}</a>
            </li>
        `;
    }

    // Add the Next button
    paginationElement.innerHTML += `
        <li class="page-item ${currentPage === totalPages - 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="navigateToPage(${currentPage + 1}); return false;">Next</a>
        </li>
    `;
}

// Navigate to a specific page of results
function navigateToPage(page) {
    if (page < 0 || page >= totalPages) {
        return;
    }

    currentPage = page;
    searchCirculars();
}

// View circular details
function viewCircularDetails(id) {
    fetch(`/api/circulars/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to fetch circular details');
            }
            return response.json();
        })
        .then(circular => {
            const modalTitle = document.getElementById('circularModalTitle');
            const modalBody = document.getElementById('circularModalBody');
            const downloadLink = document.getElementById('downloadCircular');

            modalTitle.textContent = circular.subject;

            // Format named entities as badges
            let entityBadges = '';
            if (circular.namedEntities && circular.namedEntities.length > 0) {
                entityBadges = circular.namedEntities
                    .map(entity => `<span class="badge bg-info me-1">${entity}</span>`)
                    .join('');
            }

            modalBody.innerHTML = `
            <p><strong>Circular Number:</strong> ${circular.circularNumber}</p>
            <p><strong>Reference Number:</strong> ${circular.referenceNumber}</p>
            <p><strong>Publishing Date:</strong> ${circular.publishDate}</p>
            <p><strong>Issuing Department:</strong> ${circular.issuingDepartment}</p>
            <p><strong>Intended Recipients:</strong> ${circular.intendedRecipients}</p>
            <h5>Summary</h5>
            <p>${circular.summary}</p>
            
            <h5>Named Entities</h5>
            <div class="mb-3">${entityBadges || 'No entities identified'}</div>
        `;

            if (circular.actionItems && circular.actionItems.length > 0) {
                modalBody.innerHTML += '<h5>Action Items</h5><ul>';
                circular.actionItems.forEach(item => {
                    modalBody.innerHTML += `<li>${item}</li>`;
                });
                modalBody.innerHTML += '</ul>';
            }

            downloadLink.href = `/api/circulars/download/${circular.id}`;

            // Show the modal
            new bootstrap.Modal(document.getElementById('circularModal')).show();
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });
}

// Send a message to the chatbot
function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();

    if (!message) {
        return;
    }

    // Add the user's message to the chat
    addChatMessage(message, true);

    // Clear the input
    chatInput.value = '';

    // Send the message to the API
    fetch('/api/chatbot/ask', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            question: message,
            sessionId: chatSessionId
        })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to get response from chatbot');
            }
            return response.json();
        })
        .then(data => {
            // Add the bot's response to the chat
            addChatMessage(data.answer, false, data.circularNumber);

            // Update the session ID if provided
            if (data.sessionId) {
                chatSessionId = data.sessionId;
            }
        })
        .catch(error => {
            addChatMessage(`Error: ${error.message}`, false);
        });
}

// Add a message to the chat window
function addChatMessage(message, isUser, circularRef = null) {
    const chatContainer = document.getElementById('chatContainer');

    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${isUser ? 'user-message' : 'bot-message'}`;

    // Replace newlines with <br> tags
    const formattedMessage = message.replace(/\n/g, '<br>');
    messageDiv.innerHTML = formattedMessage;

    // Add circular reference if provided
    if (circularRef) {
        const refDiv = document.createElement('div');
        refDiv.className = 'circular-reference';
        refDiv.textContent = `Reference: ${circularRef}`;
        messageDiv.appendChild(refDiv);
    }

    chatContainer.appendChild(messageDiv);

    // Scroll to the bottom of the chat container
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Retrain the chatbot model
function retrainModel() {
    const retrainButton = document.getElementById('retrainButton');
    const statusElement = document.getElementById('trainingStatus');

    retrainButton.disabled = true;
    statusElement.textContent = 'Starting training process...';

    fetch('/api/training/retrain', {
        method: 'POST'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to start training process');
            }
            return response.json();
        })
        .then(data => {
            statusElement.textContent = data.status;
            setTimeout(checkTrainingStatus, 2000); // Check status after 2 seconds
        })
        .catch(error => {
            statusElement.textContent = `Error: ${error.message}`;
            retrainButton.disabled = false;
        });
}

// Check the status of the training process
function checkTrainingStatus() {
    const statusElement = document.getElementById('trainingStatus');
    const retrainButton = document.getElementById('retrainButton');

    fetch('/api/training/status')
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to get training status');
            }
            return response.json();
        })
        .then(data => {
            if (data.training) {
                statusElement.textContent = 'Training in progress...';
                retrainButton.disabled = true;
                // Check again after 5 seconds
                setTimeout(checkTrainingStatus, 5000);
            } else {
                const lastTrainingDate = new Date(data.lastTrainingDate);
                statusElement.textContent = `Last trained: ${lastTrainingDate.toLocaleString()}`;
                retrainButton.disabled = false;
            }
        })
        .catch(error => {
            statusElement.textContent = `Error checking training status: ${error.message}`;
            retrainButton.disabled = false;
        });
}

function loadReferenceNetwork(circularId) {
    fetch(`/api/circulars/references/circular/${circularId}`)
        .then(response => response.json())
        .then(data => {
            // Create network visualization
            const nodes = [];
            const edges = [];

            // Add the focal circular
            nodes.push({
                id: circularId,
                label: currentCircular.circularNumber,
                color: '#FB7E81',
                shape: 'box',
                size: 25
            });

            // Add circulars this one cites
            data.cites.forEach(ref => {
                nodes.push({
                    id: ref.id,
                    label: ref.circularNumber,
                    title: ref.subject,
                    color: '#7BE141'
                });

                edges.push({
                    from: circularId,
                    to: ref.id,
                    arrows: 'to',
                    label: 'cites',
                    color: '#848484'
                });
            });

            // Add circulars that cite this one
            data.citedBy.forEach(ref => {
                nodes.push({
                    id: ref.id,
                    label: ref.circularNumber,
                    title: ref.subject,
                    color: '#41A2E1'
                });

                edges.push({
                    from: ref.id,
                    to: circularId,
                    arrows: 'to',
                    label: 'cites',
                    color: '#848484'
                });
            });

            // Add special styling for superseded relationships
            data.supersedes.forEach(ref => {
                // Highlight edges for superseded circulars
                const edge = edges.find(e => e.to === ref.id);
                if (edge) {
                    edge.label = 'supersedes';
                    edge.color = '#FF0000';
                    edge.width = 3;
                }
            });

            // Create the network visualization
            const container = document.getElementById('network-container');
            const networkData = {
                nodes: new vis.DataSet(nodes),
                edges: new vis.DataSet(edges)
            };

            const options = {
                physics: {
                    stabilization: true,
                    barnesHut: {
                        gravitationalConstant: -2000,
                        springConstant: 0.04,
                        springLength: 95
                    }
                },
                layout: {
                    improvedLayout: true
                }
            };

            new vis.Network(container, networkData, options);
        })
        .catch(error => {
            console.error('Error loading reference network:', error);
        });
}