-- Primary tables for circulars and their content
CREATE TABLE circulars (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    circular_number VARCHAR2(100) NOT NULL,
    reference_number VARCHAR2(100),
    publish_date DATE NOT NULL,
    issuing_department VARCHAR2(200) NOT NULL,
    intended_recipients VARCHAR2(200) NOT NULL,
    subject CLOB NOT NULL,
    summary CLOB NOT NULL,
    file_path VARCHAR2(255) NOT NULL,
    created_at DATE DEFAULT SYSDATE
);

CREATE TABLE circular_action_items (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    circular_id NUMBER NOT NULL,
    action_item VARCHAR2(1000) NOT NULL,
    CONSTRAINT fk_circular_id FOREIGN KEY (circular_id) REFERENCES circulars(id) ON DELETE CASCADE
);

CREATE TABLE circular_named_entities (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    circular_id NUMBER NOT NULL,
    entity VARCHAR2(255) NOT NULL,
    CONSTRAINT fk_named_entity_circular_id FOREIGN KEY (circular_id) REFERENCES circulars(id) ON DELETE CASCADE
);

-- Tables for chat interaction
CREATE TABLE chat_messages (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    session_id VARCHAR2(50) NOT NULL,
    message CLOB NOT NULL,
    is_user NUMBER(1) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    circular_reference VARCHAR2(50),
    circular_id NUMBER,
    CONSTRAINT fk_chat_circular_id FOREIGN KEY (circular_id) REFERENCES circulars(id) ON DELETE SET NULL
);

-- Cross-reference tables
CREATE TABLE circular_references (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    source_circular_id NUMBER NOT NULL,
    referenced_circular_id NUMBER NOT NULL,
    reference_type VARCHAR2(50) NOT NULL,
    context VARCHAR2(500),
    CONSTRAINT fk_source_circular FOREIGN KEY (source_circular_id) REFERENCES circulars(id),
    CONSTRAINT fk_referenced_circular FOREIGN KEY (referenced_circular_id) REFERENCES circulars(id)
);