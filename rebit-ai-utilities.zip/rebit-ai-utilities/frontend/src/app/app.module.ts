import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// PrimeNG Modules
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MenubarModule } from 'primeng/menubar';
import { PanelMenuModule } from 'primeng/panelmenu';
import { ChartModule } from 'primeng/chart';
import { TagModule } from 'primeng/tag';
import { ChipModule } from 'primeng/chip';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SplitterModule } from 'primeng/splitter';
import { ToolbarModule } from 'primeng/toolbar';
import { MenuModule } from 'primeng/menu';
import { CheckboxModule } from 'primeng/checkbox';

// Services
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';

// Components
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginComponent } from './components/auth/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PromptListComponent } from './components/prompt/crud/prompt-list/prompt-list.component';
import { PromptFormComponent } from './components/prompt/crud/prompt-form/prompt-form.component';
import { PromptViewComponent } from './components/prompt/crud/prompt-view/prompt-view.component';
import { PromptGenerationComponent } from './components/prompt/generation/prompt-generation.component';
import { PromptSearchComponent } from './components/prompt/search/prompt-search.component';
import { PromptImprovementComponent } from './components/prompt/improvement/prompt-improvement.component';
import { AnonymizationComponent } from './components/anonymization/anonymization.component';

// Interceptors
import { AuthInterceptor } from './interceptors/auth.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    PromptListComponent,
    PromptFormComponent,
    PromptViewComponent,
    PromptGenerationComponent,
    PromptSearchComponent,
    PromptImprovementComponent,
    AnonymizationComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    
    // PrimeNG Modules
    ButtonModule,
    CardModule,
    InputTextModule,
    InputTextareaModule,
    DropdownModule,
    TableModule,
    PaginatorModule,
    DialogModule,
    ToastModule,
    ConfirmDialogModule,
    MenubarModule,
    PanelMenuModule,
    ChartModule,
    TagModule,
    ChipModule,
    ProgressSpinnerModule,
    SplitterModule,
    ToolbarModule,
    MenuModule,
    CheckboxModule
  ],
  providers: [
    MessageService,
    ConfirmationService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }