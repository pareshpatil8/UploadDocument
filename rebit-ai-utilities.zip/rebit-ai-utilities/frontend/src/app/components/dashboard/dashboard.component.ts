import { Component, OnInit, NgZone, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { MessageService } from 'primeng/api';
import { DashboardService } from '../../services/dashboard.service';
import { DashboardStats } from '../../models/common.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  // keep or remove OnPush depending on your app;
  // leaving it ON makes UI updates explicit & robust.
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {
  loading = true;
  dashboardStats: DashboardStats | null = null;

  departmentChartData: any;
  statusChartData: any;
  chartOptions: any;
  barChartOptions: any;

  constructor(
      private dashboardService: DashboardService,
      private messageService: MessageService,
      private zone: NgZone,
      private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initializeChartOptions();
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    console.log('🔄 Starting loadDashboardData...');
    this.loading = true;
    this.cdr.markForCheck();

    this.dashboardService.getDashboardStats().subscribe({
      next: (stats) => {
        // Ensure Angular change detection runs even if HTTP callback happens out-of-zone
        this.zone.run(() => {
          console.log('✅ Dashboard stats received:', stats);
          console.log('📊 Total prompts:', stats?.totalPrompts);
          console.log('📊 Active prompts:', stats?.activePrompts);

          this.dashboardStats = stats;
          console.log('💾 dashboardStats set to:', this.dashboardStats);

          this.updateChartData();
          console.log('📈 Chart data updated');

          this.loading = false;
          console.log('⏹️ Loading set to false');
          this.cdr.markForCheck();
        });
      },
      error: (error) => {
        this.zone.run(() => {
          console.error('❌ Dashboard error:', error);
          this.loading = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to load dashboard data'
          });
          this.cdr.markForCheck();
        });
      }
    });
  }

  private updateChartData(): void {
    if (!this.dashboardStats) return;

    // Prompts by Department (doughnut)
    const deptLabels = Object.keys(this.dashboardStats.promptsByDepartment || {});
    const deptData = Object.values(this.dashboardStats.promptsByDepartment || {});
    if (deptLabels.length > 0 && deptData.some(v => (v as number) > 0)) {
      this.departmentChartData = {
        labels: deptLabels.map(l => this.formatDepartmentLabel(l)),
        datasets: [{
          data: deptData,
          // Chart.js will repeat colors if fewer than labels
          backgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
            '#9966FF', '#FF9F40', '#FF6384', '#C9CBCF'
          ]
        }]
      };
    } else {
      this.departmentChartData = null;
    }

    // Prompts by Status (bar)
    const statusLabels = Object.keys(this.dashboardStats.promptsByStatus || {});
    const statusData = Object.values(this.dashboardStats.promptsByStatus || {});
    if (statusLabels.length > 0 && statusData.some(v => (v as number) > 0)) {
      this.statusChartData = {
        labels: statusLabels,
        datasets: [{
          label: 'Prompts',
          data: statusData,
          backgroundColor: '#36A2EB',
          borderColor: '#36A2EB',
          borderWidth: 1
        }]
      };
    } else {
      this.statusChartData = null;
    }
  }

  private initializeChartOptions(): void {
    this.chartOptions = {
      plugins: {
        legend: { position: 'right' }
      },
      maintainAspectRatio: false,
      responsive: true
    };

    this.barChartOptions = {
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1 }
        }
      },
      maintainAspectRatio: false,
      responsive: true
    };
  }

  getRecentActivityTotal(): number {
    if (!this.dashboardStats?.recentActivity) return 0;
    return Object.values(this.dashboardStats.recentActivity)
        .reduce((sum: number, v: any) => sum + (v as number), 0);
  }

  getRecentActivityArray(): Array<{ label: string; value: number }> {
    if (!this.dashboardStats?.recentActivity) return [];
    return Object.entries(this.dashboardStats.recentActivity)
        .map(([label, value]) => ({ label, value: value as number }));
  }

  private formatDepartmentLabel(label: string): string {
    return label.replace(/_/g, ' ')
        .toLowerCase()
        .replace(/\b\w/g, (l) => l.toUpperCase());
  }
}
