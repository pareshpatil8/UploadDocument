import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { AnonymizationService } from '../../services/anonymization.service';
import { AnonymizationRequest, AnonymizationResponse } from '../../models/common.model';

@Component({
  selector: 'app-anonymization',
  templateUrl: './anonymization.component.html',
  styleUrls: ['./anonymization.component.scss']
})
export class AnonymizationComponent implements OnInit {
  anonymizationForm!: FormGroup;
  anonymizing = false;
  anonymizationResponse: AnonymizationResponse | null = null;

  contentTypeOptions = [
    { label: 'Auto-detect', value: 'AUTO' },
    { label: 'Code', value: 'CODE' },
    { label: 'Text/Documentation', value: 'TEXT' },
    { label: 'Mixed Content', value: 'MIXED' }
  ];

  constructor(
    private fb: FormBuilder,
    private anonymizationService: AnonymizationService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.initializeForm();
  }

  private initializeForm() {
    this.anonymizationForm = this.fb.group({
      text: ['', [Validators.required]],
      contentType: ['AUTO'],
      preserveStructure: [true]
    });
  }

  anonymizeText() {
    if (this.anonymizationForm.valid) {
      this.anonymizing = true;
      const request: AnonymizationRequest = this.anonymizationForm.value;

      this.anonymizationService.anonymizeText(request).subscribe({
        next: (response) => {
          this.anonymizationResponse = response;
          this.anonymizing = false;
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Text anonymized successfully'
          });
        },
        error: (error) => {
          this.anonymizing = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to anonymize text'
          });
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  clearForm() {
    this.anonymizationForm.reset({
      contentType: 'AUTO',
      preserveStructure: true
    });
    this.anonymizationResponse = null;
  }

  processAnother() {
    this.anonymizationForm.patchValue({
      text: this.anonymizationResponse?.anonymizedText || ''
    });
    this.anonymizationResponse = null;
  }

  copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: `${label} copied to clipboard`
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  downloadAsFile() {
    if (this.anonymizationResponse) {
      const element = document.createElement('a');
      const file = new Blob([this.anonymizationResponse.anonymizedText], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = 'anonymized-content.txt';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'File downloaded successfully'
      });
    }
  }

  saveResult() {
    // This could save to a user's personal storage or prompt management system
    this.messageService.add({
      severity: 'info',
      summary: 'Info',
      detail: 'Save functionality can be implemented based on requirements'
    });
  }

  hasReplacements(): boolean {
    return this.anonymizationResponse?.replacements && 
           Object.keys(this.anonymizationResponse.replacements).length > 0 || false;
  }

  getReplacementArray(): Array<{original: string, replacement: string}> {
    if (!this.anonymizationResponse?.replacements) return [];
    return Object.entries(this.anonymizationResponse.replacements)
      .map(([original, replacement]) => ({ original, replacement }));
  }

  isFieldInvalid(field: string): boolean {
    const formField = this.anonymizationForm.get(field);
    return !!(formField && formField.invalid && (formField.dirty || formField.touched));
  }

  private markFormGroupTouched() {
    Object.keys(this.anonymizationForm.controls).forEach(field => {
      const control = this.anonymizationForm.get(field);
      control?.markAsTouched();
    });
  }
}