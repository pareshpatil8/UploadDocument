import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PromptService } from '../../../services/prompt.service';
import { AuthService } from '../../../services/auth.service';
import { PromptGenerationRequest, PromptGenerationResponse, Department, Prompt } from '../../../models/prompt.model';

@Component({
  selector: 'app-prompt-generation',
  templateUrl: './prompt-generation.component.html',
  styleUrls: ['./prompt-generation.component.scss']
})
export class PromptGenerationComponent implements OnInit {
  generationForm!: FormGroup;
  generating = false;
  generatedResponse: PromptGenerationResponse | null = null;

  departmentOptions = [
    { label: 'Product Management', value: Department.PRODUCT_MANAGEMENT },
    { label: 'Frontend Development', value: Department.FRONTEND_DEVELOPMENT },
    { label: 'Backend Development', value: Department.BACKEND_DEVELOPMENT },
    { label: 'Testing', value: Department.TESTING },
    { label: 'DevOps', value: Department.DEVOPS },
    { label: 'Usability', value: Department.USABILITY },
    { label: 'Business Analysis', value: Department.BUSINESS_ANALYSIS },
    { label: 'Project Management', value: Department.PROJECT_MANAGEMENT }
  ];

  constructor(
    private fb: FormBuilder,
    private promptService: PromptService,
    private authService: AuthService,
    private router: Router,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.initializeForm();
  }

  private initializeForm() {
    this.generationForm = this.fb.group({
      purpose: ['', [Validators.required]],
      department: ['', [Validators.required]],
      context: [''],
      expectedOutput: [''],
      constraints: ['']
    });
  }

  generatePrompt() {
    if (this.generationForm.valid) {
      this.generating = true;
      const request: PromptGenerationRequest = this.generationForm.value;

      this.promptService.generatePrompt(request).subscribe({
        next: (response) => {
          this.generatedResponse = response;
          this.generating = false;
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Prompt generated successfully'
          });
        },
        error: (error) => {
          this.generating = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to generate prompt'
          });
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: `${label} copied to clipboard`
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  saveAsPrompt() {
    if (this.generatedResponse) {
      const currentUser = this.authService.getCurrentUser();
      if (!currentUser) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'User not authenticated'
        });
        return;
      }

      const prompt: Prompt = {
        name: this.generationForm.value.purpose.substring(0, 100), // Truncate for name
        description: this.generationForm.value.context || 'Generated prompt',
        department: this.generationForm.value.department,
        systemPrompt: this.generatedResponse.systemPrompt,
        userPromptTemplate: this.generatedResponse.userPromptTemplate,
        outputFormat: this.generationForm.value.expectedOutput,
        constraints: this.generationForm.value.constraints,
        authorId: currentUser.id,
        status: 'ACTIVE' as any
      };

      this.router.navigate(['/prompts/new'], { 
        state: { promptData: prompt } 
      });
    }
  }

  improvePrompt() {
    if (this.generatedResponse) {
      this.router.navigate(['/prompt-improvement'], { 
        queryParams: { 
          prompt: this.generatedResponse.generatedPrompt 
        } 
      });
    }
  }

  hasSimilarPrompts(): boolean {
    return !!(this.generatedResponse?.similarPrompts && this.generatedResponse.similarPrompts.length > 0);
  }

  getSimilarPrompts(): Prompt[] {
    return this.generatedResponse?.similarPrompts || [];
  }

  viewPrompt(prompt: Prompt) {
    this.router.navigate(['/prompts/view', prompt.id]);
  }

  formatDepartment(department: Department): string {
    return department.replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  }

  isFieldInvalid(field: string): boolean {
    const formField = this.generationForm.get(field);
    return !!(formField && formField.invalid && (formField.dirty || formField.touched));
  }

  private markFormGroupTouched() {
    Object.keys(this.generationForm.controls).forEach(field => {
      const control = this.generationForm.get(field);
      control?.markAsTouched();
    });
  }
}