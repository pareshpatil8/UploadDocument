import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService, ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table'; // Change this import
import { PromptService } from '../../../../services/prompt.service';
import { Prompt, Department, PromptStatus } from '../../../../models/prompt.model';

@Component({
  selector: 'app-prompt-list',
  templateUrl: './prompt-list.component.html',
  styleUrls: ['./prompt-list.component.scss']
})
export class PromptListComponent implements OnInit {
  prompts: Prompt[] = [];
  loading = true;
  totalRecords = 0;
  pageSize = 10;

  searchTerm = '';
  selectedDepartment: Department | null = null;
  selectedStatus: PromptStatus = PromptStatus.ACTIVE;

  departmentOptions = [
    { label: 'Product Management', value: Department.PRODUCT_MANAGEMENT },
    { label: 'Frontend Development', value: Department.FRONTEND_DEVELOPMENT },
    { label: 'Backend Development', value: Department.BACKEND_DEVELOPMENT },
    { label: 'Testing', value: Department.TESTING },
    { label: 'DevOps', value: Department.DEVOPS },
    { label: 'Usability', value: Department.USABILITY },
    { label: 'Business Analysis', value: Department.BUSINESS_ANALYSIS },
    { label: 'Project Management', value: Department.PROJECT_MANAGEMENT }
  ];

  statusOptions = [
    { label: 'Active', value: PromptStatus.ACTIVE },
    { label: 'Draft', value: PromptStatus.DRAFT },
    { label: 'Archived', value: PromptStatus.ARCHIVED }
  ];

  constructor(
      private promptService: PromptService,
      private router: Router,
      private messageService: MessageService,
      private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.searchPrompts();
  }

  // Change the parameter type to TableLazyLoadEvent
  loadPrompts(event: TableLazyLoadEvent) {
    this.loading = true;
    const page = (event.first || 0) / (event.rows || 10);
    const size = event.rows || 10; // Handle null/undefined rows
    const sortBy = event.sortField || 'createdAt';
    const sortDir = event.sortOrder === 1 ? 'asc' : 'desc';

    this.promptService.searchPrompts(
        this.searchTerm || undefined,
        this.selectedDepartment || undefined,
        this.selectedStatus,
        page,
        size
    ).subscribe({
      next: (response) => {
        this.prompts = response.content;
        this.totalRecords = response.totalElements;
        this.loading = false;
      },
      error: (error) => {
        this.loading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load prompts'
        });
      }
    });
  }

  searchPrompts() {
    this.loading = true;
    this.promptService.searchPrompts(
        this.searchTerm || undefined,
        this.selectedDepartment || undefined,
        this.selectedStatus,
        0,
        this.pageSize
    ).subscribe({
      next: (response) => {
        this.prompts = response.content;
        this.totalRecords = response.totalElements;
        this.loading = false;
      },
      error: (error) => {
        this.loading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to search prompts'
        });
      }
    });
  }

  deletePrompt(prompt: Prompt) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete the prompt "${prompt.name}"?`,
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.promptService.deletePrompt(prompt.id!).subscribe({
          next: () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Prompt deleted successfully'
            });
            this.searchPrompts();
          },
          error: () => {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to delete prompt'
            });
          }
        });
      }
    });
  }

  copyPrompt(prompt: Prompt) {
    const promptText = `${prompt.systemPrompt}\n\n${prompt.userPromptTemplate}`;
    navigator.clipboard.writeText(promptText).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Prompt copied to clipboard'
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  formatDepartment(department: Department): string {
    return department.replace(/_/g, ' ')
        .toLowerCase()
        .replace(/\b\w/g, l => l.toUpperCase());
  }

  getStatusSeverity(status: PromptStatus): string {
    switch (status) {
      case PromptStatus.ACTIVE: return 'success';
      case PromptStatus.DRAFT: return 'warning';
      case PromptStatus.ARCHIVED: return 'danger';
      default: return 'info';
    }
  }

  getTagArray(tags: string): string[] {
    return tags ? tags.split(',').map(tag => tag.trim()) : [];
  }

  trackByTag(index: number, tag: string): string {
    return tag;
  }
}