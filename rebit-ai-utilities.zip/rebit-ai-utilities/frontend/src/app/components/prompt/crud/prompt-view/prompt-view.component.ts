import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PromptService } from '../../../../services/prompt.service';
import { Prompt, PromptStatus, Department } from '../../../../models/prompt.model';

@Component({
  selector: 'app-prompt-view',
  templateUrl: './prompt-view.component.html',
  styleUrls: ['./prompt-view.component.scss']
})
export class PromptViewComponent implements OnInit {
  prompt: Prompt | null = null;
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private promptService: PromptService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadPrompt(+id);
    } else {
      this.router.navigate(['/prompts']);
    }
  }

  private loadPrompt(id: number) {
    this.promptService.getPrompt(id).subscribe({
      next: (prompt) => {
        this.prompt = prompt;
        this.loading = false;
      },
      error: (error) => {
        this.loading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load prompt'
        });
      }
    });
  }

  copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: `${label} copied to clipboard`
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  copyCompletePrompt() {
    if (this.prompt) {
      const completePrompt = `${this.prompt.systemPrompt}\n\n${this.prompt.userPromptTemplate}`;
      this.copyToClipboard(completePrompt, 'Complete prompt');
    }
  }

  improvePrompt() {
    if (this.prompt) {
      const completePrompt = `${this.prompt.systemPrompt}\n\n${this.prompt.userPromptTemplate}`;
      this.router.navigate(['/prompt-improvement'], { 
        queryParams: { prompt: completePrompt } 
      });
    }
  }

  findSimilarPrompts() {
    if (this.prompt) {
      const searchTerm = this.prompt.name;
      this.router.navigate(['/prompt-search'], { 
        queryParams: { search: searchTerm, department: this.prompt.department } 
      });
    }
  }

  duplicatePrompt() {
    if (this.prompt) {
      // Navigate to create form with pre-filled data
      const promptData = {
        ...this.prompt,
        name: `${this.prompt.name} (Copy)`,
        id: undefined
      };
      
      this.router.navigate(['/prompts/new'], { 
        state: { promptData } 
      });
    }
  }

  formatDepartment(department: Department): string {
    return department.replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  }

  getStatusSeverity(status: PromptStatus): string {
    switch (status) {
      case PromptStatus.ACTIVE: return 'success';
      case PromptStatus.DRAFT: return 'warning';
      case PromptStatus.ARCHIVED: return 'danger';
      default: return 'info';
    }
  }

  getTagArray(tags: string): string[] {
    return tags ? tags.split(',').map(tag => tag.trim()) : [];
  }
}