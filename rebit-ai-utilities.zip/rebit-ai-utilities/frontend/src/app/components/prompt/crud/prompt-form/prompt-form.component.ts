import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PromptService } from '../../../../services/prompt.service';
import { AuthService } from '../../../../services/auth.service';
import { Prompt, Department, PromptStatus } from '../../../../models/prompt.model';

@Component({
  selector: 'app-prompt-form',
  templateUrl: './prompt-form.component.html',
  styleUrls: ['./prompt-form.component.scss']
})
export class PromptFormComponent implements OnInit {
  promptForm!: FormGroup;
  isEditMode = false;
  promptId: number | null = null;
  saving = false;

  departmentOptions = [
    {label: 'Product Management', value: Department.PRODUCT_MANAGEMENT},
    {label: 'Frontend Development', value: Department.FRONTEND_DEVELOPMENT},
    {label: 'Backend Development', value: Department.BACKEND_DEVELOPMENT},
    {label: 'Testing', value: Department.TESTING},
    {label: 'DevOps', value: Department.DEVOPS},
    {label: 'Usability', value: Department.USABILITY},
    {label: 'Business Analysis', value: Department.BUSINESS_ANALYSIS},
    {label: 'Project Management', value: Department.PROJECT_MANAGEMENT}
  ];

  statusOptions = [
    {label: 'Active', value: PromptStatus.ACTIVE},
    {label: 'Draft', value: PromptStatus.DRAFT},
    {label: 'Archived', value: PromptStatus.ARCHIVED}
  ];

  constructor(
      private fb: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private promptService: PromptService,
      private authService: AuthService,
      private messageService: MessageService
  ) {
  }

  ngOnInit() {
    this.initializeForm();
    this.checkEditMode();
  }

  private initializeForm() {
    this.promptForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(255)]],
      description: ['', [Validators.maxLength(2000)]],
      department: ['', [Validators.required]],
      systemPrompt: ['', [Validators.required]],
      userPromptTemplate: ['', [Validators.required]],
      inputPlaceholders: [''],
      outputFormat: [''],
      constraints: [''],
      tags: ['', [Validators.maxLength(500)]],
      status: [PromptStatus.ACTIVE],
      relatedTools: ['', [Validators.maxLength(500)]]
    });
  }

  private checkEditMode() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.promptId = +id;
      this.loadPrompt(this.promptId);
    }
  }

  private loadPrompt(id: number) {
    this.promptService.getPrompt(id).subscribe({
      next: (prompt) => {
        this.promptForm.patchValue({
          name: prompt.name,
          description: prompt.description,
          department: prompt.department,
          systemPrompt: prompt.systemPrompt,
          userPromptTemplate: prompt.userPromptTemplate,
          inputPlaceholders: prompt.inputPlaceholders,
          outputFormat: prompt.outputFormat,
          constraints: prompt.constraints,
          tags: prompt.tags,
          status: prompt.status,
          relatedTools: prompt.relatedTools
        });
      },
      error: (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load prompt'
        });
        this.router.navigate(['/prompts']);
      }
    });
  }

  onSubmit() {
    if (this.promptForm.valid) {
      this.saving = true;
      const currentUser = this.authService.getCurrentUser();

      if (!currentUser) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'User not authenticated'
        });
        return;
      }

      const promptData: Prompt = {
        ...this.promptForm.value,
        authorId: currentUser.id
      };

      if (this.isEditMode && this.promptId) {
        promptData.id = this.promptId;
        this.promptService.updatePrompt(this.promptId, promptData).subscribe({
          next: () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Prompt updated successfully'
            });
            this.router.navigate(['/prompts']);
          },
          error: () => {
            this.saving = false;
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to update prompt'
            });
          }
        });
      } else {
        this.promptService.createPrompt(promptData).subscribe({
          next: () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Prompt created successfully'
            });
            this.router.navigate(['/prompts']);
          },
          error: () => {
            this.saving = false;
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to create prompt'
            });
          }
        });
      }
    } else {
      this.markFormGroupTouched();
    }
  }

  isFieldInvalid(field: string): boolean {
    const formField = this.promptForm.get(field);
    return !!(formField && formField.invalid && (formField.dirty || formField.touched));
  }

  private markFormGroupTouched() {
    Object.keys(this.promptForm.controls).forEach(field => {
      const control = this.promptForm.get(field);
      control?.markAsTouched();
    });
  }

  showPreview = false;

  saveAsDraft() {
    if (this.promptForm.get('name')?.valid) {
      this.promptForm.patchValue({status: PromptStatus.DRAFT});
      this.onSubmit();
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Please enter a prompt name to save as draft'
      });
    }
  }

  previewPrompt() {
    if (this.promptForm.get('systemPrompt')?.value && this.promptForm.get('userPromptTemplate')?.value) {
      this.showPreview = true;
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Please enter both system prompt and user prompt template to preview'
      });
    }
  }

  getCompletePrompt(): string {
    const systemPrompt = this.promptForm.get('systemPrompt')?.value || '';
    const userPrompt = this.promptForm.get('userPromptTemplate')?.value || '';
    return `${systemPrompt}\n\n${userPrompt}`;
  }

  copyPreviewToClipboard() {
    const completePrompt = this.getCompletePrompt();
    navigator.clipboard.writeText(completePrompt).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Complete prompt copied to clipboard'
      });
      this.showPreview = false;
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }
}