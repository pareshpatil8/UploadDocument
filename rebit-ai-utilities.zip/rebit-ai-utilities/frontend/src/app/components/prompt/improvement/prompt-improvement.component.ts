import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PromptService } from '../../../services/prompt.service';
import { AuthService } from '../../../services/auth.service';
import { PromptImprovementRequest, PromptImprovementResponse, Prompt, Department } from '../../../models/prompt.model';

@Component({
  selector: 'app-prompt-improvement',
  templateUrl: './prompt-improvement.component.html',
  styleUrls: ['./prompt-improvement.component.scss']
})
export class PromptImprovementComponent implements OnInit {
  improvementForm!: FormGroup;
  improving = false;
  improvementResponse: PromptImprovementResponse | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private promptService: PromptService,
    private authService: AuthService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.initializeForm();
    this.checkQueryParams();
  }

  private initializeForm() {
    this.improvementForm = this.fb.group({
      originalPrompt: ['', [Validators.required]],
      context: [''],
      desiredImprovements: ['']
    });
  }

  private checkQueryParams() {
    this.route.queryParams.subscribe(params => {
      if (params['prompt']) {
        this.improvementForm.patchValue({
          originalPrompt: params['prompt']
        });
      }
    });
  }

  improvePrompt() {
    if (this.improvementForm.valid) {
      this.improving = true;
      const request: PromptImprovementRequest = this.improvementForm.value;

      this.promptService.improvePrompt(request).subscribe({
        next: (response) => {
          this.improvementResponse = response;
          this.improving = false;
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Prompt improved successfully'
          });
        },
        error: (error) => {
          this.improving = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to improve prompt'
          });
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  quickAnalyze(type: string) {
    const currentPrompt = this.improvementForm.get('originalPrompt')?.value;
    if (!currentPrompt) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Please enter a prompt first'
      });
      return;
    }

    let context = '';
    switch (type) {
      case 'structure':
        context = 'Focus on improving the structure and organization of the prompt';
        break;
      case 'clarity':
        context = 'Focus on making the prompt clearer and more specific';
        break;
      case 'examples':
        context = 'Focus on adding relevant examples and use cases';
        break;
    }

    this.improvementForm.patchValue({
      context: context,
      desiredImprovements: `Quick analysis focusing on ${type}`
    });

    this.improvePrompt();
  }

  hasMatchingPrompts(): boolean {
    return !!(this.improvementResponse?.matchingPrompts && this.improvementResponse.matchingPrompts.length > 0);
  }

  getMatchingPrompts(): Prompt[] {
    return this.improvementResponse?.matchingPrompts || [];
  }

  clearForm() {
    this.improvementForm.reset();
    this.improvementResponse = null;
  }

  improveFurther() {
    if (this.improvementResponse) {
      this.improvementForm.patchValue({
        originalPrompt: this.improvementResponse.improvedPrompt,
        context: 'Further refinement of the improved prompt',
        desiredImprovements: ''
      });
      this.improvementResponse = null;
    }
  }

  copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: `${label} copied to clipboard`
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  saveAsPrompt() {
    if (this.improvementResponse) {
      const currentUser = this.authService.getCurrentUser();
      if (!currentUser) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'User not authenticated'
        });
        return;
      }

      const prompt: Prompt = {
        name: 'Improved Prompt - ' + new Date().toLocaleDateString(),
        description: 'Prompt created from improvement service',
        department: currentUser.department,
        systemPrompt: 'You are a helpful assistant.',
        userPromptTemplate: this.improvementResponse.improvedPrompt,
        authorId: currentUser.id,
        status: 'DRAFT' as any
      };

      this.router.navigate(['/prompts/new'], { 
        state: { promptData: prompt } 
      });
    }
  }

  viewPrompt(prompt: Prompt) {
    this.router.navigate(['/prompts/view', prompt.id]);
  }

  formatDepartment(department: Department): string {
    return department.replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  }

  isFieldInvalid(field: string): boolean {
    const formField = this.improvementForm.get(field);
    return !!(formField && formField.invalid && (formField.dirty || formField.touched));
  }

  private markFormGroupTouched() {
    Object.keys(this.improvementForm.controls).forEach(field => {
      const control = this.improvementForm.get(field);
      control?.markAsTouched();
    });
  }
}