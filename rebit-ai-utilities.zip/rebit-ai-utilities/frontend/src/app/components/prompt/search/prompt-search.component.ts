import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PromptService } from '../../../services/prompt.service';
import { Prompt, Department, PromptStatus } from '../../../models/prompt.model';

@Component({
  selector: 'app-prompt-search',
  templateUrl: './prompt-search.component.html',
  styleUrls: ['./prompt-search.component.scss']
})
export class PromptSearchComponent implements OnInit {
  prompts: Prompt[] = [];
  loading = false;
  hasSearched = false;
  totalRecords = 0;
  pageSize = 10;
  currentPage = 0;

  searchTerm = '';
  selectedDepartment: Department | null = null;
  selectedStatus: PromptStatus = PromptStatus.ACTIVE;
  tagFilter = '';

  departmentOptions = [
    { label: 'Product Management', value: Department.PRODUCT_MANAGEMENT },
    { label: 'Frontend Development', value: Department.FRONTEND_DEVELOPMENT },
    { label: 'Backend Development', value: Department.BACKEND_DEVELOPMENT },
    { label: 'Testing', value: Department.TESTING },
    { label: 'DevOps', value: Department.DEVOPS },
    { label: 'Usability', value: Department.USABILITY },
    { label: 'Business Analysis', value: Department.BUSINESS_ANALYSIS },
    { label: 'Project Management', value: Department.PROJECT_MANAGEMENT }
  ];

  statusOptions = [
    { label: 'Active', value: PromptStatus.ACTIVE },
    { label: 'Draft', value: PromptStatus.DRAFT },
    { label: 'Archived', value: PromptStatus.ARCHIVED }
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private promptService: PromptService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    // Check for query parameters from navigation
    this.route.queryParams.subscribe(params => {
      if (params['search']) {
        this.searchTerm = params['search'];
      }
      if (params['department']) {
        this.selectedDepartment = params['department'];
      }
      if (this.searchTerm || this.selectedDepartment) {
        this.performSearch();
      }
    });
  }

  performSearch() {
    this.loading = true;
    this.hasSearched = true;
    this.currentPage = 0;

    const searchTermToUse = this.buildSearchTerm();

    this.promptService.searchPrompts(
      searchTermToUse,
      this.selectedDepartment || undefined,
      this.selectedStatus,
      this.currentPage,
      this.pageSize
    ).subscribe({
      next: (response) => {
        this.prompts = response.content;
        this.totalRecords = response.totalElements;
        this.loading = false;
      },
      error: (error) => {
        this.loading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to search prompts'
        });
      }
    });
  }

  onPageChange(event: any) {
    this.currentPage = event.page;
    this.performSearch();
  }

  private buildSearchTerm(): string | undefined {
    const terms: string[] = [];
    
    if (this.searchTerm.trim()) {
      terms.push(this.searchTerm.trim());
    }
    
    if (this.tagFilter.trim()) {
      terms.push(this.tagFilter.trim());
    }
    
    return terms.length > 0 ? terms.join(' ') : undefined;
  }

  viewPrompt(prompt: Prompt) {
    this.router.navigate(['/prompts/view', prompt.id]);
  }

  copyPrompt(prompt: Prompt) {
    const promptText = `${prompt.systemPrompt}\n\n${prompt.userPromptTemplate}`;
    navigator.clipboard.writeText(promptText).then(() => {
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Prompt copied to clipboard'
      });
    }).catch(() => {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Failed to copy to clipboard'
      });
    });
  }

  usePrompt(prompt: Prompt) {
    // Navigate to prompt improvement with this prompt pre-filled
    const promptText = `${prompt.systemPrompt}\n\n${prompt.userPromptTemplate}`;
    this.router.navigate(['/prompt-improvement'], {
      queryParams: { prompt: promptText }
    });
  }

  formatDepartment(department: Department): string {
    return department.replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  }

  getStatusSeverity(status: PromptStatus): string {
    switch (status) {
      case PromptStatus.ACTIVE: return 'success';
      case PromptStatus.DRAFT: return 'warning';
      case PromptStatus.ARCHIVED: return 'danger';
      default: return 'info';
    }
  }

  getTagArray(tags: string): string[] {
    return tags ? tags.split(',').map(tag => tag.trim()) : [];
  }
}