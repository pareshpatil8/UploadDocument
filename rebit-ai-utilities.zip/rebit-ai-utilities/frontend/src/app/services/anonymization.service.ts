import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AnonymizationRequest, AnonymizationResponse } from '../models/common.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AnonymizationService {
  private apiUrl = `${environment.apiUrl}/anonymization`;

  constructor(private http: HttpClient) {}

  anonymizeText(request: AnonymizationRequest): Observable<AnonymizationResponse> {
    return this.http.post<AnonymizationResponse>(`${this.apiUrl}/anonymize`, request);
  }
}