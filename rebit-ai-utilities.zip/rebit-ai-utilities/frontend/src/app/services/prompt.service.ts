import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Prompt, PromptGenerationRequest, PromptGenerationResponse, PromptImprovementRequest, PromptImprovementResponse, Department, PromptStatus } from '../models/prompt.model';
import { PagedResponse } from '../models/common.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PromptService {
  private apiUrl = `${environment.apiUrl}/prompts`;

  constructor(private http: HttpClient) {}

  createPrompt(prompt: Prompt): Observable<Prompt> {
    return this.http.post<Prompt>(this.apiUrl, prompt);
  }

  updatePrompt(id: number, prompt: Prompt): Observable<Prompt> {
    return this.http.put<Prompt>(`${this.apiUrl}/${id}`, prompt);
  }

  deletePrompt(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getPrompt(id: number): Observable<Prompt> {
    return this.http.get<Prompt>(`${this.apiUrl}/${id}`);
  }

  getAllPrompts(page: number = 0, size: number = 10, sortBy: string = 'createdAt', sortDir: string = 'desc'): Observable<PagedResponse<Prompt>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sortBy', sortBy)
      .set('sortDir', sortDir);

    return this.http.get<PagedResponse<Prompt>>(this.apiUrl, { params });
  }

  searchPrompts(searchTerm?: string, department?: Department, status: PromptStatus = PromptStatus.ACTIVE, page: number = 0, size: number = 10): Observable<PagedResponse<Prompt>> {
    let params = new HttpParams()
      .set('status', status)
      .set('page', page.toString())
      .set('size', size.toString());

    if (searchTerm) {
      params = params.set('search', searchTerm);
    }

    if (department) {
      params = params.set('department', department);
    }

    return this.http.get<PagedResponse<Prompt>>(`${this.apiUrl}/search`, { params });
  }

  findSimilarPrompts(prompt: string): Observable<Prompt[]> {
    const params = new HttpParams().set('prompt', prompt);
    return this.http.get<Prompt[]>(`${this.apiUrl}/similar`, { params });
  }

  generatePrompt(request: PromptGenerationRequest): Observable<PromptGenerationResponse> {
    return this.http.post<PromptGenerationResponse>(`${environment.apiUrl}/prompt-generation/generate`, request);
  }

  improvePrompt(request: PromptImprovementRequest): Observable<PromptImprovementResponse> {
    return this.http.post<PromptImprovementResponse>(`${environment.apiUrl}/prompt-improvement/improve`, request);
  }
}