export interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  department: Department;
  role: UserRole;
  active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export enum Department {
  PRODUCT_MANAGEMENT = 'PRODUCT_MANAGEMENT',
  FRONTEND_DEVELOPMENT = 'FRONTEND_DEVELOPMENT',
  BACKEND_DEVELOPMENT = 'BACKEND_DEVELOPMENT',
  TESTING = 'TESTING',
  DEVOPS = 'DEVOPS',
  USABILITY = 'USABILITY',
  BUSINESS_ANALYSIS = 'BUSINESS_ANALYSIS',
  PROJECT_MANAGEMENT = 'PROJECT_MANAGEMENT'
}

export enum UserRole {
  USER = 'USER',
  ADMIN = 'ADMIN'
}