export interface PagedResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface AuthRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  type: string;
  user: any;
}

export interface DashboardStats {
  totalPrompts: number;
  activePrompts: number;
  totalUsers: number;
  promptsByDepartment: { [key: string]: number };
  promptsByStatus: { [key: string]: number };
  recentActivity: { [key: string]: number };
}

export interface AnonymizationRequest {
  text: string;
  contentType?: string;
  preserveStructure?: boolean;
}

export interface AnonymizationResponse {
  anonymizedText: string;
  replacements: { [key: string]: string };
  summary: string;
}