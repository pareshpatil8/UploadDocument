import { Department } from './user.model';

export interface Prompt {
  id?: number;
  name: string;
  description?: string;
  department: Department;
  systemPrompt: string;
  userPromptTemplate: string;
  inputPlaceholders?: string;
  outputFormat?: string;
  constraints?: string;
  tags?: string;
  authorId: number;
  authorName?: string;
  status: PromptStatus;
  relatedTools?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export enum PromptStatus {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
  DRAFT = 'DRAFT'
}

export interface PromptGenerationRequest {
  purpose: string;
  department: Department;
  context?: string;
  expectedOutput?: string;
  constraints?: string;
  inputValues?: { [key: string]: string };
}

export interface PromptGenerationResponse {
  generatedPrompt: string;
  systemPrompt: string;
  userPromptTemplate: string;
  suggestedImprovements: string;
  similarPrompts: Prompt[];
}

export interface PromptImprovementRequest {
  originalPrompt: string;
  context?: string;
  desiredImprovements?: string;
}

export interface PromptImprovementResponse {
  improvedPrompt: string;
  improvements: string;
  suggestions: string[];
  matchingPrompts: Prompt[];
}

export { Department };
