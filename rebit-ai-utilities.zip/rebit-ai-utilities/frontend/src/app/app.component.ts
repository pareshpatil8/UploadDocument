import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { MenuItem } from 'primeng/api';
import { AuthService } from './services/auth.service';
import { User } from './models/user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'ReBIT AI Utilities';
  isAuthenticated = false;
  currentUser: User | null = null;
  menuItems: MenuItem[] = [];

  private destroy$ = new Subject<void>();

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.isAuthenticated$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isAuth => {
        this.isAuthenticated = isAuth;
        if (isAuth) {
          this.initializeMenu();
        }
      });

    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe(user => {
        this.currentUser = user;
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeMenu() {
    this.menuItems = [
      {
        label: 'Dashboard',
        icon: 'pi pi-home',
        routerLink: '/dashboard'
      },
      {
        label: 'Prompt Management',
        icon: 'pi pi-file-edit',
        items: [
          {
            label: 'View All Prompts',
            icon: 'pi pi-list',
            routerLink: '/prompts'
          },
          {
            label: 'Create New Prompt',
            icon: 'pi pi-plus',
            routerLink: '/prompts/new'
          },
          {
            label: 'Search Prompts',
            icon: 'pi pi-search',
            routerLink: '/prompt-search'
          }
        ]
      },
      {
        label: 'AI Tools',
        icon: 'pi pi-bolt',
        items: [
          {
            label: 'Generate Prompt',
            icon: 'pi pi-sparkles',
            routerLink: '/prompt-generation'
          },
          {
            label: 'Improve Prompt',
            icon: 'pi pi-wrench',
            routerLink: '/prompt-improvement'
          },
          {
            label: 'Anonymize Text',
            icon: 'pi pi-eye-slash',
            routerLink: '/anonymization'
          }
        ]
      }
    ];
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}