import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

import { LoginComponent } from './components/auth/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PromptListComponent } from './components/prompt/crud/prompt-list/prompt-list.component';
import { PromptFormComponent } from './components/prompt/crud/prompt-form/prompt-form.component';
import { PromptViewComponent } from './components/prompt/crud/prompt-view/prompt-view.component';
import { PromptGenerationComponent } from './components/prompt/generation/prompt-generation.component';
import { PromptSearchComponent } from './components/prompt/search/prompt-search.component';
import { PromptImprovementComponent } from './components/prompt/improvement/prompt-improvement.component';
import { AnonymizationComponent } from './components/anonymization/anonymization.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { 
    path: '', 
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'prompts', component: PromptListComponent },
      { path: 'prompts/new', component: PromptFormComponent },
      { path: 'prompts/edit/:id', component: PromptFormComponent },
      { path: 'prompts/view/:id', component: PromptViewComponent },
      { path: 'prompt-generation', component: PromptGenerationComponent },
      { path: 'prompt-search', component: PromptSearchComponent },
      { path: 'prompt-improvement', component: PromptImprovementComponent },
      { path: 'anonymization', component: AnonymizationComponent }
    ]
  },
  { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }