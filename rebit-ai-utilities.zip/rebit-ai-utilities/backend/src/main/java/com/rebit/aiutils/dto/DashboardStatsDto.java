package com.rebit.aiutils.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDto {
    private Long totalPrompts;
    private Long activePrompts;
    private Long totalUsers;
    private Map<String, Long> promptsByDepartment;
    private Map<String, Long> promptsByStatus;
    private Map<String, Long> recentActivity;
}