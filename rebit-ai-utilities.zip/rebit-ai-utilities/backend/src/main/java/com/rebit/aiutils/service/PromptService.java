package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.PagedResponse;
import com.rebit.aiutils.dto.PromptDto;
import com.rebit.aiutils.entity.Prompt;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface PromptService {
    PromptDto createPrompt(PromptDto promptDto);
    PromptDto updatePrompt(Long id, PromptDto promptDto);
    void deletePrompt(Long id);
    Optional<PromptDto> getPromptById(Long id);
    PagedResponse<PromptDto> getAllPrompts(Pageable pageable);
    PagedResponse<PromptDto> getPromptsByStatus(PromptStatus status, Pageable pageable);
    PagedResponse<PromptDto> getPromptsByDepartment(Department department, Pageable pageable);
    PagedResponse<PromptDto> searchPrompts(String searchTerm, Department department, PromptStatus status, Pageable pageable);
    List<PromptDto> findSimilarPrompts(String prompt);
    PromptDto convertToDto(Prompt prompt);
    Prompt convertToEntity(PromptDto promptDto);
}