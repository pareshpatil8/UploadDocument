package com.rebit.aiutils.enums;

public enum PromptStatus {
    ACTIVE,
    ARCHIVED,
    DRAFT
}