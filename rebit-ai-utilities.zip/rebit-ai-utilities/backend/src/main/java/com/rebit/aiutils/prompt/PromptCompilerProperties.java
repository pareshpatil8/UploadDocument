package com.rebit.aiutils.prompt;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "app.prompt")
public class PromptCompilerProperties {
    private boolean enabled = true;
    private String defaultOutput = "json"; // json | markdown | plain
    private int maxChars = 4000;
    private boolean guardrailsNoExternalData = true;
    private boolean guardrailsAskForMissingInputs = true;
    private String style = "Concise, neutral, RBI/India context when relevant.";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getDefaultOutput() { return defaultOutput; }
    public void setDefaultOutput(String defaultOutput) { this.defaultOutput = defaultOutput; }
    public int getMaxChars() { return maxChars; }
    public void setMaxChars(int maxChars) { this.maxChars = maxChars; }
    public boolean isGuardrailsNoExternalData() { return guardrailsNoExternalData; }
    public void setGuardrailsNoExternalData(boolean v) { this.guardrailsNoExternalData = v; }
    public boolean isGuardrailsAskForMissingInputs() { return guardrailsAskForMissingInputs; }
    public void setGuardrailsAskForMissingInputs(boolean v) { this.guardrailsAskForMissingInputs = v; }
    public String getStyle() { return style; }
    public void setStyle(String style) { this.style = style; }
}
