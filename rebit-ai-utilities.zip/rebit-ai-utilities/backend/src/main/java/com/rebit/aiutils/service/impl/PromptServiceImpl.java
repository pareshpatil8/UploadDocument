package com.rebit.aiutils.service.impl;

import com.rebit.aiutils.dto.PagedResponse;
import com.rebit.aiutils.dto.PromptDto;
import com.rebit.aiutils.entity.Prompt;
import com.rebit.aiutils.entity.User;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import com.rebit.aiutils.exception.ResourceNotFoundException;
import com.rebit.aiutils.repository.PromptRepository;
import com.rebit.aiutils.repository.UserRepository;
import com.rebit.aiutils.service.PromptService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class PromptServiceImpl implements PromptService {
    
    private final PromptRepository promptRepository;
    private final UserRepository userRepository;
    
    @Override
    public PromptDto createPrompt(PromptDto promptDto) {
        log.info("Creating prompt: {}", promptDto.getName());
        Prompt prompt = convertToEntity(promptDto);
        Prompt savedPrompt = promptRepository.save(prompt);
        return convertToDto(savedPrompt);
    }
    
    @Override
    public PromptDto updatePrompt(Long id, PromptDto promptDto) {
        log.info("Updating prompt with id: {}", id);
        Prompt existingPrompt = promptRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prompt not found with id: " + id));
        
        existingPrompt.setName(promptDto.getName());
        existingPrompt.setDescription(promptDto.getDescription());
        existingPrompt.setDepartment(promptDto.getDepartment());
        existingPrompt.setSystemPrompt(promptDto.getSystemPrompt());
        existingPrompt.setUserPromptTemplate(promptDto.getUserPromptTemplate());
        existingPrompt.setInputPlaceholders(promptDto.getInputPlaceholders());
        existingPrompt.setOutputFormat(promptDto.getOutputFormat());
        existingPrompt.setConstraints(promptDto.getConstraints());
        existingPrompt.setTags(promptDto.getTags());
        existingPrompt.setStatus(promptDto.getStatus());
        existingPrompt.setRelatedTools(promptDto.getRelatedTools());
        
        Prompt savedPrompt = promptRepository.save(existingPrompt);
        return convertToDto(savedPrompt);
    }
    
    @Override
    public void deletePrompt(Long id) {
        log.info("Deleting prompt with id: {}", id);
        Prompt prompt = promptRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prompt not found with id: " + id));
        prompt.setStatus(PromptStatus.ARCHIVED);
        promptRepository.save(prompt);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<PromptDto> getPromptById(Long id) {
        return promptRepository.findById(id).map(this::convertToDto);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PagedResponse<PromptDto> getAllPrompts(Pageable pageable) {
        Page<Prompt> promptPage = promptRepository.findAll(pageable);
        return createPagedResponse(promptPage);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PagedResponse<PromptDto> getPromptsByStatus(PromptStatus status, Pageable pageable) {
        Page<Prompt> promptPage = promptRepository.findByStatus(status, pageable);
        return createPagedResponse(promptPage);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PagedResponse<PromptDto> getPromptsByDepartment(Department department, Pageable pageable) {
        Page<Prompt> promptPage = promptRepository.findByDepartment(department, pageable);
        return createPagedResponse(promptPage);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PagedResponse<PromptDto> searchPrompts(String searchTerm, Department department, PromptStatus status, Pageable pageable) {
        Page<Prompt> promptPage;
        
        if (department != null && searchTerm != null && !searchTerm.trim().isEmpty()) {
            promptPage = promptRepository.findByStatusAndDepartmentAndSearchTerm(status, department, searchTerm, pageable);
        } else if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            promptPage = promptRepository.findByStatusAndSearchTerm(status, searchTerm, pageable);
        } else {
            promptPage = promptRepository.findByStatus(status, pageable);
        }
        
        return createPagedResponse(promptPage);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PromptDto> findSimilarPrompts(String prompt) {
        return promptRepository.findSimilarPrompts(prompt)
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    private PagedResponse<PromptDto> createPagedResponse(Page<Prompt> promptPage) {
        List<PromptDto> content = promptPage.getContent()
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return PagedResponse.<PromptDto>builder()
                .content(content)
                .page(promptPage.getNumber())
                .size(promptPage.getSize())
                .totalElements(promptPage.getTotalElements())
                .totalPages(promptPage.getTotalPages())
                .first(promptPage.isFirst())
                .last(promptPage.isLast())
                .build();
    }
    
    @Override
    public PromptDto convertToDto(Prompt prompt) {
        return PromptDto.builder()
                .id(prompt.getId())
                .name(prompt.getName())
                .description(prompt.getDescription())
                .department(prompt.getDepartment())
                .systemPrompt(prompt.getSystemPrompt())
                .userPromptTemplate(prompt.getUserPromptTemplate())
                .inputPlaceholders(prompt.getInputPlaceholders())
                .outputFormat(prompt.getOutputFormat())
                .constraints(prompt.getConstraints())
                .tags(prompt.getTags())
                .authorId(prompt.getAuthor().getId())
                .authorName(prompt.getAuthor().getFirstName() + " " + prompt.getAuthor().getLastName())
                .status(prompt.getStatus())
                .relatedTools(prompt.getRelatedTools())
                .createdAt(prompt.getCreatedAt())
                .updatedAt(prompt.getUpdatedAt())
                .build();
    }
    
    @Override
    public Prompt convertToEntity(PromptDto promptDto) {
        User author = userRepository.findById(promptDto.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Author not found with id: " + promptDto.getAuthorId()));
        
        return Prompt.builder()
                .id(promptDto.getId())
                .name(promptDto.getName())
                .description(promptDto.getDescription())
                .department(promptDto.getDepartment())
                .systemPrompt(promptDto.getSystemPrompt())
                .userPromptTemplate(promptDto.getUserPromptTemplate())
                .inputPlaceholders(promptDto.getInputPlaceholders())
                .outputFormat(promptDto.getOutputFormat())
                .constraints(promptDto.getConstraints())
                .tags(promptDto.getTags())
                .author(author)
                .status(promptDto.getStatus() != null ? promptDto.getStatus() : PromptStatus.ACTIVE)
                .relatedTools(promptDto.getRelatedTools())
                .build();
    }
}