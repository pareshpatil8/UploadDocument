package com.rebit.aiutils.service.impl;

import com.rebit.aiutils.dto.PromptDto;
import com.rebit.aiutils.dto.PromptGenerationRequest;
import com.rebit.aiutils.dto.PromptGenerationResponse;
import com.rebit.aiutils.service.PromptGenerationService;
import com.rebit.aiutils.service.PromptService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PromptGenerationServiceImpl implements PromptGenerationService {
    
    private final PromptService promptService;
    
    @Override
    public PromptGenerationResponse generatePrompt(PromptGenerationRequest request) {
        log.info("Generating prompt for purpose: {}", request.getPurpose());
        
        // Generate system prompt based on department
        String systemPrompt = generateSystemPrompt(request);
        
        // Generate user prompt template
        String userPromptTemplate = generateUserPromptTemplate(request);
        
        // Create combined prompt
        String generatedPrompt = systemPrompt + "\n\n" + userPromptTemplate;
        
        // Generate suggestions
        String suggestions = generateSuggestions(request);
        
        // Find similar prompts
        List<PromptDto> similarPrompts = promptService.findSimilarPrompts(generatedPrompt);
        
        return PromptGenerationResponse.builder()
                .generatedPrompt(generatedPrompt)
                .systemPrompt(systemPrompt)
                .userPromptTemplate(userPromptTemplate)
                .suggestedImprovements(suggestions)
                .similarPrompts(similarPrompts)
                .build();
    }
    
    private String generateSystemPrompt(PromptGenerationRequest request) {
        return switch (request.getDepartment()) {
            case PRODUCT_MANAGEMENT -> "You are a product management expert specialized in creating business requirements, user stories, and product roadmaps. Focus on user needs, business value, and clear documentation.";
            case FRONTEND_DEVELOPMENT -> "You are a frontend development specialist with expertise in modern web technologies including Angular, React, HTML5, CSS3, and TypeScript. Focus on responsive design, user experience, and best practices.";
            case BACKEND_DEVELOPMENT -> "You are a backend development expert proficient in Java, Spring Boot, microservices architecture, database design, and API development. Focus on scalability, security, and clean code principles.";
            case TESTING -> "You are a quality assurance specialist with expertise in test automation, manual testing, test case design, and various testing frameworks including Selenium and JUnit. Focus on comprehensive test coverage and bug prevention.";
            case DEVOPS -> "You are a DevOps engineer experienced with CI/CD pipelines, containerization, cloud platforms, and infrastructure automation. Focus on deployment efficiency, monitoring, and system reliability.";
            case USABILITY -> "You are a UX/UI design expert with experience in user research, wireframing, prototyping, and design systems. Focus on user-centered design principles and accessibility.";
            case BUSINESS_ANALYSIS -> "You are a business analyst with expertise in requirements gathering, process modeling, stakeholder management, and solution design. Focus on bridging business needs with technical solutions.";
            case PROJECT_MANAGEMENT -> "You are a project management professional experienced with Agile methodologies, project planning, risk management, and team coordination. Focus on successful project delivery and stakeholder communication.";
        };
    }
    
    private String generateUserPromptTemplate(PromptGenerationRequest request) {
        StringBuilder template = new StringBuilder();
        template.append("Task: ").append(request.getPurpose()).append("\n\n");
        
        if (request.getContext() != null && !request.getContext().trim().isEmpty()) {
            template.append("Context: ").append(request.getContext()).append("\n\n");
        }
        
        template.append("Please provide a detailed response that includes:\n");
        
        if (request.getExpectedOutput() != null && !request.getExpectedOutput().trim().isEmpty()) {
            template.append("- ").append(request.getExpectedOutput()).append("\n");
        } else {
            template.append("- Clear explanation or solution\n");
            template.append("- Step-by-step approach when applicable\n");
            template.append("- Best practices and recommendations\n");
        }
        
        if (request.getConstraints() != null && !request.getConstraints().trim().isEmpty()) {
            template.append("\nConstraints:\n").append(request.getConstraints());
        }
        
        return template.toString();
    }
    
    private String generateSuggestions(PromptGenerationRequest request) {
        return "Consider adding:\n" +
               "1. Specific examples or use cases\n" +
               "2. Expected output format (JSON, Markdown, etc.)\n" +
               "3. Error handling requirements\n" +
               "4. Performance or security considerations\n" +
               "5. Integration requirements with existing systems";
    }
}