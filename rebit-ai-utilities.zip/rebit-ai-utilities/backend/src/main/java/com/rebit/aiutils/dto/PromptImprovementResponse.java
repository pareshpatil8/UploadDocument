package com.rebit.aiutils.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromptImprovementResponse {
    private String improvedPrompt;
    private String improvements;
    private List<String> suggestions;
    private List<PromptDto> matchingPrompts;
}