package com.rebit.aiutils.prompt;

import java.util.List;

public final class QualityScorer {
    private QualityScorer(){}

    public static QualityScore score(String task, String context, String outputFormat, List<String> lint) {
        int clarity = pct(len(task) + len(context), 80, 200, 800);
        int specificity = clamp( (has(outputFormat) ? 30 : 0) + (hasNumbers(task) ? 20 : 0) + (hasBullets(task) ? 20 : 0) + (hasExamples(task) ? 30 : 0), 0, 100);
        int structure = clamp( (has(outputFormat) ? 50 : 0) + (hasSections(task) ? 30 : 0) + (hasList(task) ? 20 : 0), 0, 100);
        int safety = 80; // baseline; you can wire your own policy
        safety -= Math.min(40, lint.size()*10);

        return QualityScore.of(clarity, specificity, structure, safety);
    }

    private static int len(String s){ return s==null?0:s.length(); }
    private static boolean has(String s){ return s!=null && !s.isBlank(); }
    private static boolean hasNumbers(String s){ return s!=null && s.matches(".*\\d+.*"); }
    private static boolean hasBullets(String s){ return s!=null && s.matches("(?s).*(^|\\n)[\\-\\*\\d+\\.)].*"); }
    private static boolean hasExamples(String s){ return s!=null && s.toLowerCase().contains("example"); }
    private static boolean hasSections(String s){ return s!=null && s.matches("(?s).*(Task:|Context:|Requirements:|Output).*"); }
    private static boolean hasList(String s){ return s!=null && s.matches("(?s).*(\\n- |\\n\\* ).*"); }

    private static int pct(int value, int minGood, int mid, int max) {
        if (value <= minGood) return 40;
        if (value >= max) return 90;
        if (value >= mid) return 80;
        return 60;
    }
    private static int clamp(int v,int lo,int hi){ return Math.max(lo, Math.min(hi, v)); }
}
