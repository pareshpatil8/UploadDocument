package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.PromptImprovementRequest;
import com.rebit.aiutils.dto.PromptImprovementResponse;

public interface PromptImprovementService {
    PromptImprovementResponse improvePrompt(PromptImprovementRequest request);
}