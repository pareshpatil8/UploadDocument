package com.rebit.aiutils.anonymize;

import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import java.io.InputStream;
import java.util.*;

/**
 * Offline OpenNLP NER wrapper.
 * Looks for PERSON / ORG / LOCATION and returns SpanHits with char offsets.
 *
 * Place models under:
 *  /models/opennlp/en-token.bin
 *  /models/opennlp/en-ner-person.bin
 *  /models/opennlp/en-ner-organization.bin
 *  /models/opennlp/en-ner-location.bin
 */
public class NerDetector implements AutoCloseable {

    private final TokenizerME tokenizer;
    private final NameFinderME person;
    private final NameFinderME organization;
    private final NameFinderME location;

    public NerDetector() {
        try {
            tokenizer = new TokenizerME(new TokenizerModel(req("/models/opennlp/en-token.bin")));
            person = new NameFinderME(new TokenNameFinderModel(req("/models/opennlp/en-ner-person.bin")));
            organization = new NameFinderME(new TokenNameFinderModel(req("/models/opennlp/en-ner-organization.bin")));
            location = new NameFinderME(new TokenNameFinderModel(req("/models/opennlp/en-ner-location.bin")));
        } catch (Exception e) {
            throw new RuntimeException("Failed to load OpenNLP models from classpath", e);
        }
    }

    public List<SpanMerger.SpanHit> detect(String text) {
        if (text == null || text.isBlank()) return List.of();
        String[] toks = tokenizer.tokenize(text);
        int[][] tokCharRanges = toCharRanges(text, toks);

        List<SpanMerger.SpanHit> out = new ArrayList<>();
        out.addAll(find("PERSON", person, toks, tokCharRanges, text));
        out.addAll(find("ORG", organization, toks, tokCharRanges, text));
        out.addAll(find("LOCATION", location, toks, tokCharRanges, text));
        return out;
    }

    private static List<SpanMerger.SpanHit> find(String type, NameFinderME finder, String[] toks, int[][] ranges, String text) {
        var spans = finder.find(toks);
        List<SpanMerger.SpanHit> out = new ArrayList<>();
        for (var sp : spans) {
            int startTok = sp.getStart();
            int endTok = sp.getEnd() - 1;
            int start = ranges[startTok][0];
            int end = ranges[endTok][1];
            String original = text.substring(start, end);
            out.add(new SpanMerger.SpanHit(start, end, type, original,
                    AnonymizationPolicyLoader.Action.PSEUDONYMIZE, // default action for NER hits; policy may override later
                    "NER_${hash8}", null, null));
        }
        finder.clearAdaptiveData(); // recommended
        return out;
    }

    private static int[][] toCharRanges(String text, String[] toks) {
        int[][] ranges = new int[toks.length][2];
        int from = 0;
        for (int i = 0; i < toks.length; i++) {
            String t = toks[i];
            int s = indexOf(text, t, from);
            int e = s + t.length();
            ranges[i][0] = s;
            ranges[i][1] = e;
            from = e;
        }
        return ranges;
    }

    private static int indexOf(String text, String token, int from) {
        int idx = text.indexOf(token, from);
        if (idx < 0) {
            // fallback (handles collapsing whitespace/tokenizer quirks)
            return from;
        }
        return idx;
    }

    private static InputStream req(String path) {
        // Resource paths are resolved from the root of the classpath.
        // We'll remove a leading slash if it exists, as it's not needed by the classloader.
        String resourcePath = path.startsWith("/") ? path.substring(1) : path;

        // Use the class's own classloader. It's generally more reliable than the
        // thread context classloader, especially in complex environments like Spring Boot.
        InputStream in = NerDetector.class.getClassLoader().getResourceAsStream(resourcePath);

        if (in == null) {
            // If the resource is not found, throw an exception with a very clear error message.
            // This helps diagnose if the path is wrong or if the file is truly missing from the final artifact.
            throw new IllegalStateException("Failed to load resource from classpath: '" + resourcePath +
                    "'. Please ensure this file exists in 'src/main/resources/" + resourcePath +
                    "' and that your build process includes it in the final JAR.");
        }
        return in;
    }

    @Override public void close() { /* nothing to close; models are memory-resident */ }
}
