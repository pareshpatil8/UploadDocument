package com.rebit.aiutils.dto;

import com.rebit.aiutils.enums.Department;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Map;

@Data
public class PromptGenerationRequest {
    @NotBlank(message = "Purpose is required")
    private String purpose;
    
    @NotNull(message = "Department is required")
    private Department department;
    
    private String context;
    private String expectedOutput;
    private String constraints;
    private Map<String, String> inputValues;
}