package com.rebit.aiutils.repository;

import com.rebit.aiutils.entity.Prompt;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromptRepository extends JpaRepository<Prompt, Long> {
    Page<Prompt> findByStatus(PromptStatus status, Pageable pageable);
    Page<Prompt> findByDepartment(Department department, Pageable pageable);
    Page<Prompt> findByAuthorId(Long authorId, Pageable pageable);

    @Query("SELECT p FROM Prompt p WHERE p.status = :status AND " +
            "(LOWER(p.name) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(p.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(p.tags) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Prompt> findByStatusAndSearchTerm(@Param("status") PromptStatus status,
                                           @Param("search") String search,
                                           Pageable pageable);

    @Query("SELECT p FROM Prompt p WHERE p.status = :status AND p.department = :department AND " +
            "(LOWER(p.name) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(p.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(p.tags) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Prompt> findByStatusAndDepartmentAndSearchTerm(@Param("status") PromptStatus status,
                                                        @Param("department") Department department,
                                                        @Param("search") String search,
                                                        Pageable pageable);

    // Fixed this method - using simpler LIKE syntax
    @Query(value = "SELECT * FROM prompts p WHERE p.status = 'ACTIVE' AND " +
            "(LOWER(p.system_prompt) LIKE LOWER(CONCAT('%', ?1, '%')) OR " +
            "LOWER(p.user_prompt_template) LIKE LOWER(CONCAT('%', ?1, '%')))",
            nativeQuery = true)
    List<Prompt> findSimilarPrompts(String prompt);

    Long countByStatus(PromptStatus status);

    @Query("SELECT p.department, COUNT(p) FROM Prompt p WHERE p.status = 'ACTIVE' GROUP BY p.department")
    List<Object[]> countPromptsByDepartment();

    @Query("SELECT p.status, COUNT(p) FROM Prompt p GROUP BY p.status")
    List<Object[]> countPromptsByStatus();
}