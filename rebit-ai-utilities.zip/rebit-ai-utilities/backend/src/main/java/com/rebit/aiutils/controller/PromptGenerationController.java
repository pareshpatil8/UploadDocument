package com.rebit.aiutils.controller;

import com.rebit.aiutils.dto.PromptGenerationRequest;
import com.rebit.aiutils.dto.PromptGenerationResponse;
import com.rebit.aiutils.service.PromptGenerationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/prompt-generation")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Prompt Generation", description = "AI-powered prompt generation service")
public class PromptGenerationController {
    
    private final PromptGenerationService promptGenerationService;
    
    @PostMapping("/generate")
    @Operation(summary = "Generate prompt", description = "Generate a structured prompt based on requirements")
    public ResponseEntity<PromptGenerationResponse> generatePrompt(@Valid @RequestBody PromptGenerationRequest request) {
        log.info("Generating prompt for purpose: {}", request.getPurpose());
        PromptGenerationResponse response = promptGenerationService.generatePrompt(request);
        return ResponseEntity.ok(response);
    }
}