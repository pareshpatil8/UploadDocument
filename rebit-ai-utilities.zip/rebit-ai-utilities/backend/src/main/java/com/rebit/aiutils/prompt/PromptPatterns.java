package com.rebit.aiutils.prompt;

import java.util.List;
import java.util.Map;

/** Common task patterns with default JSON schemas. */
public enum PromptPatterns {
    SUMMARIZE("""
      Summarize the content succinctly for a busy senior manager.
      Include key points, decisions, dates, and action items if present.
      """,
            """
            {
              "summary": "string",
              "key_points": ["string"],
              "dates": ["string"],
              "actions": ["string"]
            }
            """),

    EXTRACT("""
      Extract structured entities from the content.
      Only return fields asked; if a field is missing, return an empty string.
      """,
            """
            {
              "entities": [
                {"name":"string","value":"string","confidence": "0-1"}
              ]
            }
            """),

    CLASSIFY("""
      Classify the content into one of the allowed labels. Explain the rationale briefly.
      """,
            """
            {
              "label": "string",
              "rationale": "string"
            }
            """),

    PLAN("""
      Produce a phased plan with milestones, risks, owners, and timelines.
      """,
            """
            {
              "phases": [
                {"name":"string","milestones":["string"],"risks":["string"],"owners":["string"],"eta":"string"}
              ],
              "assumptions": ["string"]
            }
            """),

    CRITIQUE("""
      Review the draft critically and suggest concrete improvements with examples.
      """,
            """
            {
              "strengths": ["string"],
              "issues": ["string"],
              "improvements": ["string"],
              "examples": ["string"]
            }
            """),

    GENERATE_CODE("""
      Generate production-quality code in the specified language.
      Follow the standards mentioned and add minimal docs.
      """,
            """
            {
              "files":[{"path":"string","language":"string","contents":"string"}],
              "notes":["string"]
            }
            """),

    CONVERT("""
      Convert the input into the requested target format and preserve semantic meaning.
      """,
            """
            {
              "converted": "string",
              "notes": ["string"]
            }
            """),

    COMPARE("""
      Compare the two (or more) options objectively across agreed criteria and recommend one.
      """,
            """
            {
              "comparison_table": [
                {"criterion":"string","option":"string","score":0}
              ],
              "recommendation":"string",
              "rationale":"string"
            }
            """);

    public final String instructions;
    public final String defaultJsonSchema;

    PromptPatterns(String instructions, String defaultJsonSchema) {
        this.instructions = instructions.trim();
        this.defaultJsonSchema = defaultJsonSchema.trim();
    }

    public static PromptPatterns byNameOrDefault(String name, PromptPatterns def) {
        if (name == null) return def;
        try { return PromptPatterns.valueOf(name.trim().toUpperCase()); }
        catch (Exception ignored) { return def; }
    }
}
