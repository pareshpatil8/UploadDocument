package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.PromptGenerationRequest;
import com.rebit.aiutils.dto.PromptGenerationResponse;

public interface PromptGenerationService {
    PromptGenerationResponse generatePrompt(PromptGenerationRequest request);
}