package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.AnonymizationRequest;
import com.rebit.aiutils.dto.AnonymizationResponse;

public interface AnonymizationService {
    AnonymizationResponse anonymizeText(AnonymizationRequest request);
}