package com.rebit.aiutils.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromptGenerationResponse {
    private String generatedPrompt;
    private String systemPrompt;
    private String userPromptTemplate;
    private String suggestedImprovements;
    private List<PromptDto> similarPrompts;
}