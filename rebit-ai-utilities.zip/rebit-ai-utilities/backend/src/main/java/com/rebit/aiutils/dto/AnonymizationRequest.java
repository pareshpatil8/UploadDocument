package com.rebit.aiutils.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AnonymizationRequest {
    @NotBlank(message = "Text to anonymize is required")
    private String text;
    
    private String contentType; // CODE, TEXT, MIXED
    private Boolean preserveStructure = true;
}