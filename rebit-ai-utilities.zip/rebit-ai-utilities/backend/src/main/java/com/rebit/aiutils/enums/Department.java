package com.rebit.aiutils.enums;

public enum Department {
    PRODUCT_MANAGEMENT("Product Management"),
    FRONTEND_DEVELOPMENT("Frontend Development"),
    BACKEND_DEVELOPMENT("Backend Development"),
    TESTING("Testing"),
    DEVOPS("DevOps"),
    USABILITY("Usability"),
    BUSINESS_ANALYSIS("Business Analysis"),
    PROJECT_MANAGEMENT("Project Management");

    private final String displayName;

    Department(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}