package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.UserDto;
import com.rebit.aiutils.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    UserDto createUser(UserDto userDto);
    UserDto updateUser(Long id, UserDto userDto);
    void deleteUser(Long id);
    Optional<UserDto> getUserById(Long id);
    Optional<UserDto> getUserByUsername(String username);
    List<UserDto> getAllActiveUsers();
    UserDto convertToDto(User user);
    User convertToEntity(UserDto userDto);
}