package com.rebit.aiutils.service.impl;

import com.rebit.aiutils.dto.DashboardStatsDto;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import com.rebit.aiutils.repository.PromptRepository;
import com.rebit.aiutils.repository.UserRepository;
import com.rebit.aiutils.service.DashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {
    
    private final PromptRepository promptRepository;
    private final UserRepository userRepository;
    
    @Override
    public DashboardStatsDto getDashboardStats() {
        log.info("Fetching dashboard statistics");
        
        Long totalPrompts = promptRepository.count();
        Long activePrompts = promptRepository.countByStatus(PromptStatus.ACTIVE);
        Long totalUsers = userRepository.countActiveUsers();
        
        Map<String, Long> promptsByDepartment = getPromptsByDepartment();
        Map<String, Long> promptsByStatus = getPromptsByStatus();
        Map<String, Long> recentActivity = getRecentActivity();
        
        return DashboardStatsDto.builder()
                .totalPrompts(totalPrompts)
                .activePrompts(activePrompts)
                .totalUsers(totalUsers)
                .promptsByDepartment(promptsByDepartment)
                .promptsByStatus(promptsByStatus)
                .recentActivity(recentActivity)
                .build();
    }
    
    private Map<String, Long> getPromptsByDepartment() {
        List<Object[]> results = promptRepository.countPromptsByDepartment();
        Map<String, Long> departmentStats = new HashMap<>();
        
        for (Object[] result : results) {
            Department department = (Department) result[0];
            Long count = (Long) result[1];
            departmentStats.put(department.getDisplayName(), count);
        }
        
        return departmentStats;
    }
    
    private Map<String, Long> getPromptsByStatus() {
        List<Object[]> results = promptRepository.countPromptsByStatus();
        Map<String, Long> statusStats = new HashMap<>();
        
        for (Object[] result : results) {
            PromptStatus status = (PromptStatus) result[0];
            Long count = (Long) result[1];
            statusStats.put(status.name(), count);
        }
        
        return statusStats;
    }
    
    private Map<String, Long> getRecentActivity() {
        // Simple activity metrics - can be enhanced with actual activity tracking
        Map<String, Long> activity = new HashMap<>();
        activity.put("New Prompts (Last 7 days)", 5L); // This would be calculated from actual data
        activity.put("Updated Prompts (Last 7 days)", 8L);
        activity.put("Searches (Last 7 days)", 23L);
        activity.put("Generations (Last 7 days)", 15L);
        
        return activity;
    }
}