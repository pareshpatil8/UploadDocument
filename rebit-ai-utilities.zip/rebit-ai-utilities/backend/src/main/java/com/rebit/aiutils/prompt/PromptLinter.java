package com.rebit.aiutils.prompt;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class PromptLinter {
    private static final Pattern PRONOUNS = Pattern.compile("\\b(it|this|that|they|them|these|those)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern TODO_WORDS = Pattern.compile("\\b(TBD|WIP|lorem ipsum|asap)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern VARS = Pattern.compile("(?:\\$\\{([^}]+)\\}|\\{([a-zA-Z0-9_]+)\\})");
    private static final Pattern QUESTIONS = Pattern.compile("\\?");

    private PromptLinter(){}

    public static List<String> lint(String task, String context, String outputFormat, List<String> variables) {
        List<String> issues = new ArrayList<>();
        if (task == null || task.isBlank()) issues.add("Task is empty.");
        if (task != null && PRONOUNS.matcher(task).find() && (context == null || context.isBlank()))
            issues.add("Ambiguous pronouns without context. Provide concrete nouns or add context.");
        if (task != null && TODO_WORDS.matcher(task).find())
            issues.add("Contains TODO/filler words (TBD/WIP/ASAP/lorem). Replace with specifics.");
        if (outputFormat == null || outputFormat.isBlank())
            issues.add("No output format specified. Add JSON or Markdown structure.");
        if (variables != null && !variables.isEmpty()) {
            // Variables present, but do we see any '?' questions?
            if (!QUESTIONS.matcher(task).find())
                issues.add("Variables detected " + variables + " but no clarifying questions. Ask for missing inputs.");
        }
        if (task != null && task.length() < 30)
            issues.add("Task is very short; add specifics, constraints, and success criteria.");
        return issues;
    }

    public static List<String> extractVariables(String text) {
        var m = VARS.matcher(text == null ? "" : text);
        List<String> vars = new ArrayList<>();
        while (m.find()) {
            String v = m.group(1) != null ? m.group(1) : m.group(2);
            if (v != null && !v.isBlank()) vars.add(v.trim());
        }
        return vars;
    }
}
