package com.rebit.aiutils.controller;

import com.rebit.aiutils.dto.PromptImprovementRequest;
import com.rebit.aiutils.dto.PromptImprovementResponse;
import com.rebit.aiutils.service.PromptImprovementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/prompt-improvement")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Prompt Improvement", description = "AI-powered prompt improvement service")
public class PromptImprovementController {
    
    private final PromptImprovementService promptImprovementService;
    
    @PostMapping("/improve")
    @Operation(summary = "Improve prompt", description = "Analyze and improve an existing prompt")
    public ResponseEntity<PromptImprovementResponse> improvePrompt(@Valid @RequestBody PromptImprovementRequest request) {
        log.info("Improving prompt of length: {}", request.getOriginalPrompt().length());
        PromptImprovementResponse response = promptImprovementService.improvePrompt(request);
        return ResponseEntity.ok(response);
    }
}