package com.rebit.aiutils.anonymize;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Utilities to merge overlapping spans and (optionally) apply replacements.
 * Includes deterministic HMAC-based pseudonyms via alias().
 */
public class SpanMerger {

    /** Typed character-span */
    public static final class SpanHit {
        public final int start;
        public final int end; // exclusive
        public final String type;
        public final String original;
        public final AnonymizationPolicyLoader.Action action;
        public final String format;   // for PSEUDONYMIZE/GENERALIZE
        public final String mask;     // for MASK
        public final String replace;  // for GENERALIZE/REDACT

        public SpanHit(int start, int end, String type, String original,
                       AnonymizationPolicyLoader.Action action, String format, String mask, String replace) {
            this.start = start; this.end = end; this.type = type; this.original = original;
            this.action = action; this.format = format; this.mask = mask; this.replace = replace;
        }
    }

    /** Replacement result */
    public static final class Replacement {
        public final int start, end;
        public final String type, original, replacement;
        public Replacement(int start, int end, String type, String original, String replacement) {
            this.start = start; this.end = end; this.type = type; this.original = original; this.replacement = replacement;
        }
    }

    /** Merge overlaps by type priority; remove duplicates */
    public static List<SpanHit> merge(List<SpanHit> spans, Map<String,Integer> typePriority) {
        if (spans == null || spans.isEmpty()) return List.of();
        // sort by start asc, end desc -> larger spans first for same start
        List<SpanHit> s = new ArrayList<>(spans);
        s.sort(Comparator.<SpanHit>comparingInt(h -> h.start).thenComparing((a,b) -> Integer.compare(b.end, a.end)));

        List<SpanHit> out = new ArrayList<>();
        for (SpanHit cur : s) {
            boolean dropped = false;
            for (int i = 0; i < out.size(); i++) {
                SpanHit keep = out.get(i);
                if (overlaps(keep, cur)) {
                    int pk = typePriority.getOrDefault(keep.type, 0);
                    int pc = typePriority.getOrDefault(cur.type, 0);
                    if (pc > pk) {
                        out.set(i, cur); // replace with higher priority
                    }
                    dropped = true;
                    break;
                }
            }
            if (!dropped) out.add(cur);
        }
        // remove exact duplicates
        return dedupe(out);
    }

    /** Apply replacements right-to-left to avoid index shifting */
    public static CharSequence applyAndBuild(String text, List<Replacement> reps) {
        StringBuilder sb = new StringBuilder(text);
        reps.sort(Comparator.comparingInt((Replacement r) -> r.start).reversed());
        for (Replacement r : reps) sb.replace(r.start, r.end, r.replacement);
        return sb;
    }

    public static List<Replacement> buildReplacements(List<SpanHit> merged,
                                                      AnonymizationPolicyLoader.Policy policy,
                                                      Key hmacKey) {
        List<Replacement> reps = new ArrayList<>();
        for (SpanHit h : merged) {
            String repl;
            switch (h.action) {
                case MASK -> repl = (h.mask != null && !h.mask.isBlank())
                        ? h.mask : "*".repeat(h.original.length());
                case REDACT -> repl = "[REDACTED]";
                case GENERALIZE -> repl = (h.replace != null && !h.replace.isBlank())
                        ? h.replace : "[" + h.type + "]";
                case PSEUDONYMIZE -> repl = alias(h.original, h.format != null ? h.format : "${hash8}", hmacKey);
                default -> repl = "[REDACTED]";
            }
            reps.add(new Replacement(h.start, h.end, h.type, h.original, repl));
        }
        return reps;
    }

    /** HMAC-SHA256 based short alias. Keep key in Vault/JCEKS. */
    public static String alias(String value, String format, Key key) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(key);
            byte[] digest = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String hex = toHex(digest);
            String h8 = hex.substring(0, 8);
            return format.replace("${hash8}", h8);
        } catch (Exception e) {
            return "alias_" + Math.abs(Objects.hashCode(value));
        }
    }

    /* ------------ helpers ------------ */

    private static boolean overlaps(SpanHit a, SpanHit b) {
        return a.start < b.end && b.start < a.end;
    }

    private static List<SpanHit> dedupe(List<SpanHit> in) {
        Set<String> seen = new HashSet<>();
        List<SpanHit> out = new ArrayList<>();
        for (SpanHit h : in) {
            String k = h.start + ":" + h.end + ":" + h.type + ":" + h.original;
            if (seen.add(k)) out.add(h);
        }
        return out;
    }

    private static String toHex(byte[] bytes) {
        final char[] HEX = "0123456789abcdef".toCharArray();
        char[] out = new char[bytes.length * 2];
        for (int i = 0, j = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xff;
            out[j++] = HEX[v >>> 4];
            out[j++] = HEX[v & 0x0f];
        }
        return new String(out);
    }

    /** Convenience: build default HMAC key from a constant secret (replace in prod) */
    public static Key hmacKeyFrom(String secret) {
        return new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
    }
}
