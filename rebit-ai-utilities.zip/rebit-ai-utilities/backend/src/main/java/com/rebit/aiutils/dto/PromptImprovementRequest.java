package com.rebit.aiutils.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PromptImprovementRequest {
    @NotBlank(message = "Original prompt is required")
    private String originalPrompt;
    
    private String context;
    private String desiredImprovements;
}