package com.rebit.aiutils.controller;

import com.rebit.aiutils.dto.PagedResponse;
import com.rebit.aiutils.dto.PromptDto;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import com.rebit.aiutils.service.PromptService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/prompts")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Prompt Management", description = "CRUD operations for prompts")
public class PromptController {
    
    private final PromptService promptService;
    
    @PostMapping
    @Operation(summary = "Create prompt", description = "Create a new prompt")
    public ResponseEntity<PromptDto> createPrompt(@Valid @RequestBody PromptDto promptDto) {
        log.info("Creating new prompt: {}", promptDto.getName());
        PromptDto createdPrompt = promptService.createPrompt(promptDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPrompt);
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update prompt", description = "Update an existing prompt")
    public ResponseEntity<PromptDto> updatePrompt(@PathVariable Long id, @Valid @RequestBody PromptDto promptDto) {
        log.info("Updating prompt with id: {}", id);
        PromptDto updatedPrompt = promptService.updatePrompt(id, promptDto);
        return ResponseEntity.ok(updatedPrompt);
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete prompt", description = "Soft delete a prompt (archive)")
    public ResponseEntity<Void> deletePrompt(@PathVariable Long id) {
        log.info("Deleting prompt with id: {}", id);
        promptService.deletePrompt(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get prompt by ID", description = "Retrieve a specific prompt by its ID")
    public ResponseEntity<PromptDto> getPromptById(@PathVariable Long id) {
        return promptService.getPromptById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping
    @Operation(summary = "Get all prompts", description = "Retrieve all prompts with pagination")
    public ResponseEntity<PagedResponse<PromptDto>> getAllPrompts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        PagedResponse<PromptDto> prompts = promptService.getAllPrompts(pageable);
        return ResponseEntity.ok(prompts);
    }
    
    @GetMapping("/search")
    @Operation(summary = "Search prompts", description = "Search prompts with filters")
    public ResponseEntity<PagedResponse<PromptDto>> searchPrompts(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Department department,
            @RequestParam(defaultValue = "ACTIVE") PromptStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        PagedResponse<PromptDto> prompts = promptService.searchPrompts(search, department, status, pageable);
        return ResponseEntity.ok(prompts);
    }
    
    @GetMapping("/similar")
    @Operation(summary = "Find similar prompts", description = "Find prompts similar to given text")
    public ResponseEntity<List<PromptDto>> findSimilarPrompts(@RequestParam String prompt) {
        List<PromptDto> similarPrompts = promptService.findSimilarPrompts(prompt);
        return ResponseEntity.ok(similarPrompts);
    }
    
    @GetMapping("/department/{department}")
    @Operation(summary = "Get prompts by department", description = "Retrieve prompts for a specific department")
    public ResponseEntity<PagedResponse<PromptDto>> getPromptsByDepartment(
            @PathVariable Department department,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        PagedResponse<PromptDto> prompts = promptService.getPromptsByDepartment(department, pageable);
        return ResponseEntity.ok(prompts);
    }
}