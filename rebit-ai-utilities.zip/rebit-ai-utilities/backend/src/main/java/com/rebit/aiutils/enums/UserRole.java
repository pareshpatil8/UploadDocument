package com.rebit.aiutils.enums;

public enum UserRole {
    USER,
    ADMIN
}