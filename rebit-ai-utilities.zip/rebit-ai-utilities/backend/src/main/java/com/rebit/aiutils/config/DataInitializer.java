package com.rebit.aiutils.config;

import com.rebit.aiutils.entity.Prompt;
import com.rebit.aiutils.entity.User;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import com.rebit.aiutils.enums.UserRole;
import com.rebit.aiutils.repository.PromptRepository;
import com.rebit.aiutils.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;


@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {
    
    private final UserRepository userRepository;
    private final PromptRepository promptRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Override
    @Transactional
    public void run(String... args) {
        if (userRepository.count() == 0) {
            initializeUsers();
            initializePrompts();
        }
    }
    
    private void initializeUsers() {
        log.info("Initializing seed users...");
        String encodedPassword = passwordEncoder.encode("Admin123");
        
        User adminUser = User.builder()
                .username("admin")
                .firstName("System")
                .lastName("Administrator")
                .email("admin@rebit.com")
                .password(encodedPassword)
                .department(Department.PROJECT_MANAGEMENT)
                .role(UserRole.ADMIN)
                .active(true)
                .build();
        userRepository.save(adminUser);
        log.info("====Saved user password: {}", adminUser.getPassword());
        
        User devUser = User.builder()
                .username("john.developer")
                .firstName("John")
                .lastName("Developer")
                .email("john.developer@rebit.com")
                .password(encodedPassword)
                .department(Department.BACKEND_DEVELOPMENT)
                .role(UserRole.USER)
                .active(true)
                .build();
        userRepository.save(devUser);
        
        User pmUser = User.builder()
                .username("jane.manager")
                .firstName("Jane")
                .lastName("Manager")
                .email("jane.manager@rebit.com")
                .password(encodedPassword)
                .department(Department.PRODUCT_MANAGEMENT)
                .role(UserRole.USER)
                .active(true)
                .build();
        userRepository.save(pmUser);
        
        User testUser = User.builder()
                .username("mike.tester")
                .firstName("Mike")
                .lastName("Tester")
                .email("mike.tester@rebit.com")
                .password(encodedPassword)
                .department(Department.TESTING)
                .role(UserRole.USER)
                .active(true)
                .build();
        userRepository.save(testUser);

        for (Prompt p : DemoPromptSeeds.buildDemoPrompts(adminUser)) {
            promptRepository.save(p);
        }
        
        log.info("Seed users created successfully");
    }
    
    private void initializePrompts() {
        log.info("Initializing seed prompts...");
        
        User adminUser = userRepository.findByUsername("admin").orElseThrow();
        User devUser = userRepository.findByUsername("john.developer").orElseThrow();
        User pmUser = userRepository.findByUsername("jane.manager").orElseThrow();
        User testUser = userRepository.findByUsername("mike.tester").orElseThrow();
        
        // Backend Development Prompt
        Prompt backendPrompt = Prompt.builder()
                .name("Java Code Review and Optimization")
                .description("Analyze Java code for best practices, performance issues, and security vulnerabilities")
                .department(Department.BACKEND_DEVELOPMENT)
                .systemPrompt("You are a senior Java developer and architect with expertise in Spring Boot, microservices, and clean code principles. Focus on code quality, security, and performance optimization.")
                .userPromptTemplate("Please review the following Java code and provide feedback on:\n\n{code}\n\nAnalyze for:\n- Code quality and best practices\n- Performance optimization opportunities\n- Security vulnerabilities\n- Spring Boot specific improvements\n- Microservices architecture considerations")
                .inputPlaceholders("{\"code\": \"Java code to be reviewed, required\"}")
                .outputFormat("Provide response in sections: Summary, Issues Found, Recommendations, Improved Code (if applicable)")
                .constraints("Focus on Java 21 features, Spring Boot 3.x best practices. Assume air-gapped environment - no external dependencies.")
                .tags("java, spring boot, code review, microservices, security")
                .author(devUser)
                .status(PromptStatus.ACTIVE)
                .relatedTools("Local IDE, SonarQube, SpotBugs")
                .build();
        promptRepository.save(backendPrompt);
        
        // Product Management Prompt
        Prompt pmPrompt = Prompt.builder()
                .name("Business Requirements Document Generator")
                .description("Generate comprehensive BRD from high-level product requirements")
                .department(Department.PRODUCT_MANAGEMENT)
                .systemPrompt("You are a senior product manager experienced in creating detailed business requirements documents for enterprise software solutions.")
                .userPromptTemplate("Generate a Business Requirements Document for:\n\nProject: {project_name}\nObjective: {objective}\nStakeholders: {stakeholders}\nKey Features: {features}\n\nInclude: Executive Summary, Business Objectives, Functional Requirements, Non-Functional Requirements, Assumptions, and Success Criteria.")
                .inputPlaceholders("{\"project_name\": \"Name of the project, required\", \"objective\": \"Main business objective, required\", \"stakeholders\": \"Key stakeholders, optional\", \"features\": \"List of key features, required\"}")
                .outputFormat("Structured document with numbered sections, clear headings, and professional formatting suitable for stakeholder review")
                .constraints("Focus on enterprise software requirements. Include compliance and security considerations for financial services.")
                .tags("brd, requirements, product management, documentation")
                .author(pmUser)
                .status(PromptStatus.ACTIVE)
                .relatedTools("Confluence, MS Word, Jira")
                .build();
        promptRepository.save(pmPrompt);
        
        // Testing Prompt
        Prompt testPrompt = Prompt.builder()
                .name("Automated Test Case Generator")
                .description("Generate comprehensive test cases for web applications including positive, negative, and edge cases")
                .department(Department.TESTING)
                .systemPrompt("You are a senior QA engineer with expertise in test automation, Selenium WebDriver, and comprehensive test case design.")
                .userPromptTemplate("Generate test cases for the following feature:\n\nFeature: {feature_description}\nUser Story: {user_story}\nAcceptance Criteria: {acceptance_criteria}\n\nGenerate: Positive test cases, Negative test cases, Edge cases, and Selenium automation code snippets.")
                .inputPlaceholders("{\"feature_description\": \"Description of feature to test, required\", \"user_story\": \"User story or requirement, required\", \"acceptance_criteria\": \"Acceptance criteria, optional\"}")
                .outputFormat("Test cases in tabular format with Test ID, Description, Steps, Expected Results. Include Selenium code snippets.")
                .constraints("Focus on web application testing. Use Selenium WebDriver with Java. Consider air-gapped testing environment.")
                .tags("testing, selenium, automation, test cases, qa")
                .author(testUser)
                .status(PromptStatus.ACTIVE)
                .relatedTools("Selenium WebDriver, TestNG, Maven")
                .build();
        promptRepository.save(testPrompt);
        
        // Frontend Development Prompt
        Prompt frontendPrompt = Prompt.builder()
                .name("Angular Component Architecture Review")
                .description("Review Angular components for best practices, performance, and maintainability")
                .department(Department.FRONTEND_DEVELOPMENT)
                .systemPrompt("You are a senior frontend developer specializing in Angular, TypeScript, and modern web development practices. Focus on component architecture, performance optimization, and user experience.")
                .userPromptTemplate("Review this Angular component:\n\n{component_code}\n\nAnalyze for:\n- Component architecture and separation of concerns\n- TypeScript best practices\n- Performance optimization\n- Accessibility compliance\n- Angular best practices and lifecycle management")
                .inputPlaceholders("{\"component_code\": \"Angular component code (TypeScript, HTML, CSS), required\"}")
                .outputFormat("Structured review with sections: Architecture Analysis, Performance Issues, Accessibility Review, Recommendations, Improved Code")
                .constraints("Focus on Angular 16+ features, PrimeNG components, responsive design principles")
                .tags("angular, typescript, component architecture, performance, accessibility")
                .author(adminUser)
                .status(PromptStatus.ACTIVE)
                .relatedTools("Angular CLI, VS Code, Chrome DevTools")
                .build();
        promptRepository.save(frontendPrompt);
        
        // DevOps Prompt
        Prompt devopsPrompt = Prompt.builder()
                .name("OpenShift Deployment Configuration")
                .description("Generate OpenShift deployment configurations and troubleshooting guides")
                .department(Department.DEVOPS)
                .systemPrompt("You are a DevOps engineer with expertise in OpenShift, containerization, CI/CD pipelines, and enterprise deployment strategies.")
                .userPromptTemplate("Create OpenShift deployment configuration for:\n\nApplication: {app_name}\nEnvironment: {environment}\nRequirements: {requirements}\n\nInclude: Deployment YAML, Service configuration, Route setup, Health checks, Resource limits, and troubleshooting guide.")
                .inputPlaceholders("{\"app_name\": \"Application name, required\", \"environment\": \"Target environment (dev/test/prod), required\", \"requirements\": \"Specific requirements or constraints, optional\"}")
                .outputFormat("Complete YAML configurations with comments, followed by deployment guide and troubleshooting section")
                .constraints("Use OpenShift 4.x features, consider enterprise security policies, air-gapped deployment scenarios")
                .tags("openshift, deployment, kubernetes, devops, containerization")
                .author(adminUser)
                .status(PromptStatus.ACTIVE)
                .relatedTools("OpenShift CLI, kubectl, Jenkins")
                .build();
        promptRepository.save(devopsPrompt);
        
        log.info("Seed prompts created successfully");
    }
}