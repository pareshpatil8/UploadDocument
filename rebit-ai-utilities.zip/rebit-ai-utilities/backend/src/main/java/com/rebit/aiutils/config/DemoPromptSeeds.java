package com.rebit.aiutils.config;

import com.rebit.aiutils.entity.Prompt;
import com.rebit.aiutils.entity.User;
import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import java.util.*;

public final class DemoPromptSeeds {
    private DemoPromptSeeds() {}
    public static List<Prompt> buildDemoPrompts(User adminUser) {
        List<Prompt> list = new ArrayList<>();
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Write a PRD for ${project_name} with RBI-specific NFRs");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Write a PRD for ${project_name} with RBI-specific NFRs\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Draft user stories with acceptance criteria for ${module}");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Draft user stories with acceptance criteria for ${module}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Define OKRs and KPIs for ${project_name} Q${quarter}");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Define OKRs and KPIs for ${project_name} Q${quarter}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: RICE prioritization matrix for backlog items");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("RICE prioritization matrix for backlog items\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Stakeholder map and communication plan");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Stakeholder map and communication plan\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Release notes for version ${version}");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Release notes for version ${version}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Problem framing using JTBD for ${persona}");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Problem framing using JTBD for ${persona}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Experiment plan (A/B) with success metrics");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Experiment plan (A/B) with success metrics\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Product Management: Non-functional requirements checklist (RBI context)");
            p.setDescription("Prompt template for product management in RBI context.");
            p.setDepartment(Department.PRODUCT_MANAGEMENT);
            p.setSystemPrompt("You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.");
            p.setUserPromptTemplate("Non-functional requirements checklist (RBI context)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("prd,okr,roadmap,rbi,compliance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Jira, Confluence, Draw.io");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: Angular component spec for ${feature}");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("Angular component spec for ${feature}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: Responsive layout grid for ${page}");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("Responsive layout grid for ${page}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: Reactive form with validation for ${form_name}");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("Reactive form with validation for ${form_name}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: HTTP interceptor for auth & error handling");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("HTTP interceptor for auth & error handling\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: Route guards and lazy loading plan");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("Route guards and lazy loading plan\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: NgRx store design for ${domain}");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("NgRx store design for ${domain}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: i18n keys and extraction script");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("i18n keys and extraction script\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: Web performance budget and Lighthouse targets");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("Web performance budget and Lighthouse targets\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Frontend Development: A11y checklist (WCAG 2.1 AA) for ${page}");
            p.setDescription("Prompt template for frontend development in RBI context.");
            p.setDepartment(Department.FRONTEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.");
            p.setUserPromptTemplate("A11y checklist (WCAG 2.1 AA) for ${page}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("angular,rxjs,a11y,performance,security");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Angular CLI, RxJS, ESLint");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: REST API contract for ${resource} (OpenAPI)");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("REST API contract for ${resource} (OpenAPI)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Entity and repository design for ${aggregate}");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Entity and repository design for ${aggregate}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Service layering and DTO mappers plan");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Service layering and DTO mappers plan\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Exception handling & error codes catalog");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Exception handling & error codes catalog\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Input validation rules for ${endpoint}");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Input validation rules for ${endpoint}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Authentication and RBAC policy (Spring Security)");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Authentication and RBAC policy (Spring Security)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Audit logging & trace IDs across services");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Audit logging & trace IDs across services\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Hibernate/JPA performance tuning checklist");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Hibernate/JPA performance tuning checklist\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Backend Development: Hazelcast caching strategy for ${entity}");
            p.setDescription("Prompt template for backend development in RBI context.");
            p.setDepartment(Department.BACKEND_DEVELOPMENT);
            p.setSystemPrompt("You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.");
            p.setUserPromptTemplate("Hazelcast caching strategy for ${entity}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("springboot,java21,api,security,performance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Spring Boot, JPA, Kafka, OpenAPI");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Selenium test plan for ${user_flow}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Selenium test plan for ${user_flow}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Page Object Model structure for ${app}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Page Object Model structure for ${app}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Cross-browser matrix for ${app}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Cross-browser matrix for ${app}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: BDD feature file for ${feature}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("BDD feature file for ${feature}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Cucumber step definitions outline");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Cucumber step definitions outline\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Test data strategy (synthetic vs masked)");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Test data strategy (synthetic vs masked)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Regression suite selection rules");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Regression suite selection rules\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: Smoke test checklist for ${release}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("Smoke test checklist for ${release}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Testing: JMeter performance test plan for ${api}");
            p.setDescription("Prompt template for testing in RBI context.");
            p.setDepartment(Department.TESTING);
            p.setSystemPrompt("You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.");
            p.setUserPromptTemplate("JMeter performance test plan for ${api}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("selenium,jmeter,bdd,cucumber,qa");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Selenium, JMeter, Cucumber, Allure");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: BuildPiper pipeline for ${service}");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("BuildPiper pipeline for ${service}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: OpenShift Deployment/Service/Route YAML");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("OpenShift Deployment/Service/Route YAML\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Helm chart skeleton for ${service}");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Helm chart skeleton for ${service}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Image build strategy with S2I/Buildah");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Image build strategy with S2I/Buildah\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Image signing and SBOM generation");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Image signing and SBOM generation\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: OPA/SAST/Dependency scan steps");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("OPA/SAST/Dependency scan steps\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Secrets management with Vault/KMS");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Secrets management with Vault/KMS\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Blue/Green vs Rolling strategy");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Blue/Green vs Rolling strategy\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("DevOps: Resource requests/limits for ${pod}");
            p.setDescription("Prompt template for devops in RBI context.");
            p.setDepartment(Department.DEVOPS);
            p.setSystemPrompt("You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.");
            p.setUserPromptTemplate("Resource requests/limits for ${pod}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("buildpiper,openshift,ci,cd,kubernetes");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BuildPiper, OpenShift, Helm, Grafana");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Figma wireframes for ${flow}");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Figma wireframes for ${flow}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Design tokens for ${product}");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Design tokens for ${product}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: WCAG 2.1 AA audit for ${screen}");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("WCAG 2.1 AA audit for ${screen}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Component library spec (Angular handoff)");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Component library spec (Angular handoff)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Navigation IA for ${portal}");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Navigation IA for ${portal}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Error states and empty states patterns");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Error states and empty states patterns\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Form usability for ${form_name}");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Form usability for ${form_name}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Dashboard information hierarchy");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Dashboard information hierarchy\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Usability: Microcopy guidelines for RBI apps");
            p.setDescription("Prompt template for usability in RBI context.");
            p.setDepartment(Department.USABILITY);
            p.setSystemPrompt("You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.");
            p.setUserPromptTemplate("Microcopy guidelines for RBI apps\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("figma,design-system,a11y,ux,prototype");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("Figma, FigJam, WCAG tools");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: BRD outline for ${project_name}");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("BRD outline for ${project_name}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Context diagram & data flow");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Context diagram & data flow\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: BPMN process for ${process_name}");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("BPMN process for ${process_name}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Stakeholder analysis (RACI)");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Stakeholder analysis (RACI)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Requirements elicitation plan");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Requirements elicitation plan\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Use case model for ${module}");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Use case model for ${module}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Glossary and domain terms");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Glossary and domain terms\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Business Analysis: Data field mapping (source→target)");
            p.setDescription("Prompt template for business analysis in RBI context.");
            p.setDepartment(Department.BUSINESS_ANALYSIS);
            p.setSystemPrompt("You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.");
            p.setUserPromptTemplate("Data field mapping (source→target)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("brd,bpmn,requirements,traceability,rbi");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("BPMN, UML, Excel");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: WBS for ${project_name}");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("WBS for ${project_name}\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Schedule with milestones (Gantt)");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Schedule with milestones (Gantt)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Resource plan and roles");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Resource plan and roles\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: RAID log (Risks/Assumptions/Issues/Deps)");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("RAID log (Risks/Assumptions/Issues/Deps)\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Weekly status report template");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Weekly status report template\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Communication plan by audience");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Communication plan by audience\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Budget and cost baseline");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Budget and cost baseline\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        {
            Prompt p = new Prompt();
            p.setName("Project Management: Change control process");
            p.setDescription("Prompt template for project management in RBI context.");
            p.setDepartment(Department.PROJECT_MANAGEMENT);
            p.setSystemPrompt("You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.");
            p.setUserPromptTemplate("Change control process\n\nContext:\n- Project: ${project_name}\n- Module/Area: ${module}\n- Audience: ${audience}\n- Constraints: ${constraints}\n\nOutput strictly in the specified format.");
            p.setInputPlaceholders("{\"project_name\": \"Name of the RBI project/application\", \"module\": \"Module or domain area\", \"audience\": \"Primary audience for the output\", \"constraints\": \"Special constraints (e.g., air-gapped, compliance)\", \"version\": \"Optional version tag\", \"n\": \"Optional count\", \"persona\": \"Optional persona\", \"months\": \"Optional timeline in months\", \"chart_lib\": \"Optional chart library\", \"from\": \"Optional source version\", \"to\": \"Optional target version\", \"resource\": \"Optional API resource name\", \"aggregate\": \"Optional aggregate root/domain object\", \"endpoint\": \"Optional endpoint path\", \"entity\": \"Optional entity name\", \"topic\": \"Optional Kafka topic\", \"operation\": \"Idempotent operation label\", \"services\": \"Involved services\", \"service\": \"Service name\", \"pod\": \"Pod/workload name\", \"namespace\": \"OpenShift namespace\", \"flow\": \"User flow name\", \"form_name\": \"Form name\", \"component\": \"Component name\", \"domain\": \"Domain name\", \"page\": \"Page name\", \"user_flow\": \"End-to-end flow\", \"report\": \"Report name\", \"process_name\": \"Process\", \"job_name\": \"Batch job\"}");
            p.setOutputFormat("{ \"answer\": \"string\", \"assumptions\": [\"string\"], \"risks\": [\"string\"], \"next_steps\": [\"string\"] }");
            p.setConstraints("No external data exposure. Use only provided context. Ask for missing inputs.");
            p.setTags("wbs,schedule,risk,jira,governance");
            p.setStatus(PromptStatus.ACTIVE);
            p.setRelatedTools("MS Project, Jira, Confluence");
            p.setAuthor(adminUser);
            list.add(p);
        }
        return list;
    }
}