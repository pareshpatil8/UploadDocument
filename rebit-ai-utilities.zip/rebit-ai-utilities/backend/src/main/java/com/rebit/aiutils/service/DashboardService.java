package com.rebit.aiutils.service;

import com.rebit.aiutils.dto.DashboardStatsDto;

public interface DashboardService {
    DashboardStatsDto getDashboardStats();
}