package com.rebit.aiutils.dto;

import com.rebit.aiutils.enums.Department;
import com.rebit.aiutils.enums.PromptStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromptDto {
    private Long id;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    private String description;
    
    @NotNull(message = "Department is required")
    private Department department;
    
    @NotBlank(message = "System prompt is required")
    private String systemPrompt;
    
    @NotBlank(message = "User prompt template is required")
    private String userPromptTemplate;
    
    private String inputPlaceholders;
    private String outputFormat;
    private String constraints;
    private String tags;
    private Long authorId;
    private String authorName;
    private PromptStatus status;
    private String relatedTools;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}