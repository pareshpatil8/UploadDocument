package com.rebit.aiutils.controller;

import com.rebit.aiutils.dto.AnonymizationRequest;
import com.rebit.aiutils.dto.AnonymizationResponse;
import com.rebit.aiutils.service.AnonymizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/anonymization")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Anonymization", description = "Text and code anonymization service")
public class AnonymizationController {
    
    private final AnonymizationService anonymizationService;
    
    @PostMapping("/anonymize")
    @Operation(summary = "Anonymize text", description = "Remove sensitive information from text or code")
    public ResponseEntity<AnonymizationResponse> anonymizeText(@Valid @RequestBody AnonymizationRequest request) {
        log.info("Anonymizing text of length: {}", request.getText().length());
        AnonymizationResponse response = anonymizationService.anonymizeText(request);
        return ResponseEntity.ok(response);
    }
}