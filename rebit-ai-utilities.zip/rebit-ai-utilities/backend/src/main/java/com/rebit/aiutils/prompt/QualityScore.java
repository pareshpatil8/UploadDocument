package com.rebit.aiutils.prompt;

public record QualityScore(
        int clarity,
        int specificity,
        int structure,
        int safety,
        int overall
) {
    public static QualityScore of(int clarity, int specificity, int structure, int safety) {
        int overall = Math.max(0, Math.min(100, (clarity + specificity + structure + safety) / 4));
        return new QualityScore(clarity, specificity, structure, safety, overall);
    }
}
