package com.rebit.aiutils.anonymize;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.yaml.snakeyaml.LoaderOptions;


/**
 * Loads anonymization policy from YAML and provides rule-based detectors.
 * Supports REGEX and DICTIONARY rules with actions: MASK/REDACT/PSEUDONYMIZE/GENERALIZE.
 *
 * YAML example:
 *
 * rules:
 *   - type: EMAIL
 *     pattern: "(?i)\\b[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}\\b"
 *     action: PSEUDONYMIZE
 *     format: "user_${hash8}@example.com"
 *   - type: PHONE
 *     pattern: "\\b(?:\\+91[- ]?)?[6-9]\\d{9}\\b"
 *     action: MASK
 *     mask: "**********"
 *   - type: ORG
 *     dictionary: ["ReBIT","Reserve Bank of India","RBI","DC Nagpur","Navi Mumbai DC"]
 *     action: PSEUDONYMIZE
 *     format: "ORG_${hash8}"
 */
public class AnonymizationPolicyLoader {

    public enum Action { MASK, REDACT, PSEUDONYMIZE, GENERALIZE }

    /** Immutable compiled policy */
    public static final class Policy {
        private final List<Rule> rules;
        /** Higher value = higher priority when overlaps occur */
        private final Map<String,Integer> typePriority;

        Policy(List<Rule> rules, Map<String,Integer> typePriority) {
            this.rules = List.copyOf(rules);
            this.typePriority = Map.copyOf(typePriority);
        }
        public List<Rule> rules() { return rules; }
        public Map<String,Integer> typePriority() { return typePriority; }

        /** Run all rules and return hits as spans. */
        public List<SpanMerger.SpanHit> detect(String text) {
            List<SpanMerger.SpanHit> out = new ArrayList<>();
            for (Rule r : rules) out.addAll(r.detect(text));
            return out;
        }
    }

    /** Base rule interface */
    public interface Rule {
        List<SpanMerger.SpanHit> detect(String text);
        String type();
        Action action();
        Optional<String> format();
        Optional<String> mask();
        Optional<String> replace();
    }

    /** Regex rule */
    public static final class RegexRule implements Rule {
        private final String type;
        private final Action action;
        private final Pattern pattern;
        private final String format;
        private final String mask;
        private final String replace;

        public RegexRule(String type, Action action, String regex, String format, String mask, String replace, boolean caseSensitive) {
            int flags = caseSensitive ? 0 : Pattern.CASE_INSENSITIVE;
            this.type = type;
            this.action = action;
            this.pattern = Pattern.compile(regex, flags);
            this.format = format;
            this.mask = mask;
            this.replace = replace;
        }

        @Override public List<SpanMerger.SpanHit> detect(String text) {
            List<SpanMerger.SpanHit> hits = new ArrayList<>();
            Matcher m = pattern.matcher(text);
            while (m.find()) {
                int s = m.start();
                int e = m.end();
                String original = text.substring(s, e);
                hits.add(new SpanMerger.SpanHit(s, e, type, original, action, format, mask, replace));
            }
            return hits;
        }
        @Override public String type() { return type; }
        @Override public Action action() { return action; }
        @Override public Optional<String> format() { return Optional.ofNullable(format); }
        @Override public Optional<String> mask() { return Optional.ofNullable(mask); }
        @Override public Optional<String> replace() { return Optional.ofNullable(replace); }
    }

    /** Dictionary rule (token-aware optional word boundaries) */
    public static final class DictionaryRule implements Rule {
        private final String type;
        private final Action action;
        private final List<Pattern> compiled;
        private final String format;
        private final String mask;
        private final String replace;

        public DictionaryRule(String type, Action action, Collection<String> words,
                              boolean caseSensitive, boolean wordBoundary,
                              String format, String mask, String replace) {
            this.type = type;
            this.action = action;
            this.format = format;
            this.mask = mask;
            this.replace = replace;
            int flags = caseSensitive ? 0 : Pattern.CASE_INSENSITIVE;
            List<Pattern> pats = new ArrayList<>();
            for (String w : words) {
                String quoted = Pattern.quote(w);
                String rx = wordBoundary ? "\\b" + quoted + "\\b" : quoted;
                pats.add(Pattern.compile(rx, flags));
            }
            this.compiled = List.copyOf(pats);
        }

        @Override public List<SpanMerger.SpanHit> detect(String text) {
            List<SpanMerger.SpanHit> hits = new ArrayList<>();
            for (Pattern p : compiled) {
                Matcher m = p.matcher(text);
                while (m.find()) {
                    int s = m.start(), e = m.end();
                    hits.add(new SpanMerger.SpanHit(s, e, type, text.substring(s,e), action, format, mask, replace));
                }
            }
            return hits;
        }
        @Override public String type() { return type; }
        @Override public Action action() { return action; }
        @Override public Optional<String> format() { return Optional.ofNullable(format); }
        @Override public Optional<String> mask() { return Optional.ofNullable(mask); }
        @Override public Optional<String> replace() { return Optional.ofNullable(replace); }
    }

    /** YAML -> Policy */
    public static Policy loadFromClasspath(String yamlPath) {
        try (InputStream in = resource(yamlPath)) {
            if (in == null) throw new IllegalStateException("Policy YAML not found: " + yamlPath);

            LoaderOptions opts = new LoaderOptions();
            opts.setAllowDuplicateKeys(false);
            Yaml yaml = new Yaml(new Constructor(opts));
            YamlRoot root = yaml.loadAs(in, YamlRoot.class);

            if (root == null || root.rules == null) throw new IllegalStateException("Empty policy YAML: " + yamlPath);

            List<Rule> rules = new ArrayList<>();
            for (RuleDef d : root.rules) {
                Action action = Action.valueOf(Objects.requireNonNull(d.action, "action").toUpperCase(Locale.ROOT));
                String type = Objects.requireNonNull(d.type, "type");
                boolean caseSensitive = Boolean.TRUE.equals(d.caseSensitive);
                boolean wordBoundary = d.wordBoundary == null || d.wordBoundary;

                if (d.pattern != null && !d.pattern.isBlank()) {
                    rules.add(new RegexRule(type, action, d.pattern, d.format, d.mask, d.replace, caseSensitive));
                }
                if (d.dictionary != null && !d.dictionary.isEmpty()) {
                    rules.add(new DictionaryRule(type, action, d.dictionary, caseSensitive, wordBoundary, d.format, d.mask, d.replace));
                }
            }

            Map<String,Integer> pri = new HashMap<>();
            if (root.priority != null) pri.putAll(root.priority);

            // sensible defaults if not specified
            pri.putIfAbsent("AADHAAR", 100);
            pri.putIfAbsent("PAN", 95);
            pri.putIfAbsent("IFSC", 90);
            pri.putIfAbsent("ACCOUNT_NO", 85);
            pri.putIfAbsent("EMAIL", 80);
            pri.putIfAbsent("PHONE", 80);
            pri.putIfAbsent("PERSON", 75);
            pri.putIfAbsent("ORG", 70);
            pri.putIfAbsent("LOCATION", 65);
            pri.putIfAbsent("HOSTNAME", 60);
            pri.putIfAbsent("IPV4", 60);
            pri.putIfAbsent("URL", 55);
            pri.putIfAbsent("PATH", 50);
            pri.putIfAbsent("GIT_URL", 50);
            pri.putIfAbsent("CODE_IDENTIFIER", 40);

            return new Policy(rules, pri);
        } catch (Exception e) {
            throw new RuntimeException("Failed loading anonymization policy: " + yamlPath, e);
        }
    }

    private static InputStream resource(String p) {
        return Thread.currentThread().getContextClassLoader().getResourceAsStream(stripLeadingSlash(p));
    }
    private static String stripLeadingSlash(String p) {
        return p.startsWith("/") ? p.substring(1) : p;
    }

    /* ---------- YAML binding classes ---------- */

    public static final class YamlRoot {
        public List<RuleDef> rules;
        public Map<String,Integer> priority;
    }
    public static final class RuleDef {
        public String type;
        public String action;
        public String pattern;
        public List<String> dictionary;
        public Boolean caseSensitive;
        public Boolean wordBoundary;
        public String format;
        public String mask;
        public String replace;
    }
}
