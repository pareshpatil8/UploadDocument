package com.rebit.aiutils.service.impl;

import com.rebit.aiutils.anonymize.AnonymizationPolicyLoader;
import com.rebit.aiutils.anonymize.NerDetector;
import com.rebit.aiutils.anonymize.SpanMerger;
import com.rebit.aiutils.dto.AnonymizationRequest;
import com.rebit.aiutils.dto.AnonymizationResponse;
import com.rebit.aiutils.service.AnonymizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


import java.security.Key;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class AnonymizationServiceImpl implements AnonymizationService {

    private final AnonymizationPolicyLoader.Policy policy =
            AnonymizationPolicyLoader.loadFromClasspath("anonymization/anonymization-policy.yaml");

    private final NerDetector nerDetector = new NerDetector();

    private final Key hmacKey = SpanMerger.hmacKeyFrom("rotate-me-in-vault");

    @Override
    public AnonymizationResponse anonymizeText(AnonymizationRequest req) {
        String text = req.getText();

        // 1) Detect by rules + NER
        var ruleHits = policy.detect(text);
        var nerHits  = nerDetector.detect(text);

        // 2) Merge by priority
        var merged = SpanMerger.merge( concat(ruleHits, nerHits), policy.typePriority() );

        // 3) Build replacements and apply
        var reps = SpanMerger.buildReplacements(merged, policy, hmacKey);
        var anonymized = SpanMerger.applyAndBuild(text, reps).toString();

        // 4) Prepare response (you already have DTOs)
        Map<String,String> map = new LinkedHashMap<>();
        for (var r : reps) map.put(r.original, r.replacement);

        String summary = "Anonymized " + reps.size() + " spans; types=" +
                merged.stream().map(h -> h.type).distinct().toList();

        return AnonymizationResponse.builder()
                .anonymizedText(anonymized)
                .replacements(map)
                .summary(summary)
                .build();
    }

    private static <T> List<T> concat(List<T> a, List<T> b) {
        List<T> out = new ArrayList<>(a.size() + b.size());
        out.addAll(a); out.addAll(b); return out;
    }
}