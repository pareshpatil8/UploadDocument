package com.rebit.aiutils.prompt;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
@ConditionalOnProperty(prefix = "app.prompt", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(PromptCompilerProperties.class)
public class PromptCompiler {

    private final PromptCompilerProperties props;

    public PromptCompiler(PromptCompilerProperties props) {
        this.props = props;
    }

    public CompiledPrompt compile(CompileRequest req) {
        Objects.requireNonNull(req, "CompileRequest is null");

        // 1) Normalize inputs & clamp length (air-gapped safety)
        String task = clamp(req.task());
        String context = clamp(Objects.toString(req.context(), ""));
        String department = Objects.toString(req.department(), "GENERAL").trim();
        PromptPatterns pattern = PromptPatterns.byNameOrDefault(req.pattern(), defaultPatternForPurpose(req.purpose()));

        // 2) Build SYSTEM (department-aware guardrails)
        String system = """
            You are an expert assistant for the %s department.
            Follow local policies: no external data exposure; do not leak secrets; cite assumptions.
            Style: %s
            """.formatted(department, props.getStyle()).trim();

        // 3) Build INSTRUCTIONS (user message)
        String instructions = """
            Task:
            %s

            Context:
            %s

            Pattern:
            %s

            Requirements:
            - Be explicit about assumptions and missing inputs
            - Return ONLY the format defined below
            """.formatted(task, context, pattern.instructions).trim();

        // 4) Output Format
        String outputFormat = switch (props.getDefaultOutput().toLowerCase()) {
            case "markdown" -> """
               ### answer
               ...
               ### assumptions
               - ...
               ### risks
               - ...
               ### next_steps
               - ...
               """.trim();
            case "plain" -> "Return a concise, plain-text answer followed by assumptions, risks, and next steps.";
            default -> pattern.defaultJsonSchema; // json
        };

        // 5) Constraints (guardrails)
        List<String> constraints = new ArrayList<>();
        if (props.isGuardrailsNoExternalData())
            constraints.add("No external data exposure. Use only provided context.");
        if (props.isGuardrailsAskForMissingInputs())
            constraints.add("If information is missing, ask targeted questions first.");

        String constraintsStr = String.join(" ", constraints);

        // 6) Variables & Lint
        List<String> variables = PromptLinter.extractVariables(task + " " + context);
        List<String> lint = PromptLinter.lint(task, context, outputFormat, variables);

        // 7) Score
        var score = QualityScorer.score(task, context, outputFormat, lint);

        return new CompiledPrompt(system, instructions, constraintsStr, outputFormat, variables, List.of(), score, lint);
    }

    private String clamp(String s) {
        if (s == null) return "";
        if (s.length() <= props.getMaxChars()) return s;
        return s.substring(0, props.getMaxChars());
    }

    private PromptPatterns defaultPatternForPurpose(String purpose) {
        if (purpose == null) return PromptPatterns.SUMMARIZE;
        String p = purpose.trim().toLowerCase();
        if (p.contains("summary") || p.contains("summarize")) return PromptPatterns.SUMMARIZE;
        if (p.contains("extract")) return PromptPatterns.EXTRACT;
        if (p.contains("classif")) return PromptPatterns.CLASSIFY;
        if (p.contains("plan") || p.contains("roadmap")) return PromptPatterns.PLAN;
        if (p.contains("critique") || p.contains("review")) return PromptPatterns.CRITIQUE;
        if (p.contains("code") || p.contains("generate code")) return PromptPatterns.GENERATE_CODE;
        if (p.contains("convert") || p.contains("transform")) return PromptPatterns.CONVERT;
        if (p.contains("compare") || p.contains("tradeoff")) return PromptPatterns.COMPARE;
        return PromptPatterns.SUMMARIZE;
    }

    /** Lightweight request DTO you can map from your service/controller. */
    public record CompileRequest(
            String department,   // e.g., "Risk", "Compliance", "Engineering"
            String purpose,      // free text, used to pick default pattern
            String pattern,      // optional explicit pattern name (SUMMARIZE/EXTRACT/...)
            String task,         // the user's raw prompt
            String context       // optional context
    ) {}
}
