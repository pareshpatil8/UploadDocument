package com.rebit.aiutils.prompt;

import java.util.List;

public record CompiledPrompt(
        String system,
        String user,
        String constraints,
        String outputFormat,
        List<String> variables,         // detected placeholders like ${x} or {y}
        List<String> examples,          // few-shot examples if any
        QualityScore score,             // heuristic quality scores (0-100)
        List<String> lintWarnings       // linter messages
) {}
