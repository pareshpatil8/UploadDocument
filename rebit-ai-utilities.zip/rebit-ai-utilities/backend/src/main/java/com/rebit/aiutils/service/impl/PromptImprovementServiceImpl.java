package com.rebit.aiutils.service.impl;

import com.rebit.aiutils.dto.PromptDto;
import com.rebit.aiutils.dto.PromptImprovementRequest;
import com.rebit.aiutils.dto.PromptImprovementResponse;
import com.rebit.aiutils.service.PromptImprovementService;
import com.rebit.aiutils.service.PromptService;
import com.rebit.aiutils.prompt.PromptCompiler;
import com.rebit.aiutils.prompt.CompiledPrompt;
import com.rebit.aiutils.prompt.PromptCompiler.CompileRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PromptImprovementServiceImpl implements PromptImprovementService {
    
    private final PromptService promptService;
    private final PromptCompiler compiler;


    @Override
    public PromptImprovementResponse improvePrompt(PromptImprovementRequest request) {
        log.info("Improving prompt: {}", request.getOriginalPrompt().substring(0, Math.min(50, request.getOriginalPrompt().length())));

        CompileRequest creq = new CompileRequest("GENERAL" ,"improve", "EXTRACT", request.getOriginalPrompt(), request.getContext());
        CompiledPrompt cp = compiler.compile(creq);
        String improvedPrompt = """
        [SYSTEM]
        %s

        [INSTRUCTIONS]
        %s

        [CONSTRAINTS]
        %s

        [OUTPUT FORMAT]
        %s
        """.formatted(cp.system(), cp.user(), cp.constraints(), cp.outputFormat()).trim();

        String improvements = """
        Quality (0-100): clarity=%d, specificity=%d, structure=%d, safety=%d, overall=%d
        Variables detected: %s
        Lint warnings: %s
        """.formatted(
                cp.score().clarity(), cp.score().specificity(), cp.score().structure(), cp.score().safety(), cp.score().overall(),
                cp.variables(), cp.lintWarnings()
        ).trim();

        List<String> suggestions = generateSuggestions();
        List<PromptDto> matchingPrompts = promptService.findSimilarPrompts(request.getOriginalPrompt());
        
        return PromptImprovementResponse.builder()
                .improvedPrompt(improvedPrompt)
                .improvements(improvements)
                .suggestions(suggestions)
                .matchingPrompts(matchingPrompts)
                .build();
    }
    
    private List<String> generateSuggestions() {
        return Arrays.asList(
            "Consider adding specific examples to illustrate your requirements",
            "Specify the desired output format (JSON, Markdown, bullet points, etc.)",
            "Include any constraints or limitations that should be considered",
            "Add context about the intended audience or use case",
            "Consider breaking complex prompts into smaller, focused parts",
            "Use clear, actionable language with specific verbs",
            "Add success criteria to help evaluate the response quality"
        );
    }
}