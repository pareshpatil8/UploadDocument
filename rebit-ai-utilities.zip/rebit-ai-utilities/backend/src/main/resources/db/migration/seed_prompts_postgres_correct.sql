-- Seed data for prompts (matches provided DDL)
BEGIN;
INSERT INTO prompts (name, description, department, system_prompt, user_prompt_template, input_placeholders, output_format, constraints, tags, author_id, status, related_tools, created_at, updated_at) VALUES
('Product Management: Write a PRD for ${project_name} with RBI-specific NFRs', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Write a PRD for ${project_name} with RBI-specific NFRs

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Draft user stories with acceptance criteria for ${module}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Draft user stories with acceptance criteria for ${module}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Define OKRs and KPIs for ${project_name} Q${quarter}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Define OKRs and KPIs for ${project_name} Q${quarter}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: RICE prioritization matrix for backlog items', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'RICE prioritization matrix for backlog items

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Stakeholder map and communication plan', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Stakeholder map and communication plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Release notes for version ${version}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Release notes for version ${version}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Problem framing using JTBD for ${persona}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Problem framing using JTBD for ${persona}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Experiment plan (A/B) with success metrics', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Experiment plan (A/B) with success metrics

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Non-functional requirements checklist (RBI context)', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Non-functional requirements checklist (RBI context)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Risk register with mitigations', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Risk register with mitigations

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Dependency mapping across teams', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Dependency mapping across teams

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Feature comparison vs legacy system', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Feature comparison vs legacy system

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Value vs effort quadrant for top ${n} epics', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Value vs effort quadrant for top ${n} epics

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Product narrative / press release for launch', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Product narrative / press release for launch

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Data retention & archival strategy (RBI)', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Data retention & archival strategy (RBI)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Consent and privacy flow guidelines', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Consent and privacy flow guidelines

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Telemetry events spec for ${feature}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Telemetry events spec for ${feature}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Feature toggles roll-out plan', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Feature toggles roll-out plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Roadmap for next ${months} months', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Roadmap for next ${months} months

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Budget impact analysis for ${project_name}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Budget impact analysis for ${project_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Change management plan for ${department}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Change management plan for ${department}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: UAT scope definition with business owners', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'UAT scope definition with business owners

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Accessibility requirements summary', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Accessibility requirements summary

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Localization/i18n plan (English/Hindi)', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Localization/i18n plan (English/Hindi)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Incident postmortem template for product issues', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Incident postmortem template for product issues

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Customer journey map for ${persona}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Customer journey map for ${persona}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Service blueprint for ${use_case}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Service blueprint for ${use_case}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Exit criteria for MVP of ${feature}', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Exit criteria for MVP of ${feature}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Vendor assessment checklist', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Vendor assessment checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Product Management: Traceability matrix from BRD to UAT', 'Prompt template for product management in RBI context.', 'PRODUCT_MANAGEMENT', 'You are a senior Product Manager at ReBIT working on RBI systems. Prioritize user value, regulatory compliance, security, and measurable outcomes. Be specific and pragmatic.', 'Traceability matrix from BRD to UAT

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'prd,okr,roadmap,rbi,compliance', 1, 'ACTIVE', 'Jira, Confluence, Draw.io', NOW(), NOW()),
('Frontend Development: Angular component spec for ${feature}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Angular component spec for ${feature}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Responsive layout grid for ${page}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Responsive layout grid for ${page}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Reactive form with validation for ${form_name}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Reactive form with validation for ${form_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: HTTP interceptor for auth & error handling', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'HTTP interceptor for auth & error handling

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Route guards and lazy loading plan', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Route guards and lazy loading plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: NgRx store design for ${domain}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'NgRx store design for ${domain}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: i18n keys and extraction script', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'i18n keys and extraction script

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Web performance budget and Lighthouse targets', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Web performance budget and Lighthouse targets

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: A11y checklist (WCAG 2.1 AA) for ${page}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'A11y checklist (WCAG 2.1 AA) for ${page}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Reusable table component with sorting/filtering', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Reusable table component with sorting/filtering

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: File upload with size/type/virus checks stub', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'File upload with size/type/virus checks stub

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Charting spec using ${chart_lib}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Charting spec using ${chart_lib}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Dark mode + theme tokens proposal', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Dark mode + theme tokens proposal

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Unit tests (Jasmine/Karma) for ${component}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Unit tests (Jasmine/Karma) for ${component}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: End-to-end test plan for ${flow} with Selenium', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'End-to-end test plan for ${flow} with Selenium

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Security headers + CSP recommendations', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Security headers + CSP recommendations

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Input sanitization & XSS guard notes', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Input sanitization & XSS guard notes

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Global error handling and notifications', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Global error handling and notifications

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Stateful vs stateless component decision note', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Stateful vs stateless component decision note

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: SSR/Prerendering feasibility note', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'SSR/Prerendering feasibility note

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: WebSocket client wrapper for ${topic}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'WebSocket client wrapper for ${topic}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Offline caching strategy (PWA) sketch', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Offline caching strategy (PWA) sketch

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Bundle analysis & optimizer checklist', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Bundle analysis & optimizer checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: ESLint + Prettier configuration for workspace', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'ESLint + Prettier configuration for workspace

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Angular upgrade plan from ${from} to ${to}', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Angular upgrade plan from ${from} to ${to}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: UI asset pipeline (icons/fonts) plan', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'UI asset pipeline (icons/fonts) plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Visual regression approach', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Visual regression approach

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Accessibility testing with axe-core plan', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Accessibility testing with axe-core plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: Micro-frontend feasibility assessment', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'Micro-frontend feasibility assessment

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Frontend Development: UI handoff checklist from Figma', 'Prompt template for frontend development in RBI context.', 'FRONTEND_DEVELOPMENT', 'You are a senior Angular engineer building RBI-facing web apps. Emphasize accessibility, performance, security headers, and responsive UI.', 'UI handoff checklist from Figma

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'angular,rxjs,a11y,performance,security', 1, 'ACTIVE', 'Angular CLI, RxJS, ESLint', NOW(), NOW()),
('Backend Development: REST API contract for ${resource} (OpenAPI)', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'REST API contract for ${resource} (OpenAPI)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Entity and repository design for ${aggregate}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Entity and repository design for ${aggregate}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Service layering and DTO mappers plan', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Service layering and DTO mappers plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Exception handling & error codes catalog', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Exception handling & error codes catalog

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Input validation rules for ${endpoint}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Input validation rules for ${endpoint}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Authentication and RBAC policy (Spring Security)', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Authentication and RBAC policy (Spring Security)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Audit logging & trace IDs across services', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Audit logging & trace IDs across services

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Hibernate/JPA performance tuning checklist', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Hibernate/JPA performance tuning checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Hazelcast caching strategy for ${entity}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Hazelcast caching strategy for ${entity}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Async messaging with Kafka topic ${topic}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Async messaging with Kafka topic ${topic}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Idempotency key design for ${operation}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Idempotency key design for ${operation}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Transactional boundaries across ${services}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Transactional boundaries across ${services}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Resilience4j retries/circuit breakers config', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Resilience4j retries/circuit breakers config

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: OpenAPI generator + client SDK plan', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'OpenAPI generator + client SDK plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Database migration scripts with Flyway', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Database migration scripts with Flyway

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Observability: Micrometer metrics for ${domain}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Observability: Micrometer metrics for ${domain}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Centralized configuration via Spring Cloud Config', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Centralized configuration via Spring Cloud Config

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: File storage strategy and antivirus scanning', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'File storage strategy and antivirus scanning

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Encryption at rest and in transit notes', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Encryption at rest and in transit notes

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Data masking for logs and responses', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Data masking for logs and responses

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Batch job design for ${job_name}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Batch job design for ${job_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Pagination and sorting for ${endpoint}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Pagination and sorting for ${endpoint}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Rate limiting strategy for ${api}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Rate limiting strategy for ${api}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: API versioning approach', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'API versioning approach

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Performance test data generator', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Performance test data generator

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Testcontainers plan for integration tests', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Testcontainers plan for integration tests

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: API gateway policy sketch', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'API gateway policy sketch

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: SLA/SLO for ${service}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'SLA/SLO for ${service}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Backup & restore runbook for ${db}', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Backup & restore runbook for ${db}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Backend Development: Zero-downtime deployment strategy', 'Prompt template for backend development in RBI context.', 'BACKEND_DEVELOPMENT', 'You are a senior Java 21 + Spring Boot engineer. Emphasize clean architecture, security, performance, observability, and RBI data privacy.', 'Zero-downtime deployment strategy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'springboot,java21,api,security,performance', 1, 'ACTIVE', 'Spring Boot, JPA, Kafka, OpenAPI', NOW(), NOW()),
('Testing: Selenium test plan for ${user_flow}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Selenium test plan for ${user_flow}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Page Object Model structure for ${app}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Page Object Model structure for ${app}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Cross-browser matrix for ${app}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Cross-browser matrix for ${app}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: BDD feature file for ${feature}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'BDD feature file for ${feature}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Cucumber step definitions outline', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Cucumber step definitions outline

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Test data strategy (synthetic vs masked)', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Test data strategy (synthetic vs masked)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Regression suite selection rules', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Regression suite selection rules

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Smoke test checklist for ${release}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Smoke test checklist for ${release}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: JMeter performance test plan for ${api}', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'JMeter performance test plan for ${api}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Load profile and ramp-up settings', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Load profile and ramp-up settings

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Assertions and SLAs for perf tests', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Assertions and SLAs for perf tests

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Security testing checklist (OWASP)', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Security testing checklist (OWASP)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Accessibility testing plan', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Accessibility testing plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: API test cases using RestAssured', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'API test cases using RestAssured

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Contract testing with Spring Cloud Contract', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Contract testing with Spring Cloud Contract

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Test environment matrix and configs', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Test environment matrix and configs

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Mock/stub strategy for dependencies', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Mock/stub strategy for dependencies

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Failure triage workflow', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Failure triage workflow

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Defect taxonomy and severity levels', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Defect taxonomy and severity levels

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Coverage goals & measurement approach', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Coverage goals & measurement approach

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Visual regression plan', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Visual regression plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: UAT readiness checklist', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'UAT readiness checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Exploratory testing charters', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Exploratory testing charters

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Release sign-off template', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Release sign-off template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Automation ROI analysis', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Automation ROI analysis

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Flaky test detection playbook', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Flaky test detection playbook

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: CI gating rules for test stages', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'CI gating rules for test stages

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Test evidence and reporting template', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Test evidence and reporting template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Non-functional test checklist', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Non-functional test checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('Testing: Disaster recovery test scenario', 'Prompt template for testing in RBI context.', 'TESTING', 'You are a QA lead specializing in Selenium, JMeter, and BDD/Cucumber. Emphasize coverage, reproducibility, and evidence-based reporting.', 'Disaster recovery test scenario

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'selenium,jmeter,bdd,cucumber,qa', 1, 'ACTIVE', 'Selenium, JMeter, Cucumber, Allure', NOW(), NOW()),
('DevOps: BuildPiper pipeline for ${service}', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'BuildPiper pipeline for ${service}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: OpenShift Deployment/Service/Route YAML', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'OpenShift Deployment/Service/Route YAML

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Helm chart skeleton for ${service}', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Helm chart skeleton for ${service}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Image build strategy with S2I/Buildah', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Image build strategy with S2I/Buildah

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Image signing and SBOM generation', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Image signing and SBOM generation

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: OPA/SAST/Dependency scan steps', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'OPA/SAST/Dependency scan steps

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Secrets management with Vault/KMS', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Secrets management with Vault/KMS

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Blue/Green vs Rolling strategy', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Blue/Green vs Rolling strategy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Resource requests/limits for ${pod}', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Resource requests/limits for ${pod}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Health checks and readiness probes', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Health checks and readiness probes

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Log aggregation (EFK) config', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Log aggregation (EFK) config

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Metrics and alerting rules in Prometheus', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Metrics and alerting rules in Prometheus

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Backup policy for ${namespace}', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Backup policy for ${namespace}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Disaster recovery playbook', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Disaster recovery playbook

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Network policy for ${namespace}', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Network policy for ${namespace}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Ingress/Route TLS config (mTLS optional)', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Ingress/Route TLS config (mTLS optional)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: ConfigMap/Secret management plan', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'ConfigMap/Secret management plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Environment promotion strategy', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Environment promotion strategy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Pipeline approvals and audit trails', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Pipeline approvals and audit trails

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Artifact versioning and retention', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Artifact versioning and retention

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Canary rollout with % traffic', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Canary rollout with % traffic

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Namespace onboarding checklist', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Namespace onboarding checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Air-gapped mirror registry sync job', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Air-gapped mirror registry sync job

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Base image hardening checklist', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Base image hardening checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: CVE remediation process', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'CVE remediation process

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Cost monitoring and quota management', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Cost monitoring and quota management

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Infra-as-code folder structure', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Infra-as-code folder structure

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Runbook for pipeline failures', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Runbook for pipeline failures

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: Chaos engineering experiment outline', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'Chaos engineering experiment outline

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('DevOps: DR drill calendar & verification', 'Prompt template for devops in RBI context.', 'DEVOPS', 'You are a DevOps engineer using BuildPiper and OpenShift in air-gapped DCs. Emphasize reliable pipelines, security, and auditability.', 'DR drill calendar & verification

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'buildpiper,openshift,ci,cd,kubernetes', 1, 'ACTIVE', 'BuildPiper, OpenShift, Helm, Grafana', NOW(), NOW()),
('Usability: Figma wireframes for ${flow}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Figma wireframes for ${flow}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Design tokens for ${product}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Design tokens for ${product}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: WCAG 2.1 AA audit for ${screen}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'WCAG 2.1 AA audit for ${screen}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Component library spec (Angular handoff)', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Component library spec (Angular handoff)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Navigation IA for ${portal}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Navigation IA for ${portal}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Error states and empty states patterns', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Error states and empty states patterns

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Form usability for ${form_name}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Form usability for ${form_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Dashboard information hierarchy', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Dashboard information hierarchy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Microcopy guidelines for RBI apps', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Microcopy guidelines for RBI apps

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Tooltip and helper text strategy', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Tooltip and helper text strategy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Task flow diagram for ${persona}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Task flow diagram for ${persona}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Mobile breakpoints guidance', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Mobile breakpoints guidance

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Color contrast matrix & themes', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Color contrast matrix & themes

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Iconography and illustrations brief', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Iconography and illustrations brief

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Data table usability patterns', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Data table usability patterns

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Progressive disclosure guidelines', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Progressive disclosure guidelines

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Design review checklist', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Design review checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Prototype test script for ${task}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Prototype test script for ${task}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Heuristic evaluation report template', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Heuristic evaluation report template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Accessibility annotations in Figma', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Accessibility annotations in Figma

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Redlines/handoff spec for ${component}', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Redlines/handoff spec for ${component}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Localization style guide (EN/HI)', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Localization style guide (EN/HI)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Notification and toast patterns', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Notification and toast patterns

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Help & docs entry points UX', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Help & docs entry points UX

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Print/export UX considerations', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Print/export UX considerations

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Keyboard navigation map', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Keyboard navigation map

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Focus management spec', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Focus management spec

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: Error prevention guidelines', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'Error prevention guidelines

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: UX metrics (SUS/CSAT/Time-on-task)', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'UX metrics (SUS/CSAT/Time-on-task)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Usability: UX debt log template', 'Prompt template for usability in RBI context.', 'USABILITY', 'You are a UX lead using Figma for RBI apps. Emphasize clarity, accessibility (WCAG 2.1 AA), and enterprise workflows.', 'UX debt log template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'figma,design-system,a11y,ux,prototype', 1, 'ACTIVE', 'Figma, FigJam, WCAG tools', NOW(), NOW()),
('Business Analysis: BRD outline for ${project_name}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'BRD outline for ${project_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Context diagram & data flow', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Context diagram & data flow

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: BPMN process for ${process_name}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'BPMN process for ${process_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Stakeholder analysis (RACI)', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Stakeholder analysis (RACI)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Requirements elicitation plan', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Requirements elicitation plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Use case model for ${module}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Use case model for ${module}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Glossary and domain terms', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Glossary and domain terms

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Data field mapping (source→target)', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Data field mapping (source→target)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Traceability matrix (BRD→SRS→UAT)', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Traceability matrix (BRD→SRS→UAT)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Non-functional requirements grid', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Non-functional requirements grid

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Acceptance criteria catalog', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Acceptance criteria catalog

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Regulatory compliance mapping (RBI)', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Regulatory compliance mapping (RBI)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Risk assessment for ${initiative}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Risk assessment for ${initiative}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Assumption and constraint log', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Assumption and constraint log

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Current vs target state comparison', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Current vs target state comparison

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Interface specification for ${system}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Interface specification for ${system}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Report specification for ${report}', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Report specification for ${report}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Data quality rules', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Data quality rules

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Master data / reference data plan', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Master data / reference data plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Data migration strategy', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Data migration strategy

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Exception handling scenarios', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Exception handling scenarios

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: UAT plan and entry/exit criteria', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'UAT plan and entry/exit criteria

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Cutover plan outline', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Cutover plan outline

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Change request evaluation template', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Change request evaluation template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Vendor evaluation matrix', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Vendor evaluation matrix

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: SLA/SLO definitions', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'SLA/SLO definitions

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Operational readiness checklist', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Operational readiness checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Post-implementation review template', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Post-implementation review template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: BA communication plan', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'BA communication plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Business Analysis: Training plan & materials outline', 'Prompt template for business analysis in RBI context.', 'BUSINESS_ANALYSIS', 'You are a Business Analyst for RBI projects. Emphasize clear requirements, RBI policies, and traceability.', 'Training plan & materials outline

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'brd,bpmn,requirements,traceability,rbi', 1, 'ACTIVE', 'BPMN, UML, Excel', NOW(), NOW()),
('Project Management: WBS for ${project_name}', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'WBS for ${project_name}

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Schedule with milestones (Gantt)', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Schedule with milestones (Gantt)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Resource plan and roles', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Resource plan and roles

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: RAID log (Risks/Assumptions/Issues/Deps)', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'RAID log (Risks/Assumptions/Issues/Deps)

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Weekly status report template', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Weekly status report template

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Communication plan by audience', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Communication plan by audience

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Budget and cost baseline', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Budget and cost baseline

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Change control process', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Change control process

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Quality management plan', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Quality management plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Procurement plan', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Procurement plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Governance and steering cadence', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Governance and steering cadence

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: RACI matrix', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'RACI matrix

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Dependency map across teams', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Dependency map across teams

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Scope statement & success criteria', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Scope statement & success criteria

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Milestone acceptance criteria', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Milestone acceptance criteria

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Rollout & hypercare plan', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Rollout & hypercare plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Contingency & risk response plan', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Contingency & risk response plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Variance analysis approach', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Variance analysis approach

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: KPI dashboard definition', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'KPI dashboard definition

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Vendor management plan', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Vendor management plan

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Regulatory checkpoints calendar', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Regulatory checkpoints calendar

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Release train calendar', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Release train calendar

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Defect triage board workflow', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Defect triage board workflow

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Incident response playbook linkages', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Incident response playbook linkages

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Onboarding plan for new members', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Onboarding plan for new members

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Document control and versioning', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Document control and versioning

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Audit readiness checklist', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Audit readiness checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Meeting agenda templates', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Meeting agenda templates

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Lessons learned repository', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Lessons learned repository

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW()),
('Project Management: Project closure checklist', 'Prompt template for project management in RBI context.', 'PROJECT_MANAGEMENT', 'You are a project manager for RBI programs. Emphasize delivery predictability, risk control, and stakeholder transparency.', 'Project closure checklist

Context:
- Project: ${project_name}
- Module/Area: ${module}
- Audience: ${audience}
- Constraints: ${constraints}

Output strictly in the specified format.', '{"project_name": "Name of the RBI project/application", "module": "Module or domain area", "audience": "Primary audience for the output", "constraints": "Special constraints (e.g., air-gapped, compliance)", "version": "Optional version tag", "n": "Optional count", "persona": "Optional persona", "months": "Optional timeline in months", "chart_lib": "Optional chart library", "from": "Optional source version", "to": "Optional target version", "resource": "Optional API resource name", "aggregate": "Optional aggregate root/domain object", "endpoint": "Optional endpoint path", "entity": "Optional entity name", "topic": "Optional Kafka topic", "operation": "Idempotent operation label", "services": "Involved services", "service": "Service name", "pod": "Pod/workload name", "namespace": "OpenShift namespace", "flow": "User flow name", "form_name": "Form name", "component": "Component name", "domain": "Domain name", "page": "Page name", "user_flow": "End-to-end flow", "report": "Report name", "process_name": "Process", "job_name": "Batch job"}', '{ "answer": "string", "assumptions": ["string"], "risks": ["string"], "next_steps": ["string"] }', 'No external data exposure. Use only provided context. Ask for missing inputs.', 'wbs,schedule,risk,jira,governance', 1, 'ACTIVE', 'MS Project, Jira, Confluence', NOW(), NOW());
COMMIT;