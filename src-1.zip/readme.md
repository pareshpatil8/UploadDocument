# Payment Anomaly Detection System - Developer Guide

## 🚀 Project Overview

A production-ready, ML-powered fraud detection system for government payment transactions using ensemble machine learning models, real-time anomaly detection, and continuous learning through user feedback.

### 🎯 Key Features
- **Multi-Model Ensemble**: Isolation Forest, Enhanced Autoencoder, Temporal Pattern Analysis, Network Analysis
- **Real-time Detection**: Sub-second anomaly scoring for payment transactions
- **Continuous Learning**: User feedback-driven model improvement
- **Government-Specific**: Tailored for public sector payment patterns
- **Production-Ready**: Comprehensive monitoring, alerting, and error handling

---

## 🏗️ System Architecture

### Core Components
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Data Layer    │    │   ML/AI Layer   │    │  Service Layer  │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ • Transactions  │    │ • Isolation     │    │ • Detection     │
│ • Models        │    │   Forest        │    │ • Training      │
│ • Alerts        │    │ • Autoencoder   │    │ • Feedback      │
│ • Feedback      │    │ • Temporal      │    │ • Alerts        │
│ • Metrics       │    │ • Network       │    │ • Monitoring    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Technology Stack
- **Backend**: Spring Boot 3.x, Java 17+
- **ML Framework**: H2O.ai, Custom Isolation Forest
- **Database**: H2 (Dev), Oracle (Prod)
- **Frontend**: HTML5/CSS3/JavaScript, Chart.js
- **Scheduling**: Spring @Scheduled
- **Monitoring**: Spring Actuator, Prometheus
- **Security**: JWT Authentication

---

## 🚪 Main Entry/Exit Points

### 1. **Data Ingestion Entry Point**
```java
// Primary Entry: FileIngestionService.ingestFilesForTheDay()
@Scheduled(cron = "0 0 18 * * ?") // 6:00 PM daily
public void runFileIngestion() {
    fileIngestionService.ingestFilesForTheDay();
}
```

**Trigger Locations:**
- `FileIngestionJob.java` - Scheduled daily ingestion
- `POST /api/files/upload` - Manual file upload
- `FileIngestionService.java` - Core ingestion logic

**Configuration:**
```yaml
schedule:
  file-ingestion-cron: "0 0 18 * * ?"
file:
  ingestion:
    input-dir: /var/payment-data/incoming
    processed-dir: /var/payment-data/processed
    failed-dir: /var/payment-data/failed
```

### 2. **Model Training Entry Point**
```java
// Primary Entry: ModelTrainingService.trainAllModels()
@Scheduled(cron = "0 15 18 * * ?") // 6:15 PM daily
public void runNightlyTraining() {
    trainingService.trainAllModels();
}
```

**Trigger Locations:**
- `ModelTrainingJob.java` - Scheduled training
- `POST /api/training/run` - Manual training trigger
- `FeedbackLoopService.performScheduledRetraining()` - Feedback-based retraining

**Configuration:**
```yaml
schedule:
  model-training-cron: "0 15 18 * * ?"
model:
  dir: /var/models/
isolationForest:
  nTrees: 100
  subsample: 256
autoencoder:
  epochs: 100
  learningRate: 0.001
```

### 3. **Anomaly Detection Entry Point**
```java
// Primary Entry: AnomalyDetectionService.runDetectionOnRecentData()
@Scheduled(cron = "0 30 18 * * ?") // 6:30 PM daily
public void runDetection() {
    detectionService.runDetectionOnRecentData();
}
```

**Trigger Locations:**
- `AnomalyDetectionJob.java` - Scheduled detection
- `POST /api/detection/run` - Manual detection
- Real-time scoring via `scoreTransaction()`

**Configuration:**
```yaml
schedule:
  detection-cron: "0 30 18 * * ?"
model:
  ensemble:
    anomaly-threshold: 0.8
    weights:
      isolation-forest: 0.4
      autoencoder: 0.3
      temporal: 0.3
```

### 4. **User Feedback Entry Point**
```java
// Primary Entry: FeedbackController.submitFeedback()
@PostMapping("/submit")
public ResponseEntity<FeedbackProcessingResult> submitFeedback(
    @RequestParam String alertId,
    @RequestParam String userId,
    @RequestParam String feedbackType) {
    return feedbackLoopService.processFeedback(alertId, userId, type, comments);
}
```

**Trigger Locations:**
- `POST /api/feedback/submit` - User submits feedback
- Admin Console UI - Interactive feedback forms
- `FeedbackLoopService.performScheduledRetraining()` - Batch processing

**Configuration:**
```yaml
feedback:
  retraining-batch-size: 100
  auto-retrain-enabled: true
  retraining-schedule: "0 0 2 * * ?"
```

---

## 📊 Key Data Flows

### 1. **File → Transaction → Features → Scores → Alerts**
```
XML Files → XmlParsingService → PaymentTransaction → FeatureEngineering → ML Models → Ensemble → Alerts
```

### 2. **Feedback → Learning → Retraining → Deployment**
```
User Feedback → FeedbackLoopService → Enhanced Training Data → New Models → Performance Validation → Deployment
```

### 3. **Monitoring → Metrics → Dashboard → Actions**
```
Model Performance → PerformanceMonitoringService → Metrics Repository → Dashboard → Admin Actions
```

---

## 🛠️ Development Setup

### Prerequisites
```bash
# Java 17+
java -version

# Maven 3.6+
mvn -version

# Git
git --version
```

### Quick Start
```bash
# 1. Clone repository
git clone <repository-url>
cd payment-anomaly-detection

# 2. Build project
mvn clean install

# 3. Run with dev profile
mvn spring-boot:run -Dspring.profiles.active=dev

# 4. Access admin console
open http://localhost:8080/index.html
```

### Environment Configuration

#### Development (`application-dev.yml`)
```yaml
spring:
  datasource:
    url: jdbc:h2:mem:testdb
  jpa:
    show-sql: true
h2o:
  max-memory: 2g
logging:
  level:
    org.rebit.ai.fraud: DEBUG
```

#### Production (`application-prod.yml`)
```yaml
spring:
  datasource:
    url: jdbc:oracle:thin:@//prod-db:1521/ORCL
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
h2o:
  max-memory: 8g
logging:
  level:
    org.rebit.ai.fraud: INFO
```

---

## 🔌 Core APIs

### Data Ingestion APIs
```http
# Upload payment files
POST /api/files/upload
Content-Type: multipart/form-data
Files: payment1.xml, payment2.xml

# Trigger manual ingestion
POST /api/ingestion/trigger
```

### Training APIs
```http
# Train all models
POST /api/training/run

# Train specific model
POST /api/training/isolation-forest
POST /api/training/autoencoder

# Get training status
GET /api/training/status/{jobId}

# Get training statistics
GET /api/training/statistics
```

### Detection APIs
```http
# Run anomaly detection
POST /api/detection/run

# Get detection results
GET /api/detection/latest

# Score single transaction (real-time)
POST /api/detection/score
Content-Type: application/json
{
  "transactionId": "TX123",
  "amount": 50000,
  "beneficiaryAccount": "ACC456",
  ...
}
```

### Alert Management APIs
```http
# Get all alerts
GET /api/alerts

# Get alerts by transaction
GET /api/alerts/{transactionId}

# Filter alerts
GET /api/alerts?status=NEW&dateFrom=2025-01-01
```

### Feedback APIs
```http
# Submit feedback
POST /api/feedback/submit
Content-Type: application/x-www-form-urlencoded
alertId=123&userId=admin&feedbackType=FALSE_POSITIVE&comments=...

# Get uncertain cases for review
GET /api/feedback/uncertain-cases?maxCases=10

# Get feedback statistics
GET /api/feedback/statistics
```

### Model Management APIs
```http
# Get all models
GET /api/models

# Get active models
GET /api/models/active

# Get model performance
GET /api/models/{modelId}/performance
```

---

## 🏃‍♂️ Running the System

### 1. **Development Mode**
```bash
# Start with H2 database
mvn spring-boot:run -Dspring.profiles.active=dev

# Check health
curl http://localhost:8080/actuator/health

# Access admin console
open http://localhost:8080/index.html
```

### 2. **Production Mode**
```bash
# Build production JAR
mvn clean package -Pprod

# Run with external config
java -jar target/payment-anomaly-detection.jar \
  --spring.profiles.active=prod \
  --spring.config.location=classpath:/application.yml,file:/etc/app/application-prod.yml
```

### 3. **Docker Deployment**
```dockerfile
FROM openjdk:17-jre-slim
COPY target/payment-anomaly-detection.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

---

## 📁 Project Structure

```
src/main/java/org/rebit/ai/fraud/
├── config/                 # Configuration classes
│   ├── ApplicationConfig.java
│   ├── DatabaseConfig.java
│   ├── MLConfig.java
│   └── SecurityConfig.java
├── controller/             # REST API endpoints
│   ├── AnomalyAlertController.java
│   ├── FeedbackController.java
│   ├── TrainingController.java
│   └── DashboardController.java
├── service/               # Business logic services
│   ├── detection/         # Anomaly detection services
│   ├── training/          # Model training services
│   ├── feedback/          # Feedback loop services
│   ├── data/             # Data processing services
│   └── monitoring/        # Performance monitoring
├── model/                 # ML model implementations
│   ├── isolation/         # Isolation Forest models
│   ├── autoencoder/       # Autoencoder models
│   ├── temporal/          # Temporal analysis
│   └── ensemble/          # Ensemble logic
├── repository/            # Data access layer
├── entity/               # JPA entities
├── dto/                  # Data transfer objects
├── util/                 # Utility classes
└── scheduler/            # Scheduled jobs
```

---

## 🔧 Configuration Guide

### Critical Configuration Points

#### 1. **Model Parameters**
```yaml
isolationForest:
  nTrees: 100              # Number of trees (higher = better accuracy, slower training)
  subsample: 256           # Subsample size (should be < total training samples)
  contamination: 0.1       # Expected fraud rate (10%)
  
autoencoder:
  epochs: 100              # Training epochs (more = better fit, risk overfitting)
  learningRate: 0.001      # Learning rate (lower = stable, slower convergence)
  hidden-layers: [64, 32, 16, 32, 64]  # Network architecture
```

#### 2. **Ensemble Weights**
```yaml
model:
  ensemble:
    weights:
      isolation-forest: 0.4  # Tree-based anomaly detection
      autoencoder: 0.3       # Reconstruction-based detection  
      temporal: 0.3          # Time pattern analysis
      network: 0.2           # Network relationship analysis
    anomaly-threshold: 0.8   # Final decision threshold
```

#### 3. **Business Rules**
```yaml
false-positive:
  business-rule-weight: 0.3     # Impact of business rules
  min-historical-samples: 10    # Minimum samples for validation
  
temporal:
  pattern-detection:
    min-occurrences: 3          # Minimum pattern occurrences
    max-gap-days: 35            # Maximum gap in payment patterns
```

#### 4. **Performance Tuning**
```yaml
h2o:
  max-memory: 4g              # H2O memory allocation
  nthreads: -1                # Use all CPU cores

spring:
  task:
    execution:
      pool:
        core-size: 8           # Core thread pool size
        max-size: 16           # Maximum thread pool size
```

---

## 🚨 Troubleshooting Guide

### Common Issues

#### 1. **H2O Startup Issues**
```bash
# Symptoms: "H2O not ready" errors
# Check memory allocation
grep "max-memory" application.yml

# Verify H2O status
curl http://localhost:8080/actuator/health | jq '.components.h2o'

# Solution: Increase memory or restart
```

#### 2. **Model Training Failures**
```bash
# Symptoms: Training jobs fail
# Check logs
tail -f logs/application.log | grep "ModelTrainingService"

# Verify data availability
curl http://localhost:8080/api/models | jq '.[] | select(.active == true)'

# Solution: Check feature engineering and data quality
```

#### 3. **High False Positive Rate**
```bash
# Symptoms: Too many alerts
# Check current threshold
curl http://localhost:8080/api/dashboard | jq '.falsePositiveRate'

# Adjust ensemble threshold
# Edit application.yml: model.ensemble.anomaly-threshold

# Monitor feedback statistics
curl http://localhost:8080/api/feedback/statistics
```

#### 4. **Performance Issues**
```bash
# Symptoms: Slow processing
# Check thread pool utilization
curl http://localhost:8080/actuator/metrics/executor.active

# Monitor H2O memory usage
curl http://localhost:8080/api/training/h2o-status

# Solution: Tune thread pools or H2O memory
```

### Health Checks
```bash
# Overall system health
curl http://localhost:8080/actuator/health

# Check specific components
curl http://localhost:8080/actuator/health/db
curl http://localhost:8080/actuator/health/diskSpace

# Metrics endpoint
curl http://localhost:8080/actuator/metrics
```

---

## 📈 Monitoring & Observability

### Key Metrics to Monitor

#### 1. **Business Metrics**
- Alert volume (daily/weekly trends)
- False positive rate (<20%)
- Detection accuracy (>85%)
- User feedback rate (>30%)

#### 2. **Technical Metrics**
- Model training duration (<2 hours)
- API response times (<500ms)
- H2O memory usage (<80%)
- Database connection pool utilization

#### 3. **ML Model Metrics**
- Isolation Forest: Precision, Recall, F1-Score
- Autoencoder: Reconstruction error, Threshold accuracy
- Ensemble: Agreement rate, Confidence distribution

### Dashboard Access
```
http://localhost:8080/index.html
```

Key Dashboard Sections:
- **Overview**: System health, alert trends
- **Training**: Model performance, training history
- **Feedback**: User engagement, learning progress
- **Models**: Model comparison, performance metrics

---

## 🔐 Security Considerations

### Authentication
```yaml
security:
  jwt:
    secret: ${JWT_SECRET}
    expiration: 86400  # 24 hours
```

### API Security
- JWT tokens required for most endpoints
- Role-based access control (ADMIN, USER)
- Rate limiting on feedback endpoints
- Input validation and sanitization

### Data Protection
- Sensitive data hashing (account numbers)
- Audit logging for all actions
- Secure model file storage
- Database encryption at rest

---

## 🚀 Deployment Checklist

### Pre-Deployment
- [ ] Configure production database
- [ ] Set up file system directories
- [ ] Configure H2O memory allocation
- [ ] Set JWT secrets
- [ ] Configure monitoring endpoints
- [ ] Test backup/restore procedures

### Post-Deployment
- [ ] Verify health endpoints
- [ ] Run training jobs manually
- [ ] Test alert generation
- [ ] Validate feedback loop
- [ ] Monitor performance metrics
- [ ] Set up automated backups

---

## 📞 Support & Maintenance

### Regular Maintenance Tasks
1. **Daily**: Monitor dashboard, review alerts
2. **Weekly**: Check model performance metrics
3. **Monthly**: Review false positive rates, user feedback
4. **Quarterly**: Model retraining, performance benchmarking

### Getting Help
- Check logs: `/var/log/payment-detection/application.log`
- Review metrics: `http://localhost:8080/actuator/metrics`
- Monitor health: `http://localhost:8080/actuator/health`
- Dashboard insights: `http://localhost:8080/index.html`

### Contact Information
- **Technical Lead**: [Contact Information]
- **ML Engineer**: [Contact Information]
- **System Administrator**: [Contact Information]

---

## 📚 Additional Resources

### Documentation
- [ML Model Documentation](docs/models.md)
- [API Reference](docs/api.md)
- [Deployment Guide](docs/deployment.md)
- [Performance Tuning](docs/performance.md)

### External Dependencies
- [H2O.ai Documentation](https://docs.h2o.ai/)
- [Spring Boot Reference](https://docs.spring.io/spring-boot/docs/current/reference/html/)
- [Chart.js Documentation](https://www.chartjs.org/docs/)

---

**Version**: 2.0.0  
**Last Updated**: January 2025  
**Maintained By**: Rebit AI Development Team