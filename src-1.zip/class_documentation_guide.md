# Class Documentation Guide - Key Components

## 🧭 Navigation Guide for Developers

This guide provides a focused overview of the most important classes in the fraud detection system, organized by their role in the data pipeline.

---

## 📊 **Data Flow Classes**

### 1. **FileIngestionService.java** - Data Entry Point
```java
@Service
public class FileIngestionService {
    public void ingestFilesForTheDay()  // Main entry point
}
```
**Purpose**: Primary entry point for payment data  
**Key Methods**:
- `ingestFilesForTheDay()` - Scheduled file processing
- File validation and parsing  
**Integration Points**:
- Called by: `FileIngestionJob.java`
- Calls: `XmlParsingService.java`
- Outputs to: `PaymentTransaction` entities

### 2. **XmlParsingService.java** - Data Parsing
```java
@Service 
public class XmlParsingService {
    public PaymentXML parse(File xmlFile)  // Core parsing logic
}
```
**Purpose**: Parse government payment XML files  
**Key Classes**: `PaymentXML.java`, `CstmrCdtTrfInitn.java`, `CdtTrfTxInf.java`  
**Integration Points**:
- Called by: `FileIngestionService.java`
- Outputs: Structured payment data

### 3. **FeatureEngineeringService.java** - Feature Creation
```java
@Service
public class FeatureEngineeringService {
    public FeatureVectorDTO extractFeatures(PaymentTransactionDTO tx)
    public Map<String, Double> extractGovernmentSpecificFeatures(PaymentTransactionDTO tx)
}
```
**Purpose**: Transform raw payment data into ML-ready features  
**Key Features Created**:
- Amount-based features (round amounts, size categories)
- Beneficiary features (institutional vs personal)
- Entity-specific features (central vs state)
**Integration Points**:
- Called by: `AnomalyDetectionService.java`, `ModelTrainingService.java`
- Inputs: `PaymentTransactionDTO`
- Outputs: `FeatureVectorDTO`

---

## 🤖 **ML Model Classes**

### 4. **IsolationForestModelWrapper.java** - Enhanced Tree-Based Detection
```java
@Component
public class IsolationForestModelWrapper {
    public void train(List<Map<String, Double>> featureList)
    public double predict(Map<String, Double> featureVector)
    public FeatureValidationResult validateFeatures(Map<String, Double> features)
}
```
**Purpose**: Advanced isolation forest with feature validation  
**Key Features**:
- Feature validation and cleaning
- Outlier clipping and missing value imputation
- Feature importance calculation
- Cross-validation support
**Integration Points**:
- Uses: `EnhancedIsolationForest.java`
- Called by: `ModelTrainingService.java`, `AnomalyDetectionService.java`

### 5. **EnhancedAutoencoderWrapper.java** - Neural Network Detection
```java
public class EnhancedAutoencoderWrapper {
    public void train(Frame frame, int epochs, double learningRate, List<String> featureNames)
    public double scoreEnhanced(Frame frame)
    public AutoencoderExplanation explainPrediction(Frame frame)
}
```
**Purpose**: Deep learning autoencoder for reconstruction-based anomaly detection  
**Key Features**:
- Adaptive architecture based on data
- Multi-objective scoring (reconstruction + latent analysis)
- Anomaly explanation capabilities
- Performance monitoring
**Integration Points**:
- Uses: H2O Deep Learning framework
- Called by: `ModelTrainingService.java`, `AnomalyDetectionService.java`

### 6. **TemporalPatternService.java** - Time-Based Analysis
```java
@Service
public class TemporalPatternService {
    public double combinedTemporalAnomalyScore(...)
    public boolean isExpectedPattern(LocalDate txnDate, List<LocalDate> historicalDates, int periodDays)
    public double beneficiaryPaymentPatternAnomaly(...)
}
```
**Purpose**: Detect temporal anomalies in payment patterns  
**Key Features**:
- Seasonal decomposition
- Business day/calendar awareness
- Payment frequency analysis
- Pattern detection (weekly, monthly, fiscal cycles)
**Integration Points**:
- Called by: `AnomalyDetectionService.java`
- Uses: Apache Commons Math for statistical analysis

### 7. **EnsembleIntegrationService.java** - Score Combination
```java
@Service
public class EnsembleIntegrationService {
    public double ensembleScore(double isoScore, double autoScore, double tempScore, 
                               double networkScore, double amount, String entityId)
    public void updateEntityWeights(String entityId, ...)
}
```
**Purpose**: Combine individual model scores into final decision  
**Key Features**:
- Weighted ensemble with configurable weights
- Amount-based threshold adjustment
- Model agreement bonus
- Entity-specific weight learning
**Integration Points**:
- Called by: `AnomalyDetectionService.java`
- Uses scores from all individual models

---

## 🎯 **Core Service Classes**

### 8. **AnomalyDetectionService.java** - Main Detection Engine
```java
@Service
public class AnomalyDetectionService {
    public double scoreTransaction(FeatureVectorDTO fv, ...)  // Real-time scoring
    public void runDetectionOnRecentData()  // Batch detection
}
```
**Purpose**: Orchestrates the entire anomaly detection pipeline  
**Key Methods**:
- `scoreTransaction()` - Real-time single transaction scoring
- `runDetectionOnRecentData()` - Batch processing of recent transactions
**Integration Points**:
- Calls: All ML model classes, `FeatureEngineeringService`
- Called by: `AnomalyDetectionJob.java`, Detection APIs
- Outputs to: `AnomalyAlert` entities

### 9. **ModelTrainingService.java** - ML Training Pipeline
```java
@Service
public class ModelTrainingService {
    public void trainAllModels()  // Main training entry point
    public void retrainWithFeedback(String entityId, List<LabeledTrainingData> feedbackData)
    public Map<String, Object> getTrainingStatistics()
}
```
**Purpose**: Manage training lifecycle for all ML models  
**Key Features**:
- Enhanced model training with validation
- Cross-validation and metrics calculation
- Model versioning and status management
- Feedback-based retraining
**Integration Points**:
- Called by: `ModelTrainingJob.java`, Training APIs
- Uses: All ML model classes, `SimpleH2OManager`
- Outputs: Trained models, performance metrics

### 10. **FeedbackLoopService.java** - Continuous Learning
```java
@Service
public class FeedbackLoopService {
    public FeedbackProcessingResult processFeedback(String alertId, String userId, FeedbackType feedbackType, String comments)
    public List<ActiveLearningCase> identifyUncertainCases(int maxCases)
    public void performScheduledRetraining()
}
```
**Purpose**: Implement continuous learning from user feedback  
**Key Features**:
- Process user feedback (true/false positive, uncertain)
- Online learning with immediate threshold adjustments
- Active learning for uncertain cases
- Scheduled feedback-based retraining
**Integration Points**:
- Called by: `FeedbackController.java`, scheduled jobs
- Calls: `ModelTrainingService.java`
- Uses: `UserFeedback`, `AnomalyAlert` entities

---

## 🚨 **Alert & UI Classes**

### 11. **AlertGenerationService.java** - Alert Creation
```java
@Service
public class AlertGenerationService {
    public AnomalyAlert generateAlert(String transactionId, double score, String type, String notes)
}
```
**Purpose**: Create and format anomaly alerts  
**Integration Points**:
- Called by: `AnomalyDetectionService.java`
- Outputs: `AnomalyAlert` entities

### 12. **FeedbackController.java** - User Interaction API
```java
@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {
    @PostMapping("/submit")
    public ResponseEntity<FeedbackProcessingResult> submitFeedback(...)
    
    @GetMapping("/uncertain-cases")
    public ResponseEntity<List<ActiveLearningCase>> getUncertainCases(...)
}
```
**Purpose**: REST API for user feedback and active learning  
**Key Endpoints**:
- `POST /submit` - Submit user feedback on alerts
- `GET /uncertain-cases` - Get cases needing user review
- `GET /statistics` - Feedback analytics
**Integration Points**:
- Calls: `FeedbackLoopService.java`
- Used by: Admin console UI

---

## ⚙️ **Infrastructure Classes**

### 13. **SimpleH2OManager.java** - H2O Lifecycle Management
```java
@Component
public class SimpleH2OManager {
    public synchronized void startH2O()
    public Frame loadCSVToFrame(String csvPath)
    public H2OInfo getH2OInfo()
}
```
**Purpose**: Manage H2O cluster lifecycle for autoencoder training  
**Key Features**:
- H2O startup/shutdown management
- Memory and thread configuration
- CSV to H2O Frame conversion
- Health monitoring
**Integration Points**:
- Used by: `ModelTrainingService.java`, `AutoencoderUtil.java`

### 14. **PerformanceMonitoringService.java** - System Monitoring
```java
@Service 
public class PerformanceMonitoringService {
    @Scheduled(cron = "0 0 1 * * ?")
    public void calculateDailyMetrics()
    
    public Map<String, Object> getPerformanceMetrics(String entityId, int days)
}
```
**Purpose**: Monitor and calculate system performance metrics  
**Key Features**:
- Daily metrics calculation
- Model performance tracking
- Trend analysis
- Dashboard data preparation
**Integration Points**:
- Scheduled execution
- Used by: Dashboard APIs

---

## 🔧 **Configuration & Utility Classes**

### 15. **MLConfig.java** - ML Model Configuration
```java
@Configuration
public class MLConfig {
    // Isolation Forest parameters
    private int isolationForestNTrees;
    private int isolationForestSubsample;
    
    // Autoencoder parameters  
    private double autoencoderLearningRate;
    private int autoencoderEpochs;
    
    // Ensemble configuration
    private EnsembleConfig ensemble;
}
```
**Purpose**: Centralized configuration for ML parameters  
**Integration Points**:
- Used by: All ML model classes
- Configured via: `application.yml`

### 16. **FalsePositiveReductionService.java** - Noise Reduction
```java
@Service
public class FalsePositiveReductionService {
    public ProcessedFeatures reduceNoiseAndFalsePositives(PaymentTransactionDTO transaction, 
                                                          FeatureVectorDTO originalFeatures,
                                                          List<PaymentTransaction> historicalTransactions)
}
```
**Purpose**: Reduce false positives through business rules and context validation  
**Key Features**:
- Robust preprocessing and outlier handling
- Business rule application
- Contextual validation
- Semi-supervised learning techniques
**Integration Points**:
- Called by: `AnomalyDetectionService.java`
- Enhances feature quality before ML scoring

---

## 📋 **Scheduled Job Classes**

### 17. **Job Orchestration Classes**
```java
// File processing
@Component
public class FileIngestionJob {
    @Scheduled(cron = "${schedule.file-ingestion-cron}")
    public void runFileIngestion()
}

// Model training  
@Component  
public class ModelTrainingJob {
    @Scheduled(cron = "${schedule.model-training-cron}")
    public void runNightlyTraining()
}

// Anomaly detection
@Component
public class AnomalyDetectionJob {
    @Scheduled(cron = "${schedule.detection-cron}")  
    public void runDetection()
}
```
**Purpose**: Orchestrate automated system operations  
**Schedule**: Configured via `application.yml` cron expressions  
**Integration Points**: Call respective service classes

---

## 🏗️ **Data Model Classes**

### 18. **Core Entity Classes**
```java
// Main transaction entity
@Entity
public class PaymentTransaction {
    private String transactionId;
    private String sourceEntity;
    private Double amount;
    private String beneficiaryAccount;
    // ... other fields
}

// Alert storage
@Entity  
public class AnomalyAlert {
    private Long alertId;
    private String transactionId;
    private Double alertScore;
    private String alertType;
    // ... other fields
}

// User feedback storage
@Entity
public class UserFeedback {
    private Long feedbackId;
    private Long alertId;
    private String feedbackType;  // TRUE_POSITIVE, FALSE_POSITIVE, UNCERTAIN
    // ... other fields
}

// Model metadata
@Entity
public class AnomalyModel {
    private Long modelId;
    private String entityId;
    private String modelType;
    private LocalDate trainingDate;
    private String filePath;
    private Boolean active;
    // ... other fields
}
```

---

## 🎯 **Quick Navigation Map**

### **I want to...**

| **Task** | **Start Here** | **Key Classes** |
|----------|----------------|-----------------|
| Add new payment data | `FileIngestionService.java` | `XmlParsingService`, `PaymentTransaction` |
| Modify ML features | `FeatureEngineeringService.java` | `FeatureVectorDTO`, Model wrappers |
| Adjust detection logic | `AnomalyDetectionService.java` | `EnsembleIntegrationService`, Model classes |
| Change ensemble weights | `EnsembleIntegrationService.java` | `MLConfig`, `application.yml` |
| Add business rules | `FalsePositiveReductionService.java` | Business rule methods |
| Handle user feedback | `FeedbackController.java` | `FeedbackLoopService` |
| Monitor performance | `PerformanceMonitoringService.java` | Dashboard controllers |
| Configure models | `MLConfig.java` | `application.yml`, Model wrappers |
| Schedule operations | Job classes (`*Job.java`) | Service classes |
| Debug H2O issues | `SimpleH2OManager.java` | `AutoencoderUtil` |

### **Common Development Patterns**

1. **Adding New Features**: Modify `FeatureEngineeringService` → Update feature order in config → Retrain models
2. **Adjusting Thresholds**: Update `application.yml` → Restart application → Monitor results  
3. **Adding Business Rules**: Extend `FalsePositiveReductionService` → Test with historical data
4. **Improving Models**: Modify model wrapper classes → Update training pipeline → Validate performance
5. **Adding Monitoring**: Extend `PerformanceMonitoringService` → Update dashboard → Configure alerts

---

This guide provides the essential roadmap for developers to understand and modify the fraud detection system effectively. Each class is designed with clear separation of concerns and well-defined integration points.