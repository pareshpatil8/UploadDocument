// Enhanced EnsembleIntegrationService.java
package org.rebit.ai.fraud.model.ensemble;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class EnsembleIntegrationService {

    private static final Logger logger = LoggerFactory.getLogger(EnsembleIntegrationService.class);

    @Value("${model.ensemble.weights.isolation-forest:0.4}")
    private double isolationForestWeight;

    @Value("${model.ensemble.weights.autoencoder:0.3}")
    private double autoencoderWeight;

    @Value("${model.ensemble.weights.temporal:0.3}")
    private double temporalWeight;

    @Value("${model.ensemble.weights.network:0.2}")
    private double networkWeight;

    @Value("${model.ensemble.anomaly-threshold:0.8}")
    private double anomalyThreshold;

    @Value("${ensemble.amount.threshold.very-high:10000000}")
    private double veryHighThreshold;

    @Value("${ensemble.amount.threshold.high:1000000}")
    private double highThreshold;

    @Value("${ensemble.amount.threshold.medium:100000}")
    private double mediumThreshold;

    @Value("${ensemble.amount.threshold.small:1000}")
    private double smallThreshold;

    @Value("${ensemble.amount.factor.very-high:0.6}")
    private double veryHighFactor;

    @Value("${ensemble.amount.factor.high:0.7}")
    private double highFactor;

    @Value("${ensemble.amount.factor.medium:0.85}")
    private double mediumFactor;

    @Value("${ensemble.amount.factor.small:1.2}")
    private double smallFactor;


    // Dynamic weight adjustments per entity
    private final Map<String, EntityWeights> entitySpecificWeights = new ConcurrentHashMap<>();

    /**
     * Advanced weighted ensemble with dynamic score adjustment
     */
    public double ensembleScore(double isoScore, double autoScore, double tempScore,
                                double networkScore, double amount) {
        return ensembleScore(isoScore, autoScore, tempScore, networkScore, amount, null);
    }

    public double ensembleScore(double isoScore, double autoScore, double tempScore,
                                double networkScore, double amount, String entityId) {

        // Get entity-specific weights or use defaults
        EntityWeights weights = getEntityWeights(entityId);

        // 1. Basic weighted average with configurable weights
        double baseScore = isoScore * weights.isolationForest +
                autoScore * weights.autoencoder +
                tempScore * weights.temporal +
                networkScore * weights.network;

        // 2. Adaptive threshold based on amount
        // Higher amounts get more scrutiny (lower threshold)
        double amountFactor = calculateAmountFactor(amount);

        // 3. Model agreement bonus
        // If multiple models agree on anomaly, increase score
        double agreementBonus = calculateAgreementBonus(isoScore, autoScore, tempScore, networkScore);

        // 4. Entity-specific adjustment
        double entityAdjustment = getEntityAdjustment(entityId);

        // Apply adjustments
        double adjustedScore = (baseScore * amountFactor + agreementBonus + entityAdjustment);

        // Cap at 1.0
        return Math.min(1.0, Math.max(0.0, adjustedScore));
    }

    private EntityWeights getEntityWeights(String entityId) {
        if (entityId != null && entitySpecificWeights.containsKey(entityId)) {
            return entitySpecificWeights.get(entityId);
        }
        return new EntityWeights(isolationForestWeight, autoencoderWeight, temporalWeight, networkWeight);
    }

    private double calculateAmountFactor(double amount) {
        if (amount > veryHighThreshold) {
            return veryHighFactor;
        } else if (amount > highThreshold) {
            return highFactor;
        } else if (amount > mediumThreshold) {
            return mediumFactor;
        } else if (amount < smallThreshold) {
            return smallFactor;
        }
        return 1.0;
    }

    private double calculateAgreementBonus(double isoScore, double autoScore, double tempScore, double networkScore) {
        double threshold = 0.7;
        int anomalyVotes = 0;

        if (isoScore > threshold) anomalyVotes++;
        if (autoScore > threshold) anomalyVotes++;
        if (tempScore > threshold) anomalyVotes++;
        if (networkScore > threshold) anomalyVotes++;

        switch (anomalyVotes) {
            case 4: return 0.20; // All models agree - very strong signal
            case 3: return 0.15; // Strong agreement
            case 2: return 0.05; // Moderate agreement
            default: return 0.0; // Weak or no agreement
        }
    }

    private double getEntityAdjustment(String entityId) {
        // This would be populated from feedback loop adjustments
        return 0.0; // Placeholder
    }

    /**
     * Update entity-specific weights based on feedback
     */
    public void updateEntityWeights(String entityId, double isoAdjustment, double autoAdjustment,
                                    double tempAdjustment, double networkAdjustment) {
        EntityWeights current = getEntityWeights(entityId);
        EntityWeights updated = new EntityWeights(
                Math.max(0.1, Math.min(0.8, current.isolationForest + isoAdjustment)),
                Math.max(0.1, Math.min(0.8, current.autoencoder + autoAdjustment)),
                Math.max(0.1, Math.min(0.8, current.temporal + tempAdjustment)),
                Math.max(0.1, Math.min(0.8, current.network + networkAdjustment))
        );

        entitySpecificWeights.put(entityId, updated);
        logger.info("Updated weights for entity {}: {}", entityId, updated);
    }

    private static class EntityWeights {
        final double isolationForest;
        final double autoencoder;
        final double temporal;
        final double network;

        EntityWeights(double isolationForest, double autoencoder, double temporal, double network) {
            // Normalize weights to sum to 1.0
            double sum = isolationForest + autoencoder + temporal + network;
            this.isolationForest = isolationForest / sum;
            this.autoencoder = autoencoder / sum;
            this.temporal = temporal / sum;
            this.network = network / sum;
        }

        @Override
        public String toString() {
            return String.format("IF:%.3f, AE:%.3f, T:%.3f, N:%.3f",
                    isolationForest, autoencoder, temporal, network);
        }
    }
}