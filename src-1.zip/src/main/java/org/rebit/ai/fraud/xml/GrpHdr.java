package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class GrpHdr {
    @XmlElement(name = "MsgId")
    private String msgId;

    @XmlElement(name = "CreDtTm")
    private String creDtTm;

    @XmlElement(name = "NbOfTxs")
    private Integer nbOfTxs;

    @XmlElement(name = "CtrlSum")
    private Double ctrlSum;

    @XmlElement(name = "InitgPty")
    private InitgPty initgPty;
    // getters/setters


    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getCreDtTm() {
        return creDtTm;
    }

    public void setCreDtTm(String creDtTm) {
        this.creDtTm = creDtTm;
    }

    public Integer getNbOfTxs() {
        return nbOfTxs;
    }

    public void setNbOfTxs(Integer nbOfTxs) {
        this.nbOfTxs = nbOfTxs;
    }

    public Double getCtrlSum() {
        return ctrlSum;
    }

    public void setCtrlSum(Double ctrlSum) {
        this.ctrlSum = ctrlSum;
    }

    public InitgPty getInitgPty() {
        return initgPty;
    }

    public void setInitgPty(InitgPty initgPty) {
        this.initgPty = initgPty;
    }
}
