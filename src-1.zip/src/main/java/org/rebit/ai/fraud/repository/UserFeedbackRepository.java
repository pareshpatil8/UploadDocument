// UserFeedbackRepository
package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.UserFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserFeedbackRepository extends JpaRepository<UserFeedback, Long> {
    Optional<UserFeedback> findByAlertIdAndUserId(Long alertId, String userId);

    List<UserFeedback> findByEntityIdAndFeedbackDateAfter(String entityId, LocalDateTime after);

    @Query("SELECT COUNT(f) FROM UserFeedback f WHERE f.entityId = :entityId AND f.feedbackDate > :after")
    long countByEntityIdAndFeedbackDateAfter(@Param("entityId") String entityId, @Param("after") LocalDateTime after);

    @Query("SELECT DISTINCT f.entityId FROM UserFeedback f WHERE f.feedbackDate > :cutoff " +
            "GROUP BY f.entityId HAVING COUNT(f) >= :minCount")
    List<String> findEntitiesWithMinimumFeedback(@Param("minCount") int minCount, @Param("cutoff") LocalDateTime cutoff);
    List<UserFeedback> findByAlertIdIn(List<Long> alertIds);
    List<UserFeedback> findByFeedbackDateAfter(LocalDateTime after);
    // Add these methods to AnomalyAlertRepository.java
    List<AnomalyAlert> findByDetectionDateAfter(LocalDateTime after);

    List<UserFeedback> findByFeedbackDateBetween(LocalDateTime dayStart, LocalDateTime dayEnd);

    List<UserFeedback> findByEntityIdAndFeedbackDateBetween(String entityId, LocalDateTime from, LocalDateTime to);
}