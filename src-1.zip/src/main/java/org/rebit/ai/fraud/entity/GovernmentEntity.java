package org.rebit.ai.fraud.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "government_entity")
public class GovernmentEntity {
    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Id
    private String entityId;

    private String entityName;
    private String entityType; // CENTRAL/STATE
    private Boolean active;

    // Add getters and setters
}
