package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.GovernmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GovernmentEntityRepository extends JpaRepository<GovernmentEntity, String> {
}
