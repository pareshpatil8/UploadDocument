package org.rebit.ai.fraud.constants;

public enum ModelType {
    ISOLATION_FOREST,
    AUTOENCODER,
    TEMPORAL
}
