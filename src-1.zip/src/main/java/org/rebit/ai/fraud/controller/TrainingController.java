package org.rebit.ai.fraud.controller;

import org.rebit.ai.fraud.service.training.ModelTrainingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/training")
public class TrainingController {

    @Autowired
    private ModelTrainingService trainingService;

    @PostMapping("/run")
    public String runTraining() {
        trainingService.trainAllModels();
        return "Training triggered.";
    }
}
