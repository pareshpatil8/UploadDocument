package org.rebit.ai.fraud.model.autoencoder;

import hex.deeplearning.DeepLearning;
import hex.deeplearning.DeepLearningModel;
import hex.deeplearning.DeepLearningModel.DeepLearningParameters;
import org.rebit.ai.fraud.exception.FraudDetectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import water.Key;
import water.fvec.Frame;
import water.fvec.Vec;
import water.H2O;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Enhanced Autoencoder with production-ready features:
 * - Dynamic architecture adaptation
 * - Multi-objective scoring (reconstruction + latent analysis)
 * - Anomaly explanation capabilities
 * - Performance monitoring
 */
public class EnhancedAutoencoderWrapper {
    private static final Logger logger = LoggerFactory.getLogger(EnhancedAutoencoderWrapper.class);

    private DeepLearningModel model;
    private DeepLearningModel latentSpaceModel; // For latent space analysis
    private List<String> featureNames;
    private Map<String, Double> reconstructionBaselines;
    private Map<String, Double> latentSpaceStatistics;
    private double anomalyThreshold;
    private boolean useAdaptiveThreshold = true;

    // Performance monitoring
    private Map<String, Double> performanceMetrics = new ConcurrentHashMap<>();
    private List<Double> recentScores = Collections.synchronizedList(new ArrayList<>());

    // Configuration
    private int[] hiddenLayers;
    private String activation;
    private double l1Regularization;
    private double l2Regularization;
    private double inputDropout;
    private double hiddenDropout;

    public EnhancedAutoencoderWrapper() {
        // Default configuration
        this.hiddenLayers = new int[]{64, 32, 16, 32, 64};
        this.activation = "Rectifier";
        this.l1Regularization = 0.001;
        this.l2Regularization = 0.001;
        this.inputDropout = 0.1;
        this.hiddenDropout = 0.2;
        this.reconstructionBaselines = new HashMap<>();
        this.latentSpaceStatistics = new HashMap<>();
    }

    /**
     * Enhanced training with adaptive architecture and regularization
     */
    public void train(Frame frame, int epochs, double learningRate, List<String> featureNames) {
        if (frame == null || frame.numRows() == 0) {
            throw new IllegalArgumentException("Training frame cannot be null or empty");
        }

        this.featureNames = new ArrayList<>(featureNames);
        logger.info("Starting enhanced autoencoder training with {} rows, {} features",
                frame.numRows(), frame.numCols());

        try {
            // Adapt architecture based on data characteristics
            adaptArchitecture(frame);

            // Primary autoencoder for reconstruction
            trainMainAutoencoder(frame, epochs, learningRate);

            // Latent space analyzer (smaller autoencoder for latent analysis)
            trainLatentSpaceAnalyzer(frame, epochs, learningRate);

            // Calculate baseline statistics
            calculateBaselines(frame);

            // Determine adaptive threshold
            if (useAdaptiveThreshold) {
                calculateAdaptiveThreshold(frame);
            }

            logger.info("Enhanced autoencoder training completed successfully");

        } catch (Exception e) {
            logger.error("Error during enhanced autoencoder training", e);
            throw new FraudDetectionException("Enhanced autoencoder training failed", e);
        }
    }

    private void adaptArchitecture(Frame frame) {
        int inputDim = (int) frame.numCols();
        long numSamples = frame.numRows();

        // Adapt architecture based on input dimensions and data size
        if (inputDim <= 10) {
            // Small feature set - simpler architecture
            this.hiddenLayers = new int[]{32, 16, 8, 16, 32};
        } else if (inputDim <= 50) {
            // Medium feature set - standard architecture
            this.hiddenLayers = new int[]{64, 32, 16, 32, 64};
        } else {
            // Large feature set - deeper architecture
            this.hiddenLayers = new int[]{128, 64, 32, 16, 32, 64, 128};
        }

        // Adjust regularization based on data size
        if (numSamples < 1000) {
            this.l1Regularization = 0.01; // Stronger regularization for small datasets
            this.l2Regularization = 0.01;
            this.hiddenDropout = 0.3;
        } else if (numSamples > 10000) {
            this.l1Regularization = 0.0001; // Lighter regularization for large datasets
            this.l2Regularization = 0.0001;
            this.hiddenDropout = 0.1;
        }

        logger.info("Adapted architecture: layers={}, l1={}, l2={}",
                Arrays.toString(hiddenLayers), l1Regularization, l2Regularization);
    }

    private void trainMainAutoencoder(Frame frame, int epochs, double learningRate) {
        DeepLearningParameters params = new DeepLearningParameters();
        params._train = frame._key;
        params._autoencoder = true;
        params._epochs = epochs;
        params._activation = getActivationFunction(activation);
        params._hidden = hiddenLayers;
        params._l1 = l1Regularization;
        params._l2 = l2Regularization;
        params._rate = learningRate;
        params._rate_annealing = 2e-6; // Learning rate decay

        // Enhanced regularization
        params._input_dropout_ratio = inputDropout;
        params._hidden_dropout_ratios = createDropoutArray(hiddenLayers.length);

        // Early stopping
        params._stopping_rounds = 10;
        params._stopping_tolerance = 0.001;
        params._stopping_metric = hex.ScoreKeeper.StoppingMetric.MSE;

        // Adaptive learning
        params._adaptive_rate = true;
        params._rho = 0.99;
        params._epsilon = 1e-8;

        DeepLearning job = new DeepLearning(params);
        this.model = job.trainModel().get();

        if (this.model == null) {
            throw new FraudDetectionException("Failed to train main autoencoder");
        }
    }

    private void trainLatentSpaceAnalyzer(Frame frame, int epochs, double learningRate) {
        // Train a smaller autoencoder for latent space analysis
        int bottleneckSize = Math.max(2, hiddenLayers[hiddenLayers.length / 2] / 2);
        int[] latentLayers = {hiddenLayers[0] / 2, bottleneckSize, hiddenLayers[0] / 2};

        DeepLearningParameters latentParams = new DeepLearningParameters();
        latentParams._train = frame._key;
        latentParams._autoencoder = true;
        latentParams._epochs = epochs / 2; // Fewer epochs for latent analyzer
        latentParams._activation = getActivationFunction(activation);
        latentParams._hidden = latentLayers;
        latentParams._l1 = l1Regularization * 0.5;
        latentParams._l2 = l2Regularization * 0.5;
        latentParams._rate = learningRate;

        DeepLearning latentJob = new DeepLearning(latentParams);
        this.latentSpaceModel = latentJob.trainModel().get();

        logger.info("Latent space analyzer trained with architecture: {}", Arrays.toString(latentLayers));
    }

    private double[] createDropoutArray(int length) {
        double[] dropouts = new double[length];
        for (int i = 0; i < length; i++) {
            // Gradually increase dropout towards middle layers
            double position = (double) i / (length - 1);
            dropouts[i] = hiddenDropout * (1.0 + Math.sin(Math.PI * position)) / 2.0;
        }
        return dropouts;
    }

    private void calculateBaselines(Frame frame) {
        logger.info("Calculating reconstruction baselines for each feature");

        // Calculate per-feature reconstruction baselines
        Frame reconstructed = null;
        try {
            reconstructed = model.scoreAutoEncoder(frame, Key.make(), false);

            for (int col = 0; col < frame.numCols(); col++) {
                String featureName = featureNames.get(col);

                double mse = 0.0;
                double mae = 0.0;
                long validCount = 0;

                for (long row = 0; row < frame.numRows(); row++) {
                    double original = frame.vec(col).at(row);
                    double reconstructedVal = reconstructed.vec(col).at(row);

                    if (!Double.isNaN(original) && !Double.isNaN(reconstructedVal)) {
                        double diff = original - reconstructedVal;
                        mse += diff * diff;
                        mae += Math.abs(diff);
                        validCount++;
                    }
                }

                if (validCount > 0) {
                    reconstructionBaselines.put(featureName + "_mse", mse / validCount);
                    reconstructionBaselines.put(featureName + "_mae", mae / validCount);
                }
            }

        } finally {
            if (reconstructed != null) {
                reconstructed.delete();
            }
        }

        // Calculate latent space statistics
        calculateLatentSpaceStatistics(frame);
    }

    private void calculateLatentSpaceStatistics(Frame frame) {
        if (latentSpaceModel == null) return;

        Frame latentSpace = null;
        try {
            // Get latent representations
            latentSpace = latentSpaceModel.scoreAutoEncoder(frame, Key.make(), true);

            // Calculate statistics for latent dimensions
            for (int col = 0; col < latentSpace.numCols(); col++) {
                Vec vec = latentSpace.vec(col);
                double mean = vec.mean();
                double stddev = vec.sigma();

                latentSpaceStatistics.put("latent_" + col + "_mean", mean);
                latentSpaceStatistics.put("latent_" + col + "_std", stddev);
            }

        } finally {
            if (latentSpace != null) {
                latentSpace.delete();
            }
        }
    }

    private void calculateAdaptiveThreshold(Frame frame) {
        // Calculate anomaly scores for training data to set threshold
        List<Double> trainingScores = new ArrayList<>();

        for (int row = 0; row < Math.min(1000, frame.numRows()); row++) {
            Frame singleRow = frame.subframe(row, row + 1);
            try {
                double score = scoreEnhanced(singleRow);
                trainingScores.add(score);
            } finally {
                singleRow.delete();
            }
        }

        // Set threshold at 95th percentile
        Collections.sort(trainingScores);
        int thresholdIndex = (int) (0.95 * trainingScores.size());
        this.anomalyThreshold = trainingScores.get(Math.min(thresholdIndex, trainingScores.size() - 1));

        logger.info("Adaptive threshold set to: {}", anomalyThreshold);
    }

    /**
     * Enhanced scoring with multiple anomaly indicators
     */
    public double scoreEnhanced(Frame frame) {
        if (frame == null || model == null) {
            throw new IllegalArgumentException("Frame or model cannot be null");
        }

        Frame reconstructed = null;
        Frame latentSpace = null;

        try {
            // 1. Reconstruction error
            reconstructed = model.scoreAutoEncoder(frame, Key.make(), false);
            double reconstructionScore = calculateReconstructionScore(frame, reconstructed);

            // 2. Latent space analysis
            double latentScore = 0.0;
            if (latentSpaceModel != null) {
                latentSpace = latentSpaceModel.scoreAutoEncoder(frame, Key.make(), true);
                latentScore = calculateLatentSpaceScore(latentSpace);
            }

            // 3. Feature-wise anomaly detection
            double featureWiseScore = calculateFeatureWiseScore(frame, reconstructed);

            // 4. Temporal consistency (if applicable)
            double temporalScore = calculateTemporalConsistency(frame);

            // Weighted combination
            double combinedScore = 0.4 * reconstructionScore +
                    0.25 * latentScore +
                    0.25 * featureWiseScore +
                    0.1 * temporalScore;

            // Update performance monitoring
            updatePerformanceMetrics(combinedScore, reconstructionScore, latentScore);

            return combinedScore;

        } catch (Exception e) {
            logger.error("Error during enhanced scoring", e);
            throw new FraudDetectionException("Enhanced scoring failed", e);
        } finally {
            if (reconstructed != null) reconstructed.delete();
            if (latentSpace != null) latentSpace.delete();
        }
    }

    private double calculateReconstructionScore(Frame original, Frame reconstructed) {
        double totalMSE = 0.0;
        int featureCount = 0;

        for (int col = 0; col < original.numCols(); col++) {
            double mse = 0.0;
            long validCount = 0;

            for (long row = 0; row < original.numRows(); row++) {
                double orig = original.vec(col).at(row);
                double recon = reconstructed.vec(col).at(row);

                if (!Double.isNaN(orig) && !Double.isNaN(recon)) {
                    double diff = orig - recon;
                    mse += diff * diff;
                    validCount++;
                }
            }

            if (validCount > 0) {
                mse /= validCount;

                // Normalize by baseline if available
                String baselineKey = featureNames.get(col) + "_mse";
                if (reconstructionBaselines.containsKey(baselineKey)) {
                    double baseline = reconstructionBaselines.get(baselineKey);
                    if (baseline > 0) {
                        mse = mse / baseline; // Relative error
                    }
                }

                totalMSE += mse;
                featureCount++;
            }
        }

        return featureCount > 0 ? totalMSE / featureCount : 0.0;
    }

    private double calculateLatentSpaceScore(Frame latentSpace) {
        double anomalyScore = 0.0;

        for (int col = 0; col < latentSpace.numCols(); col++) {
            for (long row = 0; row < latentSpace.numRows(); row++) {
                double value = latentSpace.vec(col).at(row);

                // Compare with expected latent space statistics
                String meanKey = "latent_" + col + "_mean";
                String stdKey = "latent_" + col + "_std";

                if (latentSpaceStatistics.containsKey(meanKey) && latentSpaceStatistics.containsKey(stdKey)) {
                    double mean = latentSpaceStatistics.get(meanKey);
                    double std = latentSpaceStatistics.get(stdKey);

                    if (std > 0) {
                        double zScore = Math.abs(value - mean) / std;
                        anomalyScore += Math.max(0, zScore - 2.0); // Anomalous if z-score > 2
                    }
                }
            }
        }

        return anomalyScore;
    }

    private double calculateFeatureWiseScore(Frame original, Frame reconstructed) {
        double maxFeatureAnomaly = 0.0;

        for (int col = 0; col < original.numCols(); col++) {
            for (long row = 0; row < original.numRows(); row++) {
                double orig = original.vec(col).at(row);
                double recon = reconstructed.vec(col).at(row);

                if (!Double.isNaN(orig) && !Double.isNaN(recon)) {
                    double relativeError = Math.abs(orig - recon) / (Math.abs(orig) + 1e-8);
                    maxFeatureAnomaly = Math.max(maxFeatureAnomaly, relativeError);
                }
            }
        }

        return maxFeatureAnomaly;
    }

    private double calculateTemporalConsistency(Frame frame) {
        // Placeholder for temporal analysis
        // In a real implementation, this would analyze temporal patterns
        return 0.0;
    }

    private void updatePerformanceMetrics(double combinedScore, double reconstructionScore, double latentScore) {
        synchronized (recentScores) {
            recentScores.add(combinedScore);

            // Keep only recent scores (last 1000)
            if (recentScores.size() > 1000) {
                recentScores.remove(0);
            }
        }

        // Update performance metrics
        performanceMetrics.put("mean_score", recentScores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0));
        performanceMetrics.put("max_score", recentScores.stream().mapToDouble(Double::doubleValue).max().orElse(0.0));
        performanceMetrics.put("reconstruction_score", reconstructionScore);
        performanceMetrics.put("latent_score", latentScore);
    }

    /**
     * Provides explanation for autoencoder anomaly detection
     */
    public AutoencoderExplanation explainPrediction(Frame frame) {
        Frame reconstructed = null;
        try {
            reconstructed = model.scoreAutoEncoder(frame, Key.make(), false);

            Map<String, Double> featureErrors = new HashMap<>();
            for (int col = 0; col < frame.numCols(); col++) {
                double orig = frame.vec(col).at(0); // Assuming single row
                double recon = reconstructed.vec(col).at(0);

                if (!Double.isNaN(orig) && !Double.isNaN(recon)) {
                    double relativeError = Math.abs(orig - recon) / (Math.abs(orig) + 1e-8);
                    featureErrors.put(featureNames.get(col), relativeError);
                }
            }

            double overallScore = scoreEnhanced(frame);
            boolean isAnomaly = overallScore > anomalyThreshold;

            return new AutoencoderExplanation(overallScore, isAnomaly, anomalyThreshold, featureErrors);

        } finally {
            if (reconstructed != null) reconstructed.delete();
        }
    }

    // Standard methods
    public double score(Frame frame) {
        return scoreEnhanced(frame);
    }

    public void save(String path) {
        if (model == null) {
            throw new IllegalStateException("Cannot save: model is null");
        }

        try {
            File directory = new File(path).getParentFile();
            if (!directory.exists() && !directory.mkdirs()) {
                throw new IOException("Failed to create directory: " + directory.getAbsolutePath());
            }

            logger.info("Saving enhanced autoencoder model to: {}", path);
            model.exportBinaryModel(path, true);

            // Save latent space model if available
            if (latentSpaceModel != null) {
                String latentPath = path.replace(".model", "_latent.model");
                latentSpaceModel.exportBinaryModel(latentPath, true);
            }

        } catch (IOException e) {
            logger.error("Error saving enhanced autoencoder model", e);
            throw new FraudDetectionException("Failed to save enhanced autoencoder model", e);
        }
    }

    public static EnhancedAutoencoderWrapper load(String path) {
        try {
            logger.info("Loading enhanced autoencoder model from: {}", path);
            File modelFile = Paths.get(path).toFile();
            if (!modelFile.exists()) {
                throw new IOException("Model file does not exist: " + path);
            }

            DeepLearningModel loaded = DeepLearningModel.importBinaryModel(modelFile.getAbsolutePath());
            if (loaded == null) {
                throw new IOException("Failed to load model from: " + path);
            }

            EnhancedAutoencoderWrapper wrapper = new EnhancedAutoencoderWrapper();
            wrapper.model = loaded;

            // Try to load latent space model
            String latentPath = path.replace(".model", "_latent.model");
            File latentFile = new File(latentPath);
            if (latentFile.exists()) {
                wrapper.latentSpaceModel = DeepLearningModel.importBinaryModel(latentPath);
            }

            return wrapper;

        } catch (IOException e) {
            logger.error("Error loading enhanced autoencoder model", e);
            throw new FraudDetectionException("Failed to load enhanced autoencoder model", e);
        }
    }

    private DeepLearningParameters.Activation getActivationFunction(String activationName) {
        try {
            return DeepLearningParameters.Activation.valueOf(activationName);
        } catch (IllegalArgumentException e) {
            logger.warn("Unknown activation function: {}. Using Rectifier as default.", activationName);
            return DeepLearningParameters.Activation.Rectifier;
        }
    }

    // Getters
    public Map<String, Double> getPerformanceMetrics() { return new HashMap<>(performanceMetrics); }
    public double getAnomalyThreshold() { return anomalyThreshold; }
    public void setAnomalyThreshold(double threshold) { this.anomalyThreshold = threshold; }

    /**
     * Explanation class for autoencoder predictions
     */
    public static class AutoencoderExplanation {
        private final double anomalyScore;
        private final boolean isAnomaly;
        private final double threshold;
        private final Map<String, Double> featureErrors;

        public AutoencoderExplanation(double anomalyScore, boolean isAnomaly, double threshold,
                                      Map<String, Double> featureErrors) {
            this.anomalyScore = anomalyScore;
            this.isAnomaly = isAnomaly;
            this.threshold = threshold;
            this.featureErrors = new HashMap<>(featureErrors);
        }

        public String getExplanation() {
            StringBuilder explanation = new StringBuilder();
            explanation.append(String.format("Autoencoder Score: %.4f (Threshold: %.4f) - %s\n",
                    anomalyScore, threshold, isAnomaly ? "ANOMALY" : "NORMAL"));

            explanation.append("Feature Reconstruction Errors:\n");

            featureErrors.entrySet().stream()
                    .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                    .limit(5)
                    .forEach(entry ->
                            explanation.append(String.format("  %s: %.4f\n", entry.getKey(), entry.getValue())));

            return explanation.toString();
        }

        // Getters
        public double getAnomalyScore() { return anomalyScore; }
        public boolean isAnomaly() { return isAnomaly; }
        public Map<String, Double> getFeatureErrors() { return new HashMap<>(featureErrors); }
    }
}