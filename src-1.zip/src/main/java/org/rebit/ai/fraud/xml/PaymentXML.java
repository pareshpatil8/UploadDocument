package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlRootElement(name = "RequestPayload")
@XmlAccessorType(XmlAccessType.FIELD)
public class PaymentXML {
    @XmlElement(name = "AppHdr")
    private AppHdr appHdr;

    @XmlElement(name = "Document")
    private DocumentXML document;
    // getters/setters


    public AppHdr getAppHdr() {
        return appHdr;
    }

    public void setAppHdr(AppHdr appHdr) {
        this.appHdr = appHdr;
    }

    public DocumentXML getDocument() {
        return document;
    }

    public void setDocument(DocumentXML document) {
        this.document = document;
    }
}
