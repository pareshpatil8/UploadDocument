package org.rebit.ai.fraud.service.feedback;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.rebit.ai.fraud.entity.UserFeedback;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.PaymentTransactionRepository;
import org.rebit.ai.fraud.repository.UserFeedbackRepository;
import org.rebit.ai.fraud.service.detection.AnomalyDetectionService;
import org.rebit.ai.fraud.service.training.ModelTrainingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Comprehensive feedback loop system that:
 * 1. Collects and validates user feedback
 * 2. Implements online learning for model adaptation
 * 3. Provides active learning for uncertain cases
 * 4. Generates explanations for better user validation
 * 5. Monitors feedback quality and system performance
 */
@Service
public class FeedbackLoopService {
    private static final Logger logger = LoggerFactory.getLogger(FeedbackLoopService.class);

    @Autowired
    private AnomalyAlertRepository alertRepository;

    @Autowired
    private PaymentTransactionRepository transactionRepository;

    @Autowired
    private UserFeedbackRepository feedbackRepository;

    @Autowired
    private ModelTrainingService modelTrainingService;

    @Autowired
    private AnomalyDetectionService detectionService;

    @Value("${feedback.min-confidence-threshold:0.6}")
    private double minConfidenceThreshold;

    @Value("${feedback.retraining-batch-size:100}")
    private int retrainingBatchSize;

    @Value("${feedback.auto-retrain-enabled:true}")
    private boolean autoRetrainEnabled;

    @Value("${feedback.explanation-detail-level:DETAILED}")
    private String explanationDetailLevel;

    // Cache for feedback patterns and model adjustments
    private final Map<String, FeedbackPattern> feedbackPatternsCache = new ConcurrentHashMap<>();
    private final Map<String, Double> entityThresholdAdjustments = new ConcurrentHashMap<>();

    /**
     * Main method to process user feedback and trigger model adaptation
     */
    @Transactional
    public FeedbackProcessingResult processFeedback(String alertId, String userId,
                                                    FeedbackType feedbackType, String comments) {

        logger.info("Processing feedback for alert {} from user {}: {}", alertId, userId, feedbackType);

        // 1. Validate and store feedback
        UserFeedback feedback = validateAndStoreFeedback(alertId, userId, feedbackType, comments);

        // 2. Update alert status
        AnomalyAlert alert = updateAlertStatus(alertId, feedbackType);

        // 3. Extract learning signals
        LearningSignals signals = extractLearningSignals(alert, feedback);

        // 4. Apply immediate model adjustments
        ModelAdjustmentResult adjustmentResult = applyImmediateAdjustments(signals);

        // 5. Queue for batch retraining if needed
        boolean queuedForRetraining = queueForRetraining(signals);

        // 6. Update feedback patterns
        updateFeedbackPatterns(alert, feedback);

        // 7. Generate explanation for the feedback
        String explanation = generateFeedbackExplanation(alert, feedback, signals);

        return new FeedbackProcessingResult(
                feedback.getFeedbackId(),
                adjustmentResult,
                queuedForRetraining,
                explanation,
                signals
        );
    }

    private UserFeedback validateAndStoreFeedback(String alertId, String userId,
                                                  FeedbackType feedbackType, String comments) {

        // Validate alert exists
        AnomalyAlert alert = alertRepository.findById(Long.parseLong(alertId))
                .orElseThrow(() -> new IllegalArgumentException("Alert not found: " + alertId));

        // Check for duplicate feedback
        Optional<UserFeedback> existingFeedback = feedbackRepository
                .findByAlertIdAndUserId(Long.parseLong(alertId), userId);

        if (existingFeedback.isPresent()) {
            logger.warn("Duplicate feedback detected for alert {} from user {}", alertId, userId);
            // Update existing feedback instead of creating new
            UserFeedback existing = existingFeedback.get();
            existing.setFeedbackType(feedbackType.name());
            existing.setComments(comments);
            existing.setFeedbackDate(LocalDateTime.now());
            return feedbackRepository.save(existing);
        }

        // Create new feedback
        UserFeedback feedback = new UserFeedback();
        feedback.setAlertId(Long.parseLong(alertId));
        feedback.setUserId(userId);
        feedback.setFeedbackType(feedbackType.name());
        feedback.setComments(comments);
        feedback.setFeedbackDate(LocalDateTime.now());
        feedback.setConfidenceScore(calculateUserConfidence(comments));

        return feedbackRepository.save(feedback);
    }

    private AnomalyAlert updateAlertStatus(String alertId, FeedbackType feedbackType) {
        AnomalyAlert alert = alertRepository.findById(Long.parseLong(alertId))
                .orElseThrow(() -> new IllegalArgumentException("Alert not found: " + alertId));

        switch (feedbackType) {
            case FALSE_POSITIVE:
                alert.setStatus("FALSE_POSITIVE");
                break;
            case TRUE_POSITIVE:
                alert.setStatus("CONFIRMED");
                break;
            case UNCERTAIN:
                alert.setStatus("UNDER_REVIEW");
                break;
        }

        alert.setReviewed(true);
        return alertRepository.save(alert);
    }

    private LearningSignals extractLearningSignals(AnomalyAlert alert, UserFeedback feedback) {
        // Get the associated transaction
        PaymentTransaction transaction = transactionRepository.findById(alert.getTransactionId())
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found: " + alert.getTransactionId()));

        // Extract features and context
        Map<String, Double> transactionFeatures = extractTransactionFeatures(transaction);
        double originalScore = alert.getAlertScore();
        FeedbackType feedbackType = FeedbackType.valueOf(feedback.getFeedbackType());

        // Calculate desired score adjustment
        double desiredScore = calculateDesiredScore(originalScore, feedbackType);
        double scoreAdjustment = desiredScore - originalScore;

        // Identify contributing factors
        List<String> contributingFactors = identifyContributingFactors(transaction, alert);

        // Extract entity-specific patterns
        String entityId = transaction.getSourceEntity();
        EntityPattern entityPattern = analyzeEntityPattern(entityId, feedbackType);

        return new LearningSignals(
                alert.getTransactionId(),
                entityId,
                feedbackType,
                originalScore,
                desiredScore,
                scoreAdjustment,
                transactionFeatures,
                contributingFactors,
                entityPattern,
                feedback.getConfidenceScore()
        );
    }

    private ModelAdjustmentResult applyImmediateAdjustments(LearningSignals signals) {
        List<String> adjustmentsMade = new ArrayList<>();

        // 1. Threshold adjustment for entity
        if (Math.abs(signals.getScoreAdjustment()) > 0.1) {
            String entityId = signals.getEntityId();
            double currentAdjustment = entityThresholdAdjustments.getOrDefault(entityId, 0.0);

            // Apply exponential moving average for threshold adjustment
            double alpha = 0.3; // Learning rate
            double newAdjustment = alpha * signals.getScoreAdjustment() + (1 - alpha) * currentAdjustment;

            entityThresholdAdjustments.put(entityId, newAdjustment);
            adjustmentsMade.add("Adjusted threshold for entity " + entityId + " by " + newAdjustment);

            logger.info("Applied threshold adjustment for entity {}: {}", entityId, newAdjustment);
        }

        // 2. Feature weight adjustment (simplified online learning)
        if (signals.getFeedbackType() == FeedbackType.FALSE_POSITIVE) {
            // Reduce influence of features that contributed to false positive
            for (String factor : signals.getContributingFactors()) {
                adjustFeatureWeight(factor, -0.05); // Reduce weight
                adjustmentsMade.add("Reduced weight for feature: " + factor);
            }
        } else if (signals.getFeedbackType() == FeedbackType.TRUE_POSITIVE) {
            // Increase influence of features that correctly identified anomaly
            for (String factor : signals.getContributingFactors()) {
                adjustFeatureWeight(factor, 0.03); // Increase weight
                adjustmentsMade.add("Increased weight for feature: " + factor);
            }
        }

        return new ModelAdjustmentResult(true, adjustmentsMade);
    }

    private boolean queueForRetraining(LearningSignals signals) {
        // Count recent feedback for this entity
        String entityId = signals.getEntityId();
        LocalDateTime cutoff = LocalDateTime.now().minusDays(7);

        long recentFeedbackCount = feedbackRepository.countByEntityIdAndFeedbackDateAfter(entityId, cutoff);

        if (recentFeedbackCount >= retrainingBatchSize && autoRetrainEnabled) {
            // Queue for batch retraining
            queueEntityForRetraining(entityId);
            logger.info("Queued entity {} for retraining after {} feedback instances", entityId, recentFeedbackCount);
            return true;
        }

        return false;
    }

    private void updateFeedbackPatterns(AnomalyAlert alert, UserFeedback feedback) {
        String patternKey = alert.getAlertType() + "_" + feedback.getFeedbackType();

        FeedbackPattern pattern = feedbackPatternsCache.computeIfAbsent(patternKey,
                k -> new FeedbackPattern());

        pattern.addFeedbackInstance(alert.getAlertScore(), feedback.getConfidenceScore());

        // Analyze patterns for insights
        if (pattern.getInstanceCount() % 10 == 0) {
            analyzeFeedbackPattern(patternKey, pattern);
        }
    }

    private String generateFeedbackExplanation(AnomalyAlert alert, UserFeedback feedback,
                                               LearningSignals signals) {
        StringBuilder explanation = new StringBuilder();

        explanation.append("Feedback processed successfully!\n\n");

        explanation.append("Alert Details:\n");
        explanation.append(String.format("- Transaction ID: %s\n", alert.getTransactionId()));
        explanation.append(String.format("- Original Score: %.4f\n", alert.getAlertScore()));
        explanation.append(String.format("- Your Feedback: %s\n", feedback.getFeedbackType()));

        if (signals.getScoreAdjustment() != 0) {
            explanation.append(String.format("- Score Adjustment Applied: %.4f\n", signals.getScoreAdjustment()));
        }

        explanation.append("\nImpact on Model:\n");
        if (!signals.getContributingFactors().isEmpty()) {
            explanation.append("- Contributing factors identified: ")
                    .append(String.join(", ", signals.getContributingFactors()))
                    .append("\n");
        }

        if (entityThresholdAdjustments.containsKey(signals.getEntityId())) {
            explanation.append(String.format("- Entity threshold adjusted by: %.4f\n",
                    entityThresholdAdjustments.get(signals.getEntityId())));
        }

        explanation.append("\nLearning Process:\n");
        if (FeedbackType.valueOf(feedback.getFeedbackType()) == FeedbackType.FALSE_POSITIVE) {
            explanation.append("- System will be less sensitive to similar patterns\n");
            explanation.append("- Feature weights adjusted to reduce similar false positives\n");
        } else if (FeedbackType.valueOf(feedback.getFeedbackType()) == FeedbackType.TRUE_POSITIVE) {
            explanation.append("- System will be more sensitive to similar patterns\n");
            explanation.append("- Feature weights strengthened for better detection\n");
        }

        return explanation.toString();
    }

    /**
     * Active learning component - identifies uncertain cases for user review
     */
    public List<ActiveLearningCase> identifyUncertainCases(int maxCases) {
        List<ActiveLearningCase> uncertainCases = new ArrayList<>();

        // Find recent alerts with scores near threshold
        LocalDateTime cutoff = LocalDateTime.now().minusDays(3);
        List<AnomalyAlert> recentAlerts = alertRepository.findByDetectionDateAfterAndReviewedFalse(cutoff);

        for (AnomalyAlert alert : recentAlerts) {
            // Calculate uncertainty score
            double uncertaintyScore = calculateUncertaintyScore(alert);

            if (uncertaintyScore > minConfidenceThreshold && uncertainCases.size() < maxCases) {
                String explanation = generateUncertaintyExplanation(alert);
                uncertainCases.add(new ActiveLearningCase(
                        alert.getAlertId(),
                        alert.getTransactionId(),
                        alert.getAlertScore(),
                        uncertaintyScore,
                        explanation
                ));
            }
        }

        // Sort by uncertainty score (highest first)
        uncertainCases.sort((a, b) -> Double.compare(b.getUncertaintyScore(), a.getUncertaintyScore()));

        return uncertainCases;
    }

    private double calculateUncertaintyScore(AnomalyAlert alert) {
        double score = alert.getAlertScore();
        double threshold = 0.8; // Default threshold

        // Get entity-specific threshold adjustment
        PaymentTransaction transaction = transactionRepository.findById(alert.getTransactionId()).orElse(null);
        if (transaction != null) {
            String entityId = transaction.getSourceEntity();
            double adjustment = entityThresholdAdjustments.getOrDefault(entityId, 0.0);
            threshold += adjustment;
        }

        // Calculate distance from threshold (uncertainty is highest near threshold)
        double distance = Math.abs(score - threshold);
        double maxUncertainty = 0.2; // Uncertainty zone around threshold

        return Math.max(0, 1.0 - (distance / maxUncertainty));
    }

    private String generateUncertaintyExplanation(AnomalyAlert alert) {
        StringBuilder explanation = new StringBuilder();

        explanation.append("This alert shows characteristics that make it difficult to classify:\n\n");

        PaymentTransaction transaction = transactionRepository.findById(alert.getTransactionId()).orElse(null);
        if (transaction != null) {
            explanation.append("Transaction Details:\n");
            explanation.append(String.format("- Amount: %.2f\n", transaction.getAmount()));
            explanation.append(String.format("- Beneficiary: %s\n", transaction.getBeneficiaryName()));
            explanation.append(String.format("- Date: %s\n", transaction.getTransactionDate()));

            // Add specific uncertainty reasons
            explanation.append("\nUncertainty Factors:\n");
            if (alert.getAlertScore() > 0.75 && alert.getAlertScore() < 0.85) {
                explanation.append("- Score is near decision boundary\n");
            }

            // Check for conflicting signals
            List<String> conflictingSignals = identifyConflictingSignals(transaction);
            if (!conflictingSignals.isEmpty()) {
                explanation.append("- Conflicting indicators: ")
                        .append(String.join(", ", conflictingSignals))
                        .append("\n");
            }
        }

        explanation.append("\nYour feedback will help improve detection accuracy for similar cases.");

        return explanation.toString();
    }

    /**
     * Batch retraining scheduler
     */
    @Scheduled(cron = "${feedback.retraining-schedule:0 0 2 * * ?}") // 2 AM daily
    @Async
    public void performScheduledRetraining() {
        if (!autoRetrainEnabled) {
            return;
        }

        logger.info("Starting scheduled model retraining based on feedback");

        // Get entities with sufficient feedback
        List<String> entitiesForRetraining = identifyEntitiesForRetraining();

        for (String entityId : entitiesForRetraining) {
            try {
                performEntityRetraining(entityId);
                logger.info("Completed retraining for entity: {}", entityId);
            } catch (Exception e) {
                logger.error("Error during retraining for entity {}: {}", entityId, e.getMessage());
            }
        }

        // Clear old feedback patterns
        cleanupOldFeedbackPatterns();

        logger.info("Scheduled retraining completed for {} entities", entitiesForRetraining.size());
    }

    private void performEntityRetraining(String entityId) {
        // Get feedback data for this entity
        LocalDateTime cutoff = LocalDateTime.now().minusDays(30);
        List<UserFeedback> recentFeedback = feedbackRepository.findByEntityIdAndFeedbackDateAfter(entityId, cutoff);

        if (recentFeedback.size() < retrainingBatchSize) {
            return;
        }

        // Prepare training data with feedback labels
        List<LabeledTrainingData> trainingData = prepareLabeledTrainingData(recentFeedback);

        // Retrain models with feedback-adjusted data
        modelTrainingService.retrainWithFeedback(entityId, trainingData);

        // Update threshold adjustments
        updateEntityThreshold(entityId, recentFeedback);
    }

    // Helper methods
    private double calculateUserConfidence(String comments) {
        if (comments == null || comments.trim().isEmpty()) {
            return 0.5; // Default confidence
        }

        // Simple heuristic based on comment length and keywords
        double confidence = 0.5;

        String lowerComments = comments.toLowerCase();

        // High confidence indicators
        if (lowerComments.contains("certain") || lowerComments.contains("definitely") ||
                lowerComments.contains("absolutely")) {
            confidence += 0.3;
        }

        // Low confidence indicators
        if (lowerComments.contains("maybe") || lowerComments.contains("possibly") ||
                lowerComments.contains("not sure")) {
            confidence -= 0.2;
        }

        // Length factor
        if (comments.length() > 50) {
            confidence += 0.1; // Longer comments suggest more thought
        }

        return Math.max(0.1, Math.min(1.0, confidence));
    }

    private double calculateDesiredScore(double originalScore, FeedbackType feedbackType) {
        switch (feedbackType) {
            case FALSE_POSITIVE:
                return Math.max(0.1, originalScore - 0.3); // Reduce score significantly
            case TRUE_POSITIVE:
                return Math.min(1.0, originalScore + 0.1); // Slight increase
            case UNCERTAIN:
                return originalScore; // No change
            default:
                return originalScore;
        }
    }

    private Map<String, Double> extractTransactionFeatures(PaymentTransaction transaction) {
        Map<String, Double> features = new HashMap<>();
        features.put("amount", transaction.getAmount());
        features.put("account_hash", (double) transaction.getBeneficiaryAccount().hashCode());
        features.put("bank_hash", (double) transaction.getBeneficiaryBank().hashCode());
        // Add more features as needed
        return features;
    }

    private List<String> identifyContributingFactors(PaymentTransaction transaction, AnomalyAlert alert) {
        List<String> factors = new ArrayList<>();

        // High amount
        if (transaction.getAmount() > 100000) {
            factors.add("high_amount");
        }

        // Round amount
        if (transaction.getAmount() % 1000 == 0) {
            factors.add("round_amount");
        }

        // Add more factor identification logic

        return factors;
    }

    private EntityPattern analyzeEntityPattern(String entityId, FeedbackType feedbackType) {
        // Analyze recent feedback patterns for this entity
        LocalDateTime cutoff = LocalDateTime.now().minusDays(30);
        List<UserFeedback> recentFeedback = feedbackRepository.findByEntityIdAndFeedbackDateAfter(entityId, cutoff);

        long falsePositives = recentFeedback.stream().filter(f -> "FALSE_POSITIVE".equals(f.getFeedbackType())).count();
        long truePositives = recentFeedback.stream().filter(f -> "TRUE_POSITIVE".equals(f.getFeedbackType())).count();

        return new EntityPattern(entityId, falsePositives, truePositives, recentFeedback.size());
    }

    private void adjustFeatureWeight(String feature, double adjustment) {
        // This would integrate with your model's feature weighting system
        logger.debug("Adjusting weight for feature {} by {}", feature, adjustment);
        // Implementation depends on your specific model architecture
    }

    private void queueEntityForRetraining(String entityId) {
        // Add to retraining queue - this could be a database table or message queue
        logger.info("Entity {} queued for retraining", entityId);
    }

    private void analyzeFeedbackPattern(String patternKey, FeedbackPattern pattern) {
        logger.info("Analyzing feedback pattern {}: {} instances", patternKey, pattern.getInstanceCount());
        // Implement pattern analysis logic
    }

    private List<String> identifyConflictingSignals(PaymentTransaction transaction) {
        List<String> conflicts = new ArrayList<>();

        // Example: High amount but to known beneficiary
        // Add logic to identify conflicting signals

        return conflicts;
    }

    private List<String> identifyEntitiesForRetraining() {
        // Find entities with sufficient recent feedback
        LocalDateTime cutoff = LocalDateTime.now().minusDays(7);
        return feedbackRepository.findEntitiesWithMinimumFeedback(retrainingBatchSize, cutoff);
    }

    private List<LabeledTrainingData> prepareLabeledTrainingData(List<UserFeedback> feedback) {
        // Convert feedback to labeled training data
        return feedback.stream()
                .map(this::convertFeedbackToTrainingData)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private LabeledTrainingData convertFeedbackToTrainingData(UserFeedback feedback) {
        // Implementation to convert feedback to training data format
        return null; // Placeholder
    }

    private void updateEntityThreshold(String entityId, List<UserFeedback> feedback) {
        // Calculate optimal threshold based on feedback
        // Implementation would analyze feedback patterns and adjust thresholds
    }

    private void cleanupOldFeedbackPatterns() {
        // Remove old patterns to prevent memory bloat
        // Keep patterns from last 30 days only
    }

    // Enums and Data Classes
    public enum FeedbackType {
        FALSE_POSITIVE, TRUE_POSITIVE, UNCERTAIN
    }

    public static class FeedbackProcessingResult {
        private final String feedbackId;
        private final ModelAdjustmentResult adjustmentResult;
        private final boolean queuedForRetraining;
        private final String explanation;
        private final LearningSignals signals;

        public FeedbackProcessingResult(Long feedbackId, ModelAdjustmentResult adjustmentResult,
                                        boolean queuedForRetraining, String explanation, LearningSignals signals) {
            this.feedbackId = String.valueOf(feedbackId);
            this.adjustmentResult = adjustmentResult;
            this.queuedForRetraining = queuedForRetraining;
            this.explanation = explanation;
            this.signals = signals;
        }

        // Getters
        public String getFeedbackId() { return feedbackId; }
        public ModelAdjustmentResult getAdjustmentResult() { return adjustmentResult; }
        public boolean isQueuedForRetraining() { return queuedForRetraining; }
        public String getExplanation() { return explanation; }
        public LearningSignals getSignals() { return signals; }
    }

    public static class LearningSignals {
        private final String transactionId;
        private final String entityId;
        private final FeedbackType feedbackType;
        private final double originalScore;
        private final double desiredScore;
        private final double scoreAdjustment;
        private final Map<String, Double> transactionFeatures;
        private final List<String> contributingFactors;
        private final EntityPattern entityPattern;
        private final double confidenceScore;

        public LearningSignals(String transactionId, String entityId, FeedbackType feedbackType,
                               double originalScore, double desiredScore, double scoreAdjustment,
                               Map<String, Double> transactionFeatures, List<String> contributingFactors,
                               EntityPattern entityPattern, double confidenceScore) {
            this.transactionId = transactionId;
            this.entityId = entityId;
            this.feedbackType = feedbackType;
            this.originalScore = originalScore;
            this.desiredScore = desiredScore;
            this.scoreAdjustment = scoreAdjustment;
            this.transactionFeatures = transactionFeatures;
            this.contributingFactors = contributingFactors;
            this.entityPattern = entityPattern;
            this.confidenceScore = confidenceScore;
        }

        // Getters
        public String getTransactionId() { return transactionId; }
        public String getEntityId() { return entityId; }
        public FeedbackType getFeedbackType() { return feedbackType; }
        public double getOriginalScore() { return originalScore; }
        public double getDesiredScore() { return desiredScore; }
        public double getScoreAdjustment() { return scoreAdjustment; }
        public Map<String, Double> getTransactionFeatures() { return transactionFeatures; }
        public List<String> getContributingFactors() { return contributingFactors; }
        public EntityPattern getEntityPattern() { return entityPattern; }
        public double getConfidenceScore() { return confidenceScore; }
    }

    public static class ModelAdjustmentResult {
        private final boolean success;
        private final List<String> adjustmentsMade;

        public ModelAdjustmentResult(boolean success, List<String> adjustmentsMade) {
            this.success = success;
            this.adjustmentsMade = adjustmentsMade;
        }

        public boolean isSuccess() { return success; }
        public List<String> getAdjustmentsMade() { return adjustmentsMade; }
    }

    public static class ActiveLearningCase {
        private final Long alertId;
        private final String transactionId;
        private final double alertScore;
        private final double uncertaintyScore;
        private final String explanation;

        public ActiveLearningCase(Long alertId, String transactionId, double alertScore,
                                  double uncertaintyScore, String explanation) {
            this.alertId = alertId;
            this.transactionId = transactionId;
            this.alertScore = alertScore;
            this.uncertaintyScore = uncertaintyScore;
            this.explanation = explanation;
        }

        // Getters
        public Long getAlertId() { return alertId; }
        public String getTransactionId() { return transactionId; }
        public double getAlertScore() { return alertScore; }
        public double getUncertaintyScore() { return uncertaintyScore; }
        public String getExplanation() { return explanation; }
    }

    public static class EntityPattern {
        private final String entityId;
        private final long falsePositives;
        private final long truePositives;
        private final int totalFeedback;

        public EntityPattern(String entityId, long falsePositives, long truePositives, int totalFeedback) {
            this.entityId = entityId;
            this.falsePositives = falsePositives;
            this.truePositives = truePositives;
            this.totalFeedback = totalFeedback;
        }

        public double getFalsePositiveRate() {
            return totalFeedback > 0 ? (double) falsePositives / totalFeedback : 0.0;
        }

        // Getters
        public String getEntityId() { return entityId; }
        public long getFalsePositives() { return falsePositives; }
        public long getTruePositives() { return truePositives; }
        public int getTotalFeedback() { return totalFeedback; }
    }

    public static class FeedbackPattern {
        private final List<Double> scores = new ArrayList<>();
        private final List<Double> confidences = new ArrayList<>();

        public void addFeedbackInstance(double score, double confidence) {
            scores.add(score);
            confidences.add(confidence);
        }

        public int getInstanceCount() { return scores.size(); }
        public List<Double> getScores() { return new ArrayList<>(scores); }
        public List<Double> getConfidences() { return new ArrayList<>(confidences); }
    }

    public static class LabeledTrainingData {
        private final Map<String, Double> features;
        private final boolean isAnomalous;
        private final double weight;

        public LabeledTrainingData(Map<String, Double> features, boolean isAnomalous, double weight) {
            this.features = features;
            this.isAnomalous = isAnomalous;
            this.weight = weight;
        }

        // Getters
        public Map<String, Double> getFeatures() { return features; }
        public boolean isAnomalous() { return isAnomalous; }
        public double getWeight() { return weight; }
    }
}