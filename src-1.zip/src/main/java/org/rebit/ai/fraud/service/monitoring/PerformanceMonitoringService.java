// Performance Monitoring Service
package org.rebit.ai.fraud.service.monitoring;

import org.rebit.ai.fraud.entity.ModelPerformanceMetrics;
import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.UserFeedback;
import org.rebit.ai.fraud.repository.ModelPerformanceMetricsRepository;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.UserFeedbackRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PerformanceMonitoringService {
    private static final Logger logger = LoggerFactory.getLogger(PerformanceMonitoringService.class);

    @Autowired
    private ModelPerformanceMetricsRepository metricsRepository;

    @Autowired
    private AnomalyAlertRepository alertRepository;

    @Autowired
    private UserFeedbackRepository feedbackRepository;

    /**
     * Calculate and store daily performance metrics
     */
    @Scheduled(cron = "0 0 1 * * ?") // 1 AM daily
    public void calculateDailyMetrics() {
        logger.info("Starting daily performance metrics calculation");

        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        LocalDateTime dayBeforeYesterday = yesterday.minusDays(1);

        // Get alerts from yesterday
        List<AnomalyAlert> dailyAlerts = alertRepository.findByDetectionDateBetween(
                dayBeforeYesterday, yesterday);

        if (dailyAlerts.isEmpty()) {
            logger.info("No alerts found for metrics calculation");
            return;
        }

        // Calculate metrics by entity
        Map<String, List<AnomalyAlert>> alertsByEntity = groupAlertsByEntity(dailyAlerts);

        for (Map.Entry<String, List<AnomalyAlert>> entry : alertsByEntity.entrySet()) {
            String entityId = entry.getKey();
            List<AnomalyAlert> entityAlerts = entry.getValue();

            calculateAndStoreEntityMetrics(entityId, entityAlerts, yesterday);
        }

        // Calculate overall system metrics
        calculateAndStoreSystemMetrics(dailyAlerts, yesterday);

        logger.info("Completed daily performance metrics calculation for {} entities",
                alertsByEntity.size());
    }

    private Map<String, List<AnomalyAlert>> groupAlertsByEntity(List<AnomalyAlert> alerts) {
        Map<String, List<AnomalyAlert>> grouped = new HashMap<>();

        for (AnomalyAlert alert : alerts) {
            // Get entity from transaction - this would need a join or separate query
            String entityId = "UNKNOWN"; // Placeholder - implement proper entity lookup
            grouped.computeIfAbsent(entityId, k -> new ArrayList<>()).add(alert);
        }

        return grouped;
    }

    private void calculateAndStoreEntityMetrics(String entityId, List<AnomalyAlert> alerts,
                                                LocalDateTime calculationDate) {

        // Get feedback for these alerts
        List<Long> alertIds = alerts.stream().map(AnomalyAlert::getAlertId).collect(Collectors.toList());
        List<UserFeedback> feedback = feedbackRepository.findByAlertIdIn(alertIds);

        // Calculate metrics
        MetricsCalculation metrics = calculateMetrics(alerts, feedback);

        // Store metrics
        storeMetric(entityId, "ENSEMBLE", "precision", metrics.precision, calculationDate, alerts.size());
        storeMetric(entityId, "ENSEMBLE", "recall", metrics.recall, calculationDate, alerts.size());
        storeMetric(entityId, "ENSEMBLE", "f1_score", metrics.f1Score, calculationDate, alerts.size());
        storeMetric(entityId, "ENSEMBLE", "false_positive_rate", metrics.falsePositiveRate, calculationDate, alerts.size());
        storeMetric(entityId, "ENSEMBLE", "alert_volume", (double) alerts.size(), calculationDate, alerts.size());
        storeMetric(entityId, "ENSEMBLE", "avg_score", metrics.avgScore, calculationDate, alerts.size());
    }

    private void calculateAndStoreSystemMetrics(List<AnomalyAlert> alerts, LocalDateTime calculationDate) {
        List<UserFeedback> allFeedback = feedbackRepository.findByAlertIdIn(
                alerts.stream().map(AnomalyAlert::getAlertId).collect(Collectors.toList()));

        MetricsCalculation systemMetrics = calculateMetrics(alerts, allFeedback);

        storeMetric("SYSTEM", "ENSEMBLE", "precision", systemMetrics.precision, calculationDate, alerts.size());
        storeMetric("SYSTEM", "ENSEMBLE", "recall", systemMetrics.recall, calculationDate, alerts.size());
        storeMetric("SYSTEM", "ENSEMBLE", "f1_score", systemMetrics.f1Score, calculationDate, alerts.size());
        storeMetric("SYSTEM", "ENSEMBLE", "false_positive_rate", systemMetrics.falsePositiveRate, calculationDate, alerts.size());

        // Additional system-level metrics
        double feedbackRate = allFeedback.size() / (double) alerts.size();
        storeMetric("SYSTEM", "ENSEMBLE", "feedback_rate", feedbackRate, calculationDate, alerts.size());

        long highConfidenceAlerts = alerts.stream().filter(a -> a.getAlertScore() > 0.9).count();
        double highConfidenceRate = highConfidenceAlerts / (double) alerts.size();
        storeMetric("SYSTEM", "ENSEMBLE", "high_confidence_rate", highConfidenceRate, calculationDate, alerts.size());
    }

    private MetricsCalculation calculateMetrics(List<AnomalyAlert> alerts, List<UserFeedback> feedback) {
        // Map feedback by alert ID
        Map<Long, UserFeedback> feedbackMap = feedback.stream()
                .collect(Collectors.toMap(UserFeedback::getAlertId, f -> f, (f1, f2) -> f1));

        int truePositives = 0;
        int falsePositives = 0;
        int totalFeedback = 0;
        double totalScore = 0.0;

        for (AnomalyAlert alert : alerts) {
            totalScore += alert.getAlertScore();

            UserFeedback fb = feedbackMap.get(alert.getAlertId());
            if (fb != null) {
                totalFeedback++;
                if ("TRUE_POSITIVE".equals(fb.getFeedbackType())) {
                    truePositives++;
                } else if ("FALSE_POSITIVE".equals(fb.getFeedbackType())) {
                    falsePositives++;
                }
            }
        }

        double precision = totalFeedback > 0 ? (double) truePositives / (truePositives + falsePositives) : 0.0;
        double recall = totalFeedback > 0 ? (double) truePositives / totalFeedback : 0.0;
        double f1Score = (precision + recall) > 0 ? 2 * precision * recall / (precision + recall) : 0.0;
        double falsePositiveRate = totalFeedback > 0 ? (double) falsePositives / totalFeedback : 0.0;
        double avgScore = alerts.size() > 0 ? totalScore / alerts.size() : 0.0;

        return new MetricsCalculation(precision, recall, f1Score, falsePositiveRate, avgScore);
    }

    private void storeMetric(String entityId, String modelType, String metricName,
                             double metricValue, LocalDateTime calculationDate, int sampleSize) {
        ModelPerformanceMetrics metric = new ModelPerformanceMetrics();
        metric.setEntityId(entityId);
        metric.setModelType(modelType);
        metric.setMetricName(metricName);
        metric.setMetricValue(metricValue);
        metric.setCalculationDate(calculationDate);
        metric.setEvaluationPeriod("DAILY");
        metric.setSampleSize(sampleSize);

        metricsRepository.save(metric);
    }

    /**
     * Get performance metrics for dashboard
     */
    public Map<String, Object> getPerformanceMetrics(String entityId, int days) {
        LocalDateTime cutoff = LocalDateTime.now().minusDays(days);

        List<ModelPerformanceMetrics> metrics = metricsRepository
                .findByEntityIdAndModelTypeAndCalculationDateAfter(entityId, "ENSEMBLE", cutoff);

        Map<String, Object> result = new HashMap<>();

        // Group metrics by name
        Map<String, List<ModelPerformanceMetrics>> metricsByName = metrics.stream()
                .collect(Collectors.groupingBy(ModelPerformanceMetrics::getMetricName));

        for (Map.Entry<String, List<ModelPerformanceMetrics>> entry : metricsByName.entrySet()) {
            String metricName = entry.getKey();
            List<ModelPerformanceMetrics> metricValues = entry.getValue();

            // Calculate trend
            double currentValue = metricValues.stream()
                    .mapToDouble(ModelPerformanceMetrics::getMetricValue)
                    .average()
                    .orElse(0.0);

            result.put(metricName, currentValue);
            result.put(metricName + "_trend", calculateTrend(metricValues));
        }

        return result;
    }

    private double calculateTrend(List<ModelPerformanceMetrics> metrics) {
        if (metrics.size() < 2) return 0.0;

        // Simple trend calculation - compare first half to second half
        int midPoint = metrics.size() / 2;
        double firstHalf = metrics.subList(0, midPoint).stream()
                .mapToDouble(ModelPerformanceMetrics::getMetricValue)
                .average()
                .orElse(0.0);

        double secondHalf = metrics.subList(midPoint, metrics.size()).stream()
                .mapToDouble(ModelPerformanceMetrics::getMetricValue)
                .average()
                .orElse(0.0);

        return secondHalf - firstHalf;
    }

    private static class MetricsCalculation {
        final double precision;
        final double recall;
        final double f1Score;
        final double falsePositiveRate;
        final double avgScore;

        MetricsCalculation(double precision, double recall, double f1Score,
                           double falsePositiveRate, double avgScore) {
            this.precision = precision;
            this.recall = recall;
            this.f1Score = f1Score;
            this.falsePositiveRate = falsePositiveRate;
            this.avgScore = avgScore;
        }
    }
}