package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.PaymentBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentBatchRepository extends JpaRepository<PaymentBatch, String> {
}
