package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Fr {
    @XmlElement(name = "OrgId")
    private OrgId orgId;
    // getters/setters


    public OrgId getOrgId() {
        return orgId;
    }

    public void setOrgId(OrgId orgId) {
        this.orgId = orgId;
    }
}
