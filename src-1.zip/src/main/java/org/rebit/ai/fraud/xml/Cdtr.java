package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Cdtr {
    @XmlElement(name = "Nm")
    private String nm;

    // getters/setters
}
