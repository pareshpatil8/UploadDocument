package org.rebit.ai.fraud.util.ml;

import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.util.h2o.SimpleH2OManager;
import org.springframework.beans.factory.annotation.Autowired;
import water.fvec.Frame;
import water.fvec.Vec;
import water.Key;

import java.util.Map;

public class AutoencoderUtil {

    @Autowired
    private static SimpleH2OManager h2oManager;

    /**
     * Converts a FeatureVectorDTO to a single-row H2O Frame for scoring.
     */
    public static Frame singleRowToFrame(FeatureVectorDTO fv) {
        Map<String, Double> features = fv.getFeatures();
        String[] colNames = features.keySet().toArray(new String[0]);
        double[] values = new double[colNames.length];

        for (int i = 0; i < colNames.length; i++) {
            values[i] = features.getOrDefault(colNames[i], 0.0);
        }

        return h2oManager.createSingleRowFrame(colNames, values);
    }

    /**
     * Load CSV file to H2O Frame using the simple manager
     */
    public Frame loadCSVToFrame(String csvPath) {
        return h2oManager.loadCSVToFrame(csvPath);
    }

    /**
     * Check if H2O is ready for operations
     */
    public boolean isH2OReady() {
        return h2oManager.isH2OReady();
    }

    /**
     * Get H2O status information
     */
    public SimpleH2OManager.H2OInfo getH2OInfo() {
        return h2oManager.getH2OInfo();
    }

    /**
     * Restart H2O for memory cleanup (useful after large training jobs)
     */
    public void restartH2OForCleanup() {
        h2oManager.restartH2O();
    }
}
