package org.rebit.ai.fraud.util.h2o;

import water.fvec.Frame;
import water.Key;
import water.parser.ParseSetup;
import water.parser.ParseDataset;
import water.fvec.NFSFileVec;

import java.io.File;

public class H2OUtils {

    public static Frame loadCSVToFrame(String csvPath) {
        File file = new File(csvPath);
        NFSFileVec nfs = NFSFileVec.make(file);
        Key<Frame> key = Key.make();
        ParseSetup setup = ParseSetup.guessSetup(new Key[]{nfs._key}, false, ParseSetup.GUESS_HEADER);
        Key[] keys = new Key[]{nfs._key};
        return ParseDataset.parse(key, keys, true, setup);
    }
}
