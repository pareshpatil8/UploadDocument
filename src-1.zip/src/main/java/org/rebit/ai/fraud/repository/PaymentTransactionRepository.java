package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, String> {
    List<PaymentTransaction> findByBatchId(String batchId);
    List<PaymentTransaction> findByTransactionDate(LocalDate date);
    List<PaymentTransaction> findBySourceEntityAndTransactionDateBefore(String entity, LocalDate beforeDate);
    List<PaymentTransaction> findByBeneficiaryAccount(String beneficiaryAccount);

    // New method needed by the enhanced ModelTrainingService
    List<PaymentTransaction> findBySourceEntity(String sourceEntity);

    // Additional useful methods for enhanced functionality
    @Query("SELECT pt FROM PaymentTransaction pt WHERE pt.sourceEntity = :entityId AND pt.transactionDate >= :fromDate")
    List<PaymentTransaction> findByEntityAndDateAfter(@Param("entityId") String entityId, @Param("fromDate") LocalDate fromDate);

    @Query("SELECT pt FROM PaymentTransaction pt WHERE pt.sourceEntity = :entityId AND pt.transactionDate BETWEEN :fromDate AND :toDate")
    List<PaymentTransaction> findByEntityAndDateBetween(@Param("entityId") String entityId,
                                                        @Param("fromDate") LocalDate fromDate,
                                                        @Param("toDate") LocalDate toDate);

    @Query("SELECT COUNT(pt) FROM PaymentTransaction pt WHERE pt.sourceEntity = :entityId")
    Long countBySourceEntity(@Param("entityId") String entityId);

    @Query("SELECT DISTINCT pt.sourceEntity FROM PaymentTransaction pt")
    List<String> findDistinctSourceEntities();

    @Query("SELECT pt FROM PaymentTransaction pt WHERE pt.sourceEntity = :entityId ORDER BY pt.transactionDate DESC")
    List<PaymentTransaction> findBySourceEntityOrderByDateDesc(@Param("entityId") String entityId);

    // Methods for training data preparation
    @Query("SELECT pt FROM PaymentTransaction pt WHERE pt.sourceEntity = :entityId AND pt.amount > :minAmount ORDER BY pt.transactionDate DESC")
    List<PaymentTransaction> findByEntityAndMinAmount(@Param("entityId") String entityId, @Param("minAmount") Double minAmount);
}