package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class ClrSysMmbId {
    @XmlElement(name = "MmbId")
    private String mmbId;
    // getters/setters


    public String getMmbId() {
        return mmbId;
    }

    public void setMmbId(String mmbId) {
        this.mmbId = mmbId;
    }
}
