package org.rebit.ai.fraud.controller;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.UserFeedback;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.UserFeedbackRepository;
import org.rebit.ai.fraud.service.feedback.FeedbackLoopService;
import org.rebit.ai.fraud.service.feedback.FeedbackLoopService.FeedbackType;
import org.rebit.ai.fraud.service.feedback.FeedbackLoopService.FeedbackProcessingResult;
import org.rebit.ai.fraud.service.feedback.FeedbackLoopService.ActiveLearningCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Map.entry;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {
    private static final Logger logger = LoggerFactory.getLogger(FeedbackController.class);

    @Autowired
    private FeedbackLoopService feedbackLoopService;

    @Autowired
    private UserFeedbackRepository feedbackRepository;

    @Autowired
    private AnomalyAlertRepository alertRepository;

    /**
     * Submit feedback for an anomaly alert
     */
    @PostMapping("/submit")
    public ResponseEntity<FeedbackProcessingResult> submitFeedback(
            @RequestParam String alertId,
            @RequestParam String userId,
            @RequestParam String feedbackType,
            @RequestParam(required = false) String comments) {

        try {
            logger.info("Receiving feedback for alert {} from user {}: {}", alertId, userId, feedbackType);

            FeedbackType type = FeedbackType.valueOf(feedbackType.toUpperCase());
            FeedbackProcessingResult result = feedbackLoopService.processFeedback(
                    alertId, userId, type, comments);

            logger.info("Feedback processed successfully for alert {}", alertId);
            return ResponseEntity.ok(result);

        } catch (IllegalArgumentException e) {
            logger.error("Invalid feedback type: {}", feedbackType);
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            logger.error("Error processing feedback for alert {}: {}", alertId, e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get cases that need user review (active learning)
     */
    @GetMapping("/uncertain-cases")
    public ResponseEntity<List<ActiveLearningCase>> getUncertainCases(
            @RequestParam(defaultValue = "10") int maxCases) {

        try {
            List<ActiveLearningCase> uncertainCases = feedbackLoopService.identifyUncertainCases(maxCases);
            logger.info("Retrieved {} uncertain cases for review", uncertainCases.size());
            return ResponseEntity.ok(uncertainCases);
        } catch (Exception e) {
            logger.error("Error retrieving uncertain cases: {}", e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get comprehensive feedback statistics
     */
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getFeedbackStatistics(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        try {
            // Default to last 30 days if no dates provided
            if (from == null) from = LocalDateTime.now().minusDays(30);
            if (to == null) to = LocalDateTime.now();

            Map<String, Object> stats = calculateComprehensiveStatistics(from, to);
            return ResponseEntity.ok(stats);

        } catch (Exception e) {
            logger.error("Error calculating feedback statistics: {}", e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get feedback statistics by entity
     */
    @GetMapping("/statistics/entity/{entityId}")
    public ResponseEntity<Map<String, Object>> getEntityFeedbackStatistics(
            @PathVariable String entityId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        try {
            if (from == null) from = LocalDateTime.now().minusDays(30);
            if (to == null) to = LocalDateTime.now();

            Map<String, Object> stats = calculateEntityStatistics(entityId, from, to);
            return ResponseEntity.ok(stats);

        } catch (Exception e) {
            logger.error("Error calculating entity feedback statistics for {}: {}", entityId, e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get feedback trends over time
     */
    @GetMapping("/trends")
    public ResponseEntity<Map<String, Object>> getFeedbackTrends(
            @RequestParam(defaultValue = "30") int days) {

        try {
            Map<String, Object> trends = calculateFeedbackTrends(days);
            return ResponseEntity.ok(trends);
        } catch (Exception e) {
            logger.error("Error calculating feedback trends: {}", e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get user engagement statistics
     */
    @GetMapping("/engagement")
    public ResponseEntity<Map<String, Object>> getUserEngagement() {
        try {
            Map<String, Object> engagement = calculateUserEngagement();
            return ResponseEntity.ok(engagement);
        } catch (Exception e) {
            logger.error("Error calculating user engagement: {}", e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Calculate comprehensive feedback statistics
     */
    private Map<String, Object> calculateComprehensiveStatistics(LocalDateTime from, LocalDateTime to) {
        Map<String, Object> stats = new HashMap<>();

        // Get all feedback in date range
        List<UserFeedback> allFeedback = feedbackRepository.findByFeedbackDateBetween(from, to);
        List<AnomalyAlert> allAlerts = alertRepository.findByDetectionDateBetween(from, to);

        // Basic counts
        stats.put("totalFeedback", allFeedback.size());
        stats.put("totalAlerts", allAlerts.size());

        // Feedback rate
        double feedbackRate = allAlerts.isEmpty() ? 0.0 : (double) allFeedback.size() / allAlerts.size();
        stats.put("feedbackRate", Math.round(feedbackRate * 1000.0) / 10.0); // Percentage with 1 decimal

        // Feedback type breakdown
        Map<String, Long> feedbackTypes = allFeedback.stream()
                .collect(Collectors.groupingBy(UserFeedback::getFeedbackType, Collectors.counting()));

        long falsePositives = feedbackTypes.getOrDefault("FALSE_POSITIVE", 0L);
        long truePositives = feedbackTypes.getOrDefault("TRUE_POSITIVE", 0L);
        long uncertain = feedbackTypes.getOrDefault("UNCERTAIN", 0L);

        stats.put("falsePositives", falsePositives);
        stats.put("truePositives", truePositives);
        stats.put("uncertain", uncertain);

        // False positive rate
        long totalClassified = falsePositives + truePositives;
        double falsePositiveRate = totalClassified > 0 ? (double) falsePositives / totalClassified : 0.0;
        stats.put("falsePositiveRate", Math.round(falsePositiveRate * 1000.0) / 10.0);

        // Precision (true positives / total positives predicted)
        double precision = totalClassified > 0 ? (double) truePositives / totalClassified : 0.0;
        stats.put("precision", Math.round(precision * 1000.0) / 10.0);

        // Average confidence score
        double avgConfidence = allFeedback.stream()
                .filter(f -> f.getConfidenceScore() != null)
                .mapToDouble(UserFeedback::getConfidenceScore)
                .average()
                .orElse(0.0);
        stats.put("averageConfidence", Math.round(avgConfidence * 1000.0) / 10.0);

        // Response time analysis
        Map<String, Object> responseTimeStats = calculateResponseTimeStatistics(allFeedback, allAlerts);
        stats.put("responseTime", responseTimeStats);

        // Alert score distribution for feedback
        Map<String, Object> scoreDistribution = calculateScoreDistribution(allFeedback, allAlerts);
        stats.put("scoreDistribution", scoreDistribution);

        return stats;
    }

    /**
     * Calculate entity-specific statistics
     */
    private Map<String, Object> calculateEntityStatistics(String entityId, LocalDateTime from, LocalDateTime to) {
        HashMap<String, Object> stats = new HashMap<>();

        List<UserFeedback> entityFeedback = feedbackRepository.findByEntityIdAndFeedbackDateBetween(entityId, from, to);
        List<AnomalyAlert> entityAlerts = alertRepository.findByEntityIdAndDetectionDateBetween(entityId, from, to);

        stats.put("entityId", entityId);
        stats.put("totalFeedback", entityFeedback.size());
        stats.put("totalAlerts", entityAlerts.size());

        // Entity-specific feedback rate
        double feedbackRate = entityAlerts.isEmpty() ? 0.0 : (double) entityFeedback.size() / entityAlerts.size();
        stats.put("feedbackRate", Math.round(feedbackRate * 1000.0) / 10.0);

        // Entity-specific false positive rate
        Map<String, Long> feedbackTypes = entityFeedback.stream()
                .collect(Collectors.groupingBy(UserFeedback::getFeedbackType, Collectors.counting()));

        long falsePositives = feedbackTypes.getOrDefault("FALSE_POSITIVE", 0L);
        long truePositives = feedbackTypes.getOrDefault("TRUE_POSITIVE", 0L);
        long totalClassified = falsePositives + truePositives;

        double falsePositiveRate = totalClassified > 0 ? (double) falsePositives / totalClassified : 0.0;
        stats.put("falsePositiveRate", Math.round(falsePositiveRate * 1000.0) / 10.0);

        // Compare with system average
        Map<String, Object> systemStats = calculateComprehensiveStatistics(from, to);
        Map<String, Object> diffMap = new HashMap<>();
        diffMap.put("feedbackRateDiff", (Double) stats.get("feedbackRate") - (Double) systemStats.get("feedbackRate"));
        diffMap.put("falsePositiveRateDiff", (Double) stats.get("falsePositiveRate") - (Double) systemStats.get("falsePositiveRate"));
        stats.put("comparedToSystem", diffMap);

        return stats;
    }

    /**
     * Calculate feedback trends over time
     */
    private Map<String, Object> calculateFeedbackTrends(int days) {
        Map<String, Object> trends = new HashMap<>();
        LocalDateTime endDate = LocalDateTime.now();
        LocalDateTime startDate = endDate.minusDays(days);

        // Daily feedback counts
        List<Map<String, Object>> dailyTrends = new ArrayList<>();

        for (int i = 0; i < days; i++) {
            LocalDateTime dayStart = startDate.plusDays(i).withHour(0).withMinute(0).withSecond(0);
            LocalDateTime dayEnd = dayStart.plusDays(1);

            List<UserFeedback> dayFeedback = feedbackRepository.findByFeedbackDateBetween(dayStart, dayEnd);
            List<AnomalyAlert> dayAlerts = alertRepository.findByDetectionDateBetween(dayStart, dayEnd);

            Map<String, Long> feedbackTypes = dayFeedback.stream()
                    .collect(Collectors.groupingBy(UserFeedback::getFeedbackType, Collectors.counting()));

            Map<String, Object> dayData = new HashMap<>();
            dayData.put("date", dayStart.toLocalDate().toString());
            dayData.put("totalFeedback", dayFeedback.size());
            dayData.put("totalAlerts", dayAlerts.size());
            dayData.put("falsePositives", feedbackTypes.getOrDefault("FALSE_POSITIVE", 0L));
            dayData.put("truePositives", feedbackTypes.getOrDefault("TRUE_POSITIVE", 0L));
            dayData.put("uncertain", feedbackTypes.getOrDefault("UNCERTAIN", 0L));

            double dayFeedbackRate = dayAlerts.isEmpty() ? 0.0 : (double) dayFeedback.size() / dayAlerts.size();
            dayData.put("feedbackRate", Math.round(dayFeedbackRate * 1000.0) / 10.0);

            dailyTrends.add(dayData);
        }

        trends.put("dailyTrends", dailyTrends);

        // Calculate trend direction
        if (dailyTrends.size() >= 7) {
            // Compare last 7 days to previous 7 days
            double recent7DayAvg = dailyTrends.subList(dailyTrends.size() - 7, dailyTrends.size())
                    .stream().mapToDouble(d -> (Double) d.get("feedbackRate")).average().orElse(0.0);
            double previous7DayAvg = dailyTrends.subList(dailyTrends.size() - 14, dailyTrends.size() - 7)
                    .stream().mapToDouble(d -> (Double) d.get("feedbackRate")).average().orElse(0.0);

            double trendDirection = recent7DayAvg - previous7DayAvg;
            trends.put("feedbackRateTrend", trendDirection > 0 ? "INCREASING" : trendDirection < 0 ? "DECREASING" : "STABLE");
            trends.put("trendMagnitude", Math.abs(trendDirection));
        }

        return trends;
    }

    /**
     * Calculate user engagement metrics
     */
    private Map<String, Object> calculateUserEngagement() {
        Map<String, Object> engagement = new HashMap<>();
        LocalDateTime last30Days = LocalDateTime.now().minusDays(30);

        List<UserFeedback> recentFeedback = feedbackRepository.findByFeedbackDateAfter(last30Days);

        // Unique users providing feedback
        Set<String> uniqueUsers = recentFeedback.stream()
                .map(UserFeedback::getUserId)
                .collect(Collectors.toSet());

        engagement.put("activeUsers", uniqueUsers.size());

        // Average feedback per user
        double avgFeedbackPerUser = uniqueUsers.isEmpty() ? 0.0 : (double) recentFeedback.size() / uniqueUsers.size();
        engagement.put("averageFeedbackPerUser", Math.round(avgFeedbackPerUser * 10.0) / 10.0);

        // Top contributors
        Map<String, Long> userContributions = recentFeedback.stream()
                .collect(Collectors.groupingBy(UserFeedback::getUserId, Collectors.counting()));

        List<Map<String, Serializable>> topContributors = userContributions.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .map(entry -> {
                    Map<String, Serializable> contributor = new LinkedHashMap<>();
                    contributor.put("userId", entry.getKey());
                    contributor.put("feedbackCount", entry.getValue());
                    return contributor;
                })
                .collect(Collectors.toList());

        engagement.put("topContributors", topContributors);

        // Feedback quality metrics
        double avgConfidence = recentFeedback.stream()
                .filter(f -> f.getConfidenceScore() != null)
                .mapToDouble(UserFeedback::getConfidenceScore)
                .average()
                .orElse(0.0);

        engagement.put("averageConfidenceScore", Math.round(avgConfidence * 1000.0) / 10.0);

        // Feedback with comments percentage
        long feedbackWithComments = recentFeedback.stream()
                .filter(f -> f.getComments() != null && !f.getComments().trim().isEmpty())
                .count();

        double commentsPercentage = recentFeedback.isEmpty() ? 0.0 : (double) feedbackWithComments / recentFeedback.size();
        engagement.put("feedbackWithCommentsPercentage", Math.round(commentsPercentage * 1000.0) / 10.0);

        return engagement;
    }

    /**
     * Calculate response time statistics
     */
    private Map<String, Object> calculateResponseTimeStatistics(List<UserFeedback> feedback, List<AnomalyAlert> alerts) {
        Map<String, Object> responseTime = new HashMap<>();

        // Map alerts by ID for quick lookup
        Map<Long, AnomalyAlert> alertMap = alerts.stream()
                .collect(Collectors.toMap(AnomalyAlert::getAlertId, a -> a));

        List<Long> responseTimesHours = new ArrayList<>();

        for (UserFeedback fb : feedback) {
            AnomalyAlert alert = alertMap.get(fb.getAlertId());
            if (alert != null && alert.getDetectionDate() != null) {
                long hours = java.time.Duration.between(alert.getDetectionDate(), fb.getFeedbackDate()).toHours();
                responseTimesHours.add(hours);
            }
        }

        if (!responseTimesHours.isEmpty()) {
            double avgResponseTimeHours = responseTimesHours.stream().mapToLong(Long::longValue).average().orElse(0.0);
            long medianResponseTime = responseTimesHours.stream().sorted().skip(responseTimesHours.size() / 2).findFirst().orElse(0L);

            responseTime.put("averageHours", Math.round(avgResponseTimeHours * 10.0) / 10.0);
            responseTime.put("medianHours", medianResponseTime);
            responseTime.put("sampleSize", responseTimesHours.size());
        } else {
            responseTime.put("averageHours", 0.0);
            responseTime.put("medianHours", 0L);
            responseTime.put("sampleSize", 0);
        }

        return responseTime;
    }

    /**
     * Calculate alert score distribution for feedback
     */
    private Map<String, Object> calculateScoreDistribution(List<UserFeedback> feedback, List<AnomalyAlert> alerts) {
        Map<String, Object> distribution = new HashMap<>();

        Map<Long, AnomalyAlert> alertMap = alerts.stream()
                .collect(Collectors.toMap(AnomalyAlert::getAlertId, a -> a));

        List<Double> falsePositiveScores = new ArrayList<>();
        List<Double> truePositiveScores = new ArrayList<>();

        for (UserFeedback fb : feedback) {
            AnomalyAlert alert = alertMap.get(fb.getAlertId());
            if (alert != null) {
                if ("FALSE_POSITIVE".equals(fb.getFeedbackType())) {
                    falsePositiveScores.add(alert.getAlertScore());
                } else if ("TRUE_POSITIVE".equals(fb.getFeedbackType())) {
                    truePositiveScores.add(alert.getAlertScore());
                }
            }
        }

        distribution.put("falsePositiveScores", calculateScoreStats(falsePositiveScores));
        distribution.put("truePositiveScores", calculateScoreStats(truePositiveScores));

        return distribution;
    }

    private Map<String, Object> calculateScoreStats(List<Double> scores) {
        Map<String, Object> stats = new HashMap<>();

        if (scores.isEmpty()) {
            stats.put("count", 0);
            stats.put("average", 0.0);
            stats.put("median", 0.0);
            stats.put("min", 0.0);
            stats.put("max", 0.0);
        } else {
            Collections.sort(scores);
            stats.put("count", scores.size());
            stats.put("average", Math.round(scores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0) * 1000.0) / 1000.0);
            stats.put("median", scores.get(scores.size() / 2));
            stats.put("min", scores.get(0));
            stats.put("max", scores.get(scores.size() - 1));
        }

        return stats;
    }
}