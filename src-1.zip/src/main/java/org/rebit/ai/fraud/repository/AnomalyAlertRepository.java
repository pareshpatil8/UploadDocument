package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AnomalyAlertRepository extends JpaRepository<AnomalyAlert, Long> {
    List<AnomalyAlert> findByStatus(String status);
    List<AnomalyAlert> findByTransactionId(String transactionId);
    List<AnomalyAlert> findByDetectionDateBetween(LocalDateTime start, LocalDateTime end);
    List<AnomalyAlert> findByDetectionDateAfterAndReviewedFalse(LocalDateTime after);

    List<AnomalyAlert> findByEntityIdAndDetectionDateBetween(String entityId, LocalDateTime from, LocalDateTime to);
}
