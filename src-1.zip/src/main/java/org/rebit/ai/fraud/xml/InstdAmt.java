package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class InstdAmt {
    @XmlElement(name = "Amt")
    private Double amt;

    @XmlElement(name = "CcyOfTrf")
    private String ccyOfTrf;

    // getters/setters
}
