package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class CstmrCdtTrfInitn {
    @XmlElement(name = "GrpHdr")
    private GrpHdr grpHdr;

    @XmlElement(name = "PmtInf")
    private PmtInf pmtInf;
    // getters/setters


    public GrpHdr getGrpHdr() {
        return grpHdr;
    }

    public void setGrpHdr(GrpHdr grpHdr) {
        this.grpHdr = grpHdr;
    }

    public PmtInf getPmtInf() {
        return pmtInf;
    }

    public void setPmtInf(PmtInf pmtInf) {
        this.pmtInf = pmtInf;
    }
}
