package org.rebit.ai.fraud.service.data;

import org.rebit.ai.fraud.dto.PaymentTransactionDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Partitions transactions by source entity for per-entity model training.
 */
@Service
public class DataPartitioningService {

    public Map<String, List<PaymentTransactionDTO>> partitionByEntity(List<PaymentTransactionDTO> transactions) {
        return transactions.stream()
                .collect(Collectors.groupingBy(PaymentTransactionDTO::getSourceEntity));
    }
}
