package org.rebit.ai.fraud.scheduler;

import org.rebit.ai.fraud.service.training.ModelTrainingService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ModelTrainingJob {

    private final ModelTrainingService trainingService;

    @Value("${schedule.model-training-cron}")
    private String cronExpression;

    public ModelTrainingJob(ModelTrainingService trainingService) {
        this.trainingService = trainingService;
    }

    @Scheduled(cron = "${schedule.model-training-cron}")
    public void runNightlyTraining() {
        trainingService.trainAllModels();
    }
}
