package org.rebit.ai.fraud.util.h2o;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import water.H2O;
import water.MemoryManager;
import water.fvec.Frame;
import water.Key;
import water.parser.ParseSetup;
import water.parser.ParseDataset;
import water.fvec.NFSFileVec;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Simple H2O Manager for single autoencoder use case.
 * Handles H2O lifecycle and provides basic utilities.
 * No connection pooling needed for single-threaded training operations.
 */
@Component
public class SimpleH2OManager {
    private static final Logger logger = LoggerFactory.getLogger(SimpleH2OManager.class);

    @Value("${h2o.max-memory:4g}")
    private String maxMemory;

    @Value("${h2o.min-memory:1g}")
    private String minMemory;

    @Value("${h2o.nthreads:-1}")  // -1 means use all available cores
    private int nthreads;

    @Value("${h2o.name:fraud-detection-h2o}")
    private String h2oName;

    @Value("${h2o.port:54321}")
    private int port;

    @Value("${h2o.auto-start:true}")
    private boolean autoStart;

    private final AtomicBoolean isInitialized = new AtomicBoolean(false);
    private final AtomicBoolean isShuttingDown = new AtomicBoolean(false);

    @PostConstruct
    public void initialize() {
        if (autoStart) {
            startH2O();
        }
    }

    @PreDestroy
    public void shutdown() {
        stopH2O();
    }

    /**
     * Start H2O instance if not already running
     */
    public synchronized void startH2O() {
        if (isInitialized.get()) {
            logger.debug("H2O already initialized");
            return;
        }

        if (isShuttingDown.get()) {
            throw new IllegalStateException("H2O is shutting down");
        }

        logger.info("Starting H2O with memory: {} - {}", minMemory, maxMemory);

        try {
            // Check if H2O is already running
            if (H2O.getCloudSize() > 0) {
                logger.info("H2O already running with cloud size: {}", H2O.getCloudSize());
                isInitialized.set(true);
                return;
            }

            // Calculate nthreads if not specified
            int threads = nthreads == -1 ? Runtime.getRuntime().availableProcessors() : nthreads;

            String[] h2oArgs = {
                    "-name", h2oName,
                    "-port", String.valueOf(port),
                    "-nthreads", String.valueOf(threads),
                    "-Xmx" + maxMemory,
                    "-Xms" + minMemory
            };

            // Start H2O
            H2O.main(h2oArgs);

            // Wait for H2O to be ready (single node cluster)
            H2O.waitForCloudSize(1, 30000); // 30 second timeout

            isInitialized.set(true);
            logger.info("H2O started successfully. Cloud size: {}, Threads: {}",
                    H2O.getCloudSize(), threads);

        } catch (Exception e) {
            logger.error("Failed to start H2O", e);
            throw new RuntimeException("H2O startup failed", e);
        }
    }

    /**
     * Stop H2O instance
     */
    public synchronized void stopH2O() {
        if (!isInitialized.get()) {
            return;
        }

        isShuttingDown.set(true);
        logger.info("Shutting down H2O...");

        try {
            if (H2O.getCloudSize() > 0) {
                H2O.shutdown(0);
            }
            isInitialized.set(false);
            logger.info("H2O shutdown completed");
        } catch (Exception e) {
            logger.error("Error during H2O shutdown", e);
        } finally {
            isShuttingDown.set(false);
        }
    }

    /**
     * Load CSV file to H2O Frame
     */
    public Frame loadCSVToFrame(String csvPath) {
        ensureH2OReady();

        logger.debug("Loading CSV to H2O Frame: {}", csvPath);

        File file = new File(csvPath);
        if (!file.exists()) {
            throw new IllegalArgumentException("CSV file does not exist: " + csvPath);
        }

        try {
            NFSFileVec nfs = NFSFileVec.make(file);
            Key<Frame> key = Key.make();
            ParseSetup setup = ParseSetup.guessSetup(new Key[]{nfs._key}, false, ParseSetup.GUESS_HEADER);
            Key[] keys = new Key[]{nfs._key};

            Frame frame = ParseDataset.parse(key, keys, true, setup);
            logger.debug("Successfully loaded CSV with {} rows and {} columns",
                    frame.numRows(), frame.numCols());

            return frame;
        } catch (Exception e) {
            logger.error("Failed to load CSV file: {}", csvPath, e);
            throw new RuntimeException("CSV loading failed", e);
        }
    }

    /**
     * Create empty frame for single-row scoring
     */
    public Frame createSingleRowFrame(String[] columnNames, double[] values) {
        ensureH2OReady();

        if (columnNames.length != values.length) {
            throw new IllegalArgumentException("Column names and values must have same length");
        }

        try {
            // Create frame using H2O's frame creation utilities
            water.fvec.Vec[] vecs = new water.fvec.Vec[columnNames.length];
            for (int i = 0; i < columnNames.length; i++) {
                vecs[i] = water.fvec.Vec.makeVec(new double[]{values[i]}, water.fvec.Vec.newKey());
            }

            Frame frame = new Frame(Key.make(), columnNames, vecs);
            frame.delete_and_lock();
            frame.unlock();

            return frame;
        } catch (Exception e) {
            logger.error("Failed to create single row frame", e);
            throw new RuntimeException("Frame creation failed", e);
        }
    }

    /**
     * Check if H2O is ready for operations
     */
    public boolean isH2OReady() {
        return isInitialized.get() && !isShuttingDown.get() && H2O.getCloudSize() > 0;
    }

    /**
     * Get H2O cluster information
     */
    public H2OInfo getH2OInfo() {
        if (!isH2OReady()) {
            return new H2OInfo(false, 0, 0, 0, "Not initialized");
        }

        try {
            int cloudSize = H2O.getCloudSize();

            // For current node's memory
            long totalMemory = MemoryManager.MEM_MAX;
            long freeMemory = H2O.CLOUD.free_mem();
            long usedMemory = totalMemory - freeMemory;

            String status = "Running";
            if (usedMemory > totalMemory * 0.9) {
                status = "High Memory Usage";
            }

            return new H2OInfo(true, cloudSize, totalMemory, usedMemory, status);
        } catch (Exception e) {
            logger.error("Error getting H2O info", e);
            return new H2OInfo(false, 0, 0, 0, "Error: " + e.getMessage());
        }
    }

    /**
     * Restart H2O (useful for memory cleanup after training)
     */
    public synchronized void restartH2O() {
        logger.info("Restarting H2O for memory cleanup...");
        stopH2O();

        // Wait a bit for cleanup
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        startH2O();
    }

    private void ensureH2OReady() {
        if (!isH2OReady()) {
            throw new IllegalStateException("H2O is not ready. Current state: initialized=" +
                    isInitialized.get() + ", shuttingDown=" + isShuttingDown.get() +
                    ", cloudSize=" + H2O.getCloudSize());
        }
    }

    // Simple info class
    public static class H2OInfo {
        private final boolean ready;
        private final int cloudSize;
        private final long totalMemoryBytes;
        private final long usedMemoryBytes;
        private final String status;

        public H2OInfo(boolean ready, int cloudSize, long totalMemoryBytes, long usedMemoryBytes, String status) {
            this.ready = ready;
            this.cloudSize = cloudSize;
            this.totalMemoryBytes = totalMemoryBytes;
            this.usedMemoryBytes = usedMemoryBytes;
            this.status = status;
        }

        // Getters
        public boolean isReady() { return ready; }
        public int getCloudSize() { return cloudSize; }
        public long getTotalMemoryBytes() { return totalMemoryBytes; }
        public long getUsedMemoryBytes() { return usedMemoryBytes; }
        public String getTotalMemoryMB() { return String.format("%.1f MB", totalMemoryBytes / 1024.0 / 1024.0); }
        public String getUsedMemoryMB() { return String.format("%.1f MB", usedMemoryBytes / 1024.0 / 1024.0); }
        public double getMemoryUsagePercent() {
            return totalMemoryBytes > 0 ? (double) usedMemoryBytes / totalMemoryBytes * 100 : 0;
        }
        public String getStatus() { return status; }
    }
}