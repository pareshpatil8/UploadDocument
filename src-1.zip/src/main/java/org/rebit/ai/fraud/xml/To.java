package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class To {
    @XmlElement(name = "FIId")
    private FIId fiId;
    // getters/setters


    public FIId getFiId() {
        return fiId;
    }

    public void setFiId(FIId fiId) {
        this.fiId = fiId;
    }
}
