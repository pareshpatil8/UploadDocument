package org.rebit.ai.fraud.service.training;

import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.rebit.ai.fraud.entity.GovernmentEntity;
import org.rebit.ai.fraud.entity.AnomalyModel;
import org.rebit.ai.fraud.constants.ModelType;
import org.rebit.ai.fraud.repository.PaymentTransactionRepository;
import org.rebit.ai.fraud.repository.GovernmentEntityRepository;
import org.rebit.ai.fraud.repository.AnomalyModelRepository;
import org.rebit.ai.fraud.model.isolation.IsolationForestModelWrapper;
import org.rebit.ai.fraud.model.autoencoder.EnhancedAutoencoderWrapper;
import org.rebit.ai.fraud.util.h2o.SimpleH2OManager;
import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.dto.PaymentTransactionDTO;
import org.rebit.ai.fraud.service.data.FeatureEngineeringService;
import org.rebit.ai.fraud.service.feedback.FeedbackLoopService;
import org.rebit.ai.fraud.service.monitoring.PerformanceMonitoringService;
import org.rebit.ai.fraud.util.ml.AutoencoderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fasterxml.jackson.databind.ObjectMapper;
import water.fvec.Frame;

import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
public class ModelTrainingService {

    private static final Logger logger = LoggerFactory.getLogger(ModelTrainingService.class);

    @Autowired
    private PaymentTransactionRepository paymentTransactionRepo;
    @Autowired
    private GovernmentEntityRepository entityRepo;
    @Autowired
    private AnomalyModelRepository anomalyModelRepo;
    @Autowired
    private FeatureEngineeringService featureEngineeringService;
    @Autowired
    private SimpleH2OManager h2oManager;
    @Autowired
    private AutoencoderUtil autoencoderUtil;

    @Value("${model.dir:/var/models/}")
    private String modelDir;

    @Value("${isolationForest.nTrees:100}")
    private int nTrees;

    @Value("${isolationForest.subsample:256}")
    private int subsampleSize;

    @Value("${isolationForest.contamination:0.1}")
    private double contamination;

    @Value("${isolationForest.random-seed:42}")
    private long randomSeed;

    @Value("${autoencoder.epochs:100}")
    private int autoencoderEpochs;

    @Value("${autoencoder.learningRate:0.001}")
    private double learningRate;

    @Value("${isolationForest.featureOrder}")
    private List<String> featureOrder;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Transactional
    public void trainAllModels() {
        logger.info("Starting enhanced model training for all entities...");

        try {
            // Ensure H2O is ready for autoencoder training
            h2oManager.startH2O();

            // 1. Train Enhanced Isolation Forest models per entity
            trainEnhancedIsolationForestModels();

            // 2. Train Enhanced Autoencoder - global
            trainEnhancedGlobalAutoencoder();

            // 3. Update model status (deactivate old models)
            updateModelStatus();

            logger.info("Enhanced model training completed successfully");

        } catch (Exception e) {
            logger.error("Error during enhanced model training", e);
            throw new RuntimeException("Enhanced model training failed", e);
        }
    }

    private void trainEnhancedIsolationForestModels() {
        logger.info("Training Enhanced Isolation Forest models for each entity...");

        for (GovernmentEntity entity : entityRepo.findAll()) {
            if (!entity.getActive()) {
                logger.info("Skipping inactive entity: {}", entity.getEntityId());
                continue;
            }

            try {
                trainEntityIsolationForest(entity);
            } catch (Exception e) {
                logger.error("Error training Enhanced Isolation Forest for entity: {}", entity.getEntityId(), e);
                // Continue with other entities instead of failing completely
            }
        }
    }

    private void trainEntityIsolationForest(GovernmentEntity entity) throws Exception {
        logger.info("Training Enhanced Isolation Forest for entity: {}", entity.getEntityId());

        // Get transactions for this entity
        List<PaymentTransaction> txs = paymentTransactionRepo.findBySourceEntity(entity.getEntityId());
        if (txs.isEmpty()) {
            logger.warn("No transactions found for entity: {}", entity.getEntityId());
            return;
        }

        // Convert to feature vectors using enhanced feature engineering
        List<Map<String, Double>> featureList = new ArrayList<>();
        for (PaymentTransaction tx : txs) {
            try {
                PaymentTransactionDTO txDto = mapToDTO(tx);

                // Extract base features
                FeatureVectorDTO baseFeatures = featureEngineeringService.extractFeatures(txDto);

                // Add government-specific features
                Map<String, Double> govFeatures = featureEngineeringService.extractGovernmentSpecificFeatures(txDto);
                baseFeatures.getFeatures().putAll(govFeatures);

                featureList.add(baseFeatures.getFeatures());

            } catch (Exception e) {
                logger.error("Error extracting features for transaction: {}", tx.getTransactionId(), e);
            }
        }

        if (featureList.isEmpty()) {
            logger.warn("No valid feature vectors extracted for entity: {}", entity.getEntityId());
            return;
        }

        // Create and train Enhanced Isolation Forest
        IsolationForestModelWrapper isoModel = new IsolationForestModelWrapper(
                featureOrder, nTrees, subsampleSize);

        isoModel.train(featureList);

        // Perform cross-validation to get model metrics
        Map<String, Double> cvResults = isoModel.crossValidate(featureList, 5);
        logger.info("Cross-validation results for entity {}: {}", entity.getEntityId(), cvResults);

        // Save model to file
        Path entityModelDir = Paths.get(modelDir, entity.getEntityId());
        Files.createDirectories(entityModelDir);

        String modelPath = entityModelDir.resolve("isolation_forest_" + LocalDate.now() + ".model").toString();
        File modelFile = new File(modelPath);
        isoModel.save(modelFile);

        // Save model metadata with metrics
        AnomalyModel modelMeta = new AnomalyModel();
        modelMeta.setEntityId(entity.getEntityId());
        modelMeta.setModelType(ModelType.ISOLATION_FOREST.name());
        modelMeta.setTrainingDate(LocalDate.now());
        modelMeta.setFilePath(modelPath);
        modelMeta.setActive(true);

        // Store cross-validation metrics as JSON
        String metricsJson = objectMapper.writeValueAsString(cvResults);
        modelMeta.setMetrics(metricsJson);

        anomalyModelRepo.save(modelMeta);

        logger.info("Enhanced Isolation Forest trained for entity: {} with {} samples. Metrics: {}",
                entity.getEntityId(), featureList.size(), cvResults);
    }

    private void trainEnhancedGlobalAutoencoder() {
        logger.info("Training Enhanced Global Autoencoder model...");

        try {
            List<PaymentTransaction> allTxs = paymentTransactionRepo.findAll();
            if (allTxs.isEmpty()) {
                logger.warn("No transactions found for autoencoder training");
                return;
            }

            // Prepare training data with enhanced features
            List<Map<String, Double>> featureList = new ArrayList<>();
            for (PaymentTransaction tx : allTxs) {
                try {
                    PaymentTransactionDTO txDto = mapToDTO(tx);

                    // Extract base features
                    FeatureVectorDTO baseFeatures = featureEngineeringService.extractFeatures(txDto);

                    // Add government-specific features
                    Map<String, Double> govFeatures = featureEngineeringService.extractGovernmentSpecificFeatures(txDto);
                    baseFeatures.getFeatures().putAll(govFeatures);

                    featureList.add(baseFeatures.getFeatures());

                } catch (Exception e) {
                    logger.error("Error extracting features for transaction: {}", tx.getTransactionId(), e);
                }
            }

            if (featureList.isEmpty()) {
                logger.warn("No valid feature vectors extracted for autoencoder training");
                return;
            }

            // Create temporary CSV for H2O
            File tempCsv = createTemporaryCSV(featureList);

            try {
                // Load data into H2O Frame
                Frame frame = h2oManager.loadCSVToFrame(tempCsv.getAbsolutePath());

                // Create and train Enhanced Autoencoder
                EnhancedAutoencoderWrapper autoModel = new EnhancedAutoencoderWrapper();
                autoModel.train(frame, autoencoderEpochs, learningRate, new ArrayList<>(featureOrder));

                // Save model
                Path globalModelDir = Paths.get(modelDir, "global", "autoencoder");
                Files.createDirectories(globalModelDir);

                String autoModelPath = globalModelDir.resolve("enhanced_autoencoder_" + LocalDate.now() + ".model").toString();
                autoModel.save(autoModelPath);

                // Get model performance metrics
                Map<String, Double> performanceMetrics = autoModel.getPerformanceMetrics();

                // Save model metadata with metrics
                AnomalyModel autoMeta = new AnomalyModel();
                autoMeta.setModelType(ModelType.AUTOENCODER.name());
                autoMeta.setTrainingDate(LocalDate.now());
                autoMeta.setFilePath(autoModelPath);
                autoMeta.setActive(true);

                // Store performance metrics as JSON
                String metricsJson = objectMapper.writeValueAsString(performanceMetrics);
                autoMeta.setMetrics(metricsJson);

                anomalyModelRepo.save(autoMeta);

                // Cleanup
                frame.delete();

                logger.info("Enhanced Global Autoencoder training completed with {} samples. Metrics: {}",
                        featureList.size(), performanceMetrics);

                // Optional: restart H2O for memory cleanup after large training
                if (featureList.size() > 10000) {
                    logger.info("Restarting H2O for memory cleanup after large training dataset");
                    h2oManager.restartH2O();
                }

            } finally {
                // Always cleanup temporary file
                if (tempCsv.exists()) {
                    tempCsv.delete();
                }
            }

        } catch (Exception e) {
            logger.error("Error training enhanced global autoencoder", e);
            throw new RuntimeException("Enhanced autoencoder training failed", e);
        }
    }

    private File createTemporaryCSV(List<Map<String, Double>> featureList) throws IOException {
        File tempCsv = File.createTempFile("h2o_enhanced_autoencoder_data", ".csv");

        try (PrintWriter pw = new PrintWriter(tempCsv)) {
            // Write header
            pw.println(String.join(",", featureOrder));

            // Write data
            for (Map<String, Double> features : featureList) {
                List<String> values = featureOrder.stream()
                        .map(feature -> String.valueOf(features.getOrDefault(feature, 0.0)))
                        .collect(Collectors.toList());
                pw.println(String.join(",", values));
            }
        }

        logger.debug("Created temporary CSV with {} rows and {} columns", featureList.size(), featureOrder.size());
        return tempCsv;
    }

    private void updateModelStatus() {
        logger.info("Updating model status - deactivating old models...");

        try {
            // Deactivate old models (keep only the latest one per entity/type)
            List<AnomalyModel> allModels = anomalyModelRepo.findAll();

            // Group by entity and model type
            Map<String, List<AnomalyModel>> modelGroups = allModels.stream()
                    .collect(Collectors.groupingBy(model ->
                            (model.getEntityId() != null ? model.getEntityId() : "GLOBAL") + "_" + model.getModelType()));

            for (Map.Entry<String, List<AnomalyModel>> entry : modelGroups.entrySet()) {
                List<AnomalyModel> models = entry.getValue();

                // Sort by training date (newest first)
                models.sort((a, b) -> b.getTrainingDate().compareTo(a.getTrainingDate()));

                // Keep the newest one active, deactivate others
                for (int i = 0; i < models.size(); i++) {
                    AnomalyModel model = models.get(i);
                    model.setActive(i == 0); // Only the first (newest) remains active
                    anomalyModelRepo.save(model);
                }

                if (models.size() > 1) {
                    logger.info("Updated status for model group {}: {} models, {} active",
                            entry.getKey(), models.size(), 1);
                }
            }

        } catch (Exception e) {
            logger.error("Error updating model status", e);
        }
    }

    /**
     * Enhanced retrain models incorporating user feedback
     */
    @Transactional
    public void retrainWithFeedback(String entityId, List<FeedbackLoopService.LabeledTrainingData> feedbackData) {
        logger.info("Starting enhanced feedback-based retraining for entity: {}", entityId);

        try {
            // Ensure H2O is ready
            h2oManager.startH2O();

            // 1. Load existing model
            AnomalyModel currentModel = anomalyModelRepo.findByEntityId(entityId).stream()
                    .filter(AnomalyModel::getActive)
                    .filter(model -> ModelType.ISOLATION_FOREST.name().equals(model.getModelType()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("No active Isolation Forest model found for entity: " + entityId));

            // 2. Load historical transaction data
            List<PaymentTransaction> historicalTxs = paymentTransactionRepo.findBySourceEntity(entityId);

            // 3. Prepare enhanced training data with feedback labels
            List<Map<String, Double>> enhancedFeatureList = prepareEnhancedTrainingData(historicalTxs, feedbackData);

            if (enhancedFeatureList.isEmpty()) {
                logger.warn("No enhanced training data available for entity: {}", entityId);
                return;
            }

            // 4. Train new model with feedback-enhanced data
            IsolationForestModelWrapper newModel = new IsolationForestModelWrapper(
                    featureOrder, nTrees, subsampleSize);

            newModel.train(enhancedFeatureList);

            // 5. Validate performance improvement
            Map<String, Double> newModelMetrics = newModel.crossValidate(enhancedFeatureList, 5);

            // 6. Compare with existing model performance
            String existingMetricsJson = currentModel.getMetrics();
            if (existingMetricsJson != null) {
                Map<String, Double> existingMetrics = objectMapper.readValue(existingMetricsJson, Map.class);

                double newF1 = newModelMetrics.getOrDefault("mean_f1", 0.0);
                double existingF1 = existingMetrics.getOrDefault("mean_f1", 0.0);

                if (newF1 <= existingF1) {
                    logger.warn("New model performance (F1: {}) not better than existing (F1: {}). Skipping deployment.",
                            newF1, existingF1);
                    return;
                }
            }

            // 7. Deploy if better performance
            Path entityModelDir = Paths.get(modelDir, entityId);
            Files.createDirectories(entityModelDir);

            String newModelPath = entityModelDir.resolve("isolation_forest_feedback_" + LocalDate.now() + ".model").toString();
            File modelFile = new File(newModelPath);
            newModel.save(modelFile);

            // 8. Update model metadata
            currentModel.setActive(false);
            anomalyModelRepo.save(currentModel);

            AnomalyModel feedbackModel = new AnomalyModel();
            feedbackModel.setEntityId(entityId);
            feedbackModel.setModelType(ModelType.ISOLATION_FOREST.name());
            feedbackModel.setTrainingDate(LocalDate.now());
            feedbackModel.setFilePath(newModelPath);
            feedbackModel.setActive(true);
            feedbackModel.setMetrics(objectMapper.writeValueAsString(newModelMetrics));

            anomalyModelRepo.save(feedbackModel);

            logger.info("Enhanced feedback-based retraining completed for entity: {}. New metrics: {}",
                    entityId, newModelMetrics);

        } catch (Exception e) {
            logger.error("Error during enhanced feedback-based retraining for entity {}: {}", entityId, e.getMessage(), e);
            throw new RuntimeException("Enhanced feedback-based retraining failed", e);
        }
    }

    private List<Map<String, Double>> prepareEnhancedTrainingData(List<PaymentTransaction> transactions,
                                                                  List<FeedbackLoopService.LabeledTrainingData> feedbackData) {
        // This method would implement sophisticated data preparation
        // incorporating feedback weights and labels
        List<Map<String, Double>> enhancedData = new ArrayList<>();

        for (PaymentTransaction tx : transactions) {
            try {
                PaymentTransactionDTO txDto = mapToDTO(tx);
                FeatureVectorDTO features = featureEngineeringService.extractFeatures(txDto);

                // Add government-specific features
                Map<String, Double> govFeatures = featureEngineeringService.extractGovernmentSpecificFeatures(txDto);
                features.getFeatures().putAll(govFeatures);

                // Apply feedback-based feature weighting
                Map<String, Double> weightedFeatures = applyFeedbackWeighting(features.getFeatures(), feedbackData);

                enhancedData.add(weightedFeatures);

            } catch (Exception e) {
                logger.error("Error preparing enhanced training data for transaction: {}", tx.getTransactionId(), e);
            }
        }

        return enhancedData;
    }

    private Map<String, Double> applyFeedbackWeighting(Map<String, Double> features,
                                                       List<FeedbackLoopService.LabeledTrainingData> feedbackData) {
        // Implement feedback-based feature weighting logic
        // This is a placeholder - real implementation would be more sophisticated
        return new HashMap<>(features);
    }

    // Helper method to convert entity to DTO
    private PaymentTransactionDTO mapToDTO(PaymentTransaction tx) {
        PaymentTransactionDTO dto = new PaymentTransactionDTO();
        dto.setTransactionId(tx.getTransactionId());
        dto.setBatchId(tx.getBatchId());
        dto.setSourceEntity(tx.getSourceEntity());
        dto.setAmount(tx.getAmount());
        dto.setCurrency(tx.getCurrency());
        dto.setBeneficiaryAccount(tx.getBeneficiaryAccount());
        dto.setBeneficiaryName(tx.getBeneficiaryName());
        dto.setBeneficiaryBank(tx.getBeneficiaryBank());
        dto.setTransactionDate(tx.getTransactionDate());
        return dto;
    }

    /**
     * Get H2O status information
     */
    public SimpleH2OManager.H2OInfo getH2OStatus() {
        return h2oManager.getH2OInfo();
    }

    /**
     * Check if training environment is ready
     */
    public boolean isTrainingReady() {
        return h2oManager.isH2OReady();
    }

    /**
     * Get training statistics for dashboard
     */
    public Map<String, Object> getTrainingStatistics() {
        Map<String, Object> stats = new HashMap<>();

        try {
            List<AnomalyModel> activeModels = anomalyModelRepo.findByActiveTrue();

            stats.put("totalActiveModels", activeModels.size());
            stats.put("isolationForestModels", activeModels.stream()
                    .filter(m -> ModelType.ISOLATION_FOREST.name().equals(m.getModelType()))
                    .count());
            stats.put("autoencoderModels", activeModels.stream()
                    .filter(m -> ModelType.AUTOENCODER.name().equals(m.getModelType()))
                    .count());

            // Get latest training date
            Optional<LocalDate> latestTrainingDate = activeModels.stream()
                    .map(AnomalyModel::getTrainingDate)
                    .max(LocalDate::compareTo);

            stats.put("lastTrainingDate", latestTrainingDate.orElse(null));
            stats.put("h2oStatus", getH2OStatus());

            // Calculate average metrics if available
            List<Double> f1Scores = activeModels.stream()
                    .filter(m -> m.getMetrics() != null)
                    .map(m -> {
                        try {
                            Map<String, Double> metrics = objectMapper.readValue(m.getMetrics(), Map.class);
                            return metrics.getOrDefault("mean_f1", 0.0);
                        } catch (Exception e) {
                            return 0.0;
                        }
                    })
                    .collect(Collectors.toList());

            if (!f1Scores.isEmpty()) {
                double avgF1 = f1Scores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                stats.put("averageF1Score", avgF1);
            }

        } catch (Exception e) {
            logger.error("Error calculating training statistics", e);
            stats.put("error", e.getMessage());
        }

        return stats;
    }
}