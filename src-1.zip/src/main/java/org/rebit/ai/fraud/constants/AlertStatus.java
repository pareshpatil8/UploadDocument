package org.rebit.ai.fraud.constants;

public enum AlertStatus {
    NEW, IN_REVIEW, CONFIRMED, ARCHIVED
}
