package org.rebit.ai.fraud.model.isolation;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class IsolationForestModelWrapper implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(IsolationForestModelWrapper.class);
    private static final long serialVersionUID = 1L;

    private EnhancedIsolationForest isolationForest;
    private List<String> featureOrder;
    private Map<String, FeatureStatistics> featureStatistics;
    private Map<String, FeatureValidationRule> validationRules;
    private boolean featureValidationEnabled = true;

    @Value("${isolationForest.nTrees:100}")
    private int nTrees;

    @Value("${isolationForest.subsample:256}")
    private int subsampleSize;

    @Value("${isolationForest.contamination:0.1}")
    private double contamination;

    @Value("${isolationForest.random-seed:42}")
    private long randomSeed;

    @Value("${isolationForest.feature-validation.enabled:true}")
    private boolean validationEnabled;

    @Value("${isolationForest.feature-validation.outlier-threshold:3.0}")
    private double outlierThreshold;

    @Value("${isolationForest.feature-validation.missing-value-strategy:MEAN}")
    private String missingValueStrategy;

    public IsolationForestModelWrapper() {
        this.featureStatistics = new HashMap<>();
        this.validationRules = new HashMap<>();
        initializeValidationRules();
    }

    public IsolationForestModelWrapper(List<String> featureOrder, int nTrees, int subsampleSize) {
        this();
        this.featureOrder = featureOrder;
        this.nTrees = nTrees;
        this.subsampleSize = subsampleSize;
        this.contamination = 0.1;
        this.randomSeed = 42;
    }

    private void initializeValidationRules() {
        // Define validation rules for each feature type
        validationRules.put("amount", new FeatureValidationRule(
                0.0, Double.MAX_VALUE, true, "Amount must be positive"));

        validationRules.put("account_hash", new FeatureValidationRule(
                Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, false, "Account hash"));

        validationRules.put("bank_hash", new FeatureValidationRule(
                Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, false, "Bank hash"));

        validationRules.put("is_round_amount", new FeatureValidationRule(
                0.0, 1.0, true, "Boolean flag must be 0 or 1"));

        validationRules.put("is_institutional", new FeatureValidationRule(
                0.0, 1.0, true, "Boolean flag must be 0 or 1"));

        validationRules.put("is_central", new FeatureValidationRule(
                0.0, 1.0, true, "Boolean flag must be 0 or 1"));

        validationRules.put("name_length", new FeatureValidationRule(
                0.0, 500.0, true, "Name length must be reasonable"));

        validationRules.put("has_title", new FeatureValidationRule(
                0.0, 1.0, true, "Boolean flag must be 0 or 1"));

        validationRules.put("is_organization", new FeatureValidationRule(
                0.0, 1.0, true, "Boolean flag must be 0 or 1"));
    }

    public void train(List<Map<String, Double>> featureList) {
        if (featureOrder == null) {
            featureOrder = new ArrayList<>(featureList.get(0).keySet());
        }

        // Calculate feature statistics during training
        calculateFeatureStatistics(featureList);

        // Validate training data
        List<Map<String, Double>> validatedFeatureList = validateAndCleanFeatureList(featureList);

        this.isolationForest = new EnhancedIsolationForest(nTrees, subsampleSize, contamination, randomSeed);

        List<double[]> vectors = new ArrayList<>();
        for (Map<String, Double> fv : validatedFeatureList) {
            double[] arr = convertFeatureMapToArray(fv);
            vectors.add(arr);
        }

        isolationForest.fit(vectors, featureOrder);
        logger.info("Isolation Forest trained with {} validated samples", vectors.size());
    }

    public double predict(Map<String, Double> featureVector) {
        if (isolationForest == null) {
            throw new IllegalStateException("Model not trained yet");
        }

        // Validate and clean the feature vector
        FeatureValidationResult validationResult = validateFeatureVector(featureVector);

        if (!validationResult.isValid() && validationResult.isCritical()) {
            logger.error("Critical validation errors in feature vector: {}",
                    validationResult.getErrors());
            throw new IllegalArgumentException("Invalid feature vector: " +
                    validationResult.getErrors());
        }

        if (!validationResult.isValid()) {
            logger.warn("Non-critical validation warnings: {}", validationResult.getWarnings());
        }

        Map<String, Double> cleanedFeatures = validationResult.getCleanedFeatures();
        double[] arr = convertFeatureMapToArray(cleanedFeatures);

        double score = isolationForest.score(arr);

        // Log feature validation metrics
        logPredictionMetrics(featureVector, cleanedFeatures, validationResult);

        return score;
    }

    public boolean isAnomaly(Map<String, Double> featureVector) {
        return isolationForest.isAnomaly(convertFeatureMapToArray(featureVector));
    }

    public EnhancedIsolationForest.AnomalyExplanation explainPrediction(Map<String, Double> featureVector) {
        FeatureValidationResult validationResult = validateFeatureVector(featureVector);
        Map<String, Double> cleanedFeatures = validationResult.getCleanedFeatures();

        EnhancedIsolationForest.AnomalyExplanation explanation =
                isolationForest.explainPrediction(convertFeatureMapToArray(cleanedFeatures));

        // Enhance explanation with validation information
        return new EnhancedAnomalyExplanation(explanation, validationResult);
    }

    private void calculateFeatureStatistics(List<Map<String, Double>> featureList) {
        Map<String, List<Double>> featureValues = new HashMap<>();

        // Collect all values for each feature
        for (Map<String, Double> features : featureList) {
            for (String feature : featureOrder) {
                featureValues.computeIfAbsent(feature, k -> new ArrayList<>())
                        .add(features.getOrDefault(feature, 0.0));
            }
        }

        // Calculate statistics for each feature
        for (String feature : featureOrder) {
            List<Double> values = featureValues.get(feature);
            if (values != null && !values.isEmpty()) {
                DescriptiveStatistics stats = new DescriptiveStatistics();
                values.forEach(stats::addValue);

                featureStatistics.put(feature, new FeatureStatistics(
                        stats.getMean(),
                        stats.getStandardDeviation(),
                        stats.getMin(),
                        stats.getMax(),
                        stats.getPercentile(25),
                        stats.getPercentile(75),
                        calculateMAD(values, stats.getPercentile(50))
                ));
            }
        }

        logger.info("Calculated statistics for {} features", featureStatistics.size());
    }

    private double calculateMAD(List<Double> values, double median) {
        List<Double> deviations = values.stream()
                .map(v -> Math.abs(v - median))
                .sorted()
                .collect(Collectors.toList());

        int size = deviations.size();
        if (size % 2 == 0) {
            return (deviations.get(size / 2 - 1) + deviations.get(size / 2)) / 2.0;
        } else {
            return deviations.get(size / 2);
        }
    }

    private List<Map<String, Double>> validateAndCleanFeatureList(List<Map<String, Double>> featureList) {
        List<Map<String, Double>> cleaned = new ArrayList<>();
        int validCount = 0;
        int cleanedCount = 0;

        for (Map<String, Double> features : featureList) {
            FeatureValidationResult result = validateFeatureVector(features);

            if (result.isValid() || !result.isCritical()) {
                cleaned.add(result.getCleanedFeatures());
                validCount++;
                if (result.wasCleaned()) {
                    cleanedCount++;
                }
            }
        }

        logger.info("Training data validation: {} valid, {} cleaned, {} rejected out of {} total",
                validCount, cleanedCount, featureList.size() - validCount, featureList.size());

        return cleaned;
    }

    private FeatureValidationResult validateFeatureVector(Map<String, Double> featureVector) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        Map<String, Double> cleanedFeatures = new HashMap<>(featureVector);
        boolean wasCleaned = false;
        boolean isCritical = false;

        for (String feature : featureOrder) {
            Double value = featureVector.get(feature);
            FeatureValidationRule rule = validationRules.get(feature);
            FeatureStatistics stats = featureStatistics.get(feature);

            // Check for missing values
            if (value == null || Double.isNaN(value)) {
                wasCleaned = true;
                Double imputedValue = imputeMissingValue(feature, stats);
                cleanedFeatures.put(feature, imputedValue);
                warnings.add(String.format("Missing value imputed for %s: %f", feature, imputedValue));
                continue;
            }

            // Check for infinite values
            if (Double.isInfinite(value)) {
                errors.add(String.format("Infinite value for feature %s", feature));
                isCritical = true;
                continue;
            }

            // Apply validation rules
            if (rule != null) {
                if (value < rule.getMinValue() || value > rule.getMaxValue()) {
                    if (rule.isStrict()) {
                        errors.add(String.format("Feature %s value %f outside valid range [%f, %f]",
                                feature, value, rule.getMinValue(), rule.getMaxValue()));
                        isCritical = true;
                    } else {
                        // Clip to valid range
                        double clippedValue = Math.max(rule.getMinValue(),
                                Math.min(rule.getMaxValue(), value));
                        cleanedFeatures.put(feature, clippedValue);
                        wasCleaned = true;
                        warnings.add(String.format("Feature %s clipped from %f to %f",
                                feature, value, clippedValue));
                    }
                }
            }

            // Check for statistical outliers
            if (stats != null && featureValidationEnabled) {
                double zScore = Math.abs(value - stats.getMean()) / stats.getStdDev();
                if (zScore > outlierThreshold) {
                    warnings.add(String.format("Potential outlier for %s: value=%f, z-score=%f",
                            feature, value, zScore));

                    // Apply robust clipping using MAD
                    double madThreshold = 3.0;
                    double deviation = Math.abs(value - stats.getMedian()) / stats.getMad();
                    if (deviation > madThreshold) {
                        double clippedValue = stats.getMedian() +
                                Math.signum(value - stats.getMedian()) * madThreshold * stats.getMad();
                        cleanedFeatures.put(feature, clippedValue);
                        wasCleaned = true;
                        warnings.add(String.format("Extreme outlier clipped for %s: %f -> %f",
                                feature, value, clippedValue));
                    }
                }
            }
        }

        // Check for completely missing features
        for (String expectedFeature : featureOrder) {
            if (!cleanedFeatures.containsKey(expectedFeature)) {
                FeatureStatistics stats = featureStatistics.get(expectedFeature);
                Double imputedValue = imputeMissingValue(expectedFeature, stats);
                cleanedFeatures.put(expectedFeature, imputedValue);
                wasCleaned = true;
                warnings.add(String.format("Missing feature %s imputed with %f",
                        expectedFeature, imputedValue));
            }
        }

        return new FeatureValidationResult(
                errors.isEmpty(),
                isCritical,
                wasCleaned,
                errors,
                warnings,
                cleanedFeatures
        );
    }

    private Double imputeMissingValue(String feature, FeatureStatistics stats) {
        if (stats == null) {
            // Return default values based on feature type
            if (feature.startsWith("is_") || feature.startsWith("has_")) {
                return 0.0; // Boolean features default to false
            }
            return 0.0; // Other features default to 0
        }

        switch (missingValueStrategy.toUpperCase()) {
            case "MEDIAN":
                return stats.getMedian();
            case "MODE":
                return stats.getMean(); // Simplified - would need actual mode calculation
            case "ZERO":
                return 0.0;
            case "MEAN":
            default:
                return stats.getMean();
        }
    }

    private void logPredictionMetrics(Map<String, Double> original,
                                      Map<String, Double> cleaned,
                                      FeatureValidationResult validation) {
        if (logger.isDebugEnabled()) {
            logger.debug("Prediction validation - Errors: {}, Warnings: {}, Cleaned: {}",
                    validation.getErrors().size(),
                    validation.getWarnings().size(),
                    validation.wasCleaned());

            // Log feature changes
            for (String feature : featureOrder) {
                Double originalValue = original.get(feature);
                Double cleanedValue = cleaned.get(feature);
                if (originalValue != null && cleanedValue != null &&
                        !originalValue.equals(cleanedValue)) {
                    logger.debug("Feature {} changed: {} -> {}", feature, originalValue, cleanedValue);
                }
            }
        }
    }

    private double[] convertFeatureMapToArray(Map<String, Double> featureVector) {
        double[] arr = new double[featureOrder.size()];
        for (int i = 0; i < featureOrder.size(); i++) {
            arr[i] = featureVector.getOrDefault(featureOrder.get(i), 0.0);
        }
        return arr;
    }

    // Getters and existing methods...
    public List<String> getFeatureOrder() {
        return featureOrder != null ? new ArrayList<>(featureOrder) : new ArrayList<>();
    }

    public double[] getFeatureImportance() {
        return isolationForest != null ? isolationForest.getFeatureImportance() : new double[0];
    }

    public Map<String, Double> crossValidate(List<Map<String, Double>> data, int folds) {
        if (isolationForest == null) {
            throw new IllegalStateException("Model not trained yet");
        }

        List<double[]> vectors = new ArrayList<>();
        for (Map<String, Double> fv : data) {
            FeatureValidationResult validation = validateFeatureVector(fv);
            vectors.add(convertFeatureMapToArray(validation.getCleanedFeatures()));
        }

        return isolationForest.crossValidate(vectors, folds);
    }

    public Map<String, FeatureStatistics> getFeatureStatistics() {
        return new HashMap<>(featureStatistics);
    }

    public FeatureValidationResult validateFeatures(Map<String, Double> features) {
        return validateFeatureVector(features);
    }

    public void save(File file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(this);
        }
    }

    public static IsolationForestModelWrapper load(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (IsolationForestModelWrapper) ois.readObject();
        }
    }

    // Inner classes for validation
    public static class FeatureValidationRule {
        private final double minValue;
        private final double maxValue;
        private final boolean strict;
        private final String description;

        public FeatureValidationRule(double minValue, double maxValue, boolean strict, String description) {
            this.minValue = minValue;
            this.maxValue = maxValue;
            this.strict = strict;
            this.description = description;
        }

        // Getters
        public double getMinValue() { return minValue; }
        public double getMaxValue() { return maxValue; }
        public boolean isStrict() { return strict; }
        public String getDescription() { return description; }
    }

    public static class FeatureStatistics {
        private final double mean;
        private final double stdDev;
        private final double min;
        private final double max;
        private final double q25;
        private final double q75;
        private final double mad;
        private final double median;

        public FeatureStatistics(double mean, double stdDev, double min, double max,
                                 double q25, double q75, double mad) {
            this.mean = mean;
            this.stdDev = stdDev;
            this.min = min;
            this.max = max;
            this.q25 = q25;
            this.q75 = q75;
            this.mad = mad;
            this.median = (q25 + q75) / 2.0; // Approximation
        }

        // Getters
        public double getMean() { return mean; }
        public double getStdDev() { return stdDev; }
        public double getMin() { return min; }
        public double getMax() { return max; }
        public double getQ25() { return q25; }
        public double getQ75() { return q75; }
        public double getMad() { return mad; }
        public double getMedian() { return median; }
    }

    public static class FeatureValidationResult {
        private final boolean valid;
        private final boolean critical;
        private final boolean wasCleaned;
        private final List<String> errors;
        private final List<String> warnings;
        private final Map<String, Double> cleanedFeatures;

        public FeatureValidationResult(boolean valid, boolean critical, boolean wasCleaned,
                                       List<String> errors, List<String> warnings,
                                       Map<String, Double> cleanedFeatures) {
            this.valid = valid;
            this.critical = critical;
            this.wasCleaned = wasCleaned;
            this.errors = new ArrayList<>(errors);
            this.warnings = new ArrayList<>(warnings);
            this.cleanedFeatures = new HashMap<>(cleanedFeatures);
        }

        // Getters
        public boolean isValid() { return valid; }
        public boolean isCritical() { return critical; }
        public boolean wasCleaned() { return wasCleaned; }
        public List<String> getErrors() { return new ArrayList<>(errors); }
        public List<String> getWarnings() { return new ArrayList<>(warnings); }
        public Map<String, Double> getCleanedFeatures() { return new HashMap<>(cleanedFeatures); }
    }

    public static class EnhancedAnomalyExplanation extends EnhancedIsolationForest.AnomalyExplanation {
        private final FeatureValidationResult validationResult;

        public EnhancedAnomalyExplanation(EnhancedIsolationForest.AnomalyExplanation original,
                                          FeatureValidationResult validationResult) {
            super(original.getAnomalyScore(),
                    original.isAnomaly(),
                    original.getThreshold(),
                    original.getFeatureContributions(),  // Directly use the array
                    original.getFeatureNames());
            this.validationResult = validationResult;
        }

        @Override
        public String getExplanation() {
            StringBuilder explanation = new StringBuilder(super.getExplanation());

            explanation.append("\nFeature Validation:\n");
            if (validationResult.isValid()) {
                explanation.append("✓ All features passed validation\n");
            } else {
                explanation.append("⚠ Validation issues detected\n");
                if (!validationResult.getErrors().isEmpty()) {
                    explanation.append("Errors: ").append(String.join(", ", validationResult.getErrors())).append("\n");
                }
                if (!validationResult.getWarnings().isEmpty()) {
                    explanation.append("Warnings: ").append(String.join(", ", validationResult.getWarnings())).append("\n");
                }
            }

            if (validationResult.wasCleaned()) {
                explanation.append("📝 Features were automatically cleaned/imputed\n");
            }

            return explanation.toString();
        }

        public FeatureValidationResult getValidationResult() {
            return validationResult;
        }
    }
}