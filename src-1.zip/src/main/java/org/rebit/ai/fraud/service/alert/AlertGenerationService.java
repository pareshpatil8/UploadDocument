package org.rebit.ai.fraud.service.alert;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.constants.AlertStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AlertGenerationService {

    public AnomalyAlert generateAlert(String transactionId, double score, String type, String notes) {
        AnomalyAlert alert = new AnomalyAlert();
        alert.setTransactionId(transactionId);
        alert.setAlertScore(score);
        alert.setAlertType(type);
        alert.setStatus(AlertStatus.NEW.name());
        alert.setDetectionDate(LocalDateTime.now());
        alert.setNotes(notes);
        alert.setReviewed(false);
        return alert;
    }
}
