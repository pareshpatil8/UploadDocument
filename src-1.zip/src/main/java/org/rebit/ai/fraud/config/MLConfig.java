package org.rebit.ai.fraud.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;

@Configuration
public class MLConfig {
    // Previously existing values
    private String modelDir;
    private int isolationForestNTrees;
    private int isolationForestSubsample;
    private double autoencoderLearningRate;
    private int autoencoderEpochs;

    // New values from application.yml
    private List<Integer> autoencoderHiddenLayers;
    private String autoencoderActivation;
    private double autoencoderL1;

    private EnsembleConfig ensemble;
    private List<String> isolationForestFeatureOrder;

    // Getter/setters

    @Component
    @ConfigurationProperties(prefix = "model.ensemble")
    public static class EnsembleConfig {
        private WeightsConfig weights;
        private double anomalyThreshold;

        // Getters and setters

        public WeightsConfig getWeights() {
            return weights;
        }

        public void setWeights(WeightsConfig weights) {
            this.weights = weights;
        }

        public double getAnomalyThreshold() {
            return anomalyThreshold;
        }

        public void setAnomalyThreshold(double anomalyThreshold) {
            this.anomalyThreshold = anomalyThreshold;
        }
    }

    @Component
    @ConfigurationProperties(prefix = "model.ensemble.weights")
    public static class WeightsConfig {
        private double isolationForest;
        private double autoencoder;
        private double temporal;

        // Getters and setters

        public double getIsolationForest() {
            return isolationForest;
        }

        public void setIsolationForest(double isolationForest) {
            this.isolationForest = isolationForest;
        }

        public double getAutoencoder() {
            return autoencoder;
        }

        public void setAutoencoder(double autoencoder) {
            this.autoencoder = autoencoder;
        }

        public double getTemporal() {
            return temporal;
        }

        public void setTemporal(double temporal) {
            this.temporal = temporal;
        }
    }
}