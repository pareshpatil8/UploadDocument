package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Id {
    @XmlElement(name = "OrgId")
    private OrgId orgId;

    // getters/setters
}
