package org.rebit.ai.fraud.util.xml;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import org.rebit.ai.fraud.xml.PaymentXML;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;

@Service
public class XmlParsingService {
    public PaymentXML parse(File xmlFile) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(PaymentXML.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        return (PaymentXML) unmarshaller.unmarshal(xmlFile);
    }

    public PaymentXML parse(InputStream xmlStream) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(PaymentXML.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        return (PaymentXML) unmarshaller.unmarshal(xmlStream);
    }
}
