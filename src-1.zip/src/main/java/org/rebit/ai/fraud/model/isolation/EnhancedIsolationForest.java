package org.rebit.ai.fraud.model.isolation;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Enhanced Isolation Forest with production-ready features:
 * - Feature importance calculation
 * - Cross-validation support
 * - Robust hyperparameter handling
 * - Anomaly explanation capabilities
 */
public class EnhancedIsolationForest implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(EnhancedIsolationForest.class);
    private static final long serialVersionUID = 1L;

    private List<EnhancedIsolationTree> trees = new ArrayList<>();
    private int nTrees;
    private int subsampleSize;
    private double contamination = 0.1; // Expected percentage of anomalies
    private Random random;
    private List<String> featureNames;
    private double[] featureImportance;
    private double anomalyThreshold;

    // Performance metrics
    private Map<String, Double> validationMetrics = new HashMap<>();

    public EnhancedIsolationForest(int nTrees, int subsampleSize, double contamination, long seed) {
        this.nTrees = nTrees;
        this.subsampleSize = subsampleSize;
        this.contamination = contamination;
        this.random = new Random(seed);
    }

    public void fit(List<double[]> data, List<String> featureNames) {
        this.featureNames = new ArrayList<>(featureNames);
        this.featureImportance = new double[featureNames.size()];

        logger.info("Training Isolation Forest with {} trees, subsample size {}", nTrees, subsampleSize);

        // Validate input data
        validateInputData(data);

        // Build trees with enhanced sampling
        buildTrees(data);

        // Calculate feature importance
        calculateFeatureImportance(data);

        // Determine dynamic threshold based on contamination
        calculateDynamicThreshold(data);

        logger.info("Training completed. Anomaly threshold: {}", anomalyThreshold);
    }

    private void validateInputData(List<double[]> data) {
        if (data.isEmpty()) {
            throw new IllegalArgumentException("Training data cannot be empty");
        }

        int expectedFeatures = featureNames.size();
        for (double[] instance : data) {
            if (instance.length != expectedFeatures) {
                throw new IllegalArgumentException(
                        String.format("Feature dimension mismatch. Expected %d, got %d",
                                expectedFeatures, instance.length));
            }
        }

        // Check for data quality issues
        checkDataQuality(data);
    }

    private void checkDataQuality(List<double[]> data) {
        int numFeatures = data.get(0).length;

        for (int i = 0; i < numFeatures; i++) {
            DescriptiveStatistics stats = new DescriptiveStatistics();
            for (double[] instance : data) {
                if (!Double.isNaN(instance[i]) && !Double.isInfinite(instance[i])) {
                    stats.addValue(instance[i]);
                }
            }

            if (stats.getN() == 0) {
                logger.warn("Feature '{}' contains only invalid values", featureNames.get(i));
            } else if (stats.getStandardDeviation() == 0) {
                logger.warn("Feature '{}' has zero variance", featureNames.get(i));
            }
        }
    }

    private void buildTrees(List<double[]> data) {
        // Use stratified sampling for better tree diversity
        for (int i = 0; i < nTrees; i++) {
            List<double[]> sample = stratifiedSample(data, subsampleSize);
            int maxDepth = (int) Math.ceil(Math.log(subsampleSize) / Math.log(2));
            trees.add(new EnhancedIsolationTree(sample, 0, maxDepth, random, featureNames));
        }
    }

    private List<double[]> stratifiedSample(List<double[]> data, int sampleSize) {
        List<double[]> sample = new ArrayList<>();
        int numBins = 5; // Configurable bin count

        // Create bins based on feature distributions
        Map<Integer, List<double[]>> bins = new HashMap<>();
        for (double[] instance : data) {
            int bin = (int) (instance[0] % numBins); // Use first feature for demo
            bins.computeIfAbsent(bin, k -> new ArrayList<>()).add(instance);
        }

        // Sample proportionally from each bin
        for (List<double[]> bin : bins.values()) {
            int binSampleSize = (int) Math.ceil((double) bin.size() / data.size() * sampleSize);
            Collections.shuffle(bin);
            sample.addAll(bin.subList(0, Math.min(binSampleSize, bin.size())));
        }

        return sample.stream().distinct().limit(sampleSize).collect(Collectors.toList());
    }

    private void calculateFeatureImportance(List<double[]> data) {
        Arrays.fill(featureImportance, 0.0);

        // Calculate feature importance based on how often features are used for splits
        // and how much they contribute to isolation
        for (EnhancedIsolationTree tree : trees) {
            double[] treeImportance = tree.getFeatureImportance();
            for (int i = 0; i < featureImportance.length; i++) {
                featureImportance[i] += treeImportance[i];
            }
        }

        // Normalize feature importance
        double totalImportance = Arrays.stream(featureImportance).sum();
        if (totalImportance > 0) {
            for (int i = 0; i < featureImportance.length; i++) {
                featureImportance[i] /= totalImportance;
            }
        }

        logger.info("Feature importance calculated: {}", Arrays.toString(featureImportance));
    }

    private void calculateDynamicThreshold(List<double[]> data) {
        double[] scores = data.stream()
                .mapToDouble(this::score)
                .sorted()
                .toArray();

        if (scores.length == 0) {
            throw new IllegalStateException("No scores available for threshold calculation");
        }

        int thresholdIndex = (int) ((1.0 - contamination) * scores.length);
        this.anomalyThreshold = scores[Math.min(thresholdIndex, scores.length - 1)];

        // Ensure threshold is reasonable
        if (anomalyThreshold < 0.5 || anomalyThreshold > 0.99) {
            logger.warn("Calculated threshold {} seems unreasonable. Using default 0.85", anomalyThreshold);
            this.anomalyThreshold = 0.85;
        }
    }

    public double score(double[] instance) {
        if (trees.isEmpty()) {
            throw new IllegalStateException("Model not trained yet");
        }

        double avgPathLength = 0;
        for (EnhancedIsolationTree tree : trees) {
            avgPathLength += tree.pathLength(instance, 0);
        }
        avgPathLength /= nTrees;

        double c = calculateC(subsampleSize);
        return Math.pow(2, -avgPathLength / c);
    }

    public boolean isAnomaly(double[] instance) {
        return score(instance) > anomalyThreshold;
    }

    /**
     * Provides explanation for anomaly detection
     */
    public AnomalyExplanation explainPrediction(double[] instance) {
        double anomalyScore = score(instance);
        boolean isAnomalous = anomalyScore > anomalyThreshold;

        // Calculate per-feature contributions
        double[] featureContributions = calculateFeatureContributions(instance);

        return new AnomalyExplanation(
                anomalyScore,
                isAnomalous,
                anomalyThreshold,
                featureContributions,
                featureNames
        );
    }

    private double[] calculateFeatureContributions(double[] instance) {
        double[] contributions = new double[instance.length];

        // Calculate how much each feature contributes to the anomaly score
        for (int i = 0; i < instance.length; i++) {
            // Use feature importance and deviation from tree splits
            contributions[i] = featureImportance[i] * calculateFeatureDeviation(instance, i);
        }

        return contributions;
    }

    private double calculateFeatureDeviation(double[] instance, int featureIndex) {
        double totalDeviation = 0;
        int count = 0;

        for (EnhancedIsolationTree tree : trees) {
            double deviation = tree.getFeatureDeviation(instance, featureIndex);
            if (!Double.isNaN(deviation)) {
                totalDeviation += deviation;
                count++;
            }
        }

        return count > 0 ? totalDeviation / count : 0.0;
    }

    /**
     * Cross-validation for model evaluation
     */
    public Map<String, Double> crossValidate(List<double[]> data, int folds) {
        logger.info("Performing {}-fold cross-validation", folds);

        Collections.shuffle(data, random);
        int foldSize = data.size() / folds;

        double[] precisionScores = new double[folds];
        double[] recallScores = new double[folds];
        double[] f1Scores = new double[folds];

        for (int fold = 0; fold < folds; fold++) {
            int start = fold * foldSize;
            int end = (fold == folds - 1) ? data.size() : start + foldSize;

            List<double[]> testData = data.subList(start, end);
            List<double[]> trainData = new ArrayList<>();
            trainData.addAll(data.subList(0, start));
            trainData.addAll(data.subList(end, data.size()));

            // Train on fold
            EnhancedIsolationForest foldModel = new EnhancedIsolationForest(
                    nTrees, subsampleSize, contamination, random.nextLong());
            foldModel.fit(trainData, featureNames);

            // Evaluate on test set
            Map<String, Double> foldMetrics = evaluateModel(foldModel, testData);
            precisionScores[fold] = foldMetrics.get("precision");
            recallScores[fold] = foldMetrics.get("recall");
            f1Scores[fold] = foldMetrics.get("f1");
        }

        Map<String, Double> cvResults = new HashMap<>();
        cvResults.put("mean_precision", Arrays.stream(precisionScores).average().orElse(0.0));
        cvResults.put("mean_recall", Arrays.stream(recallScores).average().orElse(0.0));
        cvResults.put("mean_f1", Arrays.stream(f1Scores).average().orElse(0.0));
        cvResults.put("std_precision", calculateStandardDeviation(precisionScores));
        cvResults.put("std_recall", calculateStandardDeviation(recallScores));
        cvResults.put("std_f1", calculateStandardDeviation(f1Scores));

        this.validationMetrics = cvResults;
        return cvResults;
    }

    private Map<String, Double> evaluateModel(EnhancedIsolationForest model, List<double[]> testData) {
        // For unsupervised evaluation, we assume the top contamination% are anomalies
        double[] scores = testData.stream().mapToDouble(model::score).toArray();
        boolean[] predictions = new boolean[testData.size()];

        // Calculate predictions using isAnomaly method
        for (int i = 0; i < testData.size(); i++) {
            predictions[i] = model.isAnomaly(testData.get(i));
        }

        // Create pseudo ground truth based on top scores
        boolean[] groundTruth = new boolean[scores.length];
        Integer[] indices = IntStream.range(0, scores.length).boxed().toArray(Integer[]::new);
        Arrays.sort(indices, (i, j) -> Double.compare(scores[j], scores[i]));

        int numAnomalies = (int) (contamination * scores.length);
        for (int i = 0; i < numAnomalies; i++) {
            groundTruth[indices[i]] = true;
        }

        return calculateMetrics(predictions, groundTruth);
    }

    private Map<String, Double> calculateMetrics(boolean[] predictions, boolean[] groundTruth) {
        int tp = 0, fp = 0, tn = 0, fn = 0;

        for (int i = 0; i < predictions.length; i++) {
            if (predictions[i] && groundTruth[i]) tp++;
            else if (predictions[i] && !groundTruth[i]) fp++;
            else if (!predictions[i] && !groundTruth[i]) tn++;
            else fn++;
        }

        double precision = tp + fp > 0 ? (double) tp / (tp + fp) : 0.0;
        double recall = tp + fn > 0 ? (double) tp / (tp + fn) : 0.0;
        double f1 = precision + recall > 0 ? 2 * precision * recall / (precision + recall) : 0.0;

        Map<String, Double> metrics = new HashMap<>();
        metrics.put("precision", precision);
        metrics.put("recall", recall);
        metrics.put("f1", f1);
        metrics.put("accuracy", (double) (tp + tn) / (tp + fp + tn + fn));

        return metrics;
    }

    private double calculateStandardDeviation(double[] values) {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double value : values) {
            stats.addValue(value);
        }
        return stats.getStandardDeviation();
    }

    private double calculateC(int n) {
        return n > 2 ? 2.0 * (Math.log(n - 1) + 0.5772156649) - (2.0 * (n - 1) / n) : 1;
    }

    // Getters
    public double[] getFeatureImportance() { return featureImportance.clone(); }
    public List<String> getFeatureNames() { return new ArrayList<>(featureNames); }
    public double getAnomalyThreshold() { return anomalyThreshold; }
    public Map<String, Double> getValidationMetrics() { return new HashMap<>(validationMetrics); }

    /**
     * Enhanced Isolation Tree with feature importance tracking
     */
    private static class EnhancedIsolationTree {
        private IsolationNode root;
        private double[] featureImportance;
        private List<String> featureNames;
        private Map<Integer, List<Double>> featureSplits;

        EnhancedIsolationTree(List<double[]> data, int currentDepth, int maxDepth,
                              Random random, List<String> featureNames) {
            this.featureNames = featureNames;
            this.featureImportance = new double[featureNames.size()];
            this.featureSplits = new HashMap<>();

            for (int i = 0; i < featureNames.size(); i++) {
                featureSplits.put(i, new ArrayList<>());
            }

            this.root = buildEnhancedTree(data, currentDepth, maxDepth, random);
        }

        private IsolationNode buildEnhancedTree(List<double[]> data, int depth, int maxDepth, Random random) {
            if (depth >= maxDepth || data.size() <= 1) {
                return new IsolationNode(null, null, -1, 0, data.size());
            }

            int nFeatures = data.get(0).length;
            int q = random.nextInt(nFeatures);

            double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
            for (double[] d : data) {
                min = Math.min(min, d[q]);
                max = Math.max(max, d[q]);
            }

            if (min == max) {
                return new IsolationNode(null, null, -1, 0, data.size());
            }

            double p = min + random.nextDouble() * (max - min);
            featureSplits.get(q).add(p);

            // Update feature importance based on information gain
            double informationGain = calculateInformationGain(data, q, p);
            featureImportance[q] += informationGain;

            List<double[]> left = new ArrayList<>(), right = new ArrayList<>();
            for (double[] d : data) {
                if (d[q] < p) left.add(d);
                else right.add(d);
            }

            return new IsolationNode(
                    buildEnhancedTree(left, depth + 1, maxDepth, random),
                    buildEnhancedTree(right, depth + 1, maxDepth, random),
                    q, p, data.size()
            );
        }

        private double calculateInformationGain(List<double[]> data, int feature, double threshold) {
            if (data.size() <= 1) return 0.0;

            int leftCount = 0, rightCount = 0;
            for (double[] instance : data) {
                if (instance[feature] < threshold) leftCount++;
                else rightCount++;
            }

            if (leftCount == 0 || rightCount == 0) return 0.0;

            // Simple information gain approximation for isolation
            double ratio = Math.min((double) leftCount / data.size(), (double) rightCount / data.size());
            return ratio * (1 - ratio); // Gini impurity-like measure
        }

        public double pathLength(double[] instance, int depth) {
            return root.pathLength(instance, depth);
        }

        public double[] getFeatureImportance() {
            return featureImportance.clone();
        }

        public double getFeatureDeviation(double[] instance, int featureIndex) {
            List<Double> splits = featureSplits.get(featureIndex);
            if (splits.isEmpty()) return 0.0;

            double featureValue = instance[featureIndex];
            double minDeviation = Double.MAX_VALUE;

            for (double split : splits) {
                minDeviation = Math.min(minDeviation, Math.abs(featureValue - split));
            }

            return minDeviation;
        }
    }

    /**
     * Inner class representing a node in the isolation tree
     */
    private static class IsolationNode {
        IsolationNode left, right;
        int splitAttr;
        double splitValue;
        int size;

        IsolationNode(IsolationNode l, IsolationNode r, int q, double p, int size) {
            this.left = l;
            this.right = r;
            this.splitAttr = q;
            this.splitValue = p;
            this.size = size;
        }

        double pathLength(double[] inst, int depth) {
            if (left == null && right == null)
                return depth + c(size);
            if (inst[splitAttr] < splitValue) {
                return left.pathLength(inst, depth + 1);
            } else {
                return right.pathLength(inst, depth + 1);
            }
        }

        private double c(int n) {
            return n > 2 ? 2.0 * (Math.log(n - 1) + 0.5772156649) - (2.0 * (n - 1) / n) : 1;
        }
    }

    /**
     * Explanation class for anomaly predictions
     */
    public static class AnomalyExplanation {
        private final double anomalyScore;
        private final boolean isAnomaly;
        private final double threshold;
        private final double[] featureContributions;
        private final List<String> featureNames;

        public AnomalyExplanation(double anomalyScore, boolean isAnomaly, double threshold,
                                  double[] featureContributions, List<String> featureNames) {
            this.anomalyScore = anomalyScore;
            this.isAnomaly = isAnomaly;
            this.threshold = threshold;
            this.featureContributions = featureContributions.clone();
            this.featureNames = new ArrayList<>(featureNames);
        }

        public String getExplanation() {
            StringBuilder explanation = new StringBuilder();
            explanation.append(String.format("Anomaly Score: %.4f (Threshold: %.4f) - %s\n",
                    anomalyScore, threshold, isAnomaly ? "ANOMALY" : "NORMAL"));

            explanation.append("Feature Contributions:\n");

            // Sort features by contribution
            Integer[] indices = IntStream.range(0, featureContributions.length).boxed().toArray(Integer[]::new);
            Arrays.sort(indices, (i, j) -> Double.compare(featureContributions[j], featureContributions[i]));

            for (int i = 0; i < Math.min(5, indices.length); i++) {
                int idx = indices[i];
                explanation.append(String.format("  %s: %.4f\n",
                        featureNames.get(idx), featureContributions[idx]));
            }

            return explanation.toString();
        }

        // Getters
        public double getAnomalyScore() { return anomalyScore; }
        public boolean isAnomaly() { return isAnomaly; }
        public double getThreshold() { return threshold; }
        public double[] getFeatureContributions() { return featureContributions.clone(); }
        public List<String> getFeatureNames() { return new ArrayList<>(featureNames); }
    }
}