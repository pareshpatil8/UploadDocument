package org.rebit.ai.fraud.service.alert;

import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.springframework.stereotype.Service;

@Service
public class AlertNotificationService {

    public void notify(AnomalyAlert alert) {
        // Integration with e-mail/SMS/queue, etc. For demo:
        System.out.println("NOTIFY: High-priority anomaly detected! " + alert.getAlertType() +
                " for txn " + alert.getTransactionId() + ", score: " + alert.getAlertScore());
    }
}
