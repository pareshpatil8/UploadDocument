package org.rebit.ai.fraud.util.ml;

import org.rebit.ai.fraud.model.isolation.IsolationForestModelWrapper;
import org.rebit.ai.fraud.model.autoencoder.AutoencoderModelWrapper;
import org.rebit.ai.fraud.exception.FraudDetectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Utility for serializing and deserializing ML models.
 * Handles both custom isolation forest models and H2O autoencoder models.
 */
public class ModelSerializationUtil {
    private static final Logger logger = LoggerFactory.getLogger(ModelSerializationUtil.class);

    /**
     * Saves an IsolationForestModelWrapper to disk
     */
    public static void saveIsolationForestModel(IsolationForestModelWrapper model, Path path) throws IOException {
        // Ensure the directory exists
        Files.createDirectories(path.getParent());

        try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(path))) {
            oos.writeObject(model);
            logger.info("Isolation Forest model saved to: {}", path.toString());
        } catch (IOException e) {
            logger.error("Failed to save Isolation Forest model: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Loads an IsolationForestModelWrapper from disk
     */
    public static IsolationForestModelWrapper loadIsolationForestModel(Path path) throws IOException, ClassNotFoundException {
        if (!Files.exists(path)) {
            throw new IOException("Model file does not exist: " + path);
        }

        try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(path))) {
            Object model = ois.readObject();
            if (!(model instanceof IsolationForestModelWrapper)) {
                throw new ClassCastException("Stored model is not an IsolationForestModelWrapper");
            }
            logger.info("Isolation Forest model loaded from: {}", path.toString());
            return (IsolationForestModelWrapper) model;
        } catch (IOException | ClassNotFoundException e) {
            logger.error("Failed to load Isolation Forest model: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Saves an AutoencoderModelWrapper to disk using H2O's built-in serialization
     */
    public static void saveAutoencoderModel(AutoencoderModelWrapper model, Path path) throws IOException {
        // H2O's AutoencoderModelWrapper already has a save method
        try {
            Files.createDirectories(path.getParent());
            model.save(path.toString());
            logger.info("Autoencoder model saved to: {}", path.toString());
        } catch (Exception e) {
            logger.error("Failed to save Autoencoder model: {}", e.getMessage());
            throw new IOException("Failed to save Autoencoder model", e);
        }
    }

    /**
     * Loads an AutoencoderModelWrapper from disk using H2O's built-in deserialization
     */
    public static AutoencoderModelWrapper loadAutoencoderModel(Path path) throws IOException {
        if (!Files.exists(path)) {
            throw new IOException("Model file does not exist: " + path);
        }

        try {
            AutoencoderModelWrapper model = AutoencoderModelWrapper.load(path.toString());
            logger.info("Autoencoder model loaded from: {}", path.toString());
            return model;
        } catch (Exception e) {
            logger.error("Failed to load Autoencoder model: {}", e.getMessage());
            throw new IOException("Failed to load Autoencoder model", e);
        }
    }

    /**
     * Generic method to save any Serializable model object
     */
    public static void saveSerializableModel(Serializable model, Path path) throws IOException {
        Files.createDirectories(path.getParent());

        try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(path))) {
            oos.writeObject(model);
            logger.info("Serializable model saved to: {}", path.toString());
        } catch (IOException e) {
            logger.error("Failed to save serializable model: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Generic method to load any Serializable model object
     */
    public static <T extends Serializable> T loadSerializableModel(Path path, Class<T> clazz) throws IOException, ClassNotFoundException {
        if (!Files.exists(path)) {
            throw new IOException("Model file does not exist: " + path);
        }

        try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(path))) {
            Object model = ois.readObject();
            if (!clazz.isInstance(model)) {
                throw new ClassCastException("Stored model is not of type " + clazz.getName());
            }
            logger.info("Serializable model loaded from: {}", path.toString());
            return clazz.cast(model);
        } catch (IOException | ClassNotFoundException e) {
            logger.error("Failed to load serializable model: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Checks if a model file exists at the given path
     */
    public static boolean modelExists(Path path) {
        return Files.exists(path);
    }
}