package org.rebit.ai.fraud.model.temporal;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.complex.Complex;
import org.apache.commons.math3.transform.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.rebit.ai.fraud.entity.PaymentTransaction;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TemporalPatternService {

    // Configuration from application.yml
    @Value("${temporal.seasonality.default-period:7}")
    private int defaultPeriod;

    @Value("${temporal.seasonality.z-score-normalization-factor:3.0}")
    private double zScoreNormalizationFactor;

    @Value("${temporal.context-weights.business-day:0.2}")
    private double businessDayWeight;

    @Value("${temporal.context-weights.non-business-day:0.5}")
    private double nonBusinessDayWeight;

    @Value("${temporal.context-weights.end-of-month:0.2}")
    private double endOfMonthWeight;

    @Value("${temporal.context-weights.frequency:0.1}")
    private double frequencyWeight;

    @Value("${temporal.weighting.z-score:0.5}")
    private double zScoreWeight;

    @Value("${temporal.weighting.context:0.3}")
    private double contextWeight;

    @Value("${temporal.weighting.residual:0.2}")
    private double residualWeight;

    @Value("${temporal.pattern-detection.min-occurrences:3}")
    private int minOccurrences;

    @Value("${temporal.pattern-detection.max-gap-days:35}")
    private int maxGapDays;

    // Pattern-based anomaly detection (e.g., missing periodic payments)
    public boolean isExpectedPattern(LocalDate txnDate, List<LocalDate> historicalDates, int periodDays) {
        // Enhanced pattern detection
        if (historicalDates.isEmpty()) return true;

        // Check if this is part of a regular pattern
        Map<DayOfWeek, Integer> dayOfWeekCounts = new HashMap<>();
        Map<Integer, Integer> dayOfMonthCounts = new HashMap<>();

        for (LocalDate date : historicalDates) {
            dayOfWeekCounts.merge(date.getDayOfWeek(), 1, Integer::sum);
            dayOfMonthCounts.merge(date.getDayOfMonth(), 1, Integer::sum);
        }

        // Check for strong weekly patterns
        boolean weeklyPatternMatch = dayOfWeekCounts.getOrDefault(txnDate.getDayOfWeek(), 0) >= minOccurrences;

        // Check for monthly patterns (same day each month)
        boolean monthlyPatternMatch = dayOfMonthCounts.getOrDefault(txnDate.getDayOfMonth(), 0) >= minOccurrences;

        // Check for the last day of month pattern
        boolean lastDayPatternDetected = historicalDates.stream()
                .filter(d -> d.getDayOfMonth() == d.lengthOfMonth())
                .count() >= minOccurrences;
        boolean isLastDay = txnDate.getDayOfMonth() == txnDate.lengthOfMonth();
        boolean lastDayPatternMatch = lastDayPatternDetected && isLastDay;

        return weeklyPatternMatch || monthlyPatternMatch || lastDayPatternMatch;
    }

    // Seasonal decomposition with enhanced STL-like algorithm
    public Map<String, double[]> seasonalDecompose(double[] series, int period) {
        int n = series.length;
        if (period <= 0) period = defaultPeriod;
        if (n < period * 2) {
            // Handle insufficient data
            double[] trend = Arrays.copyOf(series, n);
            double[] season = new double[n];
            double[] resid = new double[n];
            Map<String, double[]> result = new HashMap<>();
            result.put("trend", trend);
            result.put("seasonal", season);
            result.put("residual", resid);
            return result;
        }

        // 1. Initial trend using centered moving average
        double[] trend = new double[n];
        int halfPeriod = period / 2;

        // Enhanced centered moving average for trend
        for (int i = 0; i < n; i++) {
            double sum = 0;
            int count = 0;
            for (int j = Math.max(0, i - halfPeriod); j <= Math.min(n - 1, i + halfPeriod); j++) {
                sum += series[j];
                count++;
            }
            trend[i] = sum / count;
        }

        // 2. De-trend the series
        double[] detrended = new double[n];
        for (int i = 0; i < n; i++) {
            detrended[i] = series[i] - trend[i];
        }

        // 3. Extract seasonal component using averaging
        double[] seasonal = new double[n];
        double[] seasonalPattern = new double[period];

        // Compute season averages by position in cycle
        for (int i = 0; i < period; i++) {
            double sum = 0;
            int count = 0;
            for (int j = i; j < n; j += period) {
                sum += detrended[j];
                count++;
            }
            seasonalPattern[i] = (count > 0) ? sum / count : 0;
        }

        // Normalize seasonal pattern to sum to zero
        double seasonalMean = Arrays.stream(seasonalPattern).average().orElse(0);
        for (int i = 0; i < period; i++) {
            seasonalPattern[i] -= seasonalMean;
        }

        // Apply pattern to entire series
        for (int i = 0; i < n; i++) {
            seasonal[i] = seasonalPattern[i % period];
        }

        // 4. Final residual component
        double[] residual = new double[n];
        for (int i = 0; i < n; i++) {
            residual[i] = series[i] - trend[i] - seasonal[i];
        }

        Map<String, double[]> result = new HashMap<>();
        result.put("trend", trend);
        result.put("seasonal", seasonal);
        result.put("residual", residual);
        return result;
    }

    // Enhanced context analysis with calendar awareness
    public boolean isBusinessDay(LocalDate date, Set<LocalDate> holidays) {
        DayOfWeek dow = date.getDayOfWeek();
        return dow != DayOfWeek.SATURDAY && dow != DayOfWeek.SUNDAY && !holidays.contains(date);
    }

    public boolean isEndOfMonthSpike(LocalDate date) {
        return date.getDayOfMonth() >= 28 && date.getDayOfMonth() == date.lengthOfMonth();
    }

    // New: Detect if payment is near fiscal period end
    public boolean isNearFiscalPeriodEnd(LocalDate date) {
        // Indian fiscal year ends March 31st
        if (date.getMonthValue() == 3 && date.getDayOfMonth() >= 25) return true;

        // Quarter ends
        if ((date.getMonthValue() == 3 || date.getMonthValue() == 6 ||
                date.getMonthValue() == 9 || date.getMonthValue() == 12) &&
                date.getDayOfMonth() >= 25) {
            return true;
        }

        return false;
    }

    // Frequency analysis with improved algorithm
    public double dominantFrequency(double[] series) {
        int n = series.length;
        if (n < 4) return 0.0;

        // 1. Autocorrelation to find periodicity
        double[] autocorr = new double[n/2];
        double mean = Arrays.stream(series).average().orElse(0);

        for (int lag = 1; lag < n/2; lag++) {
            double numerator = 0;
            double denominator = 0;

            for (int i = 0; i < n - lag; i++) {
                numerator += (series[i] - mean) * (series[i + lag] - mean);
                denominator += Math.pow(series[i] - mean, 2);
            }

            autocorr[lag] = (denominator == 0) ? 0 : numerator / denominator;
        }

        // Find peak in autocorrelation
        double maxAutocorr = -1;
        int bestLag = 0;
        for (int i = 1; i < autocorr.length; i++) {
            if (autocorr[i] > maxAutocorr) {
                maxAutocorr = autocorr[i];
                bestLag = i;
            }
        }

        // 2. Only if autocorrelation is insufficient, use FFT
        if (maxAutocorr < 0.2) {  // Threshold for "significant" autocorrelation
            FastFourierTransformer fft = new FastFourierTransformer(DftNormalization.STANDARD);

            // Pad series to power of 2 for FFT
            int paddedSize = Integer.highestOneBit(n) << 1;
            double[] padded = Arrays.copyOf(series, paddedSize);

            // Remove trend if possible to enhance periodicity detection
            double slope = 0;
            if (n > 2) {
                slope = (series[n-1] - series[0]) / (n - 1);
                for (int i = 0; i < n; i++) {
                    padded[i] -= (slope * i + series[0]);
                }
            }

            Complex[] transform = fft.transform(padded, TransformType.FORWARD);

            // Find strongest frequency (skip DC component)
            double maxMag = -1;
            int idx = 0;
            for (int i = 1; i < transform.length / 2; i++) {
                double mag = transform[i].abs();
                if (mag > maxMag) {
                    maxMag = mag;
                    idx = i;
                }
            }

            return idx * 1.0 / paddedSize;  // Return normalized frequency
        }

        return bestLag;  // Return period from autocorrelation
    }

    // Enhanced context anomaly score
    public double contextAnomalyScore(LocalDate txnDate, List<LocalDate> historicalDates, double[] amounts, Set<LocalDate> holidays) {
        // Check if business day or not
        boolean business = isBusinessDay(txnDate, holidays);
        double businessScore = business ? businessDayWeight : nonBusinessDayWeight;

        // End of month spike detection
        boolean spike = isEndOfMonthSpike(txnDate);
        double spikeScore = spike ? endOfMonthWeight : 0.0;

        // Fiscal period end detection
        boolean fiscalEnd = isNearFiscalPeriodEnd(txnDate);
        double fiscalEndScore = fiscalEnd ? 0.15 : 0.0;

        // Frequency analysis for dominant patterns
        double freqScore = 0.0;
        if (amounts != null && amounts.length > 0) {
            double freq = dominantFrequency(amounts);
            freqScore = (freq > 0) ? frequencyWeight : 0.0;
        }

        // New: Check for expected pattern
        boolean expectedPattern = isExpectedPattern(txnDate, historicalDates, defaultPeriod);
        double patternScore = expectedPattern ? 0.0 : 0.3; // Higher anomaly if not following pattern

        // Weighted combination
        return businessScore + spikeScore + fiscalEndScore + freqScore + patternScore;
    }

    // Advanced pattern detection using transaction gaps
    public double detectAnomalousTransactionGaps(LocalDate currentDate, List<LocalDate> historicalDates) {
        if (historicalDates.size() < 3) return 0.0;

        // Sort dates
        List<LocalDate> sortedDates = new ArrayList<>(historicalDates);
        Collections.sort(sortedDates);

        // Calculate gaps between consecutive transactions
        List<Long> gaps = new ArrayList<>();
        for (int i = 1; i < sortedDates.size(); i++) {
            gaps.add(ChronoUnit.DAYS.between(sortedDates.get(i-1), sortedDates.get(i)));
        }

        // Calculate mean and std dev of gaps
        DescriptiveStatistics gapStats = new DescriptiveStatistics();
        gaps.forEach(gapStats::addValue);
        double meanGap = gapStats.getMean();
        double stdDevGap = gapStats.getStandardDeviation();

        // Detect anomalous gap to current transaction
        long currentGap = ChronoUnit.DAYS.between(sortedDates.get(sortedDates.size()-1), currentDate);

        // Normalize the gap score
        if (stdDevGap == 0) return 0.0;
        double gapZScore = Math.abs(currentGap - meanGap) / Math.max(1.0, stdDevGap);

        return Math.min(gapZScore / zScoreNormalizationFactor, 1.0);
    }

    // Enhanced Z-score anomaly with robust handling
    public double zScoreAnomaly(List<Double> historical, double currentValue) {
        if (historical == null || historical.isEmpty()) return 0.0;

        DescriptiveStatistics stats = new DescriptiveStatistics();

        // Filter out extreme outliers for more robust statistics
        double median = historical.stream()
                .sorted()
                .skip((historical.size() - 1) / 2)
                .limit(1 + (1 - historical.size() % 2))
                .mapToDouble(d -> d)
                .average()
                .orElse(0.0);

        double mad = historical.stream()
                .mapToDouble(d -> Math.abs(d - median))
                .sorted()
                .skip((historical.size() - 1) / 2)
                .limit(1 + (1 - historical.size() % 2))
                .average()
                .orElse(0.0);

        // Use modified Z-score for robustness
        if (mad == 0) {
            // Fall back to regular z-score if MAD is zero
            historical.forEach(stats::addValue);
            double mean = stats.getMean();
            double stddev = stats.getStandardDeviation();
            if (stddev == 0) return 0.0;
            return Math.abs(currentValue - mean) / stddev;
        } else {
            // Modified Z-score using median absolute deviation
            return 0.6745 * Math.abs(currentValue - median) / mad;
        }
    }

    // Enhanced combined temporal anomaly score
    public double combinedTemporalAnomalyScore(
            List<Double> historicalAmounts,
            double currentAmount,
            LocalDate currentDate,
            List<LocalDate> historicalDates,
            Set<LocalDate> holidays
    ) {
        // 1. Statistical anomaly score
        double zScore = zScoreAnomaly(historicalAmounts, currentAmount);
        double normZ = Math.min(zScore / zScoreNormalizationFactor, 1.0);

        // 2. Contextual anomaly
        double[] amountsArray = historicalAmounts != null ?
                toPrimitiveArray(historicalAmounts) : new double[0];
        double context = contextAnomalyScore(currentDate, historicalDates, amountsArray, holidays);

        // 3. Seasonal decomposition (if enough data)
        double residualScore = 0.0;
        if (historicalAmounts != null && historicalAmounts.size() >= defaultPeriod) {
            double[] series = toPrimitiveArray(historicalAmounts);
            double[] fullSeries = Arrays.copyOf(series, series.length + 1);
            fullSeries[fullSeries.length - 1] = currentAmount;

            Map<String, double[]> decomposed = seasonalDecompose(fullSeries, defaultPeriod);
            double lastResidual = decomposed.get("residual")[decomposed.get("residual").length - 1];

            // Calculate standard deviation of residuals for normalization
            DescriptiveStatistics residStats = new DescriptiveStatistics();
            Arrays.stream(decomposed.get("residual"), 0, decomposed.get("residual").length - 1)
                    .forEach(residStats::addValue);
            double residStdDev = residStats.getStandardDeviation();

            // Normalize residual
            if (residStdDev > 0) {
                residualScore = Math.min(Math.abs(lastResidual) / (residStdDev * 3.0), 1.0);
            } else {
                residualScore = Math.min(Math.abs(lastResidual) / zScoreNormalizationFactor, 1.0);
            }
        }

        // 4. Transaction gap anomaly
        double gapScore = detectAnomalousTransactionGaps(currentDate, historicalDates);

        // 5. Weighted combination of all signals
        double combinedScore = (zScoreWeight * normZ) +
                (contextWeight * context) +
                (residualWeight * residualScore) +
                (0.2 * gapScore); // Gap score has its own fixed weight

        return Math.min(combinedScore, 1.0);
    }

    /**
     * Detects anomalies in payment patterns for a specific beneficiary
     */
    public double beneficiaryPaymentPatternAnomaly(String beneficiaryAccount,
                                                   LocalDate currentDate,
                                                   double amount,
                                                   List<PaymentTransaction> history) {
        // Filter transactions to this beneficiary
        List<PaymentTransaction> beneficiaryHistory = history.stream()
                .filter(tx -> tx.getBeneficiaryAccount().equals(beneficiaryAccount))
                .collect(Collectors.toList());

        if (beneficiaryHistory.isEmpty()) {
            // First transaction to this beneficiary - slight anomaly signal
            return 0.3;
        }

        // Check payment frequency pattern
        Map<Integer, Integer> daysBetweenPayments = new HashMap<>();
        List<LocalDate> dates = beneficiaryHistory.stream()
                .map(PaymentTransaction::getTransactionDate)
                .sorted()
                .collect(Collectors.toList());

        for (int i = 1; i < dates.size(); i++) {
            int days = (int) ChronoUnit.DAYS.between(dates.get(i-1), dates.get(i));
            daysBetweenPayments.merge(days, 1, Integer::sum);
        }

        // Find most common payment interval
        int mostCommonInterval = 0;
        int highestCount = 0;
        for (Map.Entry<Integer, Integer> entry : daysBetweenPayments.entrySet()) {
            if (entry.getValue() > highestCount) {
                mostCommonInterval = entry.getKey();
                highestCount = entry.getValue();
            }
        }

        // Check if current payment follows the pattern
        if (mostCommonInterval > 0 && dates.size() >= 2) {
            LocalDate lastPaymentDate = dates.get(dates.size() - 1);
            int daysSinceLastPayment = (int) ChronoUnit.DAYS.between(lastPaymentDate, currentDate);

            // Calculate deviation from pattern
            double intervalDeviation = Math.abs(daysSinceLastPayment - mostCommonInterval) /
                    (double) Math.max(1, mostCommonInterval);

            // Cap at 1.0
            return Math.min(intervalDeviation, 1.0);
        }

        return 0.0;
    }

    /**
     * Detects anomalies in payment amounts for a specific beneficiary
     */
    public double amountVariabilityAnomaly(String beneficiaryAccount,
                                           double currentAmount,
                                           List<PaymentTransaction> history) {
        // Filter transactions to this beneficiary
        List<Double> beneficiaryAmounts = history.stream()
                .filter(tx -> tx.getBeneficiaryAccount().equals(beneficiaryAccount))
                .map(PaymentTransaction::getAmount)
                .collect(Collectors.toList());

        if (beneficiaryAmounts.isEmpty()) {
            return 0.0;
        }

        // Calculate coefficient of variation of past payments
        DescriptiveStatistics stats = new DescriptiveStatistics();
        beneficiaryAmounts.forEach(stats::addValue);

        double mean = stats.getMean();
        double stdDev = stats.getStandardDeviation();

        // Low CV = consistent payments, high CV = variable payments
        double cv = (mean == 0) ? 0 : stdDev / mean;

        // For consistent payment amounts, check if current amount deviates
        if (cv < 0.1) { // Very consistent payments
            double deviation = Math.abs(currentAmount - mean) / mean;
            return Math.min(deviation, 1.0);
        } else {
            // For variable payments, check if outside historical range
            double min = stats.getMin();
            double max = stats.getMax();
            double normalizedRange = (max - min) / mean;

            if (currentAmount < min || currentAmount > max) {
                // Outside historical range
                double distanceFromRange = Math.min(Math.abs(currentAmount - min),
                        Math.abs(currentAmount - max));
                return Math.min(distanceFromRange / mean, 1.0);
            }
        }

        return 0.0;
    }

    // Helper to convert List<Double> to double[]
    private double[] toPrimitiveArray(List<Double> list) {
        if (list == null) return new double[0];
        double[] arr = new double[list.size()];
        for (int i = 0; i < list.size(); i++) {
            arr[i] = list.get(i) != null ? list.get(i) : 0.0;
        }
        return arr;
    }
}