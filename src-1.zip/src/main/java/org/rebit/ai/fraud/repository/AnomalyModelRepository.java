package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.AnomalyModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AnomalyModelRepository extends JpaRepository<AnomalyModel, Long> {
    List<AnomalyModel> findByEntityId(String entityId);
    List<AnomalyModel> findByActiveTrue();

    // Additional methods for enhanced functionality
    List<AnomalyModel> findByEntityIdAndActiveTrue(String entityId);
    List<AnomalyModel> findByModelTypeAndActiveTrue(String modelType);
    List<AnomalyModel> findByEntityIdAndModelType(String entityId, String modelType);
    List<AnomalyModel> findByEntityIdAndModelTypeAndActiveTrue(String entityId, String modelType);

    @Query("SELECT am FROM AnomalyModel am WHERE am.entityId = :entityId AND am.modelType = :modelType AND am.active = true ORDER BY am.trainingDate DESC")
    Optional<AnomalyModel> findLatestActiveModelByEntityAndType(@Param("entityId") String entityId, @Param("modelType") String modelType);

    @Query("SELECT am FROM AnomalyModel am WHERE am.modelType = :modelType AND am.active = true ORDER BY am.trainingDate DESC")
    Optional<AnomalyModel> findLatestActiveGlobalModelByType(@Param("modelType") String modelType);

    @Query("SELECT am FROM AnomalyModel am WHERE am.trainingDate < :cutoffDate AND am.active = false")
    List<AnomalyModel> findOldInactiveModels(@Param("cutoffDate") LocalDate cutoffDate);

    @Query("SELECT COUNT(am) FROM AnomalyModel am WHERE am.entityId = :entityId AND am.active = true")
    Long countActiveModelsByEntity(@Param("entityId") String entityId);

    @Query("SELECT DISTINCT am.entityId FROM AnomalyModel am WHERE am.entityId IS NOT NULL")
    List<String> findDistinctEntityIds();

    @Query("SELECT am FROM AnomalyModel am WHERE am.entityId = :entityId ORDER BY am.trainingDate DESC")
    List<AnomalyModel> findByEntityIdOrderByTrainingDateDesc(@Param("entityId") String entityId);

    // Methods for model management and cleanup
    @Query("SELECT am FROM AnomalyModel am WHERE am.active = false AND am.trainingDate < :cutoffDate")
    List<AnomalyModel> findInactiveModelsOlderThan(@Param("cutoffDate") LocalDate cutoffDate);

    @Query("SELECT COUNT(am) FROM AnomalyModel am WHERE am.modelType = :modelType AND am.active = true")
    Long countActiveModelsByType(@Param("modelType") String modelType);
}