package org.rebit.ai.fraud.scheduler;

import org.rebit.ai.fraud.service.data.FileIngestionService;
import org.rebit.ai.fraud.service.detection.AnomalyDetectionService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class AnomalyDetectionJob {
    private final AnomalyDetectionService detectionService;

    public AnomalyDetectionJob(AnomalyDetectionService detectionService) {
        this.detectionService = detectionService;
    }

    @Scheduled(cron = "${schedule.detection-cron:0 30 18 * * ?}") // e.g., 6:30pm
    public void runDetection() {
        detectionService.runDetectionOnRecentData();
    }
}
