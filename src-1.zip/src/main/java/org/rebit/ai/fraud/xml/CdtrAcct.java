package org.rebit.ai.fraud.xml;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class CdtrAcct {
    @XmlElement(name = "Id")
    private CdtrAcctId id;

    @XmlElement(name = "Tp")
    private Tp tp;

    // getters/setters
}
