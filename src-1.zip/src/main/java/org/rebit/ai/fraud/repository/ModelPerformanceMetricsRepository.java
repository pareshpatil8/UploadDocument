// ModelPerformanceMetricsRepository
package org.rebit.ai.fraud.repository;

import org.rebit.ai.fraud.entity.ModelPerformanceMetrics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface ModelPerformanceMetricsRepository extends JpaRepository<ModelPerformanceMetrics, Long> {
    List<ModelPerformanceMetrics> findByEntityIdAndModelTypeAndCalculationDateAfter(
            String entityId, String modelType, LocalDateTime after);

    @Query("SELECT m FROM ModelPerformanceMetrics m WHERE m.entityId = :entityId " +
            "AND m.metricName = :metricName ORDER BY m.calculationDate DESC")
    List<ModelPerformanceMetrics> findLatestMetricByEntityAndName(String entityId, String metricName);
}