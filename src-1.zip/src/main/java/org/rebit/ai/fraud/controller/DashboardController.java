package org.rebit.ai.fraud.controller;

import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.AnomalyModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private AnomalyAlertRepository alertRepo;
    @Autowired
    private AnomalyModelRepository modelRepo;

    @GetMapping
    public Map<String, Object> dashboardMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("totalAlerts", alertRepo.count());
        metrics.put("activeModels", modelRepo.findByActiveTrue().size());
        // Add other metrics as needed
        return metrics;
    }
}
