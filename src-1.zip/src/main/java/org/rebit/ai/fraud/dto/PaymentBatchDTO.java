package org.rebit.ai.fraud.dto;

import java.util.List;

public class PaymentBatchDTO {
    private String batchId;
    private String sourceEntity;
    private String creationTime;
    private Double totalAmount;
    private Integer totalTransactions;
    private String status;
    private List<PaymentTransactionDTO> transactions;

    // Add getters and setters

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getSourceEntity() {
        return sourceEntity;
    }

    public void setSourceEntity(String sourceEntity) {
        this.sourceEntity = sourceEntity;
    }

    public String getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Integer getTotalTransactions() {
        return totalTransactions;
    }

    public void setTotalTransactions(Integer totalTransactions) {
        this.totalTransactions = totalTransactions;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<PaymentTransactionDTO> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<PaymentTransactionDTO> transactions) {
        this.transactions = transactions;
    }
}
