package org.rebit.ai.fraud.service.reduction;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.dto.PaymentTransactionDTO;
import org.rebit.ai.fraud.entity.AnomalyAlert;
import org.rebit.ai.fraud.entity.PaymentTransaction;
import org.rebit.ai.fraud.repository.AnomalyAlertRepository;
import org.rebit.ai.fraud.repository.PaymentTransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Comprehensive false-positive reduction system that:
 * 1. Implements robust preprocessing
 * 2. Applies domain knowledge constraints
 * 3. Uses semi-supervised learning techniques
 * 4. Provides contextual validation
 */
@Service
public class FalsePositiveReductionService {
    private static final Logger logger = LoggerFactory.getLogger(FalsePositiveReductionService.class);

    @Autowired
    private AnomalyAlertRepository alertRepository;

    @Autowired
    private PaymentTransactionRepository transactionRepository;

    @Value("${false-positive.outlier-clip-factor:3.0}")
    private double outlierClipFactor;

    @Value("${false-positive.min-historical-samples:10}")
    private int minHistoricalSamples;

    @Value("${false-positive.business-rule-weight:0.3}")
    private double businessRuleWeight;

    // Cache for frequently accessed statistics
    private final Map<String, DescriptiveStatistics> entityStatisticsCache = new HashMap<>();
    private final Map<String, Set<String>> knownBeneficiariesCache = new HashMap<>();

    /**
     * Main method to reduce false positives through multiple techniques
     */
    public ProcessedFeatures reduceNoiseAndFalsePositives(
            PaymentTransactionDTO transaction,
            FeatureVectorDTO originalFeatures,
            List<PaymentTransaction> historicalTransactions) {

        logger.debug("Processing transaction {} for false-positive reduction", transaction.getTransactionId());

        // 1. Robust preprocessing
        FeatureVectorDTO preprocessedFeatures = robustPreprocessing(originalFeatures, historicalTransactions);

        // 2. Apply business rule constraints
        BusinessRuleResult businessRuleResult = applyBusinessRules(transaction, historicalTransactions);

        // 3. Contextual validation
        ContextualValidation contextualResult = performContextualValidation(transaction, historicalTransactions);

        // 4. Semi-supervised constraints
        SemiSupervisedResult semiSupervisedResult = applySemiSupervisedConstraints(
                transaction, preprocessedFeatures, historicalTransactions);

        // 5. Combine results
        return combineResults(preprocessedFeatures, businessRuleResult, contextualResult, semiSupervisedResult);
    }

    /**
     * Robust preprocessing to handle outliers and normalize features
     */
    private FeatureVectorDTO robustPreprocessing(FeatureVectorDTO originalFeatures,
                                                 List<PaymentTransaction> historicalTransactions) {

        Map<String, Double> processedFeatures = new HashMap<>(originalFeatures.getFeatures());

        // 1. Outlier clipping based on historical statistics
        processedFeatures = clipOutliers(processedFeatures, historicalTransactions);

        // 2. Robust normalization using median and MAD
        processedFeatures = robustNormalization(processedFeatures, historicalTransactions);

        // 3. Handle missing values intelligently
        processedFeatures = handleMissingValues(processedFeatures, historicalTransactions);

        // 4. Feature stabilization (reduce noise in highly variable features)
        processedFeatures = stabilizeFeatures(processedFeatures, historicalTransactions);

        FeatureVectorDTO result = new FeatureVectorDTO();
        result.setFeatures(processedFeatures);
        return result;
    }

    private Map<String, Double> clipOutliers(Map<String, Double> features,
                                             List<PaymentTransaction> historicalTransactions) {
        Map<String, Double> clippedFeatures = new HashMap<>(features);

        for (Map.Entry<String, Double> entry : features.entrySet()) {
            String featureName = entry.getKey();
            Double value = entry.getValue();

            if (value == null || Double.isNaN(value) || Double.isInfinite(value)) {
                continue;
            }

            // Get historical values for this feature
            List<Double> historicalValues = extractFeatureValues(featureName, historicalTransactions);

            if (historicalValues.size() >= minHistoricalSamples) {
                DescriptiveStatistics stats = new DescriptiveStatistics();
                historicalValues.forEach(stats::addValue);

                double median = stats.getPercentile(50);
                double mad = calculateMAD(historicalValues, median);

                if (mad > 0) {
                    double lowerBound = median - outlierClipFactor * mad;
                    double upperBound = median + outlierClipFactor * mad;

                    // Clip extreme values
                    if (value < lowerBound) {
                        clippedFeatures.put(featureName, lowerBound);
                        logger.debug("Clipped feature {} from {} to {}", featureName, value, lowerBound);
                    } else if (value > upperBound) {
                        clippedFeatures.put(featureName, upperBound);
                        logger.debug("Clipped feature {} from {} to {}", featureName, value, upperBound);
                    }
                }
            }
        }

        return clippedFeatures;
    }

    private Map<String, Double> robustNormalization(Map<String, Double> features,
                                                    List<PaymentTransaction> historicalTransactions) {
        Map<String, Double> normalizedFeatures = new HashMap<>(features);

        for (Map.Entry<String, Double> entry : features.entrySet()) {
            String featureName = entry.getKey();
            Double value = entry.getValue();

            if (value == null || Double.isNaN(value)) continue;

            List<Double> historicalValues = extractFeatureValues(featureName, historicalTransactions);

            if (historicalValues.size() >= minHistoricalSamples) {
                DescriptiveStatistics stats = new DescriptiveStatistics();
                historicalValues.forEach(stats::addValue);

                double median = stats.getPercentile(50);
                double mad = calculateMAD(historicalValues, median);

                if (mad > 0) {
                    // Robust standardization using median and MAD
                    double normalizedValue = (value - median) / mad;
                    normalizedFeatures.put(featureName, normalizedValue);
                }
            }
        }

        return normalizedFeatures;
    }

    private Map<String, Double> handleMissingValues(Map<String, Double> features,
                                                    List<PaymentTransaction> historicalTransactions) {
        Map<String, Double> imputedFeatures = new HashMap<>(features);

        // Define expected features
        String[] expectedFeatures = {"amount", "account_hash", "bank_hash", "is_round_amount", "is_institutional"};

        for (String featureName : expectedFeatures) {
            if (!imputedFeatures.containsKey(featureName) ||
                    imputedFeatures.get(featureName) == null ||
                    Double.isNaN(imputedFeatures.get(featureName))) {

                // Impute with historical median
                List<Double> historicalValues = extractFeatureValues(featureName, historicalTransactions);
                if (!historicalValues.isEmpty()) {
                    DescriptiveStatistics stats = new DescriptiveStatistics();
                    historicalValues.forEach(stats::addValue);
                    double imputedValue = stats.getPercentile(50); // Median imputation
                    imputedFeatures.put(featureName, imputedValue);
                    logger.debug("Imputed missing feature {} with value {}", featureName, imputedValue);
                }
            }
        }

        return imputedFeatures;
    }

    private Map<String, Double> stabilizeFeatures(Map<String, Double> features,
                                                  List<PaymentTransaction> historicalTransactions) {
        Map<String, Double> stabilizedFeatures = new HashMap<>(features);

        // Apply exponential smoothing to highly variable features
        String[] variableFeatures = {"amount", "account_hash", "bank_hash"};
        double smoothingFactor = 0.3;

        for (String featureName : variableFeatures) {
            if (stabilizedFeatures.containsKey(featureName)) {
                List<Double> recentValues = extractFeatureValues(featureName,
                        historicalTransactions.stream()
                                .filter(tx -> tx.getTransactionDate().isAfter(LocalDate.now().minusDays(30)))
                                .collect(Collectors.toList()));

                if (recentValues.size() >= 5) {
                    double currentValue = stabilizedFeatures.get(featureName);
                    double historicalMean = recentValues.stream().mapToDouble(Double::doubleValue).average().orElse(currentValue);

                    // Exponential smoothing
                    double stabilizedValue = smoothingFactor * currentValue + (1 - smoothingFactor) * historicalMean;
                    stabilizedFeatures.put(featureName, stabilizedValue);
                }
            }
        }

        return stabilizedFeatures;
    }

    /**
     * Apply business rules to identify likely false positives
     */
    private BusinessRuleResult applyBusinessRules(PaymentTransactionDTO transaction,
                                                  List<PaymentTransaction> historicalTransactions) {

        List<String> passedRules = new ArrayList<>();
        List<String> failedRules = new ArrayList<>();
        double ruleScore = 0.0;

        // Rule 1: Known beneficiary with consistent payment pattern
        boolean isKnownBeneficiary = checkKnownBeneficiary(transaction, historicalTransactions);
        if (isKnownBeneficiary) {
            passedRules.add("Known beneficiary with regular payments");
            ruleScore += 0.3;
        } else {
            failedRules.add("New or irregular beneficiary");
        }

        // Rule 2: Payment amount within expected range for this beneficiary
        boolean isExpectedAmount = checkExpectedAmountRange(transaction, historicalTransactions);
        if (isExpectedAmount) {
            passedRules.add("Amount within expected range");
            ruleScore += 0.25;
        } else {
            failedRules.add("Amount outside expected range");
        }

        // Rule 3: Payment timing follows established pattern
        boolean isExpectedTiming = checkExpectedTiming(transaction, historicalTransactions);
        if (isExpectedTiming) {
            passedRules.add("Payment timing follows pattern");
            ruleScore += 0.2;
        } else {
            failedRules.add("Unusual payment timing");
        }

        // Rule 4: Government entity operational hours/days
        boolean isDuringOperationalHours = checkOperationalHours(transaction);
        if (isDuringOperationalHours) {
            passedRules.add("Payment during operational hours");
            ruleScore += 0.15;
        } else {
            failedRules.add("Payment outside operational hours");
        }

        // Rule 5: Sequential transaction ID pattern (if applicable)
        boolean hasValidSequence = checkTransactionSequence(transaction, historicalTransactions);
        if (hasValidSequence) {
            passedRules.add("Valid transaction sequence");
            ruleScore += 0.1;
        } else {
            failedRules.add("Irregular transaction sequence");
        }

        return new BusinessRuleResult(ruleScore, passedRules, failedRules);
    }

    private boolean checkKnownBeneficiary(PaymentTransactionDTO transaction,
                                          List<PaymentTransaction> historicalTransactions) {
        String entityId = transaction.getSourceEntity();
        Set<String> knownBeneficiaries = knownBeneficiariesCache.computeIfAbsent(entityId,
                k -> historicalTransactions.stream()
                        .map(PaymentTransaction::getBeneficiaryAccount)
                        .collect(Collectors.toSet()));

        return knownBeneficiaries.contains(transaction.getBeneficiaryAccount());
    }

    private boolean checkExpectedAmountRange(PaymentTransactionDTO transaction,
                                             List<PaymentTransaction> historicalTransactions) {
        List<Double> beneficiaryAmounts = historicalTransactions.stream()
                .filter(tx -> tx.getBeneficiaryAccount().equals(transaction.getBeneficiaryAccount()))
                .map(PaymentTransaction::getAmount)
                .collect(Collectors.toList());

        if (beneficiaryAmounts.size() < 3) return false;

        DescriptiveStatistics stats = new DescriptiveStatistics();
        beneficiaryAmounts.forEach(stats::addValue);

        double mean = stats.getMean();
        double stddev = stats.getStandardDeviation();
        double currentAmount = transaction.getAmount();

        // Allow within 2 standard deviations
        return Math.abs(currentAmount - mean) <= 2 * stddev;
    }

    private boolean checkExpectedTiming(PaymentTransactionDTO transaction,
                                        List<PaymentTransaction> historicalTransactions) {
        // Check if payment falls on expected day of week/month
        LocalDate transactionDate = transaction.getTransactionDate();

        Map<Integer, Long> dayOfWeekCounts = historicalTransactions.stream()
                .collect(Collectors.groupingBy(
                        tx -> tx.getTransactionDate().getDayOfWeek().getValue(),
                        Collectors.counting()));

        if (dayOfWeekCounts.isEmpty()) return false;

        // Check if current day of week is among the top 3 most common
        List<Map.Entry<Integer, Long>> sortedDays = dayOfWeekCounts.entrySet().stream()
                .sorted(Map.Entry.<Integer, Long>comparingByValue().reversed())
                .limit(3)
                .collect(Collectors.toList());

        int currentDayOfWeek = transactionDate.getDayOfWeek().getValue();
        return sortedDays.stream().anyMatch(entry -> entry.getKey() == currentDayOfWeek);
    }

    private boolean checkOperationalHours(PaymentTransactionDTO transaction) {
        // Government operations typically during business hours and weekdays
        LocalDate transactionDate = transaction.getTransactionDate();
        int dayOfWeek = transactionDate.getDayOfWeek().getValue();

        // Monday to Friday (1-5)
        return dayOfWeek >= 1 && dayOfWeek <= 5;
    }

    private boolean checkTransactionSequence(PaymentTransactionDTO transaction,
                                             List<PaymentTransaction> historicalTransactions) {
        // Basic sequence check - transaction ID should follow some pattern
        String currentId = transaction.getTransactionId();
        if (currentId == null || currentId.length() < 10) return false;

        // Check if ID contains date pattern (basic validation)
        String datePattern = currentId.substring(0, Math.min(8, currentId.length()));
        try {
            Integer.parseInt(datePattern);
            return true; // Contains numeric date-like pattern
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Contextual validation based on entity behavior and external factors
     */
    private ContextualValidation performContextualValidation(PaymentTransactionDTO transaction,
                                                             List<PaymentTransaction> historicalTransactions) {

        double contextScore = 0.0;
        List<String> contextFactors = new ArrayList<>();

        // 1. Entity payment volume consistency
        double volumeConsistency = checkVolumeConsistency(transaction, historicalTransactions);
        contextScore += 0.3 * volumeConsistency;
        if (volumeConsistency > 0.7) {
            contextFactors.add("Consistent payment volume pattern");
        }

        // 2. Seasonal/cyclical pattern alignment
        double seasonalAlignment = checkSeasonalAlignment(transaction, historicalTransactions);
        contextScore += 0.25 * seasonalAlignment;
        if (seasonalAlignment > 0.7) {
            contextFactors.add("Aligns with seasonal payment pattern");
        }

        // 3. Beneficiary category consistency
        double categoryConsistency = checkBeneficiaryCategoryConsistency(transaction, historicalTransactions);
        contextScore += 0.25 * categoryConsistency;
        if (categoryConsistency > 0.7) {
            contextFactors.add("Consistent beneficiary category");
        }

        // 4. Geographic/bank pattern consistency
        double geographicConsistency = checkGeographicConsistency(transaction, historicalTransactions);
        contextScore += 0.2 * geographicConsistency;
        if (geographicConsistency > 0.7) {
            contextFactors.add("Consistent geographic/bank pattern");
        }

        return new ContextualValidation(contextScore, contextFactors);
    }

    /**
     * Semi-supervised learning techniques using known false positives
     */
    private SemiSupervisedResult applySemiSupervisedConstraints(PaymentTransactionDTO transaction,
                                                                FeatureVectorDTO features,
                                                                List<PaymentTransaction> historicalTransactions) {

        // Get historical false positives for this entity
        List<AnomalyAlert> falsePositives = alertRepository.findByStatus("FALSE_POSITIVE")
                .stream()
                .filter(alert -> {
                    // Find corresponding transaction and check if same entity
                    Optional<PaymentTransaction> tx = transactionRepository.findById(alert.getTransactionId());
                    return tx.isPresent() && tx.get().getSourceEntity().equals(transaction.getSourceEntity());
                })
                .collect(Collectors.toList());

        if (falsePositives.isEmpty()) {
            return new SemiSupervisedResult(0.0, "No historical false positives available");
        }

        // Calculate similarity to known false positives
        double maxSimilarity = 0.0;
        String mostSimilarCase = "";

        for (AnomalyAlert fp : falsePositives) {
            Optional<PaymentTransaction> fpTransaction = transactionRepository.findById(fp.getTransactionId());
            if (fpTransaction.isPresent()) {
                double similarity = calculateTransactionSimilarity(transaction, fpTransaction.get());
                if (similarity > maxSimilarity) {
                    maxSimilarity = similarity;
                    mostSimilarCase = fp.getTransactionId();
                }
            }
        }

        // If current transaction is very similar to a known false positive, increase FP probability
        double fpProbability = maxSimilarity > 0.8 ? maxSimilarity : 0.0;
        String explanation = fpProbability > 0 ?
                "Similar to known false positive: " + mostSimilarCase :
                "No significant similarity to known false positives";

        return new SemiSupervisedResult(fpProbability, explanation);
    }

    // Helper methods for specific checks
    private double checkVolumeConsistency(PaymentTransactionDTO transaction,
                                          List<PaymentTransaction> historicalTransactions) {
        if (historicalTransactions.size() < 30) return 0.5; // Not enough data

        // Group by month and calculate volume consistency
        Map<String, Double> monthlyVolumes = historicalTransactions.stream()
                .collect(Collectors.groupingBy(
                        tx -> tx.getTransactionDate().getYear() + "-" + tx.getTransactionDate().getMonthValue(),
                        Collectors.summingDouble(PaymentTransaction::getAmount)));

        if (monthlyVolumes.size() < 3) return 0.5;

        DescriptiveStatistics stats = new DescriptiveStatistics();
        monthlyVolumes.values().forEach(stats::addValue);

        double cv = stats.getStandardDeviation() / stats.getMean();
        return Math.max(0, 1.0 - cv); // Lower coefficient of variation = higher consistency
    }

    private double checkSeasonalAlignment(PaymentTransactionDTO transaction,
                                          List<PaymentTransaction> historicalTransactions) {
        // Check if current month/quarter has historical precedent
        int currentMonth = transaction.getTransactionDate().getMonthValue();

        Map<Integer, Long> monthlyFrequency = historicalTransactions.stream()
                .collect(Collectors.groupingBy(
                        tx -> tx.getTransactionDate().getMonthValue(),
                        Collectors.counting()));

        long currentMonthCount = monthlyFrequency.getOrDefault(currentMonth, 0L);
        long maxMonthCount = monthlyFrequency.values().stream().mapToLong(Long::longValue).max().orElse(1L);

        return (double) currentMonthCount / maxMonthCount;
    }

    private double checkBeneficiaryCategoryConsistency(PaymentTransactionDTO transaction,
                                                       List<PaymentTransaction> historicalTransactions) {
        // Simple heuristic based on beneficiary name patterns
        String beneficiaryName = transaction.getBeneficiaryName().toUpperCase();

        // Count similar beneficiary name patterns
        long similarBeneficiaries = historicalTransactions.stream()
                .map(tx -> tx.getBeneficiaryName().toUpperCase())
                .filter(name -> {
                    String[] currentWords = beneficiaryName.split("\\s+");
                    String[] nameWords = name.split("\\s+");

                    // Check for common words (indicating similar beneficiary types)
                    Set<String> commonWords = Arrays.stream(currentWords)
                            .filter(word -> Arrays.asList(nameWords).contains(word))
                            .collect(Collectors.toSet());

                    return commonWords.size() >= Math.min(currentWords.length, nameWords.length) / 2;
                })
                .count();

        return Math.min(1.0, (double) similarBeneficiaries / Math.max(1, historicalTransactions.size() / 10));
    }

    private double checkGeographicConsistency(PaymentTransactionDTO transaction,
                                              List<PaymentTransaction> historicalTransactions) {
        // Bank code consistency check
        String currentBank = transaction.getBeneficiaryBank();

        Map<String, Long> bankFrequency = historicalTransactions.stream()
                .collect(Collectors.groupingBy(
                        PaymentTransaction::getBeneficiaryBank,
                        Collectors.counting()));

        long currentBankCount = bankFrequency.getOrDefault(currentBank, 0L);
        long totalTransactions = historicalTransactions.size();

        return totalTransactions > 0 ? (double) currentBankCount / totalTransactions : 0.0;
    }

    private double calculateTransactionSimilarity(PaymentTransactionDTO tx1, PaymentTransaction tx2) {
        double similarity = 0.0;
        int factors = 0;

        // Amount similarity (within 10%)
        double amountDiff = Math.abs(tx1.getAmount() - tx2.getAmount()) / Math.max(tx1.getAmount(), tx2.getAmount());
        if (amountDiff < 0.1) similarity += 0.3;
        factors++;

        // Beneficiary similarity
        if (tx1.getBeneficiaryAccount().equals(tx2.getBeneficiaryAccount())) {
            similarity += 0.4;
        }
        factors++;

        // Bank similarity
        if (tx1.getBeneficiaryBank().equals(tx2.getBeneficiaryBank())) {
            similarity += 0.2;
        }
        factors++;

        // Date proximity (within 7 days)
        long daysDiff = Math.abs(java.time.temporal.ChronoUnit.DAYS.between(tx1.getTransactionDate(), tx2.getTransactionDate()));
        if (daysDiff <= 7) {
            similarity += 0.1;
        }
        factors++;

        return similarity;
    }

    /**
     * Combine all results into final processed features with confidence scoring
     */
    private ProcessedFeatures combineResults(FeatureVectorDTO preprocessedFeatures,
                                             BusinessRuleResult businessRules,
                                             ContextualValidation contextual,
                                             SemiSupervisedResult semiSupervised) {

        // Calculate overall false positive probability
        double falsePositiveProbability =
                businessRuleWeight * businessRules.getScore() +
                        0.3 * contextual.getScore() +
                        0.4 * semiSupervised.getFalsePositiveProbability();

        // Adjust feature weights based on confidence
        Map<String, Double> adjustedFeatures = new HashMap<>(preprocessedFeatures.getFeatures());

        // If high probability of false positive, reduce feature magnitudes
        if (falsePositiveProbability > 0.7) {
            double reductionFactor = 1.0 - (falsePositiveProbability - 0.7) * 0.5;
            adjustedFeatures.replaceAll((k, v) -> v * reductionFactor);
        }

        return new ProcessedFeatures(
                adjustedFeatures,
                falsePositiveProbability,
                businessRules,
                contextual,
                semiSupervised
        );
    }

    // Helper methods
    private List<Double> extractFeatureValues(String featureName, List<PaymentTransaction> transactions) {
        // This is a simplified implementation - in practice, you'd extract features from transactions
        switch (featureName) {
            case "amount":
                return transactions.stream().map(PaymentTransaction::getAmount).collect(Collectors.toList());
            default:
                return new ArrayList<>();
        }
    }

    private double calculateMAD(List<Double> values, double median) {
        List<Double> deviations = values.stream()
                .map(v -> Math.abs(v - median))
                .collect(Collectors.toList());

        Collections.sort(deviations);
        int size = deviations.size();

        if (size % 2 == 0) {
            return (deviations.get(size / 2 - 1) + deviations.get(size / 2)) / 2.0;
        } else {
            return deviations.get(size / 2);
        }
    }

    // Result classes
    public static class ProcessedFeatures {
        private final Map<String, Double> adjustedFeatures;
        private final double falsePositiveProbability;
        private final BusinessRuleResult businessRules;
        private final ContextualValidation contextual;
        private final SemiSupervisedResult semiSupervised;

        public ProcessedFeatures(Map<String, Double> adjustedFeatures, double falsePositiveProbability,
                                 BusinessRuleResult businessRules, ContextualValidation contextual,
                                 SemiSupervisedResult semiSupervised) {
            this.adjustedFeatures = adjustedFeatures;
            this.falsePositiveProbability = falsePositiveProbability;
            this.businessRules = businessRules;
            this.contextual = contextual;
            this.semiSupervised = semiSupervised;
        }

        // Getters
        public Map<String, Double> getAdjustedFeatures() { return adjustedFeatures; }
        public double getFalsePositiveProbability() { return falsePositiveProbability; }
        public BusinessRuleResult getBusinessRules() { return businessRules; }
        public ContextualValidation getContextual() { return contextual; }
        public SemiSupervisedResult getSemiSupervised() { return semiSupervised; }
    }

    public static class BusinessRuleResult {
        private final double score;
        private final List<String> passedRules;
        private final List<String> failedRules;

        public BusinessRuleResult(double score, List<String> passedRules, List<String> failedRules) {
            this.score = score;
            this.passedRules = passedRules;
            this.failedRules = failedRules;
        }

        public double getScore() { return score; }
        public List<String> getPassedRules() { return passedRules; }
        public List<String> getFailedRules() { return failedRules; }
    }

    public static class ContextualValidation {
        private final double score;
        private final List<String> contextFactors;

        public ContextualValidation(double score, List<String> contextFactors) {
            this.score = score;
            this.contextFactors = contextFactors;
        }

        public double getScore() { return score; }
        public List<String> getContextFactors() { return contextFactors; }
    }

    public static class SemiSupervisedResult {
        private final double falsePositiveProbability;
        private final String explanation;

        public SemiSupervisedResult(double falsePositiveProbability, String explanation) {
            this.falsePositiveProbability = falsePositiveProbability;
            this.explanation = explanation;
        }

        public double getFalsePositiveProbability() { return falsePositiveProbability; }
        public String getExplanation() { return explanation; }
    }
}