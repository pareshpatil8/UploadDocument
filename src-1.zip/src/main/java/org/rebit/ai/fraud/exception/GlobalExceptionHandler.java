package org.rebit.ai.fraud.exception;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(FraudDetectionException.class)
    public ResponseEntity<String> handleFraudDetection(FraudDetectionException ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
    }
}
