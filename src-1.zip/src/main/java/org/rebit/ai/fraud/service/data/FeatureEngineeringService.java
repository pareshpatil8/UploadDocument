package org.rebit.ai.fraud.service.data;

import org.rebit.ai.fraud.dto.FeatureVectorDTO;
import org.rebit.ai.fraud.dto.PaymentTransactionDTO;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class FeatureEngineeringService {

    /**
     * Example feature extraction for demonstration.
     * Extend this logic to add more domain features.
     */
    public FeatureVectorDTO extractFeatures(PaymentTransactionDTO tx) {
        Map<String, Double> features = new HashMap<>();
        features.put("amount", tx.getAmount());

        // Hash values of string attributes for anonymity and as categorical feature representations
        features.put("account_hash", (double) tx.getBeneficiaryAccount().hashCode());
        features.put("bank_hash", (double) tx.getBeneficiaryBank().hashCode());

        // Add more feature logic as needed...

        FeatureVectorDTO fv = new FeatureVectorDTO();
        fv.setFeatures(features);
        return fv;
    }

    public Map<String, Double> extractGovernmentSpecificFeatures(PaymentTransactionDTO tx) {
        Map<String, Double> features = new HashMap<>();

        // 1. Round amount detection (common in fraud schemes)
        double amount = tx.getAmount();
        features.put("is_round_amount", isRoundAmount(amount) ? 1.0 : 0.0);

        // 2. Payment fragmentation detection
        features.put("amount_log", Math.log10(Math.max(1.0, amount)));

        // 3. Entity type factors
        if (tx.getSourceEntity() != null) {
            // This would be better handled with a lookup to entity types
            if (tx.getSourceEntity().startsWith("C")) {
                // Central entity
                features.put("is_central", 1.0);
            } else {
                features.put("is_central", 0.0);
            }
        }

        // 4. Beneficiary account type features
        String beneficiaryAccount = tx.getBeneficiaryAccount();
        if (beneficiaryAccount != null) {
            // Personal vs. institutional account heuristic
            // Institutional accounts often have patterns like leading zeros, etc.
            boolean likelyInstitutional = beneficiaryAccount.matches("^0\\d+$") ||
                    beneficiaryAccount.length() > 12;
            features.put("is_institutional", likelyInstitutional ? 1.0 : 0.0);
        }

        // 5. Beneficiary name analysis
        String beneficiaryName = tx.getBeneficiaryName();
        if (beneficiaryName != null) {
            features.put("name_length", (double) beneficiaryName.length());
            features.put("has_title", containsTitle(beneficiaryName) ? 1.0 : 0.0);
            features.put("is_organization", isOrganization(beneficiaryName) ? 1.0 : 0.0);
        }

        return features;
    }

    /**
     * Helper method to determine if an amount is suspiciously "round"
     */
    private boolean isRoundAmount(double amount) {
        // Check if amount is a round number, which can be suspicious
        return amount % 1000 == 0 || amount % 500 == 0 ||
                amount % 100 == 0 || amount % 50 == 0;
    }

    private boolean containsTitle(String name) {
        String upperName = name.toUpperCase();
        return upperName.contains("DR.") || upperName.contains("MR.") ||
                upperName.contains("MRS.") || upperName.contains("MS.") ||
                upperName.contains("PROF.") || upperName.contains("SIR");
    }

    private boolean isOrganization(String name) {
        String upperName = name.toUpperCase();
        return upperName.contains("LTD") || upperName.contains("LIMITED") ||
                upperName.contains("CORP") || upperName.contains("INC") ||
                upperName.contains("SOCIETY") || upperName.contains("TRUST") ||
                upperName.contains("FOUNDATION") || upperName.contains("ASSOCIATION") ||
                upperName.contains("GOVERNMENT") || upperName.contains("OFFICE") ||
                upperName.contains("DEPARTMENT") || upperName.contains("MINISTRY");
    }
}
